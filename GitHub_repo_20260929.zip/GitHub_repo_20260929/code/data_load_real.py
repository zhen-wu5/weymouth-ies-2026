# -*- coding: utf-8 -*-
"""任务一：省级实测（气象重建）电负荷形状提取、完整性检查与合成形状对比

数据源：
  Y:\\科研\\电力数据集\\2015-2024年-中国31省-小时级-电力负荷曲线数据\\Data output.xlsx
  sheet '2019 load curve'：8761 行 x 32 列，首列 datetime 逐小时，31 省各一列，单位 GWh
  （该小时平均功率 GW）。出处：Yi et al. 2026, Scientific Data,
  DOI 10.1038/s41597-026-07327-8（气象变量重建数据集，非调度机构直接实测）。

归一化口径（一次定死）：
  - 典型日 = 全年日历平均日（每个小时对 365 天取平均）得到 24h 平均日曲线；
  - 形状归一化 = 除以该 24h 曲线的最大值（峰值归一，峰值 -> 1.0），
    与现有合成口径 data.elec_load_profile()（除以自身最大值）一致，
    峰值功率由模型参数 p_load_peak 单独给定（园区级 5 MW）。
  - 全年逐时曲线另存为均值归一（除以全年均值），供全年尺度使用。

输出（code_v3/results/）：
  load_gansu_2019_hourly.csv       甘肃全年逐时（GWh/h 原值 + 两种归一）
  load_jiangsu_2019_hourly.csv     江苏全年逐时（备用）
  load_typical_day_compare.csv     实测典型日 vs 合成典型日 24h 对照
  load_shape_compare_metrics.csv   定量对比指标
"""
import os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

XLSX = r'Y:\科研\电力数据集\2015-2024年-中国31省-小时级-电力负荷曲线数据\Data output.xlsx'
YEAR = 2019


# ---- 合成形状（从 code/data.py 复制口径，不 import code 包，避免触碰）----
def synthetic_elec_profile():
    t = np.arange(24)
    x = (0.55 + 0.30 * np.exp(-((t - 11) / 2.8) ** 2)
         + 0.42 * np.exp(-((t - 19) / 2.6) ** 2)
         + 0.12 * np.exp(-((t - 3) / 2.0) ** 2))
    return x / x.max()


def load_province_hourly(prov_key):
    """读取某省 2019 全年逐时负荷，返回 Series（GWh/h）与完整性诊断 dict"""
    df = pd.read_excel(XLSX, sheet_name=f'{YEAR} load curve')
    dtcol = df.columns[0]
    df = df.rename(columns={dtcol: 'ts', prov_key: 'load'})
    df['ts'] = pd.to_datetime(df['ts'])
    df = df.set_index('ts').sort_index()

    s = df['load'].astype(float)
    diag = {}
    diag['n_rows'] = int(len(s))
    full_idx = pd.date_range(f'{YEAR}-01-01 00:00', f'{YEAR}-12-31 23:00', freq='h')
    diag['n_expected'] = len(full_idx)  # 2019 非闰年 -> 8760
    diag['missing_hours'] = int(len(full_idx) - s.index.intersection(full_idx).size)
    diag['dup_index'] = int(s.index.duplicated().sum())
    diag['nan'] = int(s.isna().sum())
    diag['n_zero'] = int((s == 0).sum())
    diag['n_negative'] = int((s < 0).sum())
    # 突变检查：逐小时一阶差分超过 50% 现值（负荷曲线物理上不可能的跳变）
    d = s.diff().abs()
    diag['n_jump_gt50pct'] = int((d > 0.5 * s).sum())
    diag['min'] = float(s.min()); diag['max'] = float(s.max())
    diag['mean'] = float(s.mean())
    return s, diag


def typical_day(s):
    """日历平均日：每小时的 365 天均值 -> 24h 曲线 -> 峰值归一"""
    md = s.groupby(s.index.hour).mean()
    md.index.name = 'hour'
    return md, md / md.max()


def ramp_stats(shape_2d):
    """日内爬坡率分布：shape_2d (n_days, 24) 峰值归一曲线。
    爬坡率 = |Δ小时值| / 日峰值（与模型峰值定标口径一致）"""
    r = np.abs(np.diff(shape_2d, axis=1)).ravel()
    return dict(mean=float(r.mean()), p50=float(np.percentile(r, 50)),
                p95=float(np.percentile(r, 95)), max=float(r.max()))


def main():
    out_rows = []
    series = {}
    for prov, key in [('gansu', 'Gansu (甘肃)'), ('jiangsu', 'Jiangsu (江苏)')]:
        s, diag = load_province_hourly(key)
        series[prov] = s
        diag['province'] = prov
        out_rows.append(diag)
        md, tp = typical_day(s)
        mean_norm = s / s.mean()
        pd.DataFrame({'load_gwh': s, 'norm_mean': mean_norm, 'norm_peak': s / s.max()}
                     ).to_csv(os.path.join(RES, f'load_{prov}_{YEAR}_hourly.csv'),
                              encoding='utf-8-sig')
        print(f'[{prov}] diag: {diag}')

    # ---- 完整性诊断表 ----
    pd.DataFrame(out_rows).to_csv(os.path.join(RES, 'load_completeness_diag.csv'),
                                  index=False, encoding='utf-8-sig')

    # ---- 典型日对比（甘肃为主、江苏备用）----
    syn = pd.Series(synthetic_elec_profile(), index=range(24))
    rows = {}
    for prov in ['gansu', 'jiangsu']:
        s = series[prov]
        md, tp = typical_day(s)
        rows[prov] = {'typical_day_mean_gwh': md.values, 'typical_day_norm': tp.values}
    td = pd.DataFrame({
        'hour': range(24),
        'gansu_mean_gwh': rows['gansu']['typical_day_mean_gwh'],
        'gansu_norm_peak': rows['gansu']['typical_day_norm'],
        'jiangsu_norm_peak': rows['jiangsu']['typical_day_norm'],
        'synthetic_norm': syn.values,
    })
    td.to_csv(os.path.join(RES, 'load_typical_day_compare.csv'),
              index=False, encoding='utf-8-sig')

    # ---- 定量指标 ----
    g = series['gansu']; j = series['jiangsu']
    g_tp = td['gansu_norm_peak'].values; j_tp = td['jiangsu_norm_peak'].values
    synv = syn.values

    def pearson(a, b):
        a = np.asarray(a, float); b = np.asarray(b, float)
        return float(np.corrcoef(a, b)[0, 1])

    metrics = {
        'corr_typicalday_gansu_vs_syn': pearson(g_tp, synv),
        'corr_typicalday_jiangsu_vs_syn': pearson(j_tp, synv),
        # 全年逐时实测 vs 合成典型日平铺 365 天：衡量合成典型日对全年的代表性
        'corr_annual_gansu_vs_syn_tiled': pearson(
            (g / g.max()).values, np.tile(synv, len(g) // 24)),
        'corr_annual_jiangsu_vs_syn_tiled': pearson(
            (j / j.max()).values, np.tile(synv, len(j) // 24)),
        'peak_hour_syn': int(np.argmax(synv)),
        'valley_hour_syn': int(np.argmin(synv)),
        'peak_hour_gansu_typical': int(np.argmax(g_tp)),
        'valley_hour_gansu_typical': int(np.argmin(g_tp)),
        'peak_hour_jiangsu_typical': int(np.argmax(j_tp)),
        'valley_hour_jiangsu_typical': int(np.argmin(j_tp)),
    }
    # 峰谷时段：电负荷常用定义（晚峰 18-22 时段均值占比）
    for name, v in [('syn', synv), ('gansu', g_tp), ('jiangsu', j_tp)]:
        metrics[f'evening_peak_share_{name}'] = float(v[18:22].mean())

    # 日间变异系数：日峰功率的 CV、日电量的 CV（全年 365 天）
    for name, s in [('gansu', g), ('jiangsu', j)]:
        daily_peak = s.resample('D').max()
        daily_energy = s.resample('D').sum()
        metrics[f'cv_daily_peak_{name}'] = float(daily_peak.std() / daily_peak.mean())
        metrics[f'cv_daily_energy_{name}'] = float(daily_energy.std() / daily_energy.mean())
    # 合成形状的日间变异 = 0（单一典型日）
    metrics['cv_daily_peak_synthetic'] = 0.0

    # 日内爬坡率分布：全年逐日（峰值归一）vs 合成单日
    for name, s in [('gansu', g), ('jiangsu', j)]:
        arr = (s / s.max()).values.reshape(-1, 24)
        rs = ramp_stats(arr)
        for k, v in rs.items():
            metrics[f'ramp_{k}_{name}'] = v
    rs = ramp_stats(synv.reshape(1, 24))
    for k, v in rs.items():
        metrics[f'ramp_{k}_synthetic'] = v

    m = pd.DataFrame({'metric': list(metrics), 'value': list(metrics.values())})
    m.to_csv(os.path.join(RES, 'load_shape_compare_metrics.csv'),
             index=False, encoding='utf-8-sig')
    print(m.to_string(index=False))

    # ---- Power coefficients（供热/制冷功率系数）提取 ----
    pc = pd.read_excel(XLSX, sheet_name='Power coefficients', header=None)
    # 左半 heating（列0省名，列1-10 为 2015-2024），右半 cooling（列12省名，13-22）
    provs = pc.iloc[2:33, 0].str.strip().str.replace(r'\s*\(.*\)', '', regex=True)
    years = [str(int(float(x))) for x in pc.iloc[1, 1:11]]
    heat = pc.iloc[2:33, 1:11].astype(float)
    heat.columns = years; heat.insert(0, 'province', provs.values)
    provs2 = pc.iloc[2:33, 12].str.strip().str.replace(r'\s*\(.*\)', '', regex=True)
    cool = pc.iloc[2:33, 13:23].astype(float)
    cool.columns = years; cool.insert(0, 'province', provs2.values)
    heat.to_csv(os.path.join(RES, 'power_coefficients_heating.csv'),
                index=False, encoding='utf-8-sig')
    cool.to_csv(os.path.join(RES, 'power_coefficients_cooling.csv'),
                index=False, encoding='utf-8-sig')
    print('\nHeating power coefficients 2019 (GWh/°C/Day) for Gansu/Jiangsu:')
    sel = heat.loc[heat.province.isin(['Gansu', 'Jiangsu']), ['province', '2019']]
    print(sel.to_string(index=False))
    sel.to_csv(os.path.join(RES, 'power_coeff_heating_gansu_jiangsu_2019.csv'),
               index=False, encoding='utf-8-sig')


if __name__ == '__main__':
    main()
