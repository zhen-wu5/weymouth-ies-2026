# -*- coding: utf-8 -*-
"""轮20 补算：三条"只算过成本、没算过碳下限"的轴，用主链同一套协议补齐。

为什么要这个脚本（对应全文审查 B1 / B3 / D1）：
  1. B1 —— 标题把 27.361 tCO2/day 记在"a linear gas cap"名下，但存档里静态线 cap 臂
     （pwl_recheck 的 PWL_E28_*）只有成本字段、零条碳字段。不把它自己的碳下限算出来，
     标题承诺量化的那个量就没有证据。
  2. B3 —— K、A、20 bar 压力下限是"让气网必然咬住"的三个常数；四条带宽轴、方法对方法
     基线臂、网状复现臂一个都没动过它们。
  3. D1 —— paironly / shapeonly 两臂的 70 bar 上浮（6.2468%）落在声明的 certified 下限
     6.77% 之外。本脚本不重跑它们（存档即权威），只把锚点跑到能引用它们的程度上。

口径纪律：
  - 每档独立进程：V3_ARM / E_GRID_MODE 是模块级环境变量，同进程改不掉。
  - 只算"最小期望碳排 RP"：mode='carbon'、allow_shed=False、risk_lambda=0，
    MIPGap/TimeLimit 取 config_v3 默认 —— 与 gc_run_v3.py 第 138 行逐字同参。
  - 上浮分母一律是"同口径无气网下限"，与 V3_BAND_summary.csv 的 formula 列一致。
  - 三个锚点不过就整批作废：
      A1 gas_cap=None, mode='carbon'   == 存档 B0 main carbon_min_exp_rp
      A2 gas_cap=F_EQ(70), mode='cost' == 存档 PWL_E28 linear_rp_exp_cost(ps=70)
      A3 默认 K/A/pd_min, ps=70        == 存档 PS70 main carbon_min_exp_rp

输出：results/V3_AXIS5_scan.csv（新文件；不追加进 V3_BAND_scan.csv，免得动既有审计口径）。
"""
import argparse
import csv
import io
import json
import math
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
AXIS5 = os.path.join(RES, 'V3_AXIS5_scan.csv')
sys.path.insert(0, HERE)

K_DEF = 0.00383      # MW^2/bar^2，model_gc_v3.solve_gc 默认
A_DEF = 0.075        # MWh/bar
PD_DEF = 20.0        # bar

ANCHOR_UNCOUPLED = 'ANCHOR_uncoupled_carbon'
ANCHOR_LIN_COST = 'ANCHOR_linearcap_cost70'
ANCHOR_BASE = 'BASE_PS70_default'


def f_eq(ps, K=K_DEF, pd_min=PD_DEF):
    return math.sqrt(K * (float(ps) ** 2 - pd_min ** 2))


# ------------------------------------------------------------------ 存档
def _kv(path, key='metric'):
    with io.open(path, 'r', encoding='utf-8-sig', newline='') as f:
        return {r[key]: r['value'] for r in csv.DictReader(f)}


def archived_floor(arm, cfg):
    return float(_kv(os.path.join(RES, 'V3_GC_%s_%s_summary.csv' % (cfg, arm)))
                 ['carbon_min_exp_rp'])


def archived_linear_cost(ps):
    with io.open(os.path.join(RES, 'PWL_E28_summary.csv'), 'r',
                 encoding='utf-8-sig', newline='') as f:
        for r in csv.DictReader(f):
            if r['item'] == 'linear_rp_exp_cost' \
                    and abs(float(r['ps']) - float(ps)) < 1e-6:
                return float(r['value'])
    raise KeyError('PWL_E28_summary.csv 无 ps=%s 的 linear_rp_exp_cost' % ps)


# ------------------------------------------------------------------ 单元
def cells():
    """(cell_id, axis, arm, ef_mode, spec)。spec.kind: uncoupled / linearcap_cost /
    gascap / coupled。coupled 可带 K / A / pd_min 覆盖。"""
    out = [
        (ANCHOR_UNCOUPLED, 'anchor', 'main', 'official_om_nw', dict(kind='uncoupled')),
        (ANCHOR_LIN_COST, 'anchor', 'main', 'official_om_nw',
         dict(kind='linearcap_cost', ps=70)),
        (ANCHOR_BASE, 'anchor', 'main', 'official_om_nw', dict(kind='coupled', ps=70)),
    ]
    for ps in (50, 60, 70):
        out.append(('GASCAP_PS%d' % ps, 'linear_gas_cap', 'main', 'official_om_nw',
                    dict(kind='gascap', ps=ps)))
    for tag, over in [
        ('K_x0.5', dict(K=K_DEF * 0.5)),
        ('K_x2.0', dict(K=K_DEF * 2.0)),
        ('A_x0.5', dict(A=A_DEF * 0.5)),
        ('A_x2.0', dict(A=A_DEF * 2.0)),
        ('pmin15bar', dict(pd_min=15.0)),
        ('pmin25bar', dict(pd_min=25.0)),
    ]:
        for ps in (50, 70):
            spec = dict(kind='coupled', ps=ps)
            spec.update(over)
            out.append(('%s_PS%d' % (tag, ps), 'gas_network_constants',
                        'main', 'official_om_nw', spec))
    # 基准档的 50 bar 一侧（与主链存档互为锚点：应等于 37.0566）
    out.append(('BASE_PS50_default', 'anchor', 'main', 'official_om_nw',
                dict(kind='coupled', ps=50)))
    # 数据溯源两臂（EF 0.55；B0 一侧直接引用存档）
    for arm in ('paironly', 'shapeonly'):
        for ps in (50, 70):
            out.append(('%s_PS%d' % (arm, ps), 'data_provenance', arm, 'old_0.55',
                        dict(kind='coupled', ps=ps)))
    return out


# ------------------------------------------------------------------ worker
def run_cell(spec):
    import data_v3 as DP
    import model_gc_v3 as MG
    import model_stoch_v3 as MS
    from model_mesh_v3 import status_name as sname

    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']
    kind = spec['kind']
    ps = float(spec.get('ps', 70))
    K, A, pdm = spec.get('K', K_DEF), spec.get('A', A_DEF), spec.get('pd_min', PD_DEF)
    cap = None if kind in ('uncoupled',) else f_eq(ps, K, pdm)
    t0 = time.time()

    if kind in ('uncoupled', 'gascap', 'linearcap_cost'):
        mode = 'cost' if kind == 'linearcap_cost' else 'carbon'
        sol = MS.solve_stoch(base, scenarios=reduced, mode=mode,
                             allow_shed=False, gas_cap=cap, risk_lambda=0.0)
        gas_model = 'none'
    else:
        sol = MG.solve_gc(base, scenarios=reduced, mode='carbon', allow_shed=False,
                          gas_coupled=True, ps=ps, ps2=ps, K1=K, K2=K, A1=A, A2=A,
                          pd_min=pdm, gas_model=DP.gas_model(), risk_lambda=0.0)
        gas_model = DP.gas_model()
    wall = time.time() - t0

    if sol is None:
        return dict(ok=False, floor=float('nan'), cost=float('nan'), status=-1,
                    status_name='NO_SOLUTION', gap_pct=float('nan'), wall=wall,
                    deliverability=cap, K=K, A=A, pd_min=pdm, gas_model=gas_model,
                    n_vars='', n_cons='')
    return dict(ok=True,
                floor=float(sol['exp_carbon']),
                cost=float(sol.get('exp_cost', float('nan'))),
                status=int(sol['status']),
                status_name=sname(int(sol['status'])),
                gap_pct=100.0 * float(sol.get('mip_gap', float('nan'))),
                wall=wall, deliverability=cap, K=K, A=A, pd_min=pdm,
                gas_model=gas_model,
                n_vars=sol.get('n_vars', ''), n_cons=sol.get('n_cons', ''))


def worker(cell_id):
    import config_v3 as C
    for cid, axis, arm, ef, spec in cells():
        if cid != cell_id:
            continue
        r = run_cell(spec)
        r.update(cell_id=cid, axis=axis, arm=arm, ef_mode=ef,
                 e_grid=float(C.get_e_grid(ef)))
        print('AXIS5_JSON' + json.dumps(r, ensure_ascii=False))
        return 0
    print('unknown cell %s' % cell_id, file=sys.stderr)
    return 2


# ------------------------------------------------------------------ driver
COLS = ['cell_id', 'axis', 'arm', 'ef_mode', 'e_grid_tCO2_per_MWh', 'gas_model',
        'ps_bar', 'K_MW2_per_bar2', 'A_MWh_per_bar', 'p_min_bar',
        'deliverability_MW_th', 'floor_tCO2_per_day', 'floor_kind',
        'exp_cost_CNY_per_day', 'status', 'status_name', 'gap_pct', 'wall_s',
        'n_vars', 'n_cons', 'uncoupled_floor_tCO2_per_day', 'uplift_pct_vs_uncoupled',
        'cell_pair', 'lever_pct_50to70', 'lever_kind',
        'formula', 'source_files']


def driver():
    cl = cells()
    got = {}
    for cid, axis, arm, ef, spec in cl:
        env = dict(os.environ, V3_ARM=arm, E_GRID_MODE=ef,
                   PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
        print('--- %s (arm=%s ef=%s %s)' % (cid, arm, ef, spec), flush=True)
        p = subprocess.run([sys.executable, '-B', os.path.abspath(__file__),
                            '--cell', cid], env=env, cwd=HERE,
                           capture_output=True, text=True, encoding='utf-8')
        line = next((l for l in (p.stdout or '').splitlines()
                     if l.startswith('AXIS5_JSON')), None)
        if line is None:
            print('    FAILED rc=%s\n%s\n%s'
                  % (p.returncode, (p.stdout or '')[-600:], (p.stderr or '')[-1500:]),
                  flush=True)
            return 1
        r = json.loads(line[len('AXIS5_JSON'):])
        got[cid] = r
        print('    floor=%.4f cost=%s status=%s gap=%.3f%% wall=%.1fs'
              % (r['floor'], r['cost'], r['status_name'], r['gap_pct'], r['wall']),
              flush=True)

    # ---------------- 锚点：不吻合整批作废 ----------------
    ref = {ANCHOR_UNCOUPLED: archived_floor('main', 'B0'),
           ANCHOR_BASE: archived_floor('main', 'PS70'),
           'BASE_PS50_default': archived_floor('main', 'PS50'),
           ANCHOR_LIN_COST: archived_linear_cost(70)}
    bad = 0
    for cid, want in ref.items():
        have = got[cid]['cost'] if cid == ANCHOR_LIN_COST else got[cid]['floor']
        rel = abs(have - want) / max(abs(want), 1e-9)
        print('anchor %-24s mine=%14.6f archive=%14.6f reldiff=%.2e'
              % (cid, have, want, rel))
        if rel > 1e-6:
            bad += 1
    if bad:
        print('!! %d 个锚点不吻合，整批作废，不写文件' % bad)
        return 3

    # ---------------- 派生 + 落盘 ----------------
    def _kind(st):
        """2=OPTIMAL 才是点值；-1 是本脚本对"无解"的编码，既非点也非界。"""
        return 'point' if st == 2 else ('infeasible' if st == -1 else 'bound')

    def prefix(cid):
        return cid.rsplit('_PS', 1)[0]

    pair_floor = {}
    for cid, axis, arm, ef, spec in cl:
        if axis == 'anchor':
            continue
        pair_floor.setdefault((axis, arm, prefix(cid)), {})[int(spec['ps'])] = (
            got[cid]['floor'], _kind(got[cid]['status']))

    rows = []
    for cid, axis, arm, ef, spec in cl:
        if axis == 'anchor':
            continue
        g = got[cid]
        b0 = archived_floor(arm, 'B0')
        up = 100.0 * (g['floor'] - b0) / b0
        pf = pair_floor[(axis, arm, prefix(cid))]
        lev = lev_kind = ''
        if 50 in pf and 70 in pf:
            f50, k50 = pf[50]
            f70, k70 = pf[70]
            lev = 100.0 * (f50 - f70) / f50
            lev_kind = 'point' if (k50 == 'point' and k70 == 'point') else 'bound'
        rows.append(dict(
            cell_id=cid, axis=axis, arm=arm, ef_mode=ef,
            e_grid_tCO2_per_MWh=g['e_grid'], gas_model=g['gas_model'],
            ps_bar=spec['ps'], K_MW2_per_bar2=g['K'], A_MWh_per_bar=g['A'],
            p_min_bar=g['pd_min'], deliverability_MW_th=g['deliverability'],
            floor_tCO2_per_day=g['floor'],
            floor_kind=_kind(g['status']),
            exp_cost_CNY_per_day=g['cost'],
            status=g['status'], status_name=g['status_name'],
            gap_pct=g['gap_pct'], wall_s=round(g['wall'], 3),
            n_vars=g['n_vars'], n_cons=g['n_cons'],
            uncoupled_floor_tCO2_per_day=b0, uplift_pct_vs_uncoupled=up,
            cell_pair=prefix(cid), lever_pct_50to70=lev, lever_kind=lev_kind,
            formula='uplift=(C(cell)-C(B0 same arm, same EF))/C(B0)*100; '
                    'lever=(C(50)-C(70))/C(50); B0 from archive',
            source_files='axis_scan_v3.py; V3_GC_B0_%s_summary.csv' % arm,
        ))

    with io.open(AXIS5, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in COLS})
    print('\nwrote %s (%d rows)' % (AXIS5, len(rows)))
    for r in rows:
        print('  %-16s %-24s ps=%-3s cap=%7.4f MW floor=%9.4f uplift=%9.4f%% %s'
              % (r['cell_id'], r['axis'], r['ps_bar'], r['deliverability_MW_th'],
                 r['floor_tCO2_per_day'], r['uplift_pct_vs_uncoupled'],
                 r['status_name']))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cell')
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    if a.list:
        for c in cells():
            print('%-24s %-24s %-10s %-16s %s' % (c[0], c[1], c[2], c[3], c[4]))
        return 0
    if a.cell:
        return worker(a.cell)
    if a.all:
        return driver()
    ap.print_help()
    return 1


if __name__ == '__main__':
    sys.exit(main())
