# -*- coding: utf-8 -*-
"""Compare the headline lever numbers under synthetic vs measured heat.

The manuscript's three carbon-side claims (source-pressure lever, coupling
penalty, uncoupled carbon floor) were all produced with a synthetic heat curve.
This reads the archived scan and answers the only question that matters for the
declared limitation: do those claims survive when the heat side is measured?

It also counts the out-of-sample days on which a fixed commitment could not be
re-dispatched at all, because that is new information the synthetic arm could
not produce -- a day-invariant load never breaks a commitment it was trained on.

Usage: python compare_heatreal.py
"""
import csv
import io
import os
import sys

sys.stdout.reconfigure(errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

ARMS = ('main', 'heatreal')


def scan():
    out = {a: {} for a in ARMS}
    with io.open(os.path.join(RES, 'V3_GC_scan_carbon.csv'), encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            if r.get('arm') in out:
                try:
                    out[r['arm']][r['cfg']] = float(r['carbon_min_exp_rp'])
                except (TypeError, ValueError):
                    pass
    return out


def oos_failures(arm):
    """Count NaN (unsolvable) test days in the u_fix re-dispatch per config."""
    res = {}
    for cfg in ('B0', 'PS50', 'PS60', 'PS70'):
        p = os.path.join(RES, 'V3_GC_%s_%s_oos.csv' % (cfg, arm))
        if not os.path.exists(p):
            continue
        with io.open(p, encoding='utf-8-sig') as fh:
            rows = list(csv.DictReader(fh))
        bad = sum(1 for r in rows
                  if any((r.get(c) or '').strip().lower() in ('nan', '')
                         for c in ('cost_eev', 'cost_sp') if c in r))
        res[cfg] = (bad, len(rows))
    return res


s = scan()
print('%-34s %12s %12s' % ('quantity', 'main (synth)', 'heatreal'))


def row(label, fn):
    vals = []
    for a in ARMS:
        try:
            vals.append(fn(s[a]))
        except (KeyError, TypeError, ZeroDivisionError):
            vals.append(None)
    print('%-34s %12s %12s' % (
        label,
        'n/a' if vals[0] is None else ('%.3f' % vals[0]),
        'n/a' if vals[1] is None else ('%.3f' % vals[1])))


row('carbon floor, uncoupled B0', lambda d: d.get('B0'))
row('carbon floor, ps=50', lambda d: d.get('PS50'))
row('carbon floor, ps=60', lambda d: d.get('PS60'))
row('carbon floor, ps=70', lambda d: d.get('PS70'))
row('lever 50->70 (%)', lambda d: (d['PS50'] - d['PS70']) / d['PS50'] * 100)
row('coupling penalty @70 (%)', lambda d: (d['PS70'] - d['B0']) / d['B0'] * 100)
row('coupling penalty @50 (%)', lambda d: (d['PS50'] - d['B0']) / d['B0'] * 100)

print('\nout-of-sample days whose fixed commitment could NOT be re-dispatched')
for a in ARMS:
    f = oos_failures(a)
    if not f:
        print('  %-9s (no oos files yet)' % a)
        continue
    print('  %-9s %s' % (a, '  '.join('%s: %d/%d' % (c, f[c][0], f[c][1])
                                      for c in ('B0', 'PS50', 'PS60', 'PS70')
                                      if c in f)))
