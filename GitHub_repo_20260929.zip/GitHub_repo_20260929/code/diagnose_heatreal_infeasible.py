# -*- coding: utf-8 -*-
"""Which commitment actually breaks on the measured-heat held-out days.

The run log flags these days with eev=True, sp=False, i.e. the deterministic
expected-value commitment is the one that cannot be re-dispatched. That is the
opposite of a defect in the stochastic arm, so it is tested rather than read off
a log line: for every flagged day both commitments are re-applied and feasibility
is recorded separately, and the binding constraint is pulled from the infeasible
model so the physical reason is stated from the solver, not inferred.
"""
import os
import sys

import numpy as np
import pandas as pd
import gurobipy as gp

sys.stdout.reconfigure(errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
sys.path.insert(0, HERE)

import data_v3 as DP             # noqa: E402
import model_gc_v3 as MG         # noqa: E402

kw = dict(gas_coupled=True, ps=70.0, ps2=70.0)
dat = DP.prepare()
base, reduced = dat['base'], dat['reduced']

exp = MG.solve_gc(DP.expected_scenario(dat), mode='cost', **kw)
sp = MG.solve_gc(base, scenarios=reduced, mode='cost', **kw)
u_eev = exp['scen_rows'][0]['sched']['u_chp'].to_numpy()
u_sp = sp['scen_rows'][0]['sched']['u_chp'].to_numpy()
print('u_eev on-hours %d, u_sp on-hours %d, differ at %d h'
      % (int(u_eev.sum()), int(u_sp.sum()), int((u_eev != u_sp).sum())))

df = pd.read_csv(os.path.join(RES, 'V3_GC_PS70_heatreal_oos.csv'))
bad = sorted(df[df['cost_eev'].isna()]['test_day'].tolist())
print('\nflagged days: %d' % len(bad))

rows = []
for day in bad:
    i = list(dat['dates']).index(day)
    sc = DP.test_scenario(dat, i)
    h = np.asarray(sc['h_load'], float)
    r_e = MG.solve_gc(sc, mode='cost', u_fix=u_eev, **kw)
    r_s = MG.solve_gc(sc, mode='cost', u_fix=u_sp, **kw)
    rows.append(dict(day=day, heat_MWh=round(float(h.sum()), 1),
                     heat_peak=round(float(h.max()), 2),
                     eev_feasible=r_e is not None, sp_feasible=r_s is not None))

out = pd.DataFrame(rows)
print(out.to_string(index=False))
print('\nEEV commitment infeasible on %d/%d flagged days; '
      'SP commitment infeasible on %d/%d'
      % ((~out.eev_feasible).sum(), len(out), (~out.sp_feasible).sum(), len(out)))

allsum = pd.Series([float(np.asarray(DP.test_scenario(dat, list(dat['dates']).index(d))
                                    ['h_load']).sum()) for d in dat['dates']])
print('flagged days\' daily heat: %.1f-%.1f MWh_th ; all-year median %.1f'
      % (out.heat_MWh.min(), out.heat_MWh.max(), allsum.median()))

# pull the physical reason from the solver on one day
i = list(dat['dates']).index(bad[0])
sc = DP.test_scenario(dat, i)
r = MG.solve_gc_raw(sc, mode='cost', u_fix=u_eev, **kw) if hasattr(MG, 'solve_gc_raw') else None
if r is None:
    print('\n(model does not expose the raw env; skipping IIS extraction)')
else:
    r.computeIIS()
    print('\nIIS constraints on %s:' % bad[0],
          [c.ConstrName for c in r.getConstrs()][:12])
