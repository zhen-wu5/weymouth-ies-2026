# -*- coding: utf-8 -*-
"""BOOT 系列：v3 主臂的 bootstrap 显著性（code_v2 E27 的 v3 对应物）。

数据源：code_v3/results/V3_GC_B0_main_oos.csv 与 V3_GC_PS70_main_oos.csv 的逐日
cost_eev / cost_sp（gc_run_v3 协议产出的 100 个样本外测试日）。
本脚本不重解任何 MIP——逐日成本直接取自已发布的 OOS 文件，并与
V3_GC_<cfg>_main_summary.csv 的 vss_eev_minus_sp 交叉核对（不一致即停止）。

协议：
  - 配对 bootstrap：同一天的两日成本同时重抽样（保留 EEV 与 SP 的逐日相关性），
    B = 2000 次，rng seed = 2026（与 E27 同源）。
  - 统计量：VSS（元/日）= mean(EEV) − mean(SP)；VSS 占比（%）= 100·VSS/mean(EEV)。
  - 95% CI：bootstrap 分布的 2.5%/97.5% 百分位。
  - 配对检验：Wilcoxon 符号秩检验（双侧，n=100）与配对 bootstrap 检验
    （B = 10000，双侧，H0: 逐日差均值 = 0，seed = 7，与 E27 同约定）。

!!!! 列名约定（消歧，防误读 —— E27_bootstrap.csv 的教训）!!!!
  - bootmean_eev / bootmean_sp 行：bootstrap 重抽样分布的均值及其 CI——它们描述
    "重抽样分布"，不是样本外期望成本，正文禁止引用（E27 的 mean_EEV/mean_SC 即此类，
    曾被误读为样本外期望）；
  - vss_cny / vss_pct 行：VSS 的 bootstrap 分布统计（均值/CI/标准差）；
  - POINT_* 行：真实 100 测试日上的点估计（样本外期望成本）——正文只允许引用
    POINT_* 行。

用法：
  Y:/cuda/python.exe boot_v3.py

输出（code_v3/results/）：
  BOOT_B0_v3.csv / BOOT_PS70_v3.csv      每配置的 bootstrap 统计
  BOOT_significance_v3.csv               配对显著性检验（两配置合并）
"""
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

NB = 2000          # CI 重抽样次数（任务口径）
NP_BOOT_P = 10000  # bootstrap 检验 p 值重抽样次数（p 分辨率 1e-4）
SEED_CI = 2026
SEED_P = 7
CFGS = ('B0', 'PS70')


def _cvar95(x):
    """与论文/审计一致的 CVaR95 约定：降序前 ceil(0.05N) 个的均值（浮点安全）"""
    x = np.asarray(x, float)
    n = max(1, int(np.ceil(0.05 * len(x) - 1e-9)))
    return float(np.sort(x)[-n:].mean())


def boot_p(d, B=NP_BOOT_P, seed=SEED_P):
    """配对 bootstrap 双尾 p 值（H0: 均值差为 0；与 E27 同约定，下限 1/B）"""
    rng = np.random.default_rng(seed)
    d = np.asarray(d, float)
    n = len(d)
    obs = d.mean()
    boot = np.array([d[rng.integers(0, n, n)].mean() for _ in range(B)])
    return float(min(1.0, max((np.abs(boot - obs) >= abs(obs)).mean(), 1.0 / B)))


def run_cfg(cfg):
    oos = pd.read_csv(os.path.join(RES, f'V3_GC_{cfg}_main_oos.csv'))
    ok = oos.dropna(subset=['cost_eev', 'cost_sp'])
    n = len(ok)
    assert n == 100, f'{cfg}: 测试日数 {n} != 100'
    ce = ok['cost_eev'].to_numpy(float)
    cs = ok['cost_sp'].to_numpy(float)
    d = ce - cs

    # 与 summary 交叉核对（防口径漂移）
    summ = pd.read_csv(os.path.join(RES, f'V3_GC_{cfg}_main_summary.csv'))
    vss_sum = float(summ.loc[summ['metric'] == 'vss_eev_minus_sp', 'value'].iloc[0])
    vss_pt = float(ce.mean() - cs.mean())
    rel = abs(vss_pt - vss_sum) / abs(vss_sum)
    assert rel < 1e-9, f'{cfg}: OOS 文件 VSS {vss_pt} 与 summary {vss_sum} 不一致 (rel {rel:.2e})'

    # 配对 bootstrap
    rng = np.random.default_rng(SEED_CI)
    idx = rng.integers(0, n, (NB, n))
    bm_e = ce[idx].mean(axis=1)
    bm_s = cs[idx].mean(axis=1)
    b_vss = bm_e - bm_s
    b_pct = 100.0 * b_vss / bm_e

    def row(statistic, vals):
        vals = np.asarray(vals, float)
        return dict(statistic=statistic,
                    point=float(vals.mean()),
                    ci_lo=float(np.percentile(vals, 2.5)),
                    ci_hi=float(np.percentile(vals, 97.5)),
                    boot_sd=float(vals.std(ddof=1)),
                    n_boot=NB)

    rows = [
        row('bootmean_eev_cny[bootstrap 分布均值, 非样本外期望]', bm_e),
        row('bootmean_sp_cny[bootstrap 分布均值, 非样本外期望]', bm_s),
        row('vss_cny', b_vss),
        row('vss_pct_of_eev_mean', b_pct),
        dict(statistic='POINT_mean_eev_cny', point=float(ce.mean()),
             ci_lo=np.nan, ci_hi=np.nan, boot_sd=np.nan, n_boot=0),
        dict(statistic='POINT_mean_sp_cny', point=float(cs.mean()),
             ci_lo=np.nan, ci_hi=np.nan, boot_sd=np.nan, n_boot=0),
        dict(statistic='POINT_vss_cny', point=vss_pt,
             ci_lo=np.nan, ci_hi=np.nan, boot_sd=np.nan, n_boot=0),
        dict(statistic='POINT_vss_pct_of_eev_mean', point=100 * vss_pt / float(ce.mean()),
             ci_lo=np.nan, ci_hi=np.nan, boot_sd=np.nan, n_boot=0),
        dict(statistic='POINT_vss_cvar95_sp_minus_eev_cny',
             point=float(_cvar95(cs) - _cvar95(ce)),
             ci_lo=np.nan, ci_hi=np.nan, boot_sd=np.nan, n_boot=0),
    ]
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, f'BOOT_{cfg}_v3.csv'), index=False, encoding='utf-8-sig')

    # 配对显著性检验
    w = wilcoxon(d)
    bp = boot_p(d)
    sig = dict(cfg=cfg, n=n,
               vss_point_cny=vss_pt,
               vss_point_pct=100 * vss_pt / float(ce.mean()),
               vss_boot_mean_cny=float(b_vss.mean()),
               vss_boot_sd_cny=float(b_vss.std(ddof=1)),
               vss_ci_lo_cny=float(np.percentile(b_vss, 2.5)),
               vss_ci_hi_cny=float(np.percentile(b_vss, 97.5)),
               vss_pct_ci_lo=float(np.percentile(b_pct, 2.5)),
               vss_pct_ci_hi=float(np.percentile(b_pct, 97.5)),
               n_days_vss_positive=int((d > 0).sum()),
               wilcoxon_stat=float(w.statistic), wilcoxon_p=float(w.pvalue),
               boot_p=bp, boot_p_B=NP_BOOT_P,
               note='逐日差 = cost_eev - cost_sp；VSS>0 表示随机调度优于 EEV 确定性调度')
    print(f"[{cfg}] n={n} | VSS 点估计 {vss_pt:.2f} 元/日 ({100 * vss_pt / ce.mean():.2f}% of EEV) | "
          f"bootstrap 均值 {sig['vss_boot_mean_cny']:.2f} ± {sig['vss_boot_sd_cny']:.2f} | "
          f"95% CI [{sig['vss_ci_lo_cny']:.2f}, {sig['vss_ci_hi_cny']:.2f}] | "
          f"占比 CI [{sig['vss_pct_ci_lo']:.2f}%, {sig['vss_pct_ci_hi']:.2f}%]")
    print(f"[{cfg}] VSS>0 的测试日 {sig['n_days_vss_positive']}/100 | "
          f"Wilcoxon p={w.pvalue:.3g} | bootstrap p={bp:.3g} (B={NP_BOOT_P})")
    return sig


if __name__ == '__main__':
    sigs = [run_cfg(c) for c in CFGS]
    pd.DataFrame(sigs).to_csv(os.path.join(RES, 'BOOT_significance_v3.csv'),
                              index=False, encoding='utf-8-sig')
    print('  -> BOOT_B0_v3.csv / BOOT_PS70_v3.csv / BOOT_significance_v3.csv')
    print('done')
