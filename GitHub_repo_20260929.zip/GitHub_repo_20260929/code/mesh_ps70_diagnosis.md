# M_PS70「更高源压反而无解」根因诊断（Phase 1→5，superpowers:systematic-debugging 纪律）

> **⚠ 先读这条指路（补于修复轮 1 / I3）：本文件的"现场快照"已被统一口径取代。**
> 现行事实请读 `mesh_notes.md`（§7′、§7、§8 与判定表）和 `results/V3_MESH_verdict.csv`：
> ① `M_PS70` **并非无解**——下表"SolCount=0／无可行解"是旧的**搜索失败**措辞，已废止（R-B）；
>    统一「零流 MIP-start + `dir_mode=soc`」口径下 50/60/70 三格都有有限 incumbent 与 bound。
> ② 下表与正文里出现的 bound **37.731 是旧值**：统一口径重跑后
>    **L(50)=37.752、L(60)=35.237、L(70)=33.365**；incumbent 三格并列 **58.3076** 是零流锚定的
>    **上界，不是碳地板值**，不得进正文（旧判定表由它算出的 113.101% / 16.095× 亦已作废）。
> ③ 本文件**的诊断结论仍然成立并被引用**：不是模型缺陷、不是"更高压反而不可行"，全程状态码
>    为 9（TIME_LIMIT），从未被判 3（INFEASIBLE）；过期的只是被诊断的那组数字与状态措辞。

诊断对象：`code_v3/` 网状气网复现臂 `gaslib11_core_1src`（GasLib-11 单源核心）。
被诊断的现象（`results/V3_MESH_cells.csv`、`mesh_notes.md §7`）：

| cell | 冻结口径下的记录 |
|---|---|
| `M_B0`（无气网约束） | OPTIMAL，碳地板 27.361 |
| `M_PS50` | TIME_LIMIT，有 incumbent：碳地板 58.308 / 下界 37.731 / gap 35.3%，n_bin 840，反向流 0 |
| `M_PS70` | **SolCount=0，"无可行解"**（三次启发式 NoRel 150/120/SolutionLimit 均无解） |

**纪律遵守情况**：根因确认前未提出也未实施任何模型改动。本次只新增两份诊断脚本
（`mesh_feas_probe.py`、`mesh_ps_entry_map.py`）与 `results/V3_MESH_PROBE_*.csv`。
`model_mesh_v3.py` / `gc_run_mesh_v3.py` / `audit_v3.py` / 任何 tex / 上传三件套 /
`IEEE_Access_投稿前清单.md` / `文件索引.md` **一律未改动**；`V3_MESH_cells.csv` 等既有
结果文件**未被改写**；未建 commit。

诊断脚本（可复跑，命令行见各节）：
- `code_v3/mesh_feas_probe.py` —— 拦截 `gp.Model.optimize`，在**完全按原代码建好的模型**上
  做最小改动（钉锚点 / 放宽整数 / 注入 MIP Start / 换目标 / 换参数）后求解，取回 Gurobi
  原始状态码，再用哨兵异常中止调用方，因此建模与求解口径不被篡改。
- `code_v3/mesh_ps_entry_map.py` —— 穷举 p_s 进入模型的位置（约束系数与右端、二次约束、
  **PWL 断点集**、变量界与类型），按同名约束逐项比对 50→70 的变化方向。不靠人眼读码。

---

## 结论先说（TL;DR）

**不是模型缺陷，也不是"更高压反而不可行"。是求解器在 8 场景 × 24 h × 4 条可逆管段
（768 个方向二进制）的耦合下找不到那个可行整数量赋值组合——纯搜索失败，且失败与否
随随机种子与纯搜索参数漂移。** `M_PS70` 从头到尾 **没有任何一次被 Gurobi 判为不可行**
（状态码 9 = TIME_LIMIT，从未是 3 = INFEASIBLE）。四条互相独立的证据：

1. **MIP Start 被接受**：给 M_PS70 原模型（不添加任何约束、保留真实碳目标）注入解析可行点，
   Gurobi 打印 `Loaded user MIP start with objective 140.264`，**5 s** 即 incumbent 58.31，
   180 s 得下界 33.32。**同一份 M_PS50 也接受同一个起点，且复现存档 58.3076**。
2. **约束层可满足性判定**：把该解析点作为等式钉进模型后，剩余的纯可行性问题在
   p_s = 50/60/70/80 四档、`soc` 与 `binary` 两种方向线性化下**全部 OPTIMAL**，
   用时 0.017–0.055 s。
3. **"50 可行 / 70 不可行"这个二分不可复现**：换 `Seed` 后 **p_s=50 也会 240 s 无解**，
   而 **p_s=55 在另一个种子下 20.5 s 就有解**；只加两个纯搜索参数
   （`NoRelHeurTime=150, Heuristics=0.5`，即存档启发式臂）**p_s=60 就从无解翻为 175 s 有解**。
   命中率：50 → 3/4，55 → 1/4，70 → 0/4。
4. **单调性预期没有被违反**：穷举 p_s 进入模型的全部元素（soc 臂 73 项、pwl 臂 105 项
   随 p_s 变化的系数/右端/变量界/PWL 断点），**没有任何一项是收紧的**；
   根松弛值随 p_s 单调下降（35.362 @50 → 31.073 @70），与"可行域变大"一致。
   单场景下同一个网状模型 p_s=50/60/70/80 全部 4 s 出解 ⇒ 难度来自"8 场景 × 方向二进制"，
   不来自拓扑或 p_s。

真正的问题出在**口径表述**：`mesh_notes.md §7`、`V3_MESH_cells.csv` 与审计 N11 把它写成
"无可行解"，读者（包括本次任务书的作者）会把它读成"该模型不可行"，于是产生了
"更高压反而无解，与单调性矛盾"这个伪悖论。**这是记录口径缺陷，不是模型缺陷。**

**顺带一条可执行的收获**：`M_PS60` 这格（`mesh_notes §7` 记为"本轮未跑"）在存档启发式口径下
175 s 就能拿到首个可行解 ⇒ 它是**可跑的**；补上它才能真正推进结论二的次序判定（需要 ≥2 个
网状地板）。这属"求解预算/排期"层面的事，不涉及模型改动。

---

## Phase 1 · 事实核查

### 1.1 现象可复现，但"无可行解"这个词从一开始就用错了

`V3_MESH_PS70_floorretry.log` 原文：

```
[model_mesh] 无可行解: status=9 (TIME_LIMIT)
attempt: None
[model_mesh] 无可行解: status=9 (TIME_LIMIT)
attempt: None
PS70 STILL NO FEASIBLE
```

`model_mesh_v3.solve_mesh` 的判据是 `if m.SolCount == 0:` 就打印"无可行解"。
所以这句话的字面意思是"**这次求解没攒下解**"，而**不是**"这个模型没有可行解"。
Gurobi 从未宣告 INFEASIBLE。任务书里"更高压反而无解"的悖感来自把这行日志读成后者。

### 1.2 被 §7 表格掩盖的既有事实：p_s=50 也一样找不到解

`V3_MESH_cells_run.log` 显示 `M_PS50` 在 **`dir_mode=soc` 下求 RP 期望成本同样两次无解**：

```
================ CELL M_PS50 start 03:56:35 ... dir_mode=soc
[model_mesh] 无可行解: status=9 (TIME_LIMIT)
############ HEUR RUN start 04:39:31 ############  ... dir_mode=soc
[model_mesh] 无可行解: status=9 (TIME_LIMIT)
================ CELL M_PS50 start 05:35:46 ... dir_mode=soc
[model_mesh] 无可行解: status=9 (TIME_LIMIT)   <- RP 与 carbon 两侧都无解
```

最终入库的 M_PS50 RP 值来自 `dir_mode=binary`(pwl MILP) 臂。也就是说
**"8 场景网状臂在冻结 600 s 内找不到可行整数解"这件事在 p_s=50 就已经发生了**，
p_s=70 只是让它同时覆盖了两条臂。这已经把"p_s 是变量"这个前提削掉了一半。

### 1.3 记录缺陷 A：`model_mesh_v3._STATUS` 是旧表，与 Gurobi 13.0.3 不符

用 `GRB.*` 反查得到的实际常量：

| 码 | 表里写的 | Gurobi 13.0.3 实际 |
|---|---|---|
| 10 | MEMORY_LIMIT | **SOLUTION_LIMIT** |
| 11 | OBJ_LIMIT | INTERRUPTED |
| 14 | INFOUNBD | INPROGRESS |
| 15 | INTERRUPTED | USER_OBJ_LIMIT |
| 16 | INPROGRESS | WORK_LIMIT |
| 17 | UNKNOWN | MEM_LIMIT |

诊断中这次误读**真实发生过**：探针在 p_s=50 返回 status=10，按旧表被打印成
`MEMORY_LIMIT`（"内存不足"），差点被当成第 4 个根因假说；实际是
`SolutionLimit=1` 正常命中。`V3_MESH_PROBE_sol1_soc_carbon.csv` 里
`status_name=SOLUTION_LIMIT` 与 `status_name_modelapi=MEMORY_LIMIT` 两列并排留存了这个偏差。
**本条不影响 M_PS70 的结论**（9 = TIME_LIMIT 在旧表里恰好正确），但它是一条真实的、
会让后来者误判的记录缺陷。

### 1.4 记录缺陷 B（方法学）：常数目标是这台 MIQCP 的**无效**可行性探针

先按任务书做了"常数目标、只判有无可行解"的网格：

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp grid --ps 50,55,60,65,70,75,80 \
    --dir-mode soc --tl 120        # results/V3_MESH_PROBE_grid120_partial.csv
[grid] dir=soc ps=50.0 status=TIME_LIMIT SolCount=0 t=120.4s
[grid] dir=soc ps=55.0 status=TIME_LIMIT SolCount=0 t=120.4s
[grid] dir=soc ps=60.0 status=TIME_LIMIT SolCount=0 t=120.4s
[grid] dir=soc ps=65.0 status=TIME_LIMIT SolCount=0 t=120.3s
```

把时限放宽到 600 s，**p_s=50 同样 SolCount=0**
（`results/V3_MESH_PROBE_grid_soc600.log`：`ps=50.0 status=TIME_LIMIT SolCount=0 t=600.6s`）。

原因：`m.setObjective(0.0)` 把目标系数全部置零，Gurobi 的 NoRel 启发式要在"受限主问题"
上优化一个目标，c=0 时**没有任何搜索方向**；同理，把整数全部放宽后的 SOCP 走内点法，
零中心路径目标也会退化。所以这条曲线的"全档失败"是探针坏了，不是模型坏了。
=> 可行性探针改用 **保留真实目标 + `SolutionLimit=1 + MIPFocus=1`**
（求得第一个可行解即停，`Runtime` 即"首个可行解用时"），见 Phase 2.2。
常数目标只在"已经是纯 LP 的锚定实验"（Phase 2.1）里保留——那里没有整数、没有分支，
零目标不影响判定，实测 0.017 s 出解。

---

## Phase 2 · 结构不可行 vs 搜索困难（主判据）

### 2.1 锚定实验：解析可行点在**每一档 p_s、每一种方向线性化**下都成立

模型里存在一个可以手写的可行点（下称"零流点"）：

> 5 个节点压力全取上界 p_s（含 5 个一阶段共享初值 p_0）、门站调压阀关（f_gA = 0）、
> 压缩机出口等式管 f_CS01 = sqrt(K(p_s² − p_s²)) = 0、四条可逆联络管压差为 0 故 f = 0、
> 锥变量 wp = wm = dp = dm = 0、su = 2p_s、CHP 停机 u = 0 ⇒ g_chp = 0、GB 不出热 ⇒ g_gb = 0；
> 热负荷由电锅炉 2.0 MW + 热泵 2.0 MW 恰好覆盖日热峰 4.0 MW（`config_v3` EB/HP hmax 各 2.0），
> 电负荷全部由电网购电覆盖（`p_grid` 无上界），储能保持初值 soc0·cap。

把该点作为等式钉进原模型（960 个压力变量 + 5 个 p_0 + 768 个方向二进制 = 1、72 个 u = 0，
共 1757 条等式），剩余问题是纯可行性判定：

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp anchor --ps 50,60,70,80 \
    --dir-mode soc,binary --tl 45         # results/V3_MESH_PROBE_anchor.csv
[anchor] dir=soc     ps= 50.0 status=OPTIMAL  SolCount=1 t= 0.0s anchor=1757
[anchor] dir=soc     ps= 60.0 status=OPTIMAL  SolCount=1 t= 0.0s anchor=1757
[anchor] dir=soc     ps= 70.0 status=OPTIMAL  SolCount=1 t= 0.0s anchor=1757
[anchor] dir=soc     ps= 80.0 status=OPTIMAL  SolCount=1 t= 0.0s anchor=1757
[anchor] dir=binary  ps= 50.0 status=OPTIMAL  SolCount=1 t= 0.1s anchor=1757
[anchor] dir=binary  ps= 60.0 status=OPTIMAL  SolCount=1 t= 0.1s anchor=1757
[anchor] dir=binary  ps= 70.0 status=OPTIMAL  SolCount=1 t= 0.1s anchor=1757
[anchor] dir=binary  ps= 80.0 status=OPTIMAL  SolCount=1 t= 0.1s anchor=1757
```
实际 `m.Runtime` = 0.017 / 0.021 / 0.017 / 0.018 s（soc），0.054–0.056 s（binary）。
全程没有触发 `computeIIS`（status 从未为 3）。

**=> 约束层无缺陷。`M_PS70` 不是结构不可行。**

### 2.2 MIP Start 实验：不添加任何约束，直接证明 M_PS70 有可行解（最强证据）

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp start --mode carbon --allow-shed 0 \
    --ps 50,70 --dir-mode soc --tl 180 --verbose
# results/V3_MESH_PROBE_start.csv / .log
```

Gurobi 日志原文（关键行）：

```
ps=50:  Loaded user MIP start with objective 140.264
        Root relaxation: objective 3.536211e+01, 13718 iterations, 0.81 s
        Explored 679 nodes (758164 simplex iterations) in 180.11 s
        Solution count 10: 58.3076 58.3076 58.3076 ... 58.7222
        Best objective 5.830758591828e+01, best bound 3.768482981419e+01, gap 35.3689%

ps=70:  Loaded user MIP start with objective 140.264        <-- 起点被接受 = 可行解存在
        Found heuristic solution: objective 72.5730306        <-- presolve 期就另有可行解
        Root relaxation: objective 3.107330e+01, 11619 iterations, 0.91 s
        H  0  0   58.3075868  ...   32.23778  44.7%   5s      <-- 第 5 秒已有 incumbent
        Explored 1372 nodes (963905 simplex iterations) in 180.10 s
        Solution count 10: 58.3076 58.3076 58.3076 ... 72.573
        Best objective 5.830758532015e+01, best bound 3.331550064133e+01, gap 42.8625%
```

三点必须记下：

1. **`Loaded user MIP start`**：Gurobi 只在起点满足全部约束（含 1536 条锥约束与 384 条
   PWL 一般约束）时才这样打印；若违反会改打 `User MIP start did not produce a new incumbent
   ... violation ...`。所以 **M_PS70 的可行集非空，由求解器本身认证**。
2. **同一个起点（目标值 140.264，即全电零气的期望碳）在 50 与 70 都被接受** ——
   这正是"可行性与 p_s 无关"的直接实验证据。
3. **根松弛值随 p_s 单调下降**：35.362 @50 → 31.073 @70。p_s↑ 让松弛更优，方向正确，
   与"可行域放松"完全一致。
4. 交叉校验：本探针在 p_s=50 复现出 incumbent **58.307586**，与存档 `M_PS50`
   的 `carbon_min_exp_rp = 58.307586337605024` 吻合到相对 7e-9（两条臂的启发式路径不同，
   非同一顶点）；下界 37.685 @180 s vs 37.731 @600 s，随时长收紧，方向自洽。
   => 探针没有改变模型语义。

### 2.3 首个可行解用时的 p_s 曲线：只有 p_s=50 撞中，55–80 全灭

保留真实碳目标 + `SolutionLimit=1` + `MIPFocus=1`，冻结 600 s、8 场景、
`mode='carbon'`、`allow_shed=False`（与 M_PS70 失败那条臂同口径）：

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp sol1 --mode carbon --allow-shed 0 \
    --ps 50,55,60,65,70,75,80 --dir-mode soc --tl 600
```

| p_s | 状态码 | 状态（纠正表） | 旧表会写成 | SolCount | 首个可行解用时 / 时限 | 节点数 | 单纯形迭代 | 第一个 incumbent |
|---|---|---|---|---|---|---|---|---|
| 50 | 10 | SOLUTION_LIMIT | MEMORY_LIMIT（错） | 1 | **22.9 s** | 1 | 50 915 | 碳 108.95 |
| 55 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.2 s | 20029 | 2 965 722 | — |
| 60 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.2 s | 3511 | 1 203 922 | — |
| 65 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.3 s | 14929 | 2 414 634 | — |
| 70 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.3 s | 15789 | 2 775 728 | — |
| 75 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.5 s | 7243 | 1 491 510 | — |
| 80 | 9 | TIME_LIMIT | TIME_LIMIT | 0 | 600.4 s | 5051 | 2 114 025 | — |

（`results/V3_MESH_PROBE_sol1_soc_carbon.csv` / `.log`）

**这张表才是"反常"的真正形状**：不是"70 不行"，而是"**只有 50 行，55 到 80 六档全不行**"。
55/60/65 比 50 的可行域**更大**（Phase 3 证明），却在同一预算下全军覆没；
唯一在 50 成功的一次是**根节点上的一次舍入命中**（`H 0 0 ...`，节点数 = 1）。
"可行域更大反而找不到解"直接排除结构解释。§5.4 用换 Seed 的重复实验证明
**这张表本身也不可复现**。

### 2.4 连续松弛判定（附带发现：这一步的 soc 分支受 1.4 的退化影响，不能作数）

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp relax --mode carbon --allow-shed 0 \
    --ps 50,60,70,80 --dir-mode soc,binary --tl 90
[relax] dir=binary ps=50/60/70/80  status=OPTIMAL  SolCount=1  t=10.3~14.1s  relaxed=840
[relax] dir=soc    ps=50/60/70/80  status=TIME_LIMIT SolCount=0 t=90.3s      relaxed=840
```

`binary`(pwl) 臂：把 840 个整数（768 方向 + 72 承诺）全部放宽为连续后，四档**全部 OPTIMAL**
（10–14 s）=> **约束层在连续域可满足，且与 p_s 无关**。
`soc` 臂四档一律 TIME_LIMIT：**这是 1.4 记录过的探针退化**（常数目标 + 锥约束走内点法时
中心路径无定义），不是模型问题；同一模型在 2.1（钉锚点后的 LP/SOCP，0.017 s OPTIMAL）
和 2.2（注入起点，Loaded）下均已判定可满足。故本行的"soc 无解"**不计入证据**，
仅记录以免后来者误用。要拿干净的 SOCP 松弛判定，需要给 `relax` 换一个非退化目标（未做，
见"还缺哪一项证据"）。

---

## Phase 3 · p_s 进入模型的每一个位置（穷举，非人眼读码）

```
Y:/cuda/python.exe -B mesh_ps_entry_map.py --ps 50,70 --dir-mode soc,binary
# results/V3_MESH_PROBE_psentry_soc.csv (4657 项差异) / _binary.csv (4689 项)
```
抓两份完整快照（每条约束的名字 / 方向 / 右端 / 全部系数；每条二次约束；每条 PWL 的
断点集；每个变量基名的 lb/ub/类型），按**同名约束**逐项比对。约束名里不含 p_s，
所以凡随 p_s 改变的元素必然是 p_s 的进入点 —— 清单是穷举的，不会漏。

### 3.1 `dir_mode='soc'`（主判据）：p_s 的全部进入点

| # | 进入点 | 表达式 | p_s=50 | p_s=70 | p_s↑ 判定 |
|---|---|---|---|---|---|
| 1 | `dpu_<管>`（4×192=768 条） | `dp ≤ p_i−p_j + D·(1−y)`，D = p_s−20（既是系数也是右端） | 30 | 50 | **放松**（大 M 变大） |
| 2 | `dmu_<管>`（768 条） | `dm ≤ p_j−p_i + D·y`，y 系数 −D | −30 | −50 | **放松** |
| 3 | `wpy_<管>`（768 条） | `wp ≤ (f_max/√K)·y`，f_max/√K = √(p_s²−400) | 45.826 | 67.082 | **放松** |
| 4 | `wmy_<管>`（768 条） | `wm ≤ (f_max/√K)(1−y)` | 45.826 | 67.082 | **放松** |
| 5 | `p_<节点>[s,t]`（5×192=960 个） | `ub = p_s`（lb = 20 不变） | 50 | 70 | **放松** |
| 6 | `p0_<节点>`（5 个，一阶段共享） | `ub = p_s` | 50 | 70 | **放松** |
| 7 | `f_<联络管>`（4×192） | `[±√(K(p_s²−400))]` | ±2.836 | ±4.152 | **放松** |
| 8 | `f_gA` / `ub_gA` / `f_cCS01`（3×192） | `ub = √(K(p_s²−400))` | 2.836 | 4.152 | **放松** |
| 9 | `dp_*` / `dm_*`（8×192） | `ub = p_s−20` | 30 | 50 | **放松** |
| 10 | `su_*`（4×192） | `ub = 2p_s`（`lb = 2p_min = 40` 不变） | 100 | 140 | **放松** |
| 11 | `wp_*` / `wm_*`（8×192） | `ub = √(p_s²−400)` | 45.83 | 67.08 | **放松** |
| 12 | PWL 断点集（门站管 `p_entry03 → ub_gA`，192 条） | x ∈ [20, p_s]，y = √(K(p_s²−x²))，60 余弦点 | x_hi 50，y_max 2.836，末段斜率 −4.244 | x_hi 70，y_max 4.152，末段斜率 −3.890 | **放松**（域上端抬高、容量抬高、末段反而更平） |
| 13 | PWL 断点集（压缩机出口等式管 `p_N01 → f_cCS01`，192 条） | 同上，`pref = p_s2 = p_s` | 同上 | 同上 | **放松** |

**不随 p_s 变化的**（快照里零差异，写出来是为了排除嫌疑）：`su_* = p_i+p_j` 等式、
`dpl_*`/`dml_*`、`socf_*`/`socr_*` 两条锥约束（`QMatrix range [1,1]`，系数恒为 ±1）、
`sign_*`、全部 `mbal_*`（A = 0.075 恒定）、电热侧全部约束与目标系数、
`esscyc/hsscyc/cyc_*` 循环约束。**二次约束族没有任何一项随 p_s 改变**（差异表里
`quad-constr` 行数 = 0）。

去重后的条目总数：**soc 臂 73 项**（41 变量界 + 24 约束系数/右端 + 8 PWL 断点特征），
**pwl 臂 105 项**（41 + 24 + 40）。其中数值"变小"（direction=decrease）的共 12 / 16 项，
**逐条判读后全部仍是放松**，没有一项是收紧：

| 变小的条目 | 50 → 70 | 判读 |
|---|---|---|
| `dmu_*` 中 y 的系数（soc，4 组） | −30 → −50 | 约束是 `dm ≤ p_j−p_i + D·y`，写成标准形后 y 系数 = −D；−30→−50 即 **大 M 变大 ⇒ 放松** |
| `wpy_*` 中 y 的系数（soc，4 组） | −45.83 → −67.08 | 约束 `wp − M·y ≤ 0`，M = √(p_s²−400) 变大 ⇒ **放松** |
| `f_<联络管>` 的 lb（4 组） | −2.836 → −4.152 | 反向流量下界更负 ⇒ 区间变宽 ⇒ **放松** |
| （仅 pwl 臂）`abM_*`/`spM_*` 的 y 系数（8 组） | −4200→−9000、−2.836→−4.152 | 同前两行，大 M 变大 ⇒ **放松** |
| （仅 pwl 臂）√-PWL 末段斜率（4 组） | 6.75e-4 → 4.61e-4 | 只是逼近曲线末端更平，`y_max` 同时 2.836→4.152 ⇒ **不收紧任何点** |

⇒ **不存在任何一条随 p_s 收紧的约束、界或断点。**

### 3.2 `dir_mode='binary'`（pwl MILP，M_PS50 的 RP 值来自这条臂）额外进入点

`abP_*`/`abM_*` 的大 M = 2(p_s²−400)：4200 → **9000**；`spM_*`/`smM_*` 的 M = f_max：
2.836 → 4.152；变量界 `ab_*` → 4500、`pi2_*` → 4900、`s_/sp_/sm_` → 4.152；
以及 p² 的 PWL（x_hi 50→70，y_max 2500→4900）与 √ 的 PWL（x_hi 2100→4500，
y_max 2.836→4.152）。**同样全部是放松方向。**

### 3.3 专项排查（任务书点名的两类可疑写法）——均不存在

- **"把压力等式钉在 p_s"**：不存在。p_s 只出现在**上界**（`p ≤ p_s`、`p_0 ≤ p_s`）与
  **容量函数参数**（PWL 的 x 域上端与 y 值）中；差异表里没有任何 `p_* == p_s` 形式的等式，
  `mbal_*` 的系数与右端完全不随 p_s 变。
- **"与固定压比联立强制抬压"**：不存在。压缩机 `cCS01` 建模为**出口定压管**
  （`const_pipe(pref = p_s2 = p_s, equality=True)`，沿用 `model_gc_v3` 管道 2 的写法），
  代码里没有 `p_out = ratio·p_in` 这类压力关系；`comp_ratio = 0.02` 只作为**燃料率**进入
  守恒（`out_terms` 的 1.02 因子）与碳排（`comp_fuel`），不进入任何压力约束。
  因此压比与 p_s 完全解耦，不可能随 p_s 收紧。

### 3.4 有一条**结构特征**必须写清（不是缺陷，但解释了为什么容易翻车）

压缩机出口管是 `equality=True`（无节流自由度），`f_CS01 = PWL(p_N01)`，而
`PWL(p_s) = 0` **只在该 PWL 的最后一个断点取到**。所以"不用气"这个可行点在 p_N01 方向
**没有内点**——它是边界点/顶点，且要求 960 个压力变量同时精确落在各自上界上。
两节点链的管道 2 是同一写法（同样要求 `p_node2 = p_s2`，192 个变量），
所以这条"刀锋"在两节点臂里也存在、且回归闸门以 2.6e-05 通过，**它不是网状新引入的缺陷**；
网状只是把同时落在边界上的变量从 192 放大到 960，并把方向二进制从 0 放大到 768。

---

## Phase 4 · 大 M / 数值假设

数据源：`V3_MESH_PROBE_sol1_soc_carbon.csv`（nvars/nconstrs/nbin/mincoeff/maxcoeff/nnz）
与 `--verbose` 抓到的 Gurobi 自带系数统计（`V3_MESH_PROBE_start.log`、
`V3_MESH_PROBE_sol1_verbose.log`）。

| 量 | p_s=50 | p_s=70 | 判读 |
|---|---|---|---|
| nvars / nconstrs / nnz（soc，模型层） | 10061 / 10448 / 31455 | 10061 / 10448 / 31455 | 规模与 p_s **无关** |
| nbin（`NumBinVars`） | 840 | 840 | 72 机组承诺 + 768 方向二进制 |
| nqconstr | 1536 | 1536 | 4 管 × 192 × 2 锥 |
| ngconstr（PWL） | 384 | 384 | 2 条等式/阀管 × 192 |
| MinCoeff / MaxCoeff（LP 矩阵） | 0.061887 / 45.826 | 0.061887 / **67.082** | 极值比 7.4e2 → **1.1e3** |
| 同（pwl 臂） | 0.075 / 4200 | 0.075 / **9000** | 极值比 5.6e4 → **1.2e5** |
| Gurobi `Matrix range` | [6e-02, 5e+01] | [6e-02, 7e+01] | 无告警 |
| Gurobi `Bounds range` / `RHS range` | [1,1e2] / [2e-03,5e+01] | [1,1e2] / [2e-03,7e+01] | — |
| Gurobi `QMatrix range` | [1,1] | [1,1] | 锥约束系数不含 p_s |
| Gurobi `PWLCon x / y range` | [2e+01,5e+01] / [9e-02,3e+00] | [2e+01,7e+01] / [1e-01,4e+00] | — |
| presolve 后 | 9185 rows / 31277 cols / 97585 nnz / **384 SOS** / `838 integer (838 binary)` | 9192 rows / 31284 cols / 97634 nnz / 384 SOS / 838 binary | — |
| 数值告警 | 无（日志中无 NumericFocus 提升建议、无 coefficient range 警告、无 status=12 NUMERIC） | 无 | — |

回答任务书的两问：

1. **大 M 是否随 p_s 缩放？是。** SOC 臂用 D = p_s−20 与 √(p_s²−400)；pwl 臂用
   2(p_s²−400)（**二次增长**）。因此 p_s↑ 会同时削弱 LP 松弛并放大系数极值比 —— 这与
   Phase 2.3 里"p_s 越高越难"的**搜索**梯度方向一致（根节点 IntInf：@50 从 446 一路升到
   845–852，@70 首刻 434），但它**不切掉任何可行点**。
2. **`n_bin = 840` 有没有漏计？没有。** presolve 报 `838 integer (838 binary)`，
   与模型层 840 一致（2 个被固定/删除）。PWL 走的是 **SOS2**（`384 SOS constraint(s)`），
   presolve 为此多引入 21 408 个连续 λ 列（9869 → 31277 列），**不产生额外二进制**。
   所以"整数难"完全来自那 768 个方向二进制 + 72 个承诺二进制，口径可放心引用。
3. `Pool*` 类属性（`NumPoolDef` 等）在本模型上没有可比内容：这是"找不到第一个解"，
   不是"解池里全是松解"，故未作为判据；改用 `SolutionLimit=1` 直接测首个解用时。

---

## Phase 5 · 对照可用样本与重复实验（定位差异点）

### 5.1 两节点链在同一 p_s 网格上：每档都秒出可行解

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp sol1 --net chain --mode carbon --allow-shed 0 \
    --ps 50,60,70,80 --dir-mode soc --tl 300       # results/V3_MESH_PROBE_sol1_chain.csv
[sol1] net=chain ps=50 status=SOLUTION_LIMIT SolCount=2 t= 5.6s
[sol1] net=chain ps=60 status=SOLUTION_LIMIT SolCount=2 t= 2.9s
[sol1] net=chain ps=70 status=SOLUTION_LIMIT SolCount=2 t= 3.3s
[sol1] net=chain ps=80 status=SOLUTION_LIMIT SolCount=2 t= 1.6s
```
**链在 p_s=70 也 3.3 s 拿到可行解**，且用时随 p_s **下降**（1.6 s @80）——
与"更高压更难"完全相反。=> 难度不来自 p_s，而来自网状相对链**多出来的东西**。

### 5.2 单场景对照：网状在 p_s=70 也 4 s 出解

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp sol1 --scen single --mode carbon \
    --allow-shed 0 --ps 50,60,70,80 --dir-mode soc,binary --tl 300
soc    ps=50/60/70/80  SOLUTION_LIMIT  SolCount=1~2  t= 4.0~4.2s
binary ps=50/60/70/80  SOLUTION_LIMIT  SolCount=1    t= 1.6~3.3s
```

单场景（S=1，去掉 8 场景共享 p_0 的非预期性耦合）时，**同一个网状拓扑、同样 960→120 个
压力变量、768→96 个方向二进制，在 p_s=70 只用 4.1 s**；8 场景则 600 s 无解。
=> **差异点定位完成**：阻塞的不是拓扑、不是 p_s、不是锥编码的表示误差，
而是 **8 个场景 × 24 h × 4 条可逆管段 = 768 个方向二进制，加上跨场景共享的 p_0
（一阶段）把 8 份"必须同时落在边界上的压力"绑在一起**。

### 5.3 种子重复实验：**"50 可行 / 70 不可行"这个二分本身不可复现**

同口径（`--exp sol1`：真实碳目标 + `SolutionLimit=1 + MIPFocus=1`，8 场景，
`mode='carbon'`、`allow_shed=False`、`dir_mode=soc`），只改 `Gurobi Seed`：

```
for s in 1 2 3; do
  Y:/cuda/python.exe -B mesh_feas_probe.py --exp sol1 --mode carbon --allow-shed 0 \
      --ps 50,55,70 --dir-mode soc --tl 240 --seed $s \
      --out V3_MESH_PROBE_sol1_seed$s.csv
done                                          # results/V3_MESH_PROBE_batch2.log
```

| 配置 | p_s=50 | p_s=55 | p_s=70 |
|---|---|---|---|
| 默认种子，600 s | ✓ 22.9 s（首解碳 108.95，节点 1） | ✗ 600 s（20029 节点） | ✗ 600 s（15789 节点） |
| Seed 1，240 s | ✓ 24.7 s（110.05，节点 1） | **✓ 20.5 s**（112.46，节点 1） | ✗ 240 s（2836 节点） |
| Seed 2，240 s | ✓ 24.3 s（108.95，节点 1） | ✗ 240 s（2809 节点） | ✗ 240 s（2807 节点） |
| Seed 3，240 s | **✗ 240 s**（2848 节点） | ✗ 240 s（2858 节点） | ✗ 240 s（2859 节点） |
| 命中率 | 3 / 4 | **1 / 4** | 0 / 4 |

三条硬事实：

1. **换到 Seed 3，`p_s=50` 也找不到可行解**（240 s，SolCount=0）——
   所以"50 能求出来"不是模型的性质，是这一次运行的性质。
2. **换到 Seed 1，`p_s=55` 只用了 20.5 s 就找到可行解，比 `p_s=50` 的 22.9/24.7 s 还快**——
   "首解用时"在 p_s 上**不单调**。
3. 命中率确实随 p_s 下降（3/4 → 1/4 → 0/4），所以**存在一个真实的难度梯度**；
   但 240 s 的重复预算与 600 s 的默认预算不同，故梯度强度未被等预算充分估计
   （见"还缺哪一项证据"）。

结论：**"M_PS50 有 incumbent、M_PS70 无"落在一条概率性、种子依赖的命中/落空边界上，
而不是落在可行/不可行的边界上。**

### 5.4 存档启发式口径下的重复：p_s=60 与 p_s=50 **同样能命中**，p_s=70 落空

用 `mesh_arm_diag.py` 那套存档启发式参数（`NoRelHeurTime=150, MIPFocus=1, Heuristics=0.5`，
本次再加 `SolutionLimit=1` 以测首解用时）、同样的 8 场景 / 600 s / `carbon` / `allow_shed=0`：

```
Y:/cuda/python.exe -B mesh_feas_probe.py --exp sol1 --heur 1 --mode carbon --allow-shed 0 \
    --ps 50,60,70 --dir-mode soc --tl 600      # results/V3_MESH_PROBE_sol1_heur.csv
[sol1] net=mesh ps=50 status=SOLUTION_LIMIT SolCount=1 t=176.5s   （首解碳 108.95）
[sol1] net=mesh ps=60 status=SOLUTION_LIMIT SolCount=1 t=175.1s   （首解碳 112.83）
[sol1] net=mesh ps=70 status=TIME_LIMIT     SolCount=0 t=600.2s
```

**p_s=60 的首解用时（175.1 s）与 p_s=50（176.5 s）在实验误差内相同**，而 p_s=70 在同一套
参数下 600 s 落空。更关键的是**跨设置对比**：

| 参数组合（都不改模型、不改 600 s / 8 场景 / carbon / no-shed） | p_s=50 | p_s=55 | p_s=60 | p_s=70 |
|---|---|---|---|---|
| `MIPFocus=1 + SolutionLimit=1`，默认种子，600 s（= §2.3） | ✓ 22.9 s | ✗ | ✗ | ✗ |
| 同上 + `NoRelHeurTime=150, Heuristics=0.5`（= 存档启发式臂），600 s（= §5.4） | ✓ 176.5 s | 未测 | **✓ 175.1 s** | ✗ |
| `MIPFocus=1 + SolutionLimit=1`，换 Seed，240 s（= §5.3） | ✓ ✓ ✗ | **✓ 20.5 s** ✗ ✗ | 未测 | ✗ ✗ ✗ |

⇒ **只换两个纯搜索参数（加 NoRel 时段、换随机种子），p_s=60 与 p_s=55 就从"无解"翻成
"175 s / 20 s 有解"；而 p_s=50 也会因为换种子翻成"无解"。**
可行/不可行的二分完全随求解器设置漂移，p_s=70 只是这条概率带上连续落空的一端，不是台阶。

### 5.5 与存档一致性核对

| 对照项 | 存档 | 探针 | 结论 |
|---|---|---|---|
| M_PS50 碳地板 incumbent（soc，600 s） | 58.307586337605024 | 58.30758591828（`--exp start`，180 s + 起点） | 相对差 7e-9，探针未改语义 |
| M_PS50 碳地板下界 | 37.730587（600 s） | 37.684830（180 s） | 界随时长收紧，方向自洽 |
| 根松弛随 p_s | — | 35.362 @50 → 31.073 @70 | 单调下降 = 可行域放松 |
| 回归闸门 | 最大相对偏差 2.576e-05 < 1e-04 PASS | 未重跑（无模型改动，闸门不受影响） | 前提仍成立 |

---

## 根因结论（单一）

**M_PS70 的 SolCount=0 是求解器搜索失败，不是模型缺陷；"更高压反而无解"这个悖论的前提
（70 不可行 / 50 可行）两条都不成立。** 机制如下：

`build_mesh` 的网状核心把可逆管段的方向写成 **每管段每小时 1 个二进制**（8 场景 × 24 h ×
4 管 = 768 个），而"零流/少用气"这一族可行点恰好落在 `p_* = p_s` 且 `f = 0` 的**边界顶点**
上（因为压缩机出口管是 `equality=True` 的等式管，`PWL(p_s)=0` 只在其最后一个断点取到，
见 3.4）。于是"随便找到一个可行整数解"这件事，只能依赖 Gurobi 在根节点把 838 个分数二进制
舍入命中一次；命中就秒级出解，不命中就烧穿整个预算，且**命中与否由随机种子决定**。
实测命中率 3/4（p_s=50）、1/4（p_s=55）、0/4（p_s=70），且 p_s=55 的首解用时（20.5 s）
比 p_s=50（22.9–24.7 s）还短。给同一个 M_PS70 模型注入一个手工可行点（MIP Start，
不添加任何约束），**5 s** 即得 incumbent 58.31。

因此任务书里"提高 p_s 应当放松可行域，却在 70 无解 ⇒ 与单调性矛盾 ⇒ 优先怀疑缺陷"这条
推理链，其**前提被证伪**：

- 单调性没有被违反 —— 穷举 p_s 的 41 个进入点，**没有任何一条是收紧的**（Phase 3），
  根松弛值随 p_s 单调下降（35.362 @50 → 31.073 @70，Phase 2.2）；
- p_s=70 没有不可行 —— MIP Start 被接受 + 锚定可行性判定 OPTIMAL（Phase 2.1/2.2），
  Gurobi 全程从未返回 status=3；
- p_s=50 也不"可行" —— 换 Seed 3 后同一预算下同样 SolCount=0（Phase 5.3）。

"矛盾"完全来自把日志里的 `SolCount=0`（"这次没攒下解"）读成"无可行解"（"没有可行解"）。
真实存在的只是一个**难度梯度**（p_s↑ ⇒ 气网在 LP 里更值钱 ⇒ 松弛解更依赖互相一致的流向 ⇒
舍入更难命中），那是计算复杂度问题，不是可行性问题，也不是缺陷。

**证据是否充分？充分。** 判定"缺陷 vs 搜索"所需的两项证据都已到手且互相独立：
(i) 不添加任何约束的 MIP Start 被求解器接受（`Loaded user MIP start`）；
(ii) 钉入锚定等式后的纯可行性判定在 4 档 p_s × 2 种线性化下全部 OPTIMAL。
另有 (iii) 单场景与两节点链对照把难度定位到"8 场景 × 768 方向二进制"，
(iv) 穷举进入点表排除任何收紧写法，(v) 种子重复实验证明 50/70 的二分不可复现。

**还缺的两项证据（补强，不改变上述结论）**：
1. `relax` 实验的 `soc` 分支用了常数目标，落在 1.4 记录的退化陷阱里，
   因此**没有拿到一张干净的"SOCP 连续松弛在 p_s=70 可行"判定表**。补法：给
   `mesh_feas_probe.py --exp relax` 增加"放宽整数但保留非退化目标"的分支再跑 50–80。
   预期结论不变——2.1 的锚定判定本身就是纯 LP/SOCP 可满足性判定，比连续松弛更强。
2. **等预算（600 s）× 多随机种子的命中率**。§5.3 的种子重复用了 240 s，与 §2.3 的 600 s
   不同，所以 3/4 → 1/4 → 0/4 这个命中率梯度**混入了预算差异**。
   （§5.4 已经在 600 s 等预算下证明了"只改纯搜索参数就能让 p_s=60 从无解翻成有解"，
   所以定性判定不依赖这项补强；补齐后只是能给出"难度梯度有多陡"的无偏估计。）
   补法：3 个种子 × p_s ∈ {50,55,60,70} 全部跑满 600 s，约 2 h。

### 顺带查出的两条**记录层**缺陷（不是模型缺陷，本次未修）

- **R-A**：`model_mesh_v3._STATUS` 状态码表停留在旧版 Gurobi，10/11/14/15/16/17 全错
  （见 1.3）。已在真实诊断中造成一次误读。M_PS70 的 9 恰好正确，故不影响本现象。
- **R-B**：`solve_mesh` 在 `SolCount==0` 时打印"无可行解"、`mesh_notes.md §7` 与
  审计 N11 沿用"无可行解/不可判定"的措辞。按 2.1/2.2 的证据，正确措辞是
  **"600 s 内未找到可行整数解（TIME_LIMIT, SolCount=0）；可行集非空已被 MIP Start 与
  锚定可行性判定认证"**。这一条措辞正是"更高压反而无解"这个伪悖论的来源。

---

## 修复与放宽口径

### 0. "最小修复方案"一项：**不适用**

任务书要求"若确认是缺陷，写清最小修复方案"。本次诊断为**非缺陷**，因此
**不存在任何模型层面的修复方案**，也不应实施任何模型改动。
`model_mesh_v3.py` 的网状建模（锥式可逆管段、等式压缩机出口管、共享 p_0 的日循环、
5 节点单源拓扑）**经穷举核查后与 p_s 单调性预期完全一致，且与两节点回归闸门自洽**。
后来者若打算改这个模型，请先复核 Phase 2.1（锚定可行性）与 Phase 2.2（MIP Start 被接受）
两条证据，否则会修一个不存在的问题。

真正可做的两类事都**不改模型语义**，见下 A / B。

### A. 记录层修正（最小、零风险；属禁改清单，需单独授权，本次未实施）

1. **修 R-A**：`model_mesh_v3._STATUS` 按 `GRB.*` 反查重建
   （10=SOLUTION_LIMIT、11=INTERRUPTED、12=NUMERIC、13=SUBOPTIMAL、14=INPROGRESS、
   15=USER_OBJ_LIMIT、16=WORK_LIMIT、17=MEM_LIMIT、18=LOCALLY_OPTIMAL、
   19=LOCALLY_INFEASIBLE）。不改任何求解结果，只改 CSV 里 `status_name` 列的可读性。
   建议同时加一条断言：状态表覆盖 1–19 且与 `GRB.*` 逐项一致（可直接用
   `mesh_feas_probe._STATUS13` 的构造方式）。
2. **修 R-B**：`solve_mesh` 在 `SolCount==0` 时打印的"无可行解"改为
   "本次求解未攒下可行解（TIME_LIMIT/SolCount=0），不代表模型不可行"；
   `mesh_notes.md §7` 与 `audit_v3.py` N11 的"无可行解"措辞同步改为
   "冻结预算内未找到可行整数解；可行集非空，见 `mesh_ps70_diagnosis.md`"。
   **注意这会改审计脚本与 notes**，二者都在禁改清单里，需单独授权。

### B. 可声明的放宽口径选项，以及各自牺牲的科学口径

以下每条都**只改预算/求解辅助/表述层级，不改冻结的物理口径**
（K=3.83e-3、A=0.075、p_min=20、60 余弦 PWL、日循环、EF=0.8922、场景集与种子一律不动）。
诊断中已实测的数值直接标在表里。

| 选项 | 具体做法 | 实测/预期效果 | 牺牲什么 |
|---|---|---|---|
| **B1 更长时间限** | 网状臂单独放宽 TimeLimit（600 → 1800/3600 s），两节点臂保持 600 s | 有依据但不保证：p_s=50 用 22.9 s / p_s=55 用 20.5 s / p_s=60 用 175.1 s 都能命中首解，但 Seed 3 下 p_s=50 连 240 s 都没命中，p_s=70 在 4 次尝试（240–600 s）里 0 命中。**加时间提高命中率但不构成保证** | 破坏"同一 600 s 预算"的冻结口径 ⇒ 两拓扑不再同预算，"只换拓扑"的单因素对照被削弱；必须在正文写明网状用了不同预算并给出各档时限，否则是选择性放宽 |
| **B2 更少场景** | 8 → 1（或 2）场景跑网状臂（`--scen single` 已实测） | **最强**：同一个网状模型、p_s = 50/60/70/80，`soc` 与 `binary` 两种线性化，全部在 **1.6–4.2 s** 拿到可行解 | 放弃非预期性决策的 RP 解释力（一阶段只服务一个代表日），与主链 8 场景口径不可比；只能作为"机理演示格"，**不能替代 RP 格**，也不能用来报碳地板数值 |
| **B3 更粗 PWL** | 60 → 20/30 余弦断点 | 未测；会缩小 SOS 结构（384 条 → 128/192 条、presolve 的 21 408 个 λ 列按比例减少） | **直接违反冻结口径**（PWL 断点数是回归闸门的一部分，改了就得重跑 §6 闸门）；表示误差从 0.79%–0.83% 抬到数个百分点，且与两节点臂不再同口径 ⇒ **不建议** |
| **B4 分档 gap** | MIPGap 1e-4 → 5%/10%，按档位分别声明 | **注意：这不解决本次问题**。gap 只在"已有 incumbent"之后起作用；SolCount=0 的档放宽 gap 依然是 0 解。它能把 M_PS50 从"TIME_LIMIT / 35.3% gap"变成"声明 5% gap 的解"，让结论一可引用 | 牺牲"与两节点臂同一 MIPGap 1e-4"的冻结口径；且必须承认网状数值是**近似最优**而非最优，任何百分比都不得进正文（与 §8 现有处置一致） |
| **B5 注入可行起点**（诊断中新证据，**性价比最高**） | 把本文 2.1 的解析零流点作为 **MIP Start** 传给 `solve_mesh`（只加起点，不加约束、不改目标、不改冻结参数） | p_s=70：起点被接受（`Loaded user MIP start with objective 140.264`），**5 s** 即 incumbent 58.31，180 s 得下界 33.32 / gap 42.9%；p_s=50：复现存档 incumbent 58.3076 | 引入"起点"这一求解器辅助 ⇒ 必须声明。**风险要说清**：起点恰是"零气"点，可能把搜索拴在"不用气"邻域，从而**系统性偏高**碳地板 incumbent。对结论一（"耦合抬高地板"）是**保守**方向，对结论二（"p_s 降低地板"）是**不利**方向（两档都从同一个零点起跑）。所以 B5 只能用于"证明可行 + 给出上界"，**不能**用于声称求到了碳地板 |
| **B6 补 M_PS60 格**（`mesh_notes §7` 现记为"本轮未跑"） | 直接按存档启发式口径跑 `M_PS60` | **首解可通**：同一模型、同一 8 场景 / 600 s / carbon / no-shed / `NoRel150+MIPFocus1+Heur0.5`，p_s=60 在 **175.1 s** 拿到首个可行解（p_s=50 同参数 176.5 s）。注意探针加了 `SolutionLimit=1`，所以**只证明了"能进分支定界"，未测 600 s 后能否收敛到可用 incumbent** | 不涉及模型改动，但**会改写 `V3_MESH_cells.csv`（本次禁做）**；且若真要补齐，应连 M_PS50/PS70 用同一套启发式口径重跑，否则三格参数不一致 |

**给作者的建议口径（不在本次实施范围内）**：结论二在网状臂上仍应写"不可判定"，
但理由必须从"M_PS70 无可行解"改成——
"**M_PS50 与 M_PS70 在冻结 600 s 下都只得到未收敛 incumbent（gap 35–43%），
且能否进入分支定界取决于求解器随机种子（实测 p_s=50 命中 3/4 次、p_s=55 命中 1/4 次、
p_s=70 命中 0/4 次；可行集本身经 MIP Start 与锚定可行性判定证明非空），
故无法给出可认证的单调次序**"。
这样写既诚实，也不会被"其实 70 可行"的复核推翻。

---

## 预期翻绿的断言（因非缺陷，此处给"若采用 B1/B5 打通 p_s=70 后"的预测）

前提：`audit_v3.py` 的 N 节断言全部读 `V3_MESH_cells.csv`，所以任何"翻绿"都必须先把该格
正式跑出来（本次禁做）。以下只是预测，不是已发生的事实。

- **应当翻绿**：`N4b[M_PS70]`（碳地板 status ∈ {2,8,9} 且值非 nan；注意若用
  `SolutionLimit` 收尾会得到 status=10，**不在 N4b 允许集合里，会仍为红** —— 这是
  §1.3 旧状态表之外的第二处口径坑，正式跑不要带 SolutionLimit）、
  `N6b`（bound(PS70) > 线性气帽地板 27.361；B5 实测 bound(PS70)=33.32 > 27.36 ⇒ 会翻绿）、
  `N10`（判定表与逐格重算一致，PS70 有值后两边同为 True）、`N10b`。
- **仍然为红 / 新增为红**：
  `N7`/`N7b`/`N7c`（f50 > f70 需要**两个收敛的**碳地板；B5 下两者 incumbent 同为 58.31，
  严格不等式仍不成立）、`N7d`（边际递减，还需 M_PS60 正式跑出来）、
  `N8`（bound(PS50) > incumbent(PS70)：37.73 > 58.31 为假）、
  `N9`（反向流 > 0：B5 起点恰为零流，除非搜索自己走出来，仍为红）、
  `N6d`（≥10× 量级，本就允许红）。
- **特别一条**：`N11` 目前断言的是"M_PS70 无可行解（阻塞留痕）"。
  一旦 p_s=70 求得任何 incumbent，**N11 会由绿转红**——这正是该断言设计时的意图
  （"一旦收敛即为假，用来追踪阻塞状态"）。修 R-B 措辞时要同步复核这条的语义，
  否则会出现"事实推进了、审计却变红"的假退化。
- **另需修正的一条**：N4b 与 N11 的 detail 文案里"无可行解"这个说法，
  按本诊断应改成"未找到可行整数解（可行集非空）"，否则审计文案本身在陈述一个
  已被证伪的命题。

---

## 附录 A · 本次新增/产出的文件（全部为新增，未改写既有结果）

脚本：
- `code_v3/mesh_feas_probe.py`（`--exp grid|relax|anchor|start|stats|sol1`，
  `--net mesh|chain|mesh2s`，`--scen reduced|single`，`--mode cost|carbon`，
  `--allow-shed 0/1`，`--heur 1`，`--seed N`，`--tl`，`--verbose`）
- `code_v3/mesh_ps_entry_map.py`（`--ps lo,hi --dir-mode soc,binary`）

结果（`code_v3/results/`）：
`V3_MESH_PROBE_anchor.csv`、`V3_MESH_PROBE_grid.csv`、`V3_MESH_PROBE_grid120_partial.csv`、
`V3_MESH_PROBE_grid_soc600.log`、`V3_MESH_PROBE_sol1_soc_carbon.csv/.log`、
`V3_MESH_PROBE_sol1_smoke.csv`、`V3_MESH_PROBE_sol1_verbose.log`、
`V3_MESH_PROBE_start.csv/.log`、`V3_MESH_PROBE_relax.csv/.log`、
`V3_MESH_PROBE_sol1_chain.csv/.log`、`V3_MESH_PROBE_sol1_single.csv/.log`、
`V3_MESH_PROBE_sol1_seed1/2/3.csv`、`V3_MESH_PROBE_sol1_heur.csv/.log`、
`V3_MESH_PROBE_psentry_soc.csv`、`V3_MESH_PROBE_psentry_binary.csv`、
`V3_MESH_PROBE_batch1.log`、`V3_MESH_PROBE_batch2.log`

既有文件零改动：`V3_MESH_cells.csv`、`V3_MESH_regression.csv`、`V3_GC_*.csv`、
`mesh_notes.md`、`audit_v3_check.csv` 等均未触碰。

## 附录 B · 复跑顺序（单机、每档独立进程，实测总时长约 2.5 h）

每档之间请确保无其他 CPU 负载，否则用时数据失真（Gurobi 默认吃满 20 线程）。

```bash
cd code_v3
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
PY="Y:/cuda/python.exe -B"
# 1 约束层可满足性（最快、最强证据，~1 min）
$PY mesh_feas_probe.py --exp anchor --ps 50,60,70,80 --dir-mode soc,binary --tl 45
# 2 不添加约束的可行性认证（~7 min，看 "Loaded user MIP start"）
$PY mesh_feas_probe.py --exp start --mode carbon --allow-shed 0 --ps 50,70 \
    --dir-mode soc --tl 180 --verbose
# 3 首个可行解用时的 p_s 曲线（~70 min）
$PY mesh_feas_probe.py --exp sol1 --mode carbon --allow-shed 0 \
    --ps 50,55,60,65,70,75,80 --dir-mode soc --tl 600 \
    --out V3_MESH_PROBE_sol1_soc_carbon.csv
# 4 p_s 进入点穷举（~1 min）
$PY mesh_ps_entry_map.py --ps 50,70 --dir-mode soc,binary
# 5 对照：两节点链 / 单场景 / 连续松弛（~20 min）
$PY mesh_feas_probe.py --exp sol1 --net chain --mode carbon --allow-shed 0 \
    --ps 50,60,70,80 --dir-mode soc --tl 300 --out V3_MESH_PROBE_sol1_chain.csv
$PY mesh_feas_probe.py --exp sol1 --scen single --mode carbon --allow-shed 0 \
    --ps 50,60,70,80 --dir-mode soc,binary --tl 300 --out V3_MESH_PROBE_sol1_single.csv
$PY mesh_feas_probe.py --exp relax --mode carbon --allow-shed 0 --ps 50,60,70,80 \
    --dir-mode soc,binary --tl 90
# 6 种子重复（证明二分不可复现，~35 min；注意 --out 必须逐种子分开，否则会互相覆盖）
for s in 1 2 3; do
  $PY mesh_feas_probe.py --exp sol1 --mode carbon --allow-shed 0 --ps 50,55,70 \
      --dir-mode soc --tl 240 --seed $s --out V3_MESH_PROBE_sol1_seed$s.csv
done
# 7 存档启发式口径下的 600 s 对照（~25 min）
$PY mesh_feas_probe.py --exp sol1 --heur 1 --mode carbon --allow-shed 0 \
    --ps 50,60,70 --dir-mode soc --tl 600 --out V3_MESH_PROBE_sol1_heur.csv
```
