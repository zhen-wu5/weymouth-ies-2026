# -*- coding: utf-8 -*-
"""GC: Weymouth 多节点气网耦合的两阶段随机调度模型（model_stoch 的修正版）

修正的缺陷：model_stoch.py（产出全部主结果 HEP/EEV/VSS 的模型）完全没有气网——
燃气按固定价 C.C_GAS 直购，无压力/管存/流量约束，气网物理从不咬合。

本文件在 model_stoch 的两阶段结构上把 CHP 与 GB 的燃气来源改为"经由气网节点取气"，
拓扑与参数沿用 model_gas3.py（E31，多节点 Weymouth）：

  门站(源压 ps) → 管道1(Weymouth) → 节点1(CHP 取气 g1) → 压缩机(燃料 r·f2, 自节点1 抽取)
                                     → 管道2(Weymouth) → 节点2(GB 取气 g2)

  节点压力状态（每场景 s、每小时 t）：
    p1_{s,t} ∈ [pd_min, ps]，p2_{s,t} ∈ [pd_min, ps2]
  Weymouth 流量（一维 PWL，余弦 60 断点，与 model_gas3/E16 一致）：
    f1 = sqrt(K1(ps² − p1²))，f2 = sqrt(K2(ps2² − p2²))，K1=K2=0.00383
  管存动态（质量守恒，dt=1h）：
    节点1: A1·(p1_t − p1_{t−1}) = ( f1_t − f2_t·(1+r) − g1_t )·dt
    节点2: A2·(p2_t − p2_{t−1}) = ( f2_t − g2_t )·dt
    A1=A2=0.075 MWh/bar（合计 0.15，与论文/model_gas3 一致），r=0.02
  日末循环：p1_{s,T}、p2_{s,T} 回到各自范围中点；t=0 初值亦取中点（参数）。
  气源成本：门站进气量 Σf1 按 C.C_GAS 计价（由守恒恒等式
    Σf1 = Σg1 + Σg2 + r·Σf2，与原模型 C.C_GAS·(f_chp+f_gb) 单价口径一致，
    差异仅为压缩机燃料 r·f2）。
  碳排：E_GRID·p_grid + E_GAS·(g1+g2+r·f2)（压缩机燃料同样燃烧排放）。

两阶段结构不变：一阶段 u/y/z（不依赖场景）；二阶段全部连续量含 p1/p2/f1/f2/g1/g2。

解耦开关 gas_coupled=False 时直接委托 model_stoch.solve_stoch（逐参数透传），
因此"关"分支与原模型逐位一致——这是复现基准（33425.636957 / 33941.957560 /
516.320604）的构造性保证。
"""
import os
import re
import sys

import numpy as np
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

import config_v3 as C
# 状态码图例与 model_mesh_v3 共用同一份运行时导出（单一真源，避免手抄表在各文件复发）。
from model_mesh_v3 import status_name as _status_name_from_mesh


def _pwl_pts(n_pts, lo, hi):
    """余弦分布断点：平方根型函数在两端斜率变化快，均匀断点误差大（见 E29/E16）"""
    return lo + (hi - lo) * (1 - np.cos(np.pi * np.arange(n_pts) / (n_pts - 1))) / 2


def _struct_fingerprint(m):
    """从**已建好的 Gurobi 模型**里读出的结构指纹（求解前采集，不依赖任何注释或标签）。

    约束按"家族"计数：把 ConstrName 尾部的下标（_s_t / _s / 空名）剥掉后归并。
    P 节用它做非措辞性断言——'steady 去掉了管存与闭合' 这件事的唯一证据就是
    node1_*/node2_*/p1cyc_*/p2cyc_* 四个家族在 steady 的模型里**计数为 0**、
    且被 steady_node1_*/steady_node2_* 取代，而其余家族计数逐个相等。

    必须先 m.update()：Gurobi 是惰性登记的，不 update 的话 NumConstrs 与
    getConstrs() 都读到空，指纹退化成"全 0"的假证据（本轮实测踩过一次，
    两档都报 0 条约束）。广义约束（PWL）同样要 update 后才落地。
    """
    m.update()
    fams = {}
    unnamed = 0
    for con in m.getConstrs():
        nm = con.ConstrName or ''
        # Gurobi 给未命名约束自动编号为 R<下标>（本项目里是爬坡与储能末端条件那批）。
        # 它们的具体编号随模型规模漂移，不归并就会让"其余家族逐个相等"这条断言虚假地
        # 红掉——所以按"自动编号"这一类统一归并，并单独计数。
        if (not nm) or re.match(r'^R\d+$', nm):
            unnamed += 1
            key = '(auto-numbered)'
        else:
            key = re.sub(r'(_\d+)+$', '', nm)
            if not key:
                key = '(digits-only)'
        fams[key] = fams.get(key, 0) + 1
    vnames = set(v.VarName for v in m.getVars())
    n_bin = sum(1 for v in m.getVars() if v.VType == GRB.BINARY)
    return dict(
        n_cons=int(m.NumConstrs), n_vars=int(m.NumVars),
        n_gen_constrs=int(m.NumGenConstrs), n_binaries=int(n_bin),
        n_unnamed_cons=int(unnamed),
        fams=fams,
        has_p0_1 = ('p1_0' in vnames), has_p0_2 = ('p2_0' in vnames),
        n_node1 = fams.get('node1', 0), n_node2 = fams.get('node2', 0),
        n_p1cyc = fams.get('p1cyc', 0), n_p2cyc = fams.get('p2cyc', 0),
        n_steady_node1 = fams.get('steady_node1', 0),
        n_steady_node2 = fams.get('steady_node2', 0),
    )



def solve_gc(data, scenarios=None, mode='cost', lam=0.0, cap=None,
             gas_coupled=False,
             ps=70.0, ps2=None, pd_min=20.0,
             K1=0.00383, K2=0.00383, A1=0.075, A2=0.075,
             comp_ratio=0.02, n_pts=60,
             p0_mode='periodic', gate_valve=True,
             gas_model='dynamic',
             u_fix=None, verbose=False, allow_shed=True,
             risk_lambda=0.0, cvar_beta=0.95,
             time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP):
    """
    gas_coupled=False : 委托 model_stoch.solve_stoch（原模型，逐位一致）
    gas_coupled=True  : 上述 Weymouth 气网耦合模型
    ps  : 门站源压 (bar)，论文的减排杠杆；ps2 : 压缩机出口设定压力，默认 = ps
    gas_model : 气网物理口径（Task 4 方法对方法基线的唯一开关）
        'dynamic'（默认，本文口径）: 管存状态 + 日循环闭合，即上文两条节点动态
            A1·Δp1 = f1 − f2(1+r) − g1、A2·Δp2 = f2 − g2 与 p_T = p_0。
        'steady'（Kanelakis 式稳态输送基线）: **只抽掉管存这一层物理**，其余一律
            不动——节点压力变量 p1/p2 及其范围、Weymouth 系数与余弦 PWL、门站调压
            不等式、压缩机燃料 r·f2（仍自节点1 抽取、仍计价、仍计碳）、设备与负荷、
            场景与目标函数全部保持原样。被替换/删除的是：
              (a) 节点动态改为逐时独立平衡
                  f1 = f2·(1+r) + g1 ； f2 = g2        （等价于令 A1=A2=0）
              (b) 日循环闭合条件 p1_T = p1_0、p2_T = p2_0 整条删除（无管存即无闭合
                  可言，留着会成为一条与物理无关的额外约束，那才是给基线人为加严）
              (c) 一阶段初始压力变量 p1_0/p2_0 随之不存在（无状态可初始化）
            结构后果（P 节据此做非措辞性断言）：steady 的可行集是 dynamic 可行集的
            **子集**——把 steady 任一解取 p_t ≡ 常数即满足 dynamic 的全部节点动态与
            闭合条件，故 dynamic 的期望成本/最小碳排都不会比 steady 差。因此本基线
            不是"放松到显得本文更差"，也不是"收紧到显得本文更好"，而是一个被本文
            严格包含的限制模型；它若更贵，贵在省掉了管存这项可调度资源。
    p0_mode : 日循环边界条件
        'mid'      : p1_0/p2_0 固定取范围中点、p_T 回中点（model_gas3/E31 的处理）。
                     注意：节点2 唯一用气户为 GB、管道来气由压力唯一决定，此条件下
                     高 ps2(>=~68 bar) 会因"低热负荷时段被迫进气无处消纳"而不可行
                     （已用 IIS 定位：bal_h 午后时段 + node2 动态 + p2cyc 冲突）。
        'periodic' : p1_0/p2_0 为一阶段变量（场景共享，非预期性成立），p_T 回到 p_0。
                     净管存日变化仍严格为零，与 'mid' 的循环意图一致，但允许模型
                     自选循环相位——标准日循环处理，本文 GC 实验默认用此条件。
                     （与 model_gas3 '回到中点' 的差异已在 GC_notes.md 留痕。）
        仅对 gas_model='dynamic' 有意义；'steady' 下无状态可钉，本参数被忽略。
    gate_valve : True 时门站流量为不等式 f1 <= sqrt(K1(ps^2 - p1^2))——门站调压阀
        （真实门站可持低于储层压力的出口压力，流量不必达到 Weymouth 上限）；
        False 时为等式（model_gas3 的定压无限气源写法）。默认 True。
        调压生效（f1 严格低于上界）的小时数由 gc_run 报告，是"气网约束咬合"的直接证据。
        两个 gas_model 档都保持 True：调压阀与管存无关，动它就是给基线加不必要的松紧。
    mode: 'cost' | 'carbon' | 'weighted' | 'eps'（与 model_stoch 相同）
    risk_lambda>0 : 对场景运营成本 cost_s 做 CVaR（Rockafellar–Uryasev），
                    启动成本的处理与 model_stoch 相同（场景间为常量，单独相加）
    """
    if gas_model not in ('dynamic', 'steady'):
        raise ValueError(f"gas_model 只支持 'dynamic' | 'steady'，收到 {gas_model!r}")
    if not gas_coupled:
        # B0（无气网）不存在气网口径可言；显式拦住"给 B0 贴 steady 标签"的误用。
        if gas_model != 'dynamic':
            raise ValueError('gas_coupled=False 时 gas_model 只能是默认值 dynamic')
        import model_stoch_v3 as MS
        return MS.solve_stoch(data, scenarios=scenarios, mode=mode, lam=lam, cap=cap,
                              u_fix=u_fix, verbose=verbose, allow_shed=allow_shed,
                              risk_lambda=risk_lambda, cvar_beta=cvar_beta,
                              time_limit=time_limit, mipgap=mipgap)


    T = len(data['p_load'])
    dt = 1.0
    if ps2 is None:
        ps2 = ps
    S = 1 if scenarios is None else len(scenarios)
    probs = [1.0] if scenarios is None else [sc['prob'] for sc in scenarios]
    wind_avail = [np.asarray(data['wind'], float)] if scenarios is None \
        else [np.asarray(sc['wind'], float) for sc in scenarios]
    pv_avail = [np.asarray(data['pv'], float)] if scenarios is None \
        else [np.asarray(sc['pv'], float) for sc in scenarios]
    p_load_s = [np.asarray(data['p_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('p_load', data['p_load']), float) for sc in scenarios]
    h_load_s = [np.asarray(data['h_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('h_load', data['h_load']), float) for sc in scenarios]
    p_load = np.asarray(data['p_load'], float)
    h_load = np.asarray(data['h_load'], float)
    price = np.asarray(data['price'], float)

    m = gp.Model('IES_gc')
    m.Params.OutputFlag = 1 if verbose else 0
    m.Params.TimeLimit = time_limit
    m.Params.MIPGap = mipgap

    eta_he = C.CHP['eta_h'] / C.CHP['eta_e']
    pmax, pmin = C.CHP['pmax'], C.CHP['pmin_ratio'] * C.CHP['pmax']
    mid1 = 0.5 * (pd_min + ps)
    mid2 = 0.5 * (pd_min + ps2)

    # ---------- 第一阶段变量（场景共享，非预期性） ----------
    u = m.addVars(T, vtype=GRB.BINARY, name='u')
    y = m.addVars(T, vtype=GRB.BINARY, name='y')
    z = m.addVars(T, vtype=GRB.BINARY, name='z')
    # 初始压力/管存状态（一阶段；'mid' 时为常数中点，'periodic' 时为决策变量）
    # gas_model='steady' 下**不存在这两个变量**：没有管存状态就没有可初始化的量。
    # 这是 P 节的结构判据之一（不是靠注释声明，是靠变量表里查不到）。
    p0_as_vars = (gas_model == 'dynamic' and p0_mode == 'periodic')
    if p0_as_vars:
        p1_0 = m.addVar(lb=pd_min, ub=ps, name='p1_0')
        p2_0 = m.addVar(lb=pd_min, ub=ps2, name='p2_0')
    elif gas_model == 'dynamic':
        p1_0, p2_0 = mid1, mid2
    else:
        p1_0 = p2_0 = None
    if u_fix is not None:
        for t in range(T):
            m.addConstr(u[t] == int(u_fix[t]), name=f'ufix_{t}')

    # ---------- 气网 PWL 断点与范围中点（与 model_gas3 一致） ----------
    pd1_pts = _pwl_pts(n_pts, pd_min, ps)
    f1_pts = np.sqrt(np.clip(K1 * (ps ** 2 - pd1_pts ** 2), 0, None))
    pd2_pts = _pwl_pts(n_pts, pd_min, ps2)
    f2_pts = np.sqrt(np.clip(K2 * (ps2 ** 2 - pd2_pts ** 2), 0, None))
    f1_max = float(np.sqrt(K1 * (ps ** 2 - pd_min ** 2)))
    f2_max = float(np.sqrt(K2 * (ps2 ** 2 - pd_min ** 2)))

    # ---------- 第二阶段变量（按场景） ----------
    def v(name, ub=GRB.INFINITY):
        return m.addVars(S, T, lb=0, ub=ub, name=name)

    p_wind, p_pv, p_grid, p_chp = v('p_wind'), v('p_pv'), v('p_grid'), v('p_chp')
    p_shed = v('p_shed') if allow_shed else None
    h_gb = v('h_gb', C.GB['hmax']); h_eb = v('h_eb', C.EB['hmax']); h_hp = v('h_hp', C.HP['hmax'])
    p_c, p_d = v('p_c', C.ESS['pmax']), v('p_d', C.ESS['pmax'])
    soc = m.addVars(S, T, lb=0, name='soc')
    h_c, h_d = v('h_c', C.HSS['pmax']), v('h_d', C.HSS['pmax'])
    hsoc = m.addVars(S, T, lb=0, name='hsoc')
    # 气网侧
    p1 = m.addVars(S, T, lb=pd_min, ub=ps, name='p1')
    p2 = m.addVars(S, T, lb=pd_min, ub=ps2, name='p2')
    f1 = m.addVars(S, T, lb=0, name='f1')
    f2 = m.addVars(S, T, lb=0, name='f2')
    g1 = m.addVars(S, T, lb=0, name='g1')     # CHP 耗气（节点1）
    g2 = m.addVars(S, T, lb=0, name='g2')     # GB 耗气（节点2）
    # 门站调压：f1 的 Weymouth 上界（gate_valve=True 时 f1 可低于上界 = 调压节流）
    if gate_valve:
        f1ub = m.addVars(S, T, lb=0, ub=f1_max, name='f1ub')

    for s in range(S):
        for t in range(T):
            if gate_valve:
                m.addGenConstrPWL(p1[s, t], f1ub[s, t], pd1_pts.tolist(), f1_pts.tolist(),
                                  name=f'pwl1_{s}_{t}')
                m.addConstr(f1[s, t] <= f1ub[s, t], name=f'valve1_{s}_{t}')
            else:
                m.addGenConstrPWL(p1[s, t], f1[s, t], pd1_pts.tolist(), f1_pts.tolist(),
                                  name=f'pwl1_{s}_{t}')
            m.addGenConstrPWL(p2[s, t], f2[s, t], pd2_pts.tolist(), f2_pts.tolist(),
                              name=f'pwl2_{s}_{t}')

    cost_s, carbon_s = [], []
    for s in range(S):
        for t in range(T):
            m.addConstr(p_chp[s, t] <= pmax * u[t])
            m.addConstr(p_chp[s, t] >= pmin * u[t])
            m.addConstr(p_wind[s, t] <= wind_avail[s][t])
            m.addConstr(p_pv[s, t] <= pv_avail[s][t])
            p_eb = h_eb[s, t] / C.EB['eta']
            p_hp = h_hp[s, t] / C.HP['cop']
            shed_term = p_shed[s, t] if allow_shed else 0
            m.addConstr(p_wind[s, t] + p_pv[s, t] + p_chp[s, t] + p_grid[s, t] + p_d[s, t]
                        == p_load_s[s][t] - shed_term + p_eb + p_hp + p_c[s, t],
                        name=f'bal_e_{s}_{t}')
            m.addConstr(p_chp[s, t] * eta_he + h_gb[s, t] + h_eb[s, t] + h_hp[s, t] + h_d[s, t]
                        == h_load_s[s][t] + h_c[s, t], name=f'bal_h_{s}_{t}')
            prev_soc = soc[s, t - 1] if t > 0 else C.ESS['soc0'] * C.ESS['cap']
            m.addConstr(soc[s, t] == prev_soc + (C.ESS['eta_c'] * p_c[s, t] - p_d[s, t] / C.ESS['eta_d']) * dt)
            m.addConstr(soc[s, t] <= C.ESS['soc_max'] * C.ESS['cap'])
            m.addConstr(soc[s, t] >= C.ESS['soc_min'] * C.ESS['cap'])
            prev_h = hsoc[s, t - 1] if t > 0 else C.HSS['soc0'] * C.HSS['cap']
            m.addConstr(hsoc[s, t] == prev_h + (C.HSS['eta_c'] * h_c[s, t] - h_d[s, t] / C.HSS['eta_d']) * dt)
            m.addConstr(hsoc[s, t] <= C.HSS['soc_max'] * C.HSS['cap'])
            m.addConstr(hsoc[s, t] >= C.HSS['soc_min'] * C.HSS['cap'])

            # 取气与设备耗气耦合（CHP 在节点1，GB 在节点2）
            m.addConstr(g1[s, t] == p_chp[s, t] / C.CHP['eta_e'], name=f'g1def_{s}_{t}')
            m.addConstr(g2[s, t] == h_gb[s, t] / C.GB['eta'], name=f'g2def_{s}_{t}')

            # ---- 气网节点平衡：本文口径 = 管存动态；基线口径 = 逐时独立稳态平衡 ----
            # 两者只差"A·Δp 这一项在不在"。其余（f1/f2/g1/g2 的定义、Weymouth PWL、
            # 压缩机燃料 r·f2 自节点1 抽取）完全一致。
            if gas_model == 'dynamic':
                prev_p1 = p1[s, t - 1] if t > 0 else p1_0
                m.addConstr(A1 * (p1[s, t] - prev_p1)
                            == (f1[s, t] - f2[s, t] * (1 + comp_ratio) - g1[s, t]) * dt,
                            name=f'node1_{s}_{t}')
                prev_p2 = p2[s, t - 1] if t > 0 else p2_0
                m.addConstr(A2 * (p2[s, t] - prev_p2) == (f2[s, t] - g2[s, t]) * dt,
                            name=f'node2_{s}_{t}')
            else:
                m.addConstr(f1[s, t] == f2[s, t] * (1 + comp_ratio) + g1[s, t],
                            name=f'steady_node1_{s}_{t}')
                m.addConstr(f2[s, t] == g2[s, t],
                            name=f'steady_node2_{s}_{t}')

        m.addConstr(soc[s, T - 1] == C.ESS['soc0'] * C.ESS['cap'])
        m.addConstr(hsoc[s, T - 1] == C.HSS['soc0'] * C.HSS['cap'])
        # 日末循环：'mid' 回到中点；'periodic' 回到一阶段初始压力 p1_0/p2_0
        # （两种条件下净管存日变化均为零）。
        # gas_model='steady' 下整条删除——没有管存状态就没有"闭合"可言。留着它
        # 会给基线加一条与自身物理无关的额外约束（人为加严），那正是 strawman。
        if gas_model == 'dynamic':
            m.addConstr(p1[s, T - 1] == p1_0, name=f'p1cyc_{s}')
            m.addConstr(p2[s, T - 1] == p2_0, name=f'p2cyc_{s}')

        carbon_s.append(gp.quicksum(
            C.E_GRID * p_grid[s, t] + C.E_GAS * (g1[s, t] + g2[s, t] + comp_ratio * f2[s, t])
            for t in range(T)))
        cost_s.append(gp.quicksum(
            price[t] * p_grid[s, t] + C.C_GAS * f1[s, t]
            + (5000.0 * p_shed[s, t] if allow_shed else 0)
            + C.CHP['c_om'] * p_chp[s, t] + C.GB['c_om'] * h_gb[s, t]
            + C.EB['c_om'] * h_eb[s, t] + C.HP['c_om'] * h_hp[s, t]
            + C.ESS['c_om'] * (p_c[s, t] + p_d[s, t]) + C.HSS['c_om'] * (h_c[s, t] + h_d[s, t])
            + C.C_OM_WIND * p_wind[s, t] + C.C_OM_PV * p_pv[s, t]
            for t in range(T)))

    # CHP 爬坡与启停转移（第一阶段）
    for t in range(T):
        for s in range(S):
            up = p_chp[s, t] - (p_chp[s, t - 1] if t > 0 else 0.0)
            m.addConstr(up <= C.CHP['ramp'] + pmax * y[t])
            m.addConstr(-up <= C.CHP['ramp'] + pmax * z[t])
        m.addConstr(y[t] - z[t] == u[t] - (u[t - 1] if t > 0 else 0))

    exp_cost = gp.quicksum(probs[s] * cost_s[s] for s in range(S))
    exp_carbon = gp.quicksum(probs[s] * carbon_s[s] for s in range(S))
    startup = C.CHP['c_startup'] * gp.quicksum(y)

    # CVaR（与 model_stoch 相同的线性化与启动成本处理）
    cvar_expr = None
    if risk_lambda > 0:
        tau = m.addVar(lb=-GRB.INFINITY, name='tau')
        zeta = m.addVars(S, lb=0, name='zeta')
        for s in range(S):
            m.addConstr(zeta[s] >= cost_s[s] - tau)
        cvar_expr = tau + gp.quicksum(probs[s] * zeta[s] for s in range(S)) / (1 - cvar_beta)

    if mode == 'cost':
        if risk_lambda > 0:
            m.setObjective((1 - risk_lambda) * exp_cost
                           + risk_lambda * cvar_expr + startup, GRB.MINIMIZE)
        else:
            m.setObjective(exp_cost + startup, GRB.MINIMIZE)
    elif mode == 'carbon':
        m.setObjective(exp_carbon, GRB.MINIMIZE)
    elif mode == 'weighted':
        m.setObjective(exp_cost + startup + lam * exp_carbon, GRB.MINIMIZE)
    elif mode == 'eps':
        if cap is None:
            raise ValueError("mode='eps' 需要 cap")
        m.setObjective(exp_cost + startup, GRB.MINIMIZE)
        m.addConstr(exp_carbon <= cap, name='carbon_cap')
    else:
        raise ValueError(mode)

    # 结构指纹必须在 optimize() **之前**采集：此时模型还没有任何解，指纹只能是
    # "约束/变量长什么样"这一事实，与求解结果无关，也就无法被事后凑数。
    _struct = _struct_fingerprint(m)
    _struct['expected_dyn_cons'] = S * T * (2 if gas_model == 'dynamic' else 0)

    m.optimize()

    if m.Status not in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        # 图例来自 model_mesh_v3 的运行时反查导出（GRB.Status.*），不在此手抄，
        # 以免状态码漂移复发（R-A）。
        print(f'[model_gc] solve_gc 未得最优解: status={m.Status} '
              f'({_status_name_from_mesh(m.Status)})', file=sys.stderr)
        if os.environ.get('GC_DEBUG_IIS') and m.Status == GRB.INFEASIBLE:
            m.computeIIS()
            print('--- IIS 约束 ---')
            for c in m.getConstrs():
                if c.IISConstr:
                    print(c.ConstrName)
            for v_ in m.getVars():
                if v_.IISLB or v_.IISUB:
                    print(f'bound: {v_.VarName} lb={v_.IISLB} ub={v_.IISUB}')
        return None

    # ---------- 结果提取 ----------
    scen_rows = []
    for s in range(S):
        sched = pd.DataFrame({
            'wind_avail': wind_avail[s], 'pv_avail': pv_avail[s],
            'p_wind': [p_wind[s, t].X for t in range(T)],
            'p_pv': [p_pv[s, t].X for t in range(T)],
            'p_grid': [p_grid[s, t].X for t in range(T)],
            'p_chp': [p_chp[s, t].X for t in range(T)],
            'u_chp': [u[t].X for t in range(T)],
            'h_chp': [p_chp[s, t].X * eta_he for t in range(T)],
            'h_gb': [h_gb[s, t].X for t in range(T)],
            'h_eb': [h_eb[s, t].X for t in range(T)],
            'h_hp': [h_hp[s, t].X for t in range(T)],
            'p_ess_c': [p_c[s, t].X for t in range(T)],
            'p_ess_d': [p_d[s, t].X for t in range(T)],
            'soc_ess': [soc[s, t].X for t in range(T)],
            'h_hss_c': [h_c[s, t].X for t in range(T)],
            'h_hss_d': [h_d[s, t].X for t in range(T)],
            'soc_hss': [hsoc[s, t].X for t in range(T)],
            'p1_bar': [p1[s, t].X for t in range(T)],
            'p2_bar': [p2[s, t].X for t in range(T)],
            'f1': [f1[s, t].X for t in range(T)],
            'f1_ub': ([f1ub[s, t].X for t in range(T)] if gate_valve
                      else [float(np.interp(v, pd1_pts, f1_pts)) for v in
                            [p1[s, tt].X for tt in range(T)]]),
            'f2': [f2[s, t].X for t in range(T)],
            'g1_chp': [g1[s, t].X for t in range(T)],
            'g2_gb': [g2[s, t].X for t in range(T)],
            'comp_fuel': [comp_ratio * f2[s, t].X for t in range(T)],
            'lp1': [A1 * p1[s, t].X for t in range(T)],
            'lp2': [A2 * p2[s, t].X for t in range(T)],
            'p_load': p_load_s[s], 'h_load': h_load_s[s], 'price': price,
        })
        n_start = int(round(sum(y[t].X for t in range(T))))
        # ---- 逐时不平衡残差：管存这项资源在该解里到底有没有被用到 ----
        # res1_t = f1 - f2(1+r) - g1（节点1 净存气），res2_t = f2 - g2（节点2 净存气）。
        # dynamic 口径下 res = A·Δp（可正可负）；steady 口径下两个节点平衡都被约束成
        # 恒等 0。用**解里的残差**而不是变量名判定"这层物理在不在"，P 节因此不依赖措辞。
        _f1a = np.asarray(sched['f1'], float)
        _f2a = np.asarray(sched['f2'], float)
        _g1a = np.asarray(sched['g1_chp'], float)
        _g2a = np.asarray(sched['g2_gb'], float)
        _res1 = _f1a - _f2a * (1.0 + comp_ratio) - _g1a
        _res2 = _f2a - _g2a
        _res = _res1 + _res2
        _store_h = int(np.sum((np.abs(_res1) > 1e-6) | (np.abs(_res2) > 1e-6)))
        _max_res = float(max(np.abs(_res1).max(), np.abs(_res2).max())) if T else 0.0
        # 日内累计管存需求相对 0 的最大偏离（MWh）= 这一层物理被用掉的幅度
        _lp_used = float(np.abs(np.cumsum(_res)).max()) if T else 0.0
        # 日末残余（MWh）：非 0 = 该方案"存了气没还"；除以总管存系数即闭合缺口 bar
        _day_end = float(_res.sum()) if T else 0.0
        scen_rows.append(dict(
            scenario=s, prob=probs[s],
            op_cost=float(cost_s[s].getValue()),
            startup_cost=C.CHP['c_startup'] * n_start,
            carbon=float(carbon_s[s].getValue()),
            grid_buy_MWh=float(sched['p_grid'].sum() * dt),
            gas_MWh=float((sched['g1_chp'].sum() + sched['g2_gb'].sum()
                           + sched['comp_fuel'].sum()) * dt),
            gate_gas_MWh=float(sched['f1'].sum() * dt),
            comp_fuel_MWh=float(sched['comp_fuel'].sum() * dt),
            re_avail_MWh=float((wind_avail[s] + pv_avail[s]).sum() * dt),
            re_used_MWh=float((sched['p_wind'] + sched['p_pv']).sum() * dt),
            shed_MWh=(float(sum(p_shed[s, t].X for t in range(T)) * dt) if allow_shed else 0.0),
            p1_min=float(sched['p1_bar'].min()), p1_max=float(sched['p1_bar'].max()),
            p2_min=float(sched['p2_bar'].min()), p2_max=float(sched['p2_bar'].max()),
            f1_max=float(sched['f1'].max()), f2_max=float(sched['f2'].max()),
            f1_throttle_h=int(sum(1 for tt in range(T)
                                  if sched['f1_ub'][tt] - sched['f1'][tt] > 1e-4)),
            lp_swing=float((sched['lp1'] + sched['lp2']).max()
                           - (sched['lp1'] + sched['lp2']).min()),
            lp1_swing=float(sched['lp1'].max() - sched['lp1'].min()),
            lp2_swing=float(sched['lp2'].max() - sched['lp2'].min()),
            # ---- 逐时不平衡残差（定义与判据见上方 _res1/_res2/_res 注释）----
            res1=[float(x) for x in _res1],
            res2=[float(x) for x in _res2],
            store_h=_store_h,
            max_res_abs_h=_max_res,
            lp_used_MWh=_lp_used,
            day_end_imbalance_MWh=_day_end,
            sched=sched,
        ))

    exp_total_cost = float(exp_cost.getValue()) + C.CHP['c_startup'] * int(round(sum(y[t].X for t in range(T))))
    scen_costs = np.array([float(cost_s[s].getValue()) for s in range(S)])
    scen_probs = np.array(probs)
    order = np.argsort(-scen_costs)
    cvar_emp = float(np.sum(scen_probs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]] *
                            scen_costs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]])
                     / max(1e-9, np.sum(scen_probs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]])))
    metrics = dict(
        mode=mode, lam=lam, cap=cap, n_scen=S, T=T, u_fix=u_fix is not None,
        gas_coupled=True, gas_model=gas_model, ps=ps, ps2=ps2, pd_min=pd_min,
        p0_mode=(p0_mode if gas_model == 'dynamic' else 'n/a (no line-pack state)'),
        gate_valve=gate_valve,
        K1=K1, K2=K2, A1=A1, A2=A2, comp_ratio=comp_ratio, n_pts=n_pts,
        # A_eff：写进约束的管存系数实际值。'steady' 为 0.0（逐时独立平衡），
        # 与 A1/A2（冻结的几何常数，两档都是 0.075）分开记，避免"基线偷偷改了几何"
        # 或"基线的 lp_util 还可以照原口径比"这两种误读。
        A1_eff=(A1 if gas_model == 'dynamic' else 0.0),
        A2_eff=(A2 if gas_model == 'dynamic' else 0.0),
        f1_max=f1_max, f2_max=f2_max, mid1=mid1, mid2=mid2,
        risk_lambda=risk_lambda, cvar_beta=cvar_beta,
        cvar_model=(float(cvar_expr.getValue()) if cvar_expr is not None else None),
        cvar_emp=cvar_emp, worst_cost=float(scen_costs.max()),
        exp_cost=exp_total_cost,
        exp_carbon=float(exp_carbon.getValue()),
        solve_time=float(m.Runtime), mip_gap=float(m.MIPGap),
        n_vars=int(m.NumVars), n_cons=int(m.NumConstrs), status=int(m.Status),
        struct=_struct,
        scen_rows=scen_rows,
    )
    return metrics
