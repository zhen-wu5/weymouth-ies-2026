# -*- coding: utf-8 -*-
"""把两个头条百分比在各口径维度上的取值汇成**机器可读的带**（现读现算，不估不手抄）。

两个头条数（外加一个同族数 PS50 档）：
  lever_50_70 = (C(50) - C(70)) / C(50) * 100    源压 50->70 bar 的碳地板杠杆
  uplift_ps70 = (C(70) - C(B0)) / C(B0) * 100    去掉气网物理的碳地板低估（PS70，头条）
  uplift_ps50 = (C(50) - C(B0)) / C(B0) * 100    同上，PS50 档
C(x) 一律是该臂/该格存档的**最小期望碳排**（碳地板）字段 `carbon_min_exp_rp`
（单位 tCO2/日）。分母口径写进每行的 `denominator_definition` 列，不留给读者猜。

诚实约束（本脚本的硬要求）：
  * 只从既有 CSV 现读现算：`V3_GC_scan_carbon.csv`（链各臂宽表）、
    `V3_MESH_cells.csv` + `V3_MESH_verdict.csv`（网状）、
    `V3_BASELINE_ps_scan.csv`（Task 4 第二读路径）、`V3_GC_{cfg}_{arm}_summary.csv`
    （独立长表读路径，仅自检用）。缺的格如实写 `NOT_RUN`，不留空、不估。
  * 每行带 `basis` ∈ {optimal_point, bound_lower, not_run}、`certified`、
    `bound_direction`，以及该格三块碳地板各自的 Gurobi 状态码/状态名/gap。
    链上各臂的碳地板 gap **没有落盘**（主链只持久化 status+time），如实写
    `NOT_RECORDED`，并把依据写成"求解器 MIPGap 参数 = 1e-4 + 状态 OPTIMAL"。
  * 网状（GasLib-11 核心）三格状态是 TIME_LIMIT，**只有下界 L**，一律
    basis=bound_lower，绝不与点值混算：`point_value_range` 只在 certified 的
    optimal_point 上取 min/max；界导出值只进 `bound_informed_range`。
    网状 incumbent（58.3076，跨 p_s 并列的零流浅层点）不当地板值用。
  * **退化恒等格单列排除**（`degenerate` 列）：无气网格 D_nogas 的 uplift 是
    "B0 与自己比"，恒等于 0.000000%，它不是测量值而是恒等式。这类行**留在表里**
    （原始值、basis、证据列照写），但被 `degenerate=True` 标记，并从
    `point_value_range` / `bound_informed_range` 的派生中剔除，排除明细写进
    summary 的 `degenerate_excluded_*` 列。否则"认证点值区间下界 = 0.000%"会被
    审稿人一句话打回。
  * Gurobi 状态码图例从 `model_mesh_v3` 的单一真源导入（运行时由 gurobipy 反查），
    不手抄表（见 mesh_notes.md 的 R-A 教训）。

输出（code_v3/results/）：
  V3_BAND_scan.csv       长表：每行 = 一个格 × 一个指标 + 全套口径坐标与证据
  V3_BAND_summary.csv    每个指标的 point_value_range / bound_informed_range 与差异来源

用法：
  PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py                      # 生成两个 CSV
  PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest            # 全项自检
  ... --selftest=recompute | --selftest=mesh-excluded | --selftest=degenerate-excluded
  ... --selftest-mutation=basis_flip | value_perturb | b0_swap | degenerate_included
变异只打在内存副本上，变异模式强制不写盘。
"""
import argparse
import copy
import csv
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
RES = os.path.join(HERE, 'results')

OUT_SCAN = os.path.join(RES, 'V3_BAND_scan.csv')
OUT_SUMMARY = os.path.join(RES, 'V3_BAND_summary.csv')

F_SCAN_CARBON = os.path.join(RES, 'V3_GC_scan_carbon.csv')
F_MESH_CELLS = os.path.join(RES, 'V3_MESH_cells.csv')
F_MESH_VERDICT = os.path.join(RES, 'V3_MESH_verdict.csv')
F_BASELINE_PS = os.path.join(RES, 'V3_BASELINE_ps_scan.csv')

STATUS_OPTIMAL = 2          # Gurobi 2 = OPTIMAL（点值可用）；9 = TIME_LIMIT（只有界）
NOT_RECORDED = 'NOT_RECORDED'
GAP_AUTH_CHAIN = ('NOT_RECORDED: gc_run_v3 persisted only carbon_min_rp_status/time for '
                  'the carbon-min solve; solver MIPGap setting = 1e-4 '
                  '(config_v3.GRB_MIPGAP) and status OPTIMAL => gap <= 1e-4')
GAP_AUTH_MESH = ('recorded as carbon_min_mip_gap in V3_MESH_cells.csv '
                 '(TIME_LIMIT: bound not closed)')

METRICS = ['lever_50_70', 'uplift_ps70', 'uplift_ps50']

FORMULA = {
    'lever_50_70': '(C(50bar)-C(70bar))/C(50bar)*100',
    'uplift_ps70': '(C(70bar)-C(B0))/C(B0)*100',
    'uplift_ps50': '(C(50bar)-C(B0))/C(B0)*100',
}
DEN_DEF = {
    'lever_50_70': ('denominator C(50bar) = carbon floor of the SAME cell (same heat '
                    'shape, same emission factor, same gas fidelity, same topology) '
                    'with the source-pressure bound at 50 bar; NOT the uncoupled floor'),
    'uplift_ps70': ('denominator C(B0) = uncoupled (no gas network) carbon floor of the '
                    'same heat/emission-factor caliber; B0 carries no gas model, so it is '
                    'gas-fidelity- and topology-independent by construction '
                    '(model_gc_v3 raises if gas_model is set while gas_coupled=False)'),
    'uplift_ps50': ('denominator C(B0) = uncoupled (no gas network) carbon floor of the '
                    'same heat/emission-factor caliber; B0 carries no gas model, so it is '
                    'gas-fidelity- and topology-independent by construction '
                    '(model_gc_v3 raises if gas_model is set while gas_coupled=False)'),
}

# 状态码图例：单一真源（model_mesh_v3 运行时由 gurobipy 反查生成），不在此手抄
try:
    from model_mesh_v3 import status_name as STATUS_NAME
except Exception as _exc:                                       # pragma: no cover
    def STATUS_NAME(code):
        return 'UNRESOLVED_%s(%s)' % (type(_exc).__name__, int(code))
    sys.stderr.write('[band_scan] 状态码图例降级（gurobipy/model_mesh_v3 不可用）：%s\n'
                     % _exc)


# ---------------------------------------------------------------- 小工具
def _read(path):
    if not os.path.exists(path):
        return []
    with io.open(path, encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def _num(x):
    if x is None:
        return None
    s = str(x).strip()
    if s in ('', 'nan', 'NaN', 'None', 'NOT_RUN', 'n/a'):
        return None
    return float(s)


def _txt(x):
    return '' if x is None else str(x).strip()


def _floor(v):
    return 'NOT_RUN' if v is None else '%.10f' % v


def _pct(v):
    return 'NOT_RUN' if v is None else '%.9f' % v


# ---------------------------------------------------------------- 源数据
def load_chain_floors():
    """链（两节点）各臂碳地板：(arm, cfg) -> 读数。basis 由状态码决定，不手填。"""
    out = {}
    for r in _read(F_SCAN_CARBON):
        st = _num(r.get('carbon_min_rp_status'))
        opt = st is not None and int(st) == STATUS_OPTIMAL
        out[(_txt(r['arm']), _txt(r['cfg']))] = dict(
            value=_num(r['carbon_min_exp_rp']),
            status=(None if st is None else int(st)),
            status_name=STATUS_NAME(st) if st is not None else 'n/a',
            time_s=_num(r.get('carbon_min_rp_time')),
            e_grid=_txt(r.get('e_grid')), ef_mode=_txt(r.get('e_grid_mode')),
            gas_coupled=_txt(r.get('gas_coupled')), ps=_txt(r.get('ps')),
            kind='optimal_point' if opt else 'bound_lower',
            gap_pct=NOT_RECORDED, gap_authority=GAP_AUTH_CHAIN,
            source=os.path.basename(F_SCAN_CARBON),
        )
    return out


def load_mesh_floors():
    """网状三格 + 网状 B0：OPTIMAL 才有资格当点值，TIME_LIMIT 只留下界 L。"""
    out = {}
    for r in _read(F_MESH_CELLS):
        st = _num(r.get('carbon_min_status'))
        gap = _num(r.get('carbon_min_mip_gap'))
        bound = _num(r.get('carbon_min_obj_bound'))
        incumbent = _num(r.get('carbon_min_exp_rp'))
        opt = st is not None and int(st) == STATUS_OPTIMAL
        out[_txt(r['cell'])] = dict(
            value=(incumbent if opt else bound),
            lower_bound=bound, incumbent=incumbent,
            status=(None if st is None else int(st)),
            status_name=STATUS_NAME(st) if st is not None else 'n/a',
            time_s=_num(r.get('carbon_min_solve_time')),
            gap_pct=(NOT_RECORDED if gap is None else '%.4f' % (gap * 100.0)),
            gap_authority=GAP_AUTH_MESH,
            kind='optimal_point' if opt else 'bound_lower',
            e_grid=_txt(r.get('e_grid')), ef_mode=_txt(r.get('e_grid_mode')),
            ps=_txt(r.get('ps')), source=os.path.basename(F_MESH_CELLS),
        )
    return out


def load_verdict():
    rows = _read(F_MESH_VERDICT)
    return rows[0] if rows else {}


def load_baseline_ps_scan():
    out = {}
    for r in _read(F_BASELINE_PS):
        # 该表的臂列叫 gas_model（取值 main / steady），没有 arm 列
        out[(_txt(r['gas_model']), _txt(r['cfg']))] = dict(
            value=_num(r['carbon_min_exp_rp']), status=_num(r['carbon_min_status']),
            source=os.path.basename(F_BASELINE_PS))
    return out


def load_all_gc_table():
    """又一条独立读路径：V3_all_gc_summary_table.csv（每臂每档的 carb_min 宽表）。"""
    out = {}
    for r in _read(os.path.join(RES, 'V3_all_gc_summary_table.csv')):
        out[(_txt(r['arm']), _txt(r['cfg']))] = _num(r['carb_min'])
    return out


# 独立读路径 1：V3_GC_{cfg}_{arm}_summary.csv 长表（下面 load_summary_long）
def load_summary_long(cfg, arm):
    """独立读路径：V3_GC_{cfg}_{arm}_summary.csv 的长表 metric,value。"""
    p = os.path.join(RES, 'V3_GC_%s_%s_summary.csv' % (cfg, arm))
    if not os.path.exists(p):
        return None
    d = {_txt(r['metric']): _txt(r['value']) for r in _read(p)}
    st = _num(d.get('carbon_min_rp_status'))
    return dict(value=_num(d.get('carbon_min_exp_rp')),
                status=(None if st is None else int(st)),
                time_s=_num(d.get('carbon_min_rp_time')),
                e_grid=d.get('e_grid'), ef_mode=d.get('e_grid_mode'),
                gas_model=d.get('gas_model'), gas_coupled=d.get('gas_coupled'),
                rp_exp_carbon=_num(d.get('rp_exp_carbon')),
                source=os.path.basename(p))


# ---------------------------------------------------------------- 格子规格
# (cell_id, dimension, level_label, coords, src, in_pool_first_copy)
# coords = (net, heat_load, ef_mode, e_grid, gas_model)
DECLARED = ('2node_chain', 'synthetic_typical_day', 'official_om_nw', '0.8922',
            'dynamic_line_pack')
CELL_SPECS = [
    ('A_declared', 'declared_baseline',
     'declared caliber: EF 0.8922 / synthetic heat / dynamic line-pack / 2-node chain',
     DECLARED, dict(kind='chain', arm='main'), True),
    # 维度 1：电网排放因子
    ('B_ef055', 'emission_factor', 'EF 0.55 (legacy value)',
     ('2node_chain', 'synthetic_typical_day', 'old_0.55', '0.55', 'dynamic_line_pack'),
     dict(kind='chain', arm='efold'), True),
    ('B_ref', 'emission_factor', 'EF 0.8922 (declared level, same cell as A_declared)',
     DECLARED, dict(kind='chain', arm='main'), False),
    # 维度 2：热负荷形状
    ('C_heatreal', 'heat_shape', 'measured heat (Denmark Broenderslev 2019, 91 days)',
     ('2node_chain', 'measured_denmark_2019', 'official_om_nw', '0.8922',
      'dynamic_line_pack'),
     dict(kind='chain', arm='heatreal'), True),
    ('C_ref', 'heat_shape', 'synthetic typical day (declared level)',
     DECLARED, dict(kind='chain', arm='main'), False),
    # 维度 3：气网保真度
    ('D_steady', 'gas_fidelity', 'steady transport, no line-pack (Task 4 baseline arm)',
     ('2node_chain', 'synthetic_typical_day', 'official_om_nw', '0.8922',
      'steady_transport'),
     dict(kind='chain', arm='steady'), True),
    ('D_nogas', 'gas_fidelity', 'no gas network at all (B0 abstraction)',
     ('2node_chain', 'synthetic_typical_day', 'official_om_nw', '0.8922', 'none'),
     dict(kind='nogas'), True),
    ('D_ref', 'gas_fidelity', 'dynamic line-pack (declared level)',
     DECLARED, dict(kind='chain', arm='main'), False),
    # 维度 4：拓扑
    ('E_mesh', 'topology', 'GasLib-11 meshed core, 5 gas nodes / 4 links (TIME_LIMIT: '
     'lower bound only)',
     ('gaslib11_core_1src', 'synthetic_typical_day', 'official_om_nw', '0.8922',
      'dynamic_line_pack'),
     dict(kind='mesh'), True),
    ('E_ref', 'topology', '2-node chain (declared level)',
     DECLARED, dict(kind='chain', arm='main'), False),
    # 未跑的交叉格：如实 NOT_RUN
    ('X1_ef055_x_heatreal', 'uncovered_cross', 'EF 0.55 x measured heat (chain)',
     ('2node_chain', 'measured_denmark_2019', 'old_0.55', '0.55', 'dynamic_line_pack'),
     dict(kind='absent', why='no such arm was run'), True),   # 独立格，如实计入 n_not_run_cells
    ('X2_ef055_x_steady', 'uncovered_cross', 'EF 0.55 x steady transport (chain)',
     ('2node_chain', 'synthetic_typical_day', 'old_0.55', '0.55', 'steady_transport'),
     dict(kind='absent', why='no such arm was run'), True),   # 独立格，如实计入 n_not_run_cells
    ('X3_heatreal_x_steady', 'uncovered_cross', 'measured heat x steady transport (chain)',
     ('2node_chain', 'measured_denmark_2019', 'official_om_nw', '0.8922',
      'steady_transport'),
     dict(kind='absent', why='no such arm was run'), True),   # 独立格，如实计入 n_not_run_cells
    ('X4_mesh_x_ef055', 'uncovered_cross', 'GasLib-11 meshed core x EF 0.55',
     ('gaslib11_core_1src', 'synthetic_typical_day', 'old_0.55', '0.55',
      'dynamic_line_pack'),
     dict(kind='absent', why='no such mesh cell was run'), True),   # 独立格，如实计入 n_not_run_cells
    ('X5_mesh_x_heatreal', 'uncovered_cross', 'GasLib-11 meshed core x measured heat',
     ('gaslib11_core_1src', 'measured_denmark_2019', 'official_om_nw', '0.8922',
      'dynamic_line_pack'),
     dict(kind='absent', why='no such mesh cell was run'), True),   # 独立格，如实计入 n_not_run_cells
    ('X6_mesh_x_steady', 'uncovered_cross', 'GasLib-11 meshed core x steady transport',
     ('gaslib11_core_1src', 'synthetic_typical_day', 'official_om_nw', '0.8922',
      'steady_transport'),
     dict(kind='absent', why='no such mesh cell was run'), True),   # 独立格，如实计入 n_not_run_cells
]

FLOOR_SUF = {'50': 'ps50', '70': 'ps70', 'b0': 'b0'}


def floor_cols(which):
    s = FLOOR_SUF[which]
    return ['floor_%s_value' % s, 'floor_%s_kind' % s, 'floor_%s_status' % s,
            'floor_%s_status_name' % s, 'floor_%s_gap_pct' % s,
            'floor_%s_gap_authority' % s, 'floor_%s_source' % s]


def floor_block(rec, which):
    if rec is None:
        return dict(zip(floor_cols(which), ('NOT_RUN',) * 7))
    return dict(zip(floor_cols(which), (
        _floor(rec.get('value')), rec.get('kind', 'n/a'),
        'n/a' if rec.get('status') is None else rec['status'],
        rec.get('status_name', 'n/a'), rec.get('gap_pct', NOT_RECORDED),
        rec.get('gap_authority', 'n/a'), rec.get('source', 'n/a'))))


def read_floors(spec, chain, mesh):
    """-> (c50, c70, cb0, bound_role, missing_reason)；None 表示该读数不存在。"""
    kind = spec['kind']
    if kind == 'chain':
        arm = spec['arm']
        c50, c70, cb0 = chain.get((arm, 'PS50')), chain.get((arm, 'PS70')), chain.get((arm, 'B0'))
        if arm == 'steady' and cb0 is None:
            # steady 臂不产 B0 档：B0 无气网、与 gas_model 无关（模型层禁止），
            # 因此沿用 main 的 B0 是恒等操作，不是估值。
            cb0 = dict(chain[('main', 'B0')])
            cb0['source'] = ('%s (arm=main,cfg=B0; B0 has no gas network -> '
                             'gas-model independent by construction)'
                             % os.path.basename(F_SCAN_CARBON))
        return c50, c70, cb0, 'n/a', ''
    if kind == 'nogas':
        cb0 = dict(chain[('main', 'B0')])
        return None, None, cb0, 'identity', (
            'uplift is identically 0.000000: the numerator IS the denominator '
            '(both are the certified B0 optimum); leverage is undefined because an '
            'uncoupled model has no source-pressure bound')
    if kind == 'mesh':
        return mesh.get('M_PS50'), mesh.get('M_PS70'), mesh.get('M_B0'), \
            'bound_lower_only', ''
    return None, None, None, 'n/a', spec.get('why', 'not run')


def derive_rows(chain, mesh):
    """展开成 (格 × 指标) 长表；所有数值现算。"""
    rows = []
    seen = set()
    for cell_id, dimension, level, coords, src, first_flag in CELL_SPECS:
        key = '%s|%s|%s|%s' % (coords[0], coords[1], coords[2], coords[4])
        in_pool = bool(first_flag) and key not in seen
        seen.add(key)
        c50, c70, cb0, bound_role, missing = read_floors(src, chain, mesh)
        for metric in METRICS:
            # 每个指标 = (a - b) / base * 100；base 就是分母口径，写进 DEN_DEF 列
            if metric == 'lever_50_70':
                fa, fb, fbase = c50, c70, c50          # (C50-C70)/C50
            elif metric == 'uplift_ps70':
                fa, fb, fbase = c70, cb0, cb0          # (C70-CB0)/CB0
            else:
                fa, fb, fbase = c50, cb0, cb0          # (C50-CB0)/CB0
            val, basis, certified, direction = None, 'not_run', False, 'n/a'
            reason = missing
            if src['kind'] == 'nogas':
                if metric == 'lever_50_70':
                    basis, direction = 'not_run', 'undefined_without_gas_network'
                else:
                    assert cb0 is not None and cb0.get('value') is not None
                    val = (cb0['value'] - cb0['value']) / cb0['value'] * 100.0
                    basis, certified = 'optimal_point', True
                    direction = 'identity_zero_equals_denominator'
                    reason = ''
            elif all(f is not None and f.get('value') is not None
                     for f in (fa, fb, fbase)):
                val = (fa['value'] - fb['value']) / fbase['value'] * 100.0
                if all(f['kind'] == 'optimal_point' for f in (fa, fb, fbase)):
                    basis, certified, direction = 'optimal_point', True, 'point_value'
                    reason = ''
                else:
                    basis, certified = 'bound_lower', False
                    if metric == 'lever_50_70':
                        direction = 'ratio_of_lower_bounds_NOT_a_bound'
                        reason = ('both floors are TIME_LIMIT lower bounds L(p_s); '
                                  'L(50),L(70) bound (C50-C70)/C50 in neither '
                                  'direction (the mesh incumbents are tied at the '
                                  'zero-flow anchor and cannot cap it either)')
                    else:
                        direction = 'lower_bound_on_metric'
                        reason = ('numerator is a lower bound, denominator is a '
                                  'certified optimum => value is a RIGOROUS lower '
                                  'bound on the metric, with no upper cap available')
            srcs = sorted({r['source'] for r in (c50, c70, cb0) if r}
                          | {os.path.basename(F_SCAN_CARBON),
                             os.path.basename(F_MESH_CELLS)})
            # 退化恒等格：分子就是分母（B0 与自己比），取值是恒等式而非测量值。
            # 标记而不删行 —— 原始值与证据列照写，但不进任何 range 派生。
            degenerate = (direction == 'identity_zero_equals_denominator')
            rows.append(dict(
                cell_id=cell_id, metric=metric, dimension=dimension,
                level_label=level, unique_cell_key=key,
                in_range_pool='True' if in_pool else 'False',
                net=coords[0], heat_load=coords[1], ef_mode=coords[2],
                e_grid=coords[3], gas_model=coords[4],
                source_arm=_txt(src.get('arm', src['kind'])),
                formula=FORMULA[metric], denominator_definition=DEN_DEF[metric],
                value_pct=_pct(val), basis=basis, certified=str(certified),
                bound_role=bound_role, bound_direction=direction,
                degenerate=str(degenerate),
                excluded_from_range=str(degenerate),
                exclusion_reason=(
                    'degenerate identity cell: numerator IS the denominator, so the '
                    'value is 0.000000 by construction and carries no measurement '
                    'information; row kept in the table but excluded from every '
                    'derived range' if degenerate else 'n/a'),
                rigor_note=(reason or
                            'point value: every floor entering it solved to OPTIMAL'),
                missing_reason=(reason or 'n/a'),
                source_files=';'.join(srcs),
                **floor_block(c50, '50'), **floor_block(c70, '70'),
                **floor_block(cb0, 'b0')))
    return rows


# ---------------------------------------------------------------- 取值池与汇总
def pool(rows, metric, want_points):
    """want_points=True -> 只取 certified 点值；False -> 只取界导出值。按格去重。

    **退化恒等格（degenerate=True）两边都不进**：它们的 0.000% 是"B0 与自己比"的
    恒等式，不是测量值；让它们进池就等于把区间下界写成 0.000%。
    """
    out, seen = [], set()
    for r in rows:
        if r['metric'] != metric or r['value_pct'] == 'NOT_RUN':
            continue
        if r['in_range_pool'] != 'True' or r['unique_cell_key'] in seen:
            continue
        if r.get('degenerate') == 'True':
            continue
        is_point = r['basis'] == 'optimal_point' and r['certified'] == 'True'
        if is_point != want_points:
            continue
        seen.add(r['unique_cell_key'])
        out.append(dict(v=float(r['value_pct']), cell_id=r['cell_id'],
                        basis=r['basis'], direction=r['bound_direction'],
                        net=r['net'], level=r['level_label']))
    return out


def degenerate_pool(rows, metric):
    """被排除的退化恒等格（仍留在长表里，只是不进任何 range 派生）。"""
    out, seen = [], set()
    for r in rows:
        if r['metric'] != metric or r['value_pct'] == 'NOT_RUN':
            continue
        if r['in_range_pool'] != 'True' or r['unique_cell_key'] in seen:
            continue
        if r.get('degenerate') != 'True':
            continue
        seen.add(r['unique_cell_key'])
        out.append(dict(v=float(r['value_pct']), cell_id=r['cell_id'],
                        level=r['level_label'], reason=r.get('exclusion_reason', '')))
    return out


def summarize(rows):
    out = []
    for metric in METRICS:
        pts = pool(rows, metric, True)
        bnd = pool(rows, metric, False)
        deg = degenerate_pool(rows, metric)
        n_not_run = sum(1 for r in rows if r['metric'] == metric
                        and r['in_range_pool'] == 'True' and r['value_pct'] == 'NOT_RUN')
        p_lo = min(pts, key=lambda d: d['v']) if pts else None
        p_hi = max(pts, key=lambda d: d['v']) if pts else None
        allv = pts + bnd
        b_lo = min(allv, key=lambda d: d['v']) if allv else None
        b_hi = max(allv, key=lambda d: d['v']) if allv else None
        outside = ['%s = %.3f%% [%s] (%s)' % (d['cell_id'], d['v'], d['direction'],
                                              d['level'])
                   for d in bnd
                   if p_lo and p_hi and not (p_lo['v'] - 1e-12 <= d['v'] <= p_hi['v'] + 1e-12)]
        if p_lo and b_lo:
            diff = ('point span %.3f..%.3f%% (%d certified cells) vs bound-informed '
                    'span %.3f..%.3f%% (%d certified + %d bound-derived cells). '
                    'Widening comes from exactly: %s'
                    % (p_lo['v'], p_hi['v'], len(pts), b_lo['v'], b_hi['v'], len(pts),
                       len(bnd), '; '.join(outside) if outside else
                       'nothing - every bound-derived value falls inside the point '
                       'span, so the two ranges coincide'))
        else:
            diff = 'no certified point value available for this metric'
        if deg:
            diff += ('. Excluded from both spans as degenerate identity cells (rows '
                     'still present in V3_BAND_scan.csv with their raw values): %s'
                     % '; '.join('%s=%.3f%% (%s)' % (d['cell_id'], d['v'], d['level'])
                                 for d in deg))
        uncapped = ('yes: the top end %s is a rigorous LOWER bound on that cell\'s '
                    'metric, so the true value is >= %.3f%% with no upper cap '
                    'available (mesh incumbents unusable)' % (b_hi['cell_id'], b_hi['v'])
                    if b_hi and b_hi['direction'] == 'lower_bound_on_metric'
                    else ('yes-but-weaker: the top end %s is a ratio of two lower '
                          'bounds, i.e. not a bound at all' % b_hi['cell_id']
                          if b_hi and b_hi['direction'].startswith('ratio_of')
                          else 'no'))
        out.append(dict(
            metric=metric, formula=FORMULA[metric],
            denominator_definition=DEN_DEF[metric],
            n_point_cells=len(pts), n_bound_cells=len(bnd), n_not_run_cells=n_not_run,
            n_degenerate_excluded=len(deg),
            degenerate_excluded_cells='; '.join(
                '%s=%s%%' % (d['cell_id'], _pct(d['v'])) for d in deg) or 'none',
            degenerate_excluded_why='; '.join(
                '%s: %s' % (d['cell_id'], d['reason']) for d in deg) or 'none',
            point_value_range_low=_pct(None if not p_lo else p_lo['v']),
            point_value_range_high=_pct(None if not p_hi else p_hi['v']),
            point_low_cell='' if not p_lo else p_lo['cell_id'],
            point_high_cell='' if not p_hi else p_hi['cell_id'],
            point_cells='; '.join('%s=%.3f' % (d['cell_id'], d['v']) for d in pts),
            bound_cells='; '.join('%s=%.3f[%s]' % (d['cell_id'], d['v'], d['direction'])
                                  for d in bnd),
            bound_informed_range_low=_pct(None if not b_lo else b_lo['v']),
            bound_informed_range_high=_pct(None if not b_hi else b_hi['v']),
            bound_informed_low_cell='' if not b_lo else b_lo['cell_id'],
            bound_informed_high_cell='' if not b_hi else b_hi['cell_id'],
            bound_end_uncapped_above=uncapped,
            difference_explained=diff,
        ))
    return out


COLS = (['cell_id', 'metric', 'dimension', 'level_label', 'unique_cell_key',
         'in_range_pool', 'net', 'heat_load', 'ef_mode', 'e_grid', 'gas_model',
         'source_arm', 'formula', 'denominator_definition', 'value_pct', 'basis',
         'certified', 'bound_role', 'bound_direction', 'degenerate',
         'excluded_from_range', 'exclusion_reason', 'rigor_note']
        + floor_cols('50') + floor_cols('70') + floor_cols('b0')
        + ['missing_reason', 'source_files'])
SUM_COLS = ['metric', 'formula', 'denominator_definition', 'n_point_cells',
            'n_bound_cells', 'n_not_run_cells', 'n_degenerate_excluded',
            'degenerate_excluded_cells', 'degenerate_excluded_why',
            'point_value_range_low',
            'point_value_range_high', 'point_low_cell', 'point_high_cell',
            'point_cells', 'bound_cells', 'bound_informed_range_low',
            'bound_informed_range_high', 'bound_informed_low_cell',
            'bound_informed_high_cell', 'bound_end_uncapped_above',
            'difference_explained']


def write_csv(path, rows, cols):
    with io.open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print('[band_scan] wrote %s (%d rows x %d cols)' % (path, len(rows), len(cols)))


# ---------------------------------------------------------------- 自检 ①
TOL_REL = 1e-6      # 打印到 9 位小数，容差留 1e-6 相对余量（变异 +0.5% 仍能翻红）


def check_recompute(rows):
    """① 每个 certified 点值 / 每个界导出值都要能从**另一条**读路径独立复算。"""
    n_pt = n_bd = 0
    base = load_baseline_ps_scan()
    # 前置一致性：B0 无气网，故与拓扑无关 —— 链表和网状表必须给出同一个 B0 地板
    m0 = load_mesh_floors().get('M_B0')
    c0 = load_chain_floors().get(('main', 'B0'))
    if m0 and c0 and abs(m0['value'] - c0['value']) > 1e-9:
        raise AssertionError('两个文件里的 B0 地板不一致: mesh=%r chain=%r，'
                             '网状 uplift 的分母口径不成立' % (m0['value'], c0['value']))
    for r in rows:
        if r['value_pct'] == 'NOT_RUN':
            continue
        want = float(r['value_pct'])
        metric = r['metric']
        if r['basis'] == 'optimal_point' and r['certified'] == 'True':
            if r['gas_model'] == 'none':
                b0 = load_summary_long('B0', 'main')
                if b0 is None or b0['status'] != STATUS_OPTIMAL:
                    raise AssertionError('无气网格：B0 分母在长表里未认证')
                if abs(want) > 1e-12:
                    raise AssertionError('无气网格的 uplift 必须恒 0，得 %r' % want)
                n_pt += 1
                continue
            if r['net'] != '2node_chain':
                raise AssertionError('网状格不该是 certified 点值：%s/%s'
                                     % (r['cell_id'], metric))
            arm = r['source_arm']
            # 分母归属逐臂写死：efold / heatreal 各用**本臂**的 B0（EF、热形状都会
            # 改 B0 地板），只有 steady 复用 main 的 B0（B0 无气网，恒等）。
            b0arm = {'main': 'main', 'efold': 'efold', 'heatreal': 'heatreal',
                     'steady': 'main'}.get(arm)
            if b0arm is None:
                raise AssertionError('未知臂 %r，无法核对分母归属' % arm)
            lo = load_summary_long('PS50', arm)
            hi = load_summary_long('PS70', arm)
            b0 = load_summary_long('B0', b0arm)
            if not (lo and hi and b0):
                raise AssertionError('长表缺失 arm=%s (b0 arm=%s)' % (arm, b0arm))
            for tag, rec in (('ps50', lo), ('ps70', hi), ('b0', b0)):
                if rec['status'] != STATUS_OPTIMAL:
                    raise AssertionError(
                        '%s/%s 长表状态=%s 非 OPTIMAL，却被当成认证点值'
                        % (arm, tag, rec['status']))
                stored = _num(r['floor_%s_value' % tag])
                if stored is None or abs(stored - rec['value']) > 1e-8:
                    raise AssertionError(
                        '%s/%s 行内 floor_%s_value=%r 与本臂长表 %r 不符（分母归属错）'
                        % (r['cell_id'], metric, tag, stored, rec['value']))
            if metric == 'lever_50_70':
                got = (lo['value'] - hi['value']) / lo['value'] * 100.0
            else:
                cur = hi if metric == 'uplift_ps70' else lo
                got = (cur['value'] - b0['value']) / b0['value'] * 100.0
            # 第三读路径 1：Task 4 的 p_s 扫描（main/steady 两臂有盘）
            for tag, ref in (('PS50', lo), ('PS70', hi)):
                alt = base.get((arm, tag))
                if alt is None:
                    continue
                if abs(alt['value'] - ref['value']) > TOL_REL * abs(ref['value']):
                    raise AssertionError('%s/%s 两源不一致 scan=%r baseline=%r'
                                         % (arm, tag, ref['value'], alt['value']))
                if int(alt['status']) != STATUS_OPTIMAL:
                    raise AssertionError('%s/%s baseline 扫描状态非 OPTIMAL' % (arm, tag))
            # 第三读路径 2：全臂汇总表（覆盖 efold / heatreal 的 PS50 与 B0）
            allv = load_all_gc_table()
            for tag, cfg, ref in (('PS50', 'PS50', lo), ('PS70', 'PS70', hi),
                                  ('B0', 'B0', b0)):
                a2 = allv.get((arm, cfg))
                if a2 is None:
                    continue
                if abs(a2 - ref['value']) > 1e-8:
                    raise AssertionError('%s/%s 与 V3_all_gc_summary_table 不一致: '
                                         '%r vs %r' % (arm, tag, ref['value'], a2))
            if abs(got - want) > TOL_REL * max(1.0, abs(want)):
                raise AssertionError('复现失败 %s/%s: 表内 %.12g vs 独立重算 %.12g'
                                     % (r['cell_id'], metric, want, got))
            # 第三源：V3_MESH_verdict.csv 把两节点链的 uplift 也算了一遍（c1_2node_*）
            if r['cell_id'] == 'A_declared' and metric in ('uplift_ps70', 'uplift_ps50'):
                key = 'c1_2node_carbon_distort_pct_' + ('PS70' if metric == 'uplift_ps70'
                                                        else 'PS50')
                ref = _num(load_verdict().get(key))
                if ref is None or abs(ref - got) > 1e-6:
                    raise AssertionError('与第三源 V3_MESH_verdict.%s 不一致: %r vs %r'
                                         % (key, got, ref))
            n_pt += 1
        elif r['basis'] == 'bound_lower':
            if r['net'] != 'gaslib11_core_1src':
                raise AssertionError('unexpected bound_lower row %s' % r['cell_id'])
            mesh = load_mesh_floors()
            L50 = mesh['M_PS50']['lower_bound']
            L70 = mesh['M_PS70']['lower_bound']
            b0 = mesh['M_B0']
            if b0['kind'] != 'optimal_point':
                raise AssertionError('网状 B0 分母不是认证点值，uplift 界无从谈起')
            if metric == 'lever_50_70':
                got = (L50 - L70) / L50 * 100.0
            else:
                cur = L70 if metric == 'uplift_ps70' else L50
                got = (cur - b0['value']) / b0['value'] * 100.0
            if abs(got - want) > TOL_REL * max(1.0, abs(want)):
                raise AssertionError('网状界导出复现失败 %s: %r vs %r'
                                     % (metric, want, got))
            # 行内自带的下界也必须等于 cells 里的下界（防"分母归属错"）
            for tag, ref in (('ps50', L50), ('ps70', L70), ('b0', b0['value'])):
                stored = _num(r['floor_%s_value' % tag])
                if stored is None or abs(stored - ref) > 1e-8:
                    raise AssertionError('%s/%s 行内 floor_%s_value=%r 与 cells 的'
                                         '下界 %r 不符' % (r['cell_id'], metric, tag,
                                                           stored, ref))
            # 第三源：verdict 的 c1_carbon_distort_pct_PSxx 就是同一量（下界基）
            key = ('c1_carbon_distort_pct_PS70' if metric == 'uplift_ps70' else
                   'c1_carbon_distort_pct_PS50')
            if metric != 'lever_50_70':
                ref = _num(load_verdict().get(key))
                if ref is None or abs(ref - got) > 1e-6:
                    raise AssertionError('与第三源 V3_MESH_verdict.%s 不一致: %r vs %r'
                                         % (key, got, ref))
            n_bd += 1
        else:
            raise AssertionError('行 %s/%s 有取值但 basis=%s 既非点值也非界导出，'
                                 '自检覆盖不到' % (r['cell_id'], metric, r['basis']))
    todo = sum(1 for r in rows if r['value_pct'] != 'NOT_RUN')
    if n_pt + n_bd != todo or n_pt < 1 or n_bd < 1:
        raise AssertionError('复现覆盖不全：应核 %d 行，实核 point=%d bound=%d'
                             % (todo, n_pt, n_bd))
    print('[selftest] recompute OK: %d certified point values reproduced from the '
          'per-arm summary long tables (cross-checked against '
          'V3_BASELINE_ps_scan.csv / V3_all_gc_summary_table.csv / '
          'V3_MESH_verdict c1_2node_*) and %d bound-derived values from '
          'V3_MESH_cells.csv (cross-checked against c1_carbon_distort_pct_PS50/PS70)'
          % (n_pt, n_bd))
    return n_pt, n_bd


# ---------------------------------------------------------------- 自检 ②
def check_mesh_excluded(rows):
    """② 网状（只有下界）格**不得**进 point_value_range，也不得与点值混算。"""
    for metric in METRICS:
        pts = pool(rows, metric, True)
        bnd = pool(rows, metric, False)
        for d in pts:
            if d['net'] != '2node_chain' or d['basis'] != 'optimal_point':
                raise AssertionError('%s 的 point 池混进了 %s/%s'
                                     % (metric, d['cell_id'], d['basis']))
        if any(d['net'] == 'gaslib11_core_1src' for d in pts):
            raise AssertionError('%s 的 point 池里出现网状格' % metric)
        # point 段的两个端点都不能恰好等于某个网状界导出值
        for d in (min(pts, key=lambda x: x['v']), max(pts, key=lambda x: x['v'])):
            for b in bnd:
                if abs(b['v'] - d['v']) < 1e-9:
                    raise AssertionError('point 端点 %s 与界导出值 %s 相同 -> 混算'
                                         % (d['cell_id'], b['cell_id']))
    mesh = load_mesh_floors()
    for cell in ('M_PS50', 'M_PS60', 'M_PS70'):
        if cell not in mesh:
            continue
        if mesh[cell]['kind'] == 'optimal_point' or mesh[cell]['status'] == STATUS_OPTIMAL:
            raise AssertionError('%s 状态 %s 竟被判为认证点值' % (cell, mesh[cell]['status_name']))
    s = {row['metric']: row for row in summarize(rows)}
    for metric, row in s.items():
        if row['point_value_range_low'] == 'NOT_RUN':
            continue
        hi = float(row['point_value_range_high'])
        mesh_vals = [float(x['value_pct']) for x in rows
                     if x['net'] == 'gaslib11_core_1src' and x['metric'] == metric
                     and x['value_pct'] != 'NOT_RUN']
        for mv in mesh_vals:
            if mv > hi + 1e-12 and row['bound_informed_range_high'] == 'NOT_RUN':
                raise AssertionError('界导出值 %r 大于 point 上端却没进 bound_informed' % mv)
        if any(abs(mv - hi) < 1e-12 for mv in mesh_vals):
            raise AssertionError('%s: point_value_range_high 恰等于网状界值' % metric)
    print('[selftest] mesh-exclusion OK: no GasLib-11 (bound-only) cell enters any '
          'point_value_range; mesh coupled cells are TIME_LIMIT with lower bounds only')
    return True


# ---------------------------------------------------------------- 自检 ③
def check_degenerate_excluded(rows):
    """③ 退化恒等格（B0 与自己比 = 恒等 0）必须**标记 + 排除**在任何 range 派生之外。

    这条检查存在的理由：`uplift_ps70` 的认证点值区间下界一度写成 0.000%，而它来自
    D_nogas 那格的恒等式，不是测量值。审稿人一句话就能打回。这里同时验证
    (a) 标记与恒等式一一对应，(b) 排除确实改变了答案（0.000 不可能是下界），
    (c) summary 里没有任何 0.000% 型的区间端点。
    """
    # (a) 标记 <-> 恒等式 双向一致；用另一列（exclusion_reason）作独立判据交叉核对
    ident_dir = {r['cell_id'] + '/' + r['metric']
                 for r in rows if r['bound_direction'] == 'identity_zero_equals_denominator'}
    marked = {r['cell_id'] + '/' + r['metric'] for r in rows if r['exclusion_reason'] != 'n/a'}
    flagged = {r['cell_id'] + '/' + r['metric'] for r in rows if r['degenerate'] == 'True'}
    if not (ident_dir == marked == flagged):
        raise AssertionError('degenerate 标记与恒等式不一致: direction=%s flagged=%s '
                             'reason=%s' % (sorted(ident_dir), sorted(flagged), sorted(marked)))
    if not ident_dir:
        raise AssertionError('没有任何退化恒等格被标记 —— 标记逻辑失效（空转）')
    for r in rows:
        if r['degenerate'] != 'True':
            continue
        if r['certified'] != 'True' or r['basis'] != 'optimal_point':
            raise AssertionError('%s/%s 恒等格应仍是 certified 点值（原始值要留在表里）'
                                 % (r['cell_id'], r['metric']))
        if abs(float(r['value_pct'])) > 1e-12:
            raise AssertionError('%s/%s 恒等格取值非 0: %r'
                                 % (r['cell_id'], r['metric'], r['value_pct']))
        if r['in_range_pool'] != 'True':
            raise AssertionError('%s/%s 恒等格该留在池里、只是不进 range' % (r['cell_id'], r['metric']))
    # (b) 排除确实改变了答案
    changed = 0
    for metric in METRICS:
        pts = pool(rows, metric, True)
        bnd = pool(rows, metric, False)
        deg = degenerate_pool(rows, metric)
        ids = {d['cell_id'] for d in deg}
        for name, p in (('point', pts), ('bound', bnd)):
            for d in p:
                if d['cell_id'] in ids or abs(d['v']) < 1e-12:
                    raise AssertionError('%s/%s 恒等格 %s 竟进了 %s 池'
                                         % (metric, d['cell_id'], d['cell_id'], name))
        row = {r['metric']: r for r in summarize(rows)}[metric]
        if not deg:
            continue
        # 恒等格原始值必须仍完整留在长表里（排除 != 删除）
        kept = [r for r in rows if r['metric'] == metric and r['degenerate'] == 'True']
        if len({r['cell_id'] for r in kept}) != len(deg):
            raise AssertionError('%s: 恒等格行被删了（表内 %d 行 / summary 计 %d）'
                                 % (metric, len(kept), len(deg)))
        if int(row['n_degenerate_excluded']) != len(deg):
            raise AssertionError('%s: n_degenerate_excluded 与实际不符' % metric)
        lo = float(row['point_value_range_low'])
        dgap = min(d['v'] for d in deg)
        if not dgap < lo - 1e-12:
            raise AssertionError('%s: 排除恒等格后下界没有变（%r vs %r）—— 排除没生效'
                                 % (metric, dgap, lo))
        # (c) 任何端点都不得是 0.000%
        for col in ('point_value_range_low', 'point_value_range_high',
                    'bound_informed_range_low', 'bound_informed_range_high'):
            v = row[col]
            if v == 'NOT_RUN':
                continue
            if abs(float(v)) < 1e-12:
                raise AssertionError('%s.%s = 0.000%% —— 恒等格混进了区间端点'
                                     % (metric, col))
        changed += 1
    if changed == 0:
        raise AssertionError('没有任何指标因排除恒等格而改变区间，检查是空转的')
    # (d) 落盘的 summary CSV 也必须与现算一致（防"改了脚本没重跑"）
    if os.path.exists(OUT_SUMMARY):
        for srow in _read(OUT_SUMMARY):
            fresh = {r['metric']: r for r in summarize(rows)}[srow['metric']]
            for col in ('point_value_range_low', 'point_value_range_high',
                        'n_point_cells', 'n_degenerate_excluded'):
                if str(srow[col]) != str(fresh[col]):
                    raise AssertionError('盘上 %s 的 %s=%r 与现算 %r 不一致（CSV 未重生成）'
                                         % (os.path.basename(OUT_SUMMARY), col,
                                            srow[col], fresh[col]))
            if srow['point_value_range_low'] not in ('NOT_RUN',) and \
                    abs(float(srow['point_value_range_low'])) < 1e-12:
                raise AssertionError('盘上 %s 的区间下界仍是 0.000%%' % srow['metric'])
    print('[selftest] degenerate-exclusion OK: %d identity row(s) flagged (%s) and kept '
          'in the long table, but excluded from every derived range; no range endpoint '
          'is 0.000%%' % (len(ident_dir), ', '.join(sorted(ident_dir))))
    return True


# ---------------------------------------------------------------- 变异（只在内存）
def apply_mutation(rows, which):
    m = copy.deepcopy(rows)
    if which == 'degenerate_included':
        # 三处标记**一致地**摘掉，模拟"恒等格被当成普通认证点值重新计入区间"，
        # 这样一致性检查 (a) 会通过，逼检查真正落在 range 派生本身（检查 b/c）上。
        hit = [r for r in m if r['degenerate'] == 'True']
        if not hit:
            raise AssertionError('找不到退化恒等格可变异')
        g = hit[0]
        g['degenerate'] = 'False'
        g['excluded_from_range'] = 'False'
        g['exclusion_reason'] = 'n/a'
        g['bound_direction'] = 'point_value'
        print('[mutation] %s/%s 的恒等格标记整体摘掉（三列一致地改成普通点值格，'
              '内存副本，活动 CSV 未改）' % (g['cell_id'], g['metric']))
        return m, 'degenerate-excluded'
    if which == 'degenerate_unflagged':
        # 保留排除（pool 不看这列），但把标记列本身弄错：标记与恒等式必须一一对应
        hit = [r for r in m if r['degenerate'] == 'True'][0]
        hit['bound_direction'] = 'point_value'
        print('[mutation] %s/%s bound_direction identity_* -> point_value（内存副本）'
              % (hit['cell_id'], hit['metric']))
        return m, 'degenerate-excluded'
    if which == 'basis_flip':
        hit = [r for r in m if r['net'] == 'gaslib11_core_1src'
               and r['metric'] == 'lever_50_70']
        if not hit:
            raise AssertionError('找不到网状行可变异')
        hit[0]['basis'], hit[0]['certified'] = 'optimal_point', 'True'
        hit[0]['in_range_pool'] = 'True'
        print('[mutation] %s/%s basis bound_lower -> optimal_point（内存副本，'
              '活动 CSV 未改）' % (hit[0]['cell_id'], hit[0]['metric']))
        return m, 'mesh-excluded'
    if which == 'value_perturb':
        hit = [r for r in m if r['cell_id'] == 'A_declared'
               and r['metric'] == 'lever_50_70'][0]
        orig = float(hit['value_pct'])
        hit['value_pct'] = '%.9f' % (orig * 1.005)
        print('[mutation] %s/%s value %.9f -> %s（+0.5%%，内存副本）'
              % (hit['cell_id'], hit['metric'], orig, hit['value_pct']))
        return m, 'recompute'
    if which == 'b0_swap':
        # 分母归属错：把 heatreal 格的 B0 换成 main 的 B0（EF/热形状都会改 B0 地板）
        hit = next(r for r in m if r['cell_id'] == 'C_heatreal'
                   and r['metric'] == 'uplift_ps70')
        donor = next(r for r in m if r['cell_id'] == 'A_declared'
                     and r['metric'] == 'uplift_ps70')
        new_b0 = float(donor['floor_b0_value'])
        print('[mutation] C_heatreal/uplift_ps70: B0 分母 %s -> %s（借了 main 的 B0，'
              '内存副本）' % (hit['floor_b0_value'], new_b0))
        hit['floor_b0_value'] = '%.10f' % new_b0
        hit['value_pct'] = '%.9f' % ((float(hit['floor_ps70_value']) - new_b0)
                                     / new_b0 * 100.0)
        return m, 'recompute'
    raise AssertionError('未知变异 %s' % which)


# ---------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description='头条百分比的口径带（band scan）')
    ap.add_argument('--selftest', nargs='?', const='all', default=None,
                    choices=['all', 'recompute', 'mesh-excluded', 'degenerate-excluded'],
                    help='自检（期望退出码 0）')
    ap.add_argument('--selftest-mutation', default=None,
                    choices=['basis_flip', 'value_perturb', 'b0_swap',
                             'degenerate_included', 'degenerate_unflagged'],
                    help='变异自检：内存里破坏一项，期望本进程非零退出')
    ap.add_argument('--no-write', action='store_true', help='只派生不落盘')
    args = ap.parse_args(argv)

    chain = load_chain_floors()
    mesh = load_mesh_floors()
    rows = derive_rows(chain, mesh)

    if not args.no_write and args.selftest_mutation is None:
        write_csv(OUT_SCAN, rows, COLS)
        write_csv(OUT_SUMMARY, summarize(rows), SUM_COLS)

    if args.selftest_mutation is None:
        for m in METRICS:
            pts = pool(rows, m, True)
            bnd = pool(rows, m, False)
            allv = pts + bnd
            print('\n== %s ==' % m)
            print('  point_value_range   : %s' % (
                '%.3f%% .. %.3f%% over %d certified cells [%s]'
                % (min(d['v'] for d in pts), max(d['v'] for d in pts), len(pts),
                   ', '.join('%s=%.3f' % (d['cell_id'], d['v']) for d in pts))
                if pts else 'n/a (no certified point)'))
            print('  bound_informed_range: %s' % (
                '%.3f%% .. %.3f%% (+bound-derived: %s)'
                % (min(d['v'] for d in allv), max(d['v'] for d in allv),
                   ', '.join('%s=%.3f[%s]' % (d['cell_id'], d['v'], d['direction'])
                             for d in bnd)) if allv else 'n/a'))
            deg = degenerate_pool(rows, m)
            print('  excluded_degenerate : %s' % (
                ', '.join('%s=%.3f (identity: numerator IS denominator)'
                          % (d['cell_id'], d['v']) for d in deg) if deg else 'none'))

    if args.selftest:
        # 内存里刚派生的行 + （若已落盘）写出去的 CSV 读回来，两条都跑同一套检查
        targets = [('in-memory rows', rows)]
        if os.path.exists(OUT_SCAN):
            targets.append(('written %s' % os.path.basename(OUT_SCAN), _read(OUT_SCAN)))
        for label, rr in targets:
            if args.selftest in ('all', 'recompute'):
                check_recompute(rr)
            if args.selftest in ('all', 'mesh-excluded'):
                check_mesh_excluded(rr)
            if args.selftest in ('all', 'degenerate-excluded'):
                check_degenerate_excluded(rr)
            print('[selftest] %s OK on %s' % (args.selftest, label))
        print('[selftest] PASS (%s)' % args.selftest)
        return 0

    if args.selftest_mutation:
        mrows, target = apply_mutation(rows, args.selftest_mutation)
        print('[selftest] 变异后跑 %s 检查，期望它**变红**' % target)
        if target == 'recompute':
            check_recompute(mrows)
        elif target == 'mesh-excluded':
            check_mesh_excluded(mrows)
        else:
            check_degenerate_excluded(mrows)
        print('[selftest] FAIL: 变异未被抓到 —— 自检是空转的，必须修（退出码 2）')
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
