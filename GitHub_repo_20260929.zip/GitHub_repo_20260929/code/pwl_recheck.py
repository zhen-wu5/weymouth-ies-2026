# -*- coding: utf-8 -*-
"""PWL 系列重检实验：E28 / E29 的 ps=50/60/70 对应物（v3 口径，论文口径对齐用）。

背景：code_v2 的 E28（线性气容物理越限）与 E29（PWL 断点精度）都在 ps=75 bar 单管
确定性口径下生成（experiments_review.py:26: PS, PD_MIN, K_W, A_LP = 75.0, 20.0, 0.00383,
0.15），与论文主轴 ps=50/60/70 bar 两节点 Weymouth+管存（model_gc_v3）不同族。
本文件在 v3 主臂（V3_ARM=main，官方西北 OM=0.8922，甘肃风+甘肃光）上重做：

  E28 对应物（子命令 e28 <ps>）：
    - "线性气容"模型 = model_stoch_v3 的两阶段随机调度 + 逐时总供气上限
      g1+g2 <= F_EQ（无管存、无压力、无压缩机燃料），F_EQ = sqrt(K(ps²-pd_min²))
      取该 ps 下 Weymouth 管道的物理最大流量（对线性模型最有利的设置）。
      结构逐字复制 model_stoch_v3.solve_stoch（mode='cost' 默认分支），
      以 f_cap=None 复现 B0 RP 成本（33933.32765119941）为锚点校验（子命令 validate）。
    - 把线性 RP 方案逐场景的取气轨迹 (g1_t, g2_t) 代回真实两节点 Weymouth+管存
      动力学（等式源：f1=sqrt(K1(ps²-p1²))，f2=sqrt(K2(ps2²-p2²))，ps2=ps，无调压阀；
      与 v2 E28 的 _pd_next 单节点递推同一处理），逐时二分求解节点压力：
        节点2: A2(p2_t-p2_{t-1}) = f2(p2_t) - g2_t
        节点1: A1(p1_t-p1_{t-1}) = f1(p1_t) - (1+r)f2(p2_t) - g1_t
      越限判据：p < pd_min - 1e-4（压力地板取 0 bar 绝对真空；等式源下根恒 <= ps，
      上向越限在物理上不可能，见 PWL_BOOT_notes.md）。
      另做"逐日重复运行"仿真：同一 (g1,g2) 轨迹逐日循环，记录首次越限日前天数
      （管存日末不闭合 => 非可循环运行方案，重复执行迟早越限）。
    - 对照组：Weymouth RP 方案（gate_valve=True，与 gc_run_v3 完全同参）用其
      计划流量 (f1,f2,g1,g2) 做线性管存递推，须逐时复现模型解出的 p1/p2
      （校验递推实现），且日末闭合误差为 0（模型约束 p1cyc/p2cyc）。
    - 成本劣化 = Weymouth RP 期望成本 - 线性 RP 期望成本（同为 8 场景期望，元/日）；
      Weymouth RP 期望成本同时与 V3_GC_PSxx_main_summary.csv 的 rp_exp_cost 交叉核对。

  E29 对应物（子命令 e29，纯数学无 MIP）：
    ps = 50/60/70 下，比较均匀与余弦断点在区间数 20/40/60/120（外加模型默认
    59 区间/60 点）下对精确 sqrt(K(ps²-pd²)) 的最大/平均误差（MW 与占 f_max 百分比），
    密集网格 40001 点（与 v2 E29 同口径）。

用法（每档独立进程，禁止同进程连跑）：
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe pwl_recheck.py validate
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe pwl_recheck.py e28 50
  ... 同理 60 / 70
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe pwl_recheck.py e29
  Y:/cuda/python.exe pwl_recheck.py collect    # 合并 per-ps 汇总 -> PWL_E28_summary.csv

输出（code_v3/results/）：
  PWL_E28_ps{50,60,70}.csv            每档汇总（tidy: ps/item/value）
  PWL_E28_ps{50,60,70}_scen.csv       每档逐场景递推明细
  PWL_E28_summary.csv                 collect 合并
  PWL_E29_accuracy.csv                断点分布 × 区间数 × ps 全网格
不修改任何既有模型文件；不调 MIPGap/TimeLimit（沿用 config_v3 默认）。
"""
import os
import sys

import numpy as np
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

import config_v3 as C
import data_v3 as DP
import model_gc_v3 as MG

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

# ---------------- 气网参数（与 model_gc_v3 / 论文标定值一致，不得改动） ----------------
PD_MIN = 20.0                 # bar
K_W = 0.00383                 # MW²/bar²（标定值）
A1 = 0.075                    # MWh/bar（节点1管存系数；A1+A2=0.15 与论文一致）
A2 = 0.075
COMP_R = 0.02                 # 压缩机燃料率 r
TOL_BAR = 1e-4                # 越限判据容差（与 gc_run_v3 一致）
BISECT_ITERS = 100
MAX_REPEAT_DAYS = 365         # 逐日重复仿真上限
PS_LEVELS = (50.0, 60.0, 70.0)

# 线性模型锚点：f_cap=None 时必须复现 B0 RP 期望成本（V3_GC_B0_main_summary.csv）
ANCHOR_B0_RP_COST = 33933.32765119941


def f_wey(p, K, ps):
    """Weymouth 流量 f = sqrt(K(ps² - p²))；p < 0 时按外延公式继续（供递推地板用）"""
    return float(np.sqrt(max(K * (ps * ps - p * p), 0.0)))


# ================= 线性气容 RP 模型（结构逐字复制 model_stoch_v3.solve_stoch） =================
def solve_linear_gas_rp(data, scenarios=None, f_cap=None,
                        verbose=False, time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP):
    """model_stoch_v3.solve_stoch(mode='cost', risk_lambda=0, allow_shed=True) 的逐字复制，
    唯一增补：f_cap 不为 None 时加逐时线性气容约束 g1+g2 <= f_cap（无管存/压力/压缩机）。
    f_cap=None 时与 B0 完全同构，作为锚点校验（见 validate）。"""
    T = len(data['p_load'])
    dt = 1.0
    S = 1 if scenarios is None else len(scenarios)
    probs = [1.0] if scenarios is None else [sc['prob'] for sc in scenarios]
    wind_avail = [np.asarray(data['wind'], float)] if scenarios is None \
        else [np.asarray(sc['wind'], float) for sc in scenarios]
    pv_avail = [np.asarray(data['pv'], float)] if scenarios is None \
        else [np.asarray(sc['pv'], float) for sc in scenarios]
    p_load_s = [np.asarray(data['p_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('p_load', data['p_load']), float) for sc in scenarios]
    h_load_s = [np.asarray(data['h_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('h_load', data['h_load']), float) for sc in scenarios]
    p_load = np.asarray(data['p_load'], float)
    h_load = np.asarray(data['h_load'], float)
    price = np.asarray(data['price'], float)

    m = gp.Model('IES_lin_gas')
    m.Params.OutputFlag = 1 if verbose else 0
    m.Params.TimeLimit = time_limit
    m.Params.MIPGap = mipgap

    eta_he = C.CHP['eta_h'] / C.CHP['eta_e']
    pmax, pmin = C.CHP['pmax'], C.CHP['pmin_ratio'] * C.CHP['pmax']

    u = m.addVars(T, vtype=GRB.BINARY, name='u')
    y = m.addVars(T, vtype=GRB.BINARY, name='y')
    z = m.addVars(T, vtype=GRB.BINARY, name='z')

    def v(name, ub=GRB.INFINITY):
        return m.addVars(S, T, lb=0, ub=ub, name=name)

    p_wind, p_pv, p_grid, p_chp = v('p_wind'), v('p_pv'), v('p_grid'), v('p_chp')
    p_shed = v('p_shed')
    h_gb = v('h_gb', C.GB['hmax']); h_eb = v('h_eb', C.EB['hmax']); h_hp = v('h_hp', C.HP['hmax'])
    p_c, p_d = v('p_c', C.ESS['pmax']), v('p_d', C.ESS['pmax'])
    soc = m.addVars(S, T, lb=0, name='soc')
    h_c, h_d = v('h_c', C.HSS['pmax']), v('h_d', C.HSS['pmax'])
    hsoc = m.addVars(S, T, lb=0, name='hsoc')

    cost_s, carbon_s = [], []
    for s in range(S):
        for t in range(T):
            m.addConstr(p_chp[s, t] <= pmax * u[t])
            m.addConstr(p_chp[s, t] >= pmin * u[t])
            m.addConstr(p_wind[s, t] <= wind_avail[s][t])
            m.addConstr(p_pv[s, t] <= pv_avail[s][t])
            p_eb = h_eb[s, t] / C.EB['eta']
            p_hp = h_hp[s, t] / C.HP['cop']
            m.addConstr(p_wind[s, t] + p_pv[s, t] + p_chp[s, t] + p_grid[s, t] + p_d[s, t]
                        == p_load_s[s][t] - p_shed[s, t] + p_eb + p_hp + p_c[s, t],
                        name=f'bal_e_{s}_{t}')
            m.addConstr(p_chp[s, t] * eta_he + h_gb[s, t] + h_eb[s, t] + h_hp[s, t] + h_d[s, t]
                        == h_load_s[s][t] + h_c[s, t], name=f'bal_h_{s}_{t}')
            prev_soc = soc[s, t - 1] if t > 0 else C.ESS['soc0'] * C.ESS['cap']
            m.addConstr(soc[s, t] == prev_soc + (C.ESS['eta_c'] * p_c[s, t] - p_d[s, t] / C.ESS['eta_d']) * dt)
            m.addConstr(soc[s, t] <= C.ESS['soc_max'] * C.ESS['cap'])
            m.addConstr(soc[s, t] >= C.ESS['soc_min'] * C.ESS['cap'])
            prev_h = hsoc[s, t - 1] if t > 0 else C.HSS['soc0'] * C.HSS['cap']
            m.addConstr(hsoc[s, t] == prev_h + (C.HSS['eta_c'] * h_c[s, t] - h_d[s, t] / C.HSS['eta_d']) * dt)
            m.addConstr(hsoc[s, t] <= C.HSS['soc_max'] * C.HSS['cap'])
            m.addConstr(hsoc[s, t] >= C.HSS['soc_min'] * C.HSS['cap'])

            g1 = p_chp[s, t] / C.CHP['eta_e']
            g2 = h_gb[s, t] / C.GB['eta']
            if f_cap is not None:
                m.addConstr(g1 + g2 <= f_cap, name=f'gascap_{s}_{t}')

        m.addConstr(soc[s, T - 1] == C.ESS['soc0'] * C.ESS['cap'])
        m.addConstr(hsoc[s, T - 1] == C.HSS['soc0'] * C.HSS['cap'])

        f_chp = [p_chp[s, t] / C.CHP['eta_e'] for t in range(T)]
        f_gb = [h_gb[s, t] / C.GB['eta'] for t in range(T)]
        carbon_s.append(gp.quicksum(
            C.E_GRID * p_grid[s, t] + C.E_GAS * (f_chp[t] + f_gb[t]) for t in range(T)))
        cost_s.append(gp.quicksum(
            price[t] * p_grid[s, t] + C.C_GAS * (f_chp[t] + f_gb[t])
            + 5000.0 * p_shed[s, t]
            + C.CHP['c_om'] * p_chp[s, t] + C.GB['c_om'] * h_gb[s, t]
            + C.EB['c_om'] * h_eb[s, t] + C.HP['c_om'] * h_hp[s, t]
            + C.ESS['c_om'] * (p_c[s, t] + p_d[s, t]) + C.HSS['c_om'] * (h_c[s, t] + h_d[s, t])
            + C.C_OM_WIND * p_wind[s, t] + C.C_OM_PV * p_pv[s, t]
            for t in range(T)))

    for t in range(T):
        for s in range(S):
            up = p_chp[s, t] - (p_chp[s, t - 1] if t > 0 else 0.0)
            m.addConstr(up <= C.CHP['ramp'] + pmax * y[t])
            m.addConstr(-up <= C.CHP['ramp'] + pmax * z[t])
        m.addConstr(y[t] - z[t] == u[t] - (u[t - 1] if t > 0 else 0))

    exp_cost = gp.quicksum(probs[s] * cost_s[s] for s in range(S))
    exp_carbon = gp.quicksum(probs[s] * carbon_s[s] for s in range(S))
    startup = C.CHP['c_startup'] * gp.quicksum(y)
    m.setObjective(exp_cost + startup, GRB.MINIMIZE)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        return None

    scen_rows = []
    for s in range(S):
        sched = pd.DataFrame({
            'wind_avail': wind_avail[s], 'pv_avail': pv_avail[s],
            'p_wind': [p_wind[s, t].X for t in range(T)],
            'p_pv': [p_pv[s, t].X for t in range(T)],
            'p_grid': [p_grid[s, t].X for t in range(T)],
            'p_chp': [p_chp[s, t].X for t in range(T)],
            'u_chp': [u[t].X for t in range(T)],
            'h_gb': [h_gb[s, t].X for t in range(T)],
            'h_eb': [h_eb[s, t].X for t in range(T)],
            'h_hp': [h_hp[s, t].X for t in range(T)],
            'p_load': p_load_s[s], 'h_load': h_load_s[s], 'price': price,
        })
        n_start = int(round(sum(y[t].X for t in range(T))))
        scen_rows.append(dict(
            scenario=s, prob=probs[s],
            op_cost=float(cost_s[s].getValue()),
            startup_cost=C.CHP['c_startup'] * n_start,
            carbon=float(carbon_s[s].getValue()),
            shed_MWh=float(sum(p_shed[s, t].X for t in range(T)) * dt),
            g1=np.array([p_chp[s, t].X / C.CHP['eta_e'] for t in range(T)]),
            g2=np.array([h_gb[s, t].X / C.GB['eta'] for t in range(T)]),
            sched=sched,
        ))

    exp_total_cost = float(exp_cost.getValue()) + C.CHP['c_startup'] * int(round(sum(y[t].X for t in range(T))))
    return dict(
        n_scen=S, f_cap=(np.inf if f_cap is None else float(f_cap)),
        exp_cost=exp_total_cost, exp_carbon=float(exp_carbon.getValue()),
        solve_time=float(m.Runtime), mip_gap=float(m.MIPGap),
        n_vars=int(m.NumVars), n_cons=int(m.NumConstrs), status=int(m.Status),
        scen_rows=scen_rows,
    )


# ================= 物理递推（等式 Weymouth 源，两节点） =================
def _bisect_root(h, lo, hi):
    """h 在 [lo, hi] 单调增且 h(hi) >= 0：返回唯一根（保证 h(lo) <= 0 由调用方判定）"""
    for _ in range(BISECT_ITERS):
        mid = 0.5 * (lo + hi)
        if h(mid) < 0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def simulate_day_eq(g1, g2, ps, p1_0, p2_0):
    """等式 Weymouth 源（无调压阀）下，给定逐时取气 (g1, g2) 的两节点压力递推。

    每小时先解节点2（其平衡只含 p2），再解节点1（f2 由节点2 解出后代入）。
    压力地板取 0 bar（绝对真空）：若根落在 0 以下，取 p=0 并把缺口记为不可交付气量。
    返回逐时轨迹与统计。"""
    ps2 = ps
    p1, p2 = float(p1_0), float(p2_0)
    P1, P2, F1, F2, UD1, UD2 = [], [], [], [], [], []
    for t in range(len(g1)):
        # ---- 节点2: A2(p2-p2p) = f2(p2) - g2 ----
        h2 = lambda p: A2 * (p - p2) - f_wey(p, K_W, ps2) + g2[t]
        if h2(0.0) > 0:                      # 即使降到真空仍供不应求
            p2n, ud2 = 0.0, g2[t] - (f_wey(0.0, K_W, ps2) + A2 * (p2 - 0.0))
        else:
            p2n, ud2 = _bisect_root(h2, 0.0, ps2), 0.0
        f2n = f_wey(p2n, K_W, ps2)
        # ---- 节点1: A1(p1-p1p) = f1(p1) - (1+r) f2 - g1 ----
        h1 = lambda p: A1 * (p - p1) - f_wey(p, K_W, ps) + (1 + COMP_R) * f2n + g1[t]
        if h1(0.0) > 0:
            p1n, ud1 = 0.0, g1[t] + (1 + COMP_R) * f2n - (f_wey(0.0, K_W, ps) + A1 * (p1 - 0.0))
        else:
            p1n, ud1 = _bisect_root(h1, 0.0, ps), 0.0
        f1n = f_wey(p1n, K_W, ps)
        P1.append(p1n); P2.append(p2n); F1.append(f1n); F2.append(f2n)
        UD1.append(max(ud1, 0.0)); UD2.append(max(ud2, 0.0))
        p1, p2 = p1n, p2n
    return dict(p1=np.array(P1), p2=np.array(P2), f1=np.array(F1), f2=np.array(F2),
                undeliv1=np.array(UD1), undeliv2=np.array(UD2),
                p1_end=p1, p2_end=p2, p1_0=float(p1_0), p2_0=float(p2_0))


def day_stats(res, ps):
    pd_min = PD_MIN
    v1 = np.maximum(pd_min - res['p1'], 0.0)
    v2 = np.maximum(pd_min - res['p2'], 0.0)
    return dict(
        viol_h_p1=int((res['p1'] < pd_min - TOL_BAR).sum()),
        viol_h_p2=int((res['p2'] < pd_min - TOL_BAR).sum()),
        max_viol_bar_p1=float(v1.max()), max_viol_bar_p2=float(v2.max()),
        min_p1_bar=float(res['p1'].min()), min_p2_bar=float(res['p2'].min()),
        max_p1_bar=float(res['p1'].max()), max_p2_bar=float(res['p2'].max()),
        p1_at_ps_h=int((res['p1'] >= ps - TOL_BAR).sum()),
        p2_at_ps_h=int((res['p2'] >= ps - TOL_BAR).sum()),
        closure_err_p1_bar=float(res['p1_end'] - res['p1_0']),
        closure_err_p2_bar=float(res['p2_end'] - res['p2_0']),
        undeliv_MWh=float(res['undeliv1'].sum() + res['undeliv2'].sum()),
        gate_gas_MWh=float(res['f1'].sum()),
        comp_fuel_MWh=float(COMP_R * res['f2'].sum()),
    )


def repeat_days_until_violation(g1, g2, ps, max_days=MAX_REPEAT_DAYS):
    """同一取气轨迹逐日重复执行：返回首次出现 p < pd_min-TOL 的日期序号（1 起）；
    若 max_days 日内无越限返回 max_days（并标记 stable）。返回 (days, stable, worst_bar)"""
    p1 = p2 = 0.5 * (PD_MIN + ps)
    worst = 0.0
    for day in range(1, max_days + 1):
        res = simulate_day_eq(g1, g2, ps, p1, p2)
        v = max(float((PD_MIN - res['p1']).max()), float((PD_MIN - res['p2']).max()))
        worst = max(worst, v)
        if (res['p1'] < PD_MIN - TOL_BAR).any() or (res['p2'] < PD_MIN - TOL_BAR).any():
            return day, False, worst
        p1, p2 = res['p1_end'], res['p2_end']
    return max_days, True, worst


def fixed_point_orbit(g1, g2, ps, max_iters=300, tol=1e-8):
    """同一取气轨迹逐日重复执行时压力日映射的不动点（收敛的循环运行轨道）。

    返回 dict：fp_p1/fp_p2（循环初始压力）、residual（日末-日初最大偏差 bar）、
    orbit 内的 min/at-ps/viol 统计。node2 平衡只含 p2（管道2 无阀，轨迹自主），
    故 fp_p2 由 (g2) 唯一决定，与调压阀无关——判据稳健。"""
    p1 = p2 = 0.5 * (PD_MIN + ps)
    res = None
    for _ in range(max_iters):
        res = simulate_day_eq(g1, g2, ps, p1, p2)
        d = max(abs(res['p1_end'] - p1), abs(res['p2_end'] - p2))
        p1, p2 = res['p1_end'], res['p2_end']
        if d < tol:
            break
    # 末一日从不动点出发的完整轨道
    orb = simulate_day_eq(g1, g2, ps, p1, p2)
    v1 = np.maximum(PD_MIN - orb['p1'], 0.0)
    v2 = np.maximum(PD_MIN - orb['p2'], 0.0)
    return dict(
        fp_p1_bar=float(p1), fp_p2_bar=float(p2), residual_bar=float(d),
        fp_min_p1_bar=float(orb['p1'].min()), fp_min_p2_bar=float(orb['p2'].min()),
        fp_max_p1_bar=float(orb['p1'].max()), fp_max_p2_bar=float(orb['p2'].max()),
        fp_viol_h=int(((orb['p1'] < PD_MIN - TOL_BAR) | (orb['p2'] < PD_MIN - TOL_BAR)).sum()),
        fp_at_ps_h=int(((orb['p1'] >= ps - TOL_BAR) | (orb['p2'] >= ps - TOL_BAR)).sum()),
    )


# ================= E28 对应物 =================
def _read_summary_metric(cfg, key):
    fp = os.path.join(RES, f'V3_GC_{cfg}_main_summary.csv')
    df = pd.read_csv(fp)
    row = df.loc[df['metric'] == key]
    return float(row['value'].iloc[0]) if len(row) else np.nan


def e28(ps):
    ps = float(ps)
    assert ps in PS_LEVELS, ps
    tag = int(ps)
    f_eq = float(np.sqrt(K_W * (ps ** 2 - PD_MIN ** 2)))
    print(f'=== E28 对应物 | ps={ps} bar | 线性气容 F_EQ={f_eq:.4f} MW ===')

    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']

    # ---- 线性气容 RP ----
    lin = solve_linear_gas_rp(base, scenarios=reduced, f_cap=f_eq)
    assert lin is not None, '线性气容 RP 不可行'
    print(f"  线性 RP: exp_cost={lin['exp_cost']:.2f} ({lin['solve_time']:.1f}s, "
          f"gap={lin['mip_gap']:.2e}, status={lin['status']})")

    # ---- Weymouth RP（与 gc_run_v3 完全同参：gas_coupled, ps, ps2=ps，其余默认）----
    wey = MG.solve_gc(base, scenarios=reduced, mode='cost',
                      gas_coupled=True, ps=ps, ps2=ps)
    assert wey is not None, 'Weymouth RP 不可行'
    wey_summary = _read_summary_metric(f'PS{tag}', 'rp_exp_cost')
    rel = abs(wey['exp_cost'] - wey_summary) / wey_summary
    print(f"  Weymouth RP: exp_cost={wey['exp_cost']:.2f} ({wey['solve_time']:.1f}s, "
          f"gap={wey['mip_gap']:.2e}, status={wey['status']}) | 汇总表 {wey_summary:.2f} "
          f"(rel diff {rel:.2e})")

    # ---- 对照组：Weymouth 方案的管存线性递推须复现模型解 ----
    ctrl_rows = []
    for r in wey['scen_rows']:
        sc = r['sched']
        f1, f2 = sc['f1'].to_numpy(), sc['f2'].to_numpy()
        g1, g2 = sc['g1_chp'].to_numpy(), sc['g2_gb'].to_numpy()
        p1m, p2m = sc['p1_bar'].to_numpy(), sc['p2_bar'].to_numpy()
        # 反解一阶段初始压力（t=0 平衡）
        p1_0 = p1m[0] - (f1[0] - (1 + COMP_R) * f2[0] - g1[0]) / A1
        p2_0 = p2m[0] - (f2[0] - g2[0]) / A2
        p1r = np.empty(24); p2r = np.empty(24)
        pa, pb = p1_0, p2_0
        for t in range(24):
            pa = pa + (f1[t] - (1 + COMP_R) * f2[t] - g1[t]) / A1
            pb = pb + (f2[t] - g2[t]) / A2
            p1r[t], p2r[t] = pa, pb
        dmax = float(max(np.abs(p1r - p1m).max(), np.abs(p2r - p2m).max()))
        # Weymouth 等式侧核对：计划 f2 与精确 sqrt 在节点压力处的偏差（=PWL 近似误差）
        f2_exact = np.array([f_wey(v, K_W, ps) for v in p2m])
        pwl_gap = float(np.abs(f2 - f2_exact).max())
        ctrl_rows.append(dict(plan='weymouth_control', scenario=r['scenario'], prob=r['prob'],
                              recursion_vs_model_maxdiff_bar=dmax, pwl_f2_vs_exact_MW=pwl_gap))
        s_id = r['scenario']
        print(f"  [ctrl] 场景{s_id}: 递推复现最大偏差 {dmax:.2e} bar, "
              f"PWL f2 vs 精确 sqrt 最大差 {pwl_gap:.4f} MW")

    # ---- 线性方案逐场景物理递推 + 逐日重复 ----
    scen_rows = []
    exp = dict(viol_h_p1=0.0, viol_h_p2=0.0, undeliv=0.0, comp=0.0, gate=0.0, lp_surplus=0.0)
    for r in lin['scen_rows']:
        res = simulate_day_eq(r['g1'], r['g2'], ps, 0.5 * (PD_MIN + ps), 0.5 * (PD_MIN + ps))
        st = day_stats(res, ps)
        days, stable, worst_rep = repeat_days_until_violation(r['g1'], r['g2'], ps)
        fp = fixed_point_orbit(r['g1'], r['g2'], ps)
        row = dict(plan='linear', scenario=r['scenario'], prob=r['prob'], **st)
        row.update(repeat_days_to_violation=(days if not stable else MAX_REPEAT_DAYS),
                   repeat_stable=stable, repeat_worst_viol_bar=worst_rep,
                   op_cost_nominal=r['op_cost'], **fp)
        scen_rows.append(row)
        for k in ('viol_h_p1', 'viol_h_p2'):
            exp[k] += r['prob'] * st[k]
        exp['undeliv'] += r['prob'] * st['undeliv_MWh']
        exp['comp'] += r['prob'] * st['comp_fuel_MWh']
        exp['gate'] += r['prob'] * st['gate_gas_MWh']
        exp['lp_surplus'] += r['prob'] * (A1 * st['closure_err_p1_bar']
                                          + A2 * st['closure_err_p2_bar'])
        print(f"  [linear] 场景{r['scenario']} (p={r['prob']:.3f}): "
              f"越限 p1 {st['viol_h_p1']}h/max {st['max_viol_bar_p1']:.2f} bar, "
              f"p2 {st['viol_h_p2']}h/max {st['max_viol_bar_p2']:.2f} bar, "
              f"闭合误差 p1 {st['closure_err_p1_bar']:+.2f} p2 {st['closure_err_p2_bar']:+.2f} bar, "
              f"循环不动点 p1*={fp['fp_p1_bar']:.2f} p2*={fp['fp_p2_bar']:.2f} "
              f"(残差 {fp['residual_bar']:.1e}, 轨道最低 p2 {fp['fp_min_p2_bar']:.2f}), "
              f"重复运行第 {days} 日越限" + ("（未越限）" if stable else ""))

    # Weymouth 对照的逐场景统计（应全部无越限、闭合误差 0）
    for r in wey['scen_rows']:
        sc = r['sched']
        f1, f2 = sc['f1'].to_numpy(), sc['f2'].to_numpy()
        g1, g2 = sc['g1_chp'].to_numpy(), sc['g2_gb'].to_numpy()
        p1m, p2m = sc['p1_bar'].to_numpy(), sc['p2_bar'].to_numpy()
        p1_0 = p1m[0] - (f1[0] - (1 + COMP_R) * f2[0] - g1[0]) / A1
        p2_0 = p2m[0] - (f2[0] - g2[0]) / A2
        st = dict(
            viol_h_p1=int((p1m < PD_MIN - TOL_BAR).sum()),
            viol_h_p2=int((p2m < PD_MIN - TOL_BAR).sum()),
            max_viol_bar_p1=float(max((PD_MIN - p1m).max(), 0.0)),
            max_viol_bar_p2=float(max((PD_MIN - p2m).max(), 0.0)),
            min_p1_bar=float(p1m.min()), min_p2_bar=float(p2m.min()),
            max_p1_bar=float(p1m.max()), max_p2_bar=float(p2m.max()),
            p1_at_ps_h=int((p1m >= ps - TOL_BAR).sum()),
            p2_at_ps_h=int((p2m >= ps - TOL_BAR).sum()),
            closure_err_p1_bar=float(p1m[-1] - p1_0), closure_err_p2_bar=float(p2m[-1] - p2_0),
            undeliv_MWh=0.0, gate_gas_MWh=float(f1.sum()), comp_fuel_MWh=float(COMP_R * f2.sum()),
        )
        scen_rows.append(dict(plan='weymouth_control', scenario=r['scenario'], prob=r['prob'],
                              **st, repeat_days_to_violation=np.nan, repeat_stable=np.nan,
                              repeat_worst_viol_bar=np.nan, op_cost_nominal=r['op_cost']))

    # ---- 汇总 ----
    probs = np.array([r['prob'] for r in lin['scen_rows']])
    peak_gas = max(float((r['g1'] + r['g2']).max()) for r in lin['scen_rows'])
    degr = wey['exp_cost'] - lin['exp_cost']
    rows = [
        dict(ps=ps, item='linear_f_cap_F_EQ_MW', value=f_eq),
        dict(ps=ps, item='weymouth_f1_max_MW', value=float(wey['f1_max'])),
        dict(ps=ps, item='linear_rp_exp_cost', value=lin['exp_cost']),
        dict(ps=ps, item='wey_rp_exp_cost_inproc', value=wey['exp_cost']),
        dict(ps=ps, item='wey_rp_exp_cost_summary', value=wey_summary),
        dict(ps=ps, item='wey_cost_crosscheck_reldiff', value=rel),
        dict(ps=ps, item='linear_rp_solve_time_s', value=lin['solve_time']),
        dict(ps=ps, item='wey_rp_solve_time_s', value=wey['solve_time']),
        dict(ps=ps, item='linear_rp_mip_gap', value=lin['mip_gap']),
        dict(ps=ps, item='wey_rp_mip_gap', value=wey['mip_gap']),
        dict(ps=ps, item='linear_rp_status', value=lin['status']),
        dict(ps=ps, item='wey_rp_status', value=wey['status']),
        dict(ps=ps, item='linear_peak_total_gas_MW', value=peak_gas),
        dict(ps=ps, item='linear_peak_margin_to_F_EQ_MW', value=f_eq - peak_gas),
        dict(ps=ps, item='linear_viol_h_p1_expected', value=exp['viol_h_p1']),
        dict(ps=ps, item='linear_viol_h_p2_expected', value=exp['viol_h_p2']),
        dict(ps=ps, item='linear_max_viol_bar_p1', value=max(r['max_viol_bar_p1'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_max_viol_bar_p2', value=max(r['max_viol_bar_p2'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_min_p1_bar', value=min(r['min_p1_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_min_p2_bar', value=min(r['min_p2_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_closure_err_p1_bar_mean', value=float(np.mean([r['closure_err_p1_bar'] for r in scen_rows if r['plan'] == 'linear']))),
        dict(ps=ps, item='linear_closure_err_p2_bar_mean', value=float(np.mean([r['closure_err_p2_bar'] for r in scen_rows if r['plan'] == 'linear']))),
        dict(ps=ps, item='linear_undeliv_gas_MWh_day_expected', value=exp['undeliv']),
        dict(ps=ps, item='linear_comp_fuel_ignored_MWh_day_expected', value=exp['comp']),
        dict(ps=ps, item='linear_gate_gas_MWh_day_expected', value=exp['gate']),
        dict(ps=ps, item='linear_repeat_days_to_violation_min', value=min(r['repeat_days_to_violation'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_repeat_all_stable', value=bool(all(r['repeat_stable'] for r in scen_rows if r['plan'] == 'linear'))),
        dict(ps=ps, item='linear_linepack_surplus_MWh_day_expected', value=exp['lp_surplus']),
        dict(ps=ps, item='linear_fp_p1_spread_bar', value=max(r['fp_p1_bar'] for r in scen_rows if r['plan'] == 'linear') - min(r['fp_p1_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_fp_p2_spread_bar', value=max(r['fp_p2_bar'] for r in scen_rows if r['plan'] == 'linear') - min(r['fp_p2_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_fp_common_p0_feasible', value=bool(max(r['fp_p2_bar'] for r in scen_rows if r['plan'] == 'linear') - min(r['fp_p2_bar'] for r in scen_rows if r['plan'] == 'linear') < 1e-6)),
        dict(ps=ps, item='linear_fp_min_p1_bar', value=min(r['fp_min_p1_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_fp_min_p2_bar', value=min(r['fp_min_p2_bar'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_fp_viol_h_total', value=sum(r['fp_viol_h'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='linear_fp_at_ps_h_total', value=sum(r['fp_at_ps_h'] for r in scen_rows if r['plan'] == 'linear')),
        dict(ps=ps, item='wey_ctrl_viol_h_total', value=sum(r['viol_h_p1'] + r['viol_h_p2'] for r in scen_rows if r['plan'] == 'weymouth_control')),
        dict(ps=ps, item='wey_ctrl_max_closure_err_bar', value=max(max(abs(r['closure_err_p1_bar']), abs(r['closure_err_p2_bar'])) for r in scen_rows if r['plan'] == 'weymouth_control')),
        dict(ps=ps, item='wey_ctrl_recursion_maxdiff_bar', value=max(r['recursion_vs_model_maxdiff_bar'] for r in ctrl_rows)),
        dict(ps=ps, item='cost_degradation_cny_per_day', value=degr),
        dict(ps=ps, item='cost_degradation_pct_of_wey', value=100 * degr / wey['exp_cost']),
    ]
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, f'PWL_E28_ps{tag}.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(scen_rows).to_csv(os.path.join(RES, f'PWL_E28_ps{tag}_scen.csv'),
                                   index=False, encoding='utf-8-sig')
    print(f'  -> PWL_E28_ps{tag}.csv / PWL_E28_ps{tag}_scen.csv')
    print(f'  成本劣化（物理可执行溢价）: {degr:.2f} 元/日 ({100 * degr / wey["exp_cost"]:.3f}% of Weymouth RP)')


# ================= E29 对应物（纯数学，无 MIP） =================
def e29():
    print('=== E29 对应物 | PWL 断点分布精度（均匀 vs 余弦） ===')
    n_dense = 40001
    n_ints = [20, 40, 60, 120]
    rows = []
    for ps in PS_LEVELS:
        pd_f = np.linspace(PD_MIN, ps, n_dense)
        f_true = np.sqrt(np.clip(K_W * (ps ** 2 - pd_f ** 2), 0, None))
        f_max = float(np.sqrt(K_W * (ps ** 2 - PD_MIN ** 2)))
        grids = {}
        for n_int in n_ints:
            grids[f'uniform-{n_int}int'] = ('uniform', n_int)
            grids[f'cosine-{n_int}int'] = ('cosine', n_int)
        grids['cosine-59int (model default)'] = ('cosine', 59)   # model_gc_v3: n_pts=60 点
        for tag, (kind, n_int) in grids.items():
            n_pts = n_int + 1
            if kind == 'uniform':
                pts = np.linspace(PD_MIN, ps, n_pts)
            else:
                pts = PD_MIN + (ps - PD_MIN) * (1 - np.cos(np.pi * np.arange(n_pts) / n_int)) / 2
            f_pts = np.sqrt(np.clip(K_W * (ps ** 2 - pts ** 2), 0, None))
            e = np.abs(np.interp(pd_f, pts, f_pts) - f_true)
            imax = int(np.argmax(e))
            rows.append(dict(
                ps=ps, scheme=tag, kind=kind, n_int=n_int, n_pts=n_pts,
                max_abs_err_MW=float(e.max()), mean_abs_err_MW=float(e.mean()),
                max_rel_err_pct=float(100 * e.max() / f_max),
                mean_rel_err_pct=float(100 * e.mean() / f_max),
                err_at_pd_bar=float(pd_f[imax]), f_max_MW=f_max,
            ))
            print(f'  ps={ps:.0f} {tag:28s}: max {e.max():.5f} MW ({100 * e.max() / f_max:6.3f}% of f_max), '
                  f'mean {e.mean():.6f} MW, at pd={pd_f[imax]:.2f} bar')
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, 'PWL_E29_accuracy.csv'), index=False, encoding='utf-8-sig')
    print('  -> PWL_E29_accuracy.csv')

    # 直接回答：60 区间下余弦是否优于均匀（各 ps）
    print('  --- 60 区间对比 ---')
    for ps in PS_LEVELS:
        u = df.loc[(df['ps'] == ps) & (df['scheme'] == 'uniform-60int')].iloc[0]
        c = df.loc[(df['ps'] == ps) & (df['scheme'] == 'cosine-60int')].iloc[0]
        print(f"  ps={ps:.0f}: uniform max {u['max_rel_err_pct']:.3f}% vs cosine {c['max_rel_err_pct']:.3f}% "
              f"(余弦/均匀 = {c['max_abs_err_MW'] / u['max_abs_err_MW']:.3f}); "
              f"mean {u['mean_abs_err_MW']:.6f} vs {c['mean_abs_err_MW']:.6f}")
    # 系统性：全部 ps × 全部区间数下余弦 max/mean 误差是否一律更小
    sys_max, sys_mean = True, True
    for ps in PS_LEVELS:
        for n_int in n_ints:
            u = df.loc[(df['ps'] == ps) & (df['scheme'] == f'uniform-{n_int}int')].iloc[0]
            c = df.loc[(df['ps'] == ps) & (df['scheme'] == f'cosine-{n_int}int')].iloc[0]
            sys_max &= c['max_abs_err_MW'] < u['max_abs_err_MW']
            sys_mean &= c['mean_abs_err_MW'] < u['mean_abs_err_MW']
    print(f'  余弦在全部 ps × 区间数下 max 误差更小: {sys_max}; mean 误差更小: {sys_mean}')


# ================= validate / collect =================
def validate():
    print('=== 锚点校验：线性模型 f_cap=None 须复现 B0 RP 期望成本 ===')
    dat = DP.prepare()
    lin = solve_linear_gas_rp(dat['base'], scenarios=dat['reduced'], f_cap=None)
    assert lin is not None
    rel = abs(lin['exp_cost'] - ANCHOR_B0_RP_COST) / ANCHOR_B0_RP_COST
    print(f"  复现值 {lin['exp_cost']:.9f} vs 锚点 {ANCHOR_B0_RP_COST:.9f} (rel {rel:.2e})")
    ok = rel < 1e-6
    print(f'  锚点校验: {"OK" if ok else "FAIL"}')
    pd.DataFrame([dict(item='anchor_B0_rp_cost_reproduced', value=lin['exp_cost']),
                  dict(item='anchor_B0_rp_cost_reference', value=ANCHOR_B0_RP_COST),
                  dict(item='anchor_rel_diff', value=rel),
                  dict(item='anchor_ok', value=ok)],
                 ).to_csv(os.path.join(RES, 'PWL_E28_anchor_check.csv'),
                          index=False, encoding='utf-8-sig')
    if not ok:
        print('  STOP: 线性模型结构与 model_stoch_v3 不一致，勿采用 e28 结果')
        sys.exit(2)


def collect():
    frames = [pd.read_csv(os.path.join(RES, f'PWL_E28_ps{int(p)}.csv')) for p in PS_LEVELS]
    out = pd.concat(frames, ignore_index=True)
    out.to_csv(os.path.join(RES, 'PWL_E28_summary.csv'), index=False, encoding='utf-8-sig')
    print(f'  -> PWL_E28_summary.csv ({len(out)} rows)')


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    if cmd == 'e28':
        e28(sys.argv[2])
    elif cmd == 'e29':
        e29()
    elif cmd == 'validate':
        validate()
    elif cmd == 'collect':
        collect()
    else:
        print(__doc__)
        sys.exit(1)
    print('done')
