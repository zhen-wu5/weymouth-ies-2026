# -*- coding: utf-8 -*-
"""网状臂诊断驱动（Task 3 · 修复后如实记录用）。

不套 subprocess（R6），单进程内顺序调用 solve_mesh，取两臂的**互补**可行结果：
  · 碳地板/下界/gap/状态  <- 精确 SOC(MIQCP) 臂的 mode='carbon'（allow_shed=False，与主链同口径）
  · RP 期望成本/碳 + 气网诊断(节流/贴界/管存/反向流) <- pwl(binary) MILP 臂的 mode='cost'
两臂都在**冻结 600s / MIPGap 1e-4 / 8 场景**下跑；若 TIME_LIMIT 则如实记 gap/bound，不粉饰。
写 results/V3_MESH_cells.csv（列名与 gc_run_mesh_v3.run_cell 对齐，供 verdict/audit 读取）
与 results/V3_MESH_arms.log。dir_mode 字段显式标注 'hybrid:soc-floor+pwl-rp'，透明可核。
"""
import os
import sys

import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_mesh_v3 as MM
import gc_run_mesh_v3 as GR

RES = GR.RES
HEUR = dict(NoRelHeurTime=150.0, MIPFocus=1, Heuristics=0.5)
ARM_LOG = os.path.join(RES, 'V3_MESH_arms.log')


def log(msg):
    print(msg)
    sys.stdout.flush()
    with open(ARM_LOG, 'a', encoding='utf-8') as fh:
        fh.write(msg + '\n')


def run(cell, ps):
    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']
    net = MM.build_mesh(ps=ps, ps2=ps, pd_min=GR.PD_MIN, K=GR.K_W, A=GR.A_NODE,
                        comp_ratio=GR.COMP_R, single_source=True)
    log(f'\n===== {cell} ps={ps} nodes={len(net["nodes"])} elements={len(net["elements"])} =====')
    # 碳地板 <- SOC
    floor = MM.solve_mesh(base, net, scenarios=reduced, mode='carbon', allow_shed=False,
                          n_pts=GR.N_PTS, gas_coupled=True, dir_mode='soc',
                          time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP, params=HEUR)
    log(f'[{cell}] SOC floor: ' + ('NONE (no feasible @600s)' if floor is None else
        f'incumbent={floor["exp_carbon"]:.5f} bound={floor["obj_bound"]:.5f} '
        f'gap={floor["mip_gap"]:.3f} status={floor["status_name"]} t={floor["solve_time"]:.0f}s'))
    # RP <- pwl(binary) MILP
    rp = MM.solve_mesh(base, net, scenarios=reduced, mode='cost', n_pts=GR.N_PTS,
                       gas_coupled=True, dir_mode='binary',
                       time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP, params=HEUR)
    log(f'[{cell}] pwl RP: ' + ('NONE' if rp is None else
        f'cost={rp["exp_cost"]:.4f} carbon={rp["exp_carbon"]:.4f} '
        f'gap={rp["mip_gap"]:.3f} status={rp["status_name"]} t={rp["solve_time"]:.0f}s'))
    gm = GR.net_metrics(rp['scen_rows'], rp, net) if rp is not None else {}
    fmax_gate = float(sum(e['fmax'] for e in net['elements']
                          if e['kind'] == 'const' and e['id'] in net['purchases'] and 'fmax' in e))
    lp_cap = 0.0 if rp is None else rp['lp_cap']
    row = dict(
        cell=cell, arm=GR.ARM, net=net['name'], e_grid=C.E_GRID, e_grid_mode=C.E_GRID_MODE,
        coupled=True, ps=ps, dir_mode='hybrid:soc-floor+pwl-rp', n_pts=GR.N_PTS,
        pd_min=GR.PD_MIN, A_node=GR.A_NODE, K_pipe=GR.K_W, comp_ratio=GR.COMP_R,
        n_gas_nodes=len(net['nodes']), n_elements=len(net['elements']),
        n_links=sum(1 for e in net['elements'] if e['kind'] == 'link'),
        n_const=sum(1 for e in net['elements'] if e['kind'] == 'const'),
        lp_cap_MWh=lp_cap, gate_deliverability_MWh_h=fmax_gate,
        rp_exp_cost=None if rp is None else rp['exp_cost'],
        rp_exp_carbon=None if rp is None else rp['exp_carbon'],
        rp_solve_time=None if rp is None else rp['solve_time'],
        rp_mip_gap=None if rp is None else rp['mip_gap'],
        rp_status=(-1 if rp is None else int(rp['status'])),
        rp_status_name=('None' if rp is None else rp['status_name']),
        rp_obj_bound=None if rp is None else rp['obj_bound'],
        rp_n_vars=None if rp is None else rp['n_vars'],
        rp_n_cons=None if rp is None else rp['n_cons'],
        rp_n_bin=None if rp is None else rp['n_bin'],
        carbon_min_exp_rp=None if floor is None else floor['exp_carbon'],
        carbon_min_solve_time=None if floor is None else floor['solve_time'],
        carbon_min_mip_gap=None if floor is None else floor['mip_gap'],
        carbon_min_status=(-1 if floor is None else int(floor['status'])),
        carbon_min_status_name=('None' if floor is None else floor['status_name']),
        carbon_min_obj_bound=None if floor is None else floor['obj_bound'],
        single_source=True, gate_purchases=len(net['purchases']),
        eev_exp_cost=np.nan, eev_status=-1, eev_solve_time=np.nan,
    )
    row.update({'gas_' + k: v for k, v in gm.items()})
    GR.append_row(os.path.join(RES, 'V3_MESH_cells.csv'), row, 'cell', cell)
    return row


if __name__ == '__main__':
    cells = [('M_PS50', 50.0), ('M_PS70', 70.0), ('M_PS60', 60.0)]
    if len(sys.argv) > 1:
        only = set(sys.argv[1].split(','))
        cells = [c for c in cells if c[0] in only]
    for cell, ps in cells:
        run(cell, ps)
    log('\nARMS_DIAG_DONE')
