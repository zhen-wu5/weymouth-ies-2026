# -*- coding: utf-8 -*-
"""CAL 探针专用：model_rc_cap.solve_rc_cap 的复制副本（物理参数重校准任务用）。

本文件是 code_v2/model_rc_cap.py 的**逐行复制 + 两处最小改动**（不改原文件）：
  1. scen_rows 增加场景内逐小时电网进口最大值 grid_max_MW 与逐小时序列 grid_profile
     （用于"重校准容量下约束是否咬住"的诊断）。
  2. scen_rows 增加场景碳排 carbon（model_rc_cap 已有，此处保留并在 metrics 汇总
     exp_carbon，便于样本外逐日提取）。

所有开关关闭且 grid_cap=None 时与 model_rc / model_stoch 完全等价
（等价性由 CAL_run.py 的锚点断言校验，协议同 probe_gridcap_run.py / E13 / E32）。
"""
import numpy as np
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

import config_v3 as C


def solve_rc_cap(data, scenarios=None, use_reserve=False, c_res=0.0,
                 risk_lambda=0.0, cvar_beta=0.95, risk_basis='loss',
                 heat_shed=False, voll_e=5000.0, voll_h=5000.0,
                 stage_starts=(0,), u_fix=None, pbar_fix=None,
                 rplus_fix=None, rminus_fix=None, fix_hours=None,
                 min_up=0, min_dn=0, allow_shed=True, grid_cap=None,
                 verbose=False, time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP):
    T = len(data['p_load'])
    dt = 1.0
    stage_starts = tuple(sorted(int(x) for x in stage_starts))
    multi = len(stage_starts) > 1
    S = 1 if scenarios is None else len(scenarios)
    probs = [1.0] if scenarios is None else [sc['prob'] for sc in scenarios]
    wind_avail = [np.asarray(data['wind'], float)] if scenarios is None \
        else [np.asarray(sc['wind'], float) for sc in scenarios]
    pv_avail = [np.asarray(data['pv'], float)] if scenarios is None \
        else [np.asarray(sc['pv'], float) for sc in scenarios]
    p_load_s = [np.asarray(data['p_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('p_load', data['p_load']), float) for sc in scenarios]
    h_load_s = [np.asarray(data['h_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('h_load', data['h_load']), float) for sc in scenarios]
    price = np.asarray(data['price'], float)

    m = gp.Model('IES_rc_cap')
    m.Params.OutputFlag = 1 if verbose else 0
    m.Params.TimeLimit = time_limit
    m.Params.MIPGap = mipgap

    eta_he = C.CHP['eta_h'] / C.CHP['eta_e']
    pmax, pmin = C.CHP['pmax'], C.CHP['pmin_ratio'] * C.CHP['pmax']
    ramp = C.CHP['ramp']

    tree_members, tree_rep, tree_prob = [], [], []
    if multi:
        for k, t0 in enumerate(stage_starts):
            if k == 0:
                sn = [0] * S
                members = {0: list(range(S))}
            else:
                keys, sn = {}, []
                for s in range(S):
                    key = (tuple(np.round(wind_avail[s][:t0], 9)),
                           tuple(np.round(pv_avail[s][:t0], 9)))
                    if key not in keys:
                        keys[key] = len(keys)
                    sn.append(keys[key])
                members = {}
                for s, n in enumerate(sn):
                    members.setdefault(n, []).append(s)
            tree_members.append(members)
            tree_rep.append({n: min(idx) for n, idx in members.items()})
            tree_prob.append({n: sum(probs[s] for s in idx) for n, idx in members.items()})

    def stage_of(t):
        k = 0
        for kk, t0 in enumerate(stage_starts):
            if t >= t0:
                k = kk
        return k

    # ---------- 第一阶段变量 ----------
    if not multi:
        u = m.addVars(T, vtype=GRB.BINARY, name='u')
        y = m.addVars(T, vtype=GRB.BINARY, name='y')
        z = m.addVars(T, vtype=GRB.BINARY, name='z')
        pbar = m.addVars(T, lb=0.0, name='pbar') if use_reserve else None
        rplus = m.addVars(T, lb=0.0, name='rplus') if use_reserve else None
        rminus = m.addVars(T, lb=0.0, name='rminus') if use_reserve else None

        def U(s, t):
            return u[t]

        def Y(s, t):
            return y[t]

        def Z(s, t):
            return z[t]

        def PB(s, t):
            return pbar[t]

        def RP(s, t):
            return rplus[t]

        def RM(s, t):
            return rminus[t]
    else:
        u = {s: m.addVars(T, vtype=GRB.BINARY, name=f'u_{s}') for s in range(S)}
        y = {s: m.addVars(T, vtype=GRB.BINARY, name=f'y_{s}') for s in range(S)}
        z = {s: m.addVars(T, vtype=GRB.BINARY, name=f'z_{s}') for s in range(S)}
        pbar = {s: m.addVars(T, lb=0.0, name=f'pbar_{s}') for s in range(S)} if use_reserve else None
        rplus = {s: m.addVars(T, lb=0.0, name=f'rplus_{s}') for s in range(S)} if use_reserve else None
        rminus = {s: m.addVars(T, lb=0.0, name=f'rminus_{s}') for s in range(S)} if use_reserve else None

        def U(s, t):
            return u[s][t]

        def Y(s, t):
            return y[s][t]

        def Z(s, t):
            return z[s][t]

        def PB(s, t):
            return pbar[s][t]

        def RP(s, t):
            return rplus[s][t]

        def RM(s, t):
            return rminus[s][t]

        n_nac = 0
        for k in range(len(stage_starts)):
            t_lo, t_hi = stage_starts[k], (stage_starts[k + 1] if k + 1 < len(stage_starts) else T)
            for n, idx in tree_members[k].items():
                r = tree_rep[k][n]
                for t in range(t_lo, t_hi):
                    for s in idx:
                        if s == r:
                            continue
                        m.addConstr(u[s][t] == u[r][t], name=f'nac_u_{k}_{n}_{s}_{t}')
                        m.addConstr(y[s][t] == y[r][t], name=f'nac_y_{k}_{n}_{s}_{t}')
                        m.addConstr(z[s][t] == z[r][t], name=f'nac_z_{k}_{n}_{s}_{t}')
                        if use_reserve:
                            m.addConstr(pbar[s][t] == pbar[r][t], name=f'nac_pb_{k}_{n}_{s}_{t}')
                            m.addConstr(rplus[s][t] == rplus[r][t], name=f'nac_rp_{k}_{n}_{s}_{t}')
                            m.addConstr(rminus[s][t] == rminus[r][t], name=f'nac_rm_{k}_{n}_{s}_{t}')
                        n_nac += 1

    if u_fix is not None:
        hours = range(T) if fix_hours is None else list(fix_hours)
        for t in hours:
            m.addConstr(U(0, t) == int(round(u_fix[t])), name=f'ufix_{t}')
    if use_reserve and pbar_fix is not None:
        hours = range(T) if fix_hours is None else list(fix_hours)
        for t in hours:
            m.addConstr(PB(0, t) == float(pbar_fix[t]), name=f'pbfix_{t}')
            m.addConstr(RP(0, t) == float(rplus_fix[t]), name=f'rpfix_{t}')
            m.addConstr(RM(0, t) == float(rminus_fix[t]), name=f'rmfix_{t}')

    for k in range(len(stage_starts)):
        t_lo = stage_starts[k]
        t_hi = stage_starts[k + 1] if k + 1 < len(stage_starts) else T
        node_set = tree_rep[k].keys() if multi else {0}
        for n in node_set:
            s_ref = tree_rep[k][n] if multi else 0
            for t in range(t_lo, t_hi):
                m.addConstr(Y(s_ref, t) - Z(s_ref, t)
                            == U(s_ref, t) - (U(s_ref, t - 1) if t > 0 else 0))
                if min_up > 0:
                    m.addConstr(gp.quicksum(Y(s_ref, tt)
                                for tt in range(max(0, t - min_up + 1), t + 1)) <= U(s_ref, t))
                if min_dn > 0:
                    m.addConstr(gp.quicksum(Z(s_ref, tt)
                                for tt in range(max(0, t - min_dn + 1), t + 1)) <= 1 - U(s_ref, t))
                if use_reserve:
                    m.addConstr(pmin * U(s_ref, t) <= PB(s_ref, t))
                    m.addConstr(PB(s_ref, t) <= pmax * U(s_ref, t))
                    m.addConstr(PB(s_ref, t) + RP(s_ref, t) <= pmax * U(s_ref, t))
                    m.addConstr(PB(s_ref, t) - RM(s_ref, t) >= pmin * U(s_ref, t))
                    prev_pb = PB(s_ref, t - 1) if t > 0 else 0.0
                    m.addConstr(PB(s_ref, t) + RP(s_ref, t) - prev_pb <= ramp + pmax * Y(s_ref, t))
                    m.addConstr(prev_pb - (PB(s_ref, t) - RM(s_ref, t)) <= ramp + pmax * Z(s_ref, t))
                    m.addConstr(RP(s_ref, t) <= ramp * U(s_ref, t) + pmax * Y(s_ref, t))
                    m.addConstr(RM(s_ref, t) <= ramp * U(s_ref, t) + pmax * Z(s_ref, t))

    # ---------- 第二阶段变量（按场景） ----------
    def v(name, ub=GRB.INFINITY):
        return m.addVars(S, T, lb=0, ub=ub, name=name)

    p_wind, p_pv, p_grid, p_chp = v('p_wind'), v('p_pv'), v('p_grid'), v('p_chp')
    if grid_cap is not None:
        for s in range(S):
            for t in range(T):
                m.addConstr(p_grid[s, t] <= float(grid_cap), name=f'gridcap_{s}_{t}')
    p_shed = v('p_shed') if allow_shed else None
    h_shed = v('h_shed') if heat_shed else None
    h_gb = v('h_gb', C.GB['hmax']); h_eb = v('h_eb', C.EB['hmax']); h_hp = v('h_hp', C.HP['hmax'])
    p_c, p_d = v('p_c', C.ESS['pmax']), v('p_d', C.ESS['pmax'])
    soc = m.addVars(S, T, lb=0, name='soc')
    h_c, h_d = v('h_c', C.HSS['pmax']), v('h_d', C.HSS['pmax'])
    hsoc = m.addVars(S, T, lb=0, name='hsoc')

    cost_s, loss_s, carbon_s = [], [], []
    for s in range(S):
        for t in range(T):
            m.addConstr(p_chp[s, t] <= pmax * U(s, t))
            m.addConstr(p_chp[s, t] >= pmin * U(s, t))
            if use_reserve:
                m.addConstr(p_chp[s, t] <= PB(s, t) + RP(s, t))
                m.addConstr(p_chp[s, t] >= PB(s, t) - RM(s, t))
            m.addConstr(p_wind[s, t] <= wind_avail[s][t])
            m.addConstr(p_pv[s, t] <= pv_avail[s][t])
            p_eb = h_eb[s, t] / C.EB['eta']
            p_hp = h_hp[s, t] / C.HP['cop']
            shed_term = p_shed[s, t] if allow_shed else 0
            m.addConstr(p_wind[s, t] + p_pv[s, t] + p_chp[s, t] + p_grid[s, t] + p_d[s, t]
                        == p_load_s[s][t] - shed_term + p_eb + p_hp + p_c[s, t],
                        name=f'bal_e_{s}_{t}')
            h_shed_term = h_shed[s, t] if heat_shed else 0
            m.addConstr(p_chp[s, t] * eta_he + h_gb[s, t] + h_eb[s, t] + h_hp[s, t] + h_d[s, t]
                        == h_load_s[s][t] - h_shed_term + h_c[s, t], name=f'bal_h_{s}_{t}')
            prev_soc = soc[s, t - 1] if t > 0 else C.ESS['soc0'] * C.ESS['cap']
            m.addConstr(soc[s, t] == prev_soc + (C.ESS['eta_c'] * p_c[s, t] - p_d[s, t] / C.ESS['eta_d']) * dt)
            m.addConstr(soc[s, t] <= C.ESS['soc_max'] * C.ESS['cap'])
            m.addConstr(soc[s, t] >= C.ESS['soc_min'] * C.ESS['cap'])
            prev_h = hsoc[s, t - 1] if t > 0 else C.HSS['soc0'] * C.HSS['cap']
            m.addConstr(hsoc[s, t] == prev_h + (C.HSS['eta_c'] * h_c[s, t] - h_d[s, t] / C.HSS['eta_d']) * dt)
            m.addConstr(hsoc[s, t] <= C.HSS['soc_max'] * C.HSS['cap'])
            m.addConstr(hsoc[s, t] >= C.HSS['soc_min'] * C.HSS['cap'])
        m.addConstr(soc[s, T - 1] == C.ESS['soc0'] * C.ESS['cap'])
        m.addConstr(hsoc[s, T - 1] == C.HSS['soc0'] * C.HSS['cap'])

        f_chp = [p_chp[s, t] / C.CHP['eta_e'] for t in range(T)]
        f_gb = [h_gb[s, t] / C.GB['eta'] for t in range(T)]
        carbon_s.append(gp.quicksum(
            C.E_GRID * p_grid[s, t] + C.E_GAS * (f_chp[t] + f_gb[t]) for t in range(T)))
        cost_s.append(gp.quicksum(
            price[t] * p_grid[s, t] + C.C_GAS * (f_chp[t] + f_gb[t])
            + (voll_e * p_shed[s, t] if allow_shed else 0)
            + (voll_h * h_shed[s, t] if heat_shed else 0)
            + C.CHP['c_om'] * p_chp[s, t] + C.GB['c_om'] * h_gb[s, t]
            + C.EB['c_om'] * h_eb[s, t] + C.HP['c_om'] * h_hp[s, t]
            + C.ESS['c_om'] * (p_c[s, t] + p_d[s, t]) + C.HSS['c_om'] * (h_c[s, t] + h_d[s, t])
            + C.C_OM_WIND * p_wind[s, t] + C.C_OM_PV * p_pv[s, t]
            for t in range(T)))
        loss_s.append(gp.quicksum(
            (voll_e * p_shed[s, t] if allow_shed else 0)
            + (voll_h * h_shed[s, t] if heat_shed else 0)
            for t in range(T)))

        for t in range(T):
            up = p_chp[s, t] - (p_chp[s, t - 1] if t > 0 else 0.0)
            m.addConstr(up <= ramp + pmax * Y(s, t))
            m.addConstr(-up <= ramp + pmax * Z(s, t))

    # ---------- 目标 ----------
    if not multi:
        startup = C.CHP['c_startup'] * gp.quicksum(y[t] for t in range(T))
        reserve_cost = (c_res * gp.quicksum(rplus[t] + rminus[t] for t in range(T))) \
            if use_reserve else None
    else:
        st_terms, rc_terms = [], []
        for k in range(len(stage_starts)):
            t_lo = stage_starts[k]
            t_hi = stage_starts[k + 1] if k + 1 < len(stage_starts) else T
            for n, idx in tree_members[k].items():
                r = tree_rep[k][n]
                w = tree_prob[k][n]
                st_terms.append(w * gp.quicksum(y[r][t] for t in range(t_lo, t_hi)))
                if use_reserve:
                    rc_terms.append(w * gp.quicksum(rplus[r][t] + rminus[r][t]
                                                    for t in range(t_lo, t_hi)))
        startup = C.CHP['c_startup'] * gp.quicksum(st_terms)
        reserve_cost = c_res * gp.quicksum(rc_terms) if use_reserve else None

    exp_cost = gp.quicksum(probs[s] * cost_s[s] for s in range(S))
    exp_loss = gp.quicksum(probs[s] * loss_s[s] for s in range(S))

    risk_expr = None
    if risk_lambda > 0:
        eta_v = m.addVar(lb=-GRB.INFINITY, name='eta')
        xi = m.addVars(S, lb=0, name='xi')
        for s in range(S):
            base_expr = loss_s[s] if risk_basis == 'loss' else cost_s[s]
            m.addConstr(xi[s] >= base_expr - eta_v)
        risk_expr = eta_v + gp.quicksum(probs[s] * xi[s] for s in range(S)) / (1 - cvar_beta)

    obj = exp_cost + startup
    if use_reserve:
        obj = obj + reserve_cost
    if risk_lambda > 0:
        obj = obj + risk_lambda * risk_expr
    m.setObjective(obj, GRB.MINIMIZE)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        return None

    def x0(container, t):
        return container[t].X if not multi else container[0][t].X

    u_arr = np.array([round(x0(u, t)) for t in range(T)], dtype=int)
    pbar_arr = np.array([x0(pbar, t) for t in range(T)]) if use_reserve else None
    rplus_arr = np.array([x0(rplus, t) for t in range(T)]) if use_reserve else None
    rminus_arr = np.array([x0(rminus, t) for t in range(T)]) if use_reserve else None

    scen_rows = []
    for s in range(S):
        grid_prof = [float(p_grid[s, t].X) for t in range(T)]
        scen_rows.append(dict(
            scenario=s, prob=probs[s],
            op_cost=float(cost_s[s].getValue()),
            rel_loss=float(loss_s[s].getValue()),
            shed_e_MWh=float(sum(p_shed[s, t].X for t in range(T)) * dt) if allow_shed else 0.0,
            shed_h_MWh=float(sum(h_shed[s, t].X for t in range(T)) * dt) if heat_shed else 0.0,
            shed_e_hours=([float(p_shed[s, t].X) for t in range(T)] if allow_shed else [0.0] * T),
            shed_h_hours=([float(h_shed[s, t].X) for t in range(T)] if heat_shed else [0.0] * T),
            grid_buy_MWh=float(sum(p_grid[s, t].X for t in range(T)) * dt),
            grid_max_MW=float(max(grid_prof)),
            grid_profile=grid_prof,
            re_avail_MWh=float((wind_avail[s] + pv_avail[s]).sum() * dt),
            carbon=float(carbon_s[s].getValue()),
        ))

    startup_val = float(startup.getValue())
    reserve_val = float(reserve_cost.getValue()) if use_reserve else 0.0
    res_MWh = float(sum(rplus_arr) + sum(rminus_arr)) if use_reserve else 0.0
    exp_total = float(exp_cost.getValue()) + startup_val + reserve_val
    exp_carbon = float(sum(probs[s] * scen_rows[s]['carbon'] for s in range(S)))

    metrics = dict(
        exp_cost=exp_total,
        exp_op_cost=float(exp_cost.getValue()),
        startup_cost=startup_val, reserve_cost=reserve_val,
        reserve_rplus_MWh=float(sum(rplus_arr)) if use_reserve else 0.0,
        reserve_rminus_MWh=float(sum(rminus_arr)) if use_reserve else 0.0,
        reserve_total_MWh=res_MWh,
        u=u_arr, pbar=pbar_arr, rplus=rplus_arr, rminus=rminus_arr,
        scen_rows=scen_rows,
        scen_costs=np.array([r['op_cost'] for r in scen_rows]),
        scen_loss=np.array([r['rel_loss'] for r in scen_rows]),
        cvar_risk=(float(risk_expr.getValue()) if risk_expr is not None else None),
        n_scen=S, stage_starts=list(stage_starts),
        tree_shape=([len(mm) for mm in tree_members] if multi else [1]),
        n_nac_eq=(n_nac if multi else 0),
        use_reserve=use_reserve, c_res=c_res, risk_lambda=risk_lambda,
        risk_basis=risk_basis, heat_shed=heat_shed, grid_cap=grid_cap,
        exp_carbon=exp_carbon,
        grid_max_MW=float(max(r['grid_max_MW'] for r in scen_rows)),
        solve_time=float(m.Runtime), mip_gap=float(m.MIPGap),
        n_vars=int(m.NumVars), n_cons=int(m.NumConstrs), status=int(m.Status),
    )
    return metrics
