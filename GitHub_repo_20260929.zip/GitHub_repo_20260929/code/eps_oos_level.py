# -*- coding: utf-8 -*-
"""EPS 单档样本外评价（每档独立进程）：给定一档的一阶段承诺 u，在 100 个测试日上
逐日重调度（u_fix、mode='cost'、allow_shed=False、气网耦合 ps=ps2=70 bar）。

协议与 gc_run_v3.py 的样本外评价一致（265/100 划分 seed=42、u_fix 再调度），
差异仅两点（均为 ε 前沿口径的必然推论，见 EPS_notes.md）：
  1. 每日只解 1 次（该档策略的 u_fix 重调度），不做 EEV/WS 对照；
  2. allow_shed=False——与 ε 前沿的样本内口径一致（切负荷零碳陷阱，见 eps_run_level.py）。
     因此 OOS 的 EENS 恒为 0（结构性为 0，如实记录）。

用法：
  Y:/cuda/python.exe eps_oos_level.py --tag lev01

输出：
  results/EPS_oos_<tag>.csv      逐日记录（成本/碳排/切负荷）
  results/EPS_oossum_<tag>.csv   单行汇总（期望成本、CVaR95、最差日、期望碳排、EENS）
"""
import argparse
import os

import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_gc_v3 as MG

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

PS = 70.0


def cvar_emp(costs, beta):
    costs = np.sort(np.asarray(costs, float))[::-1]
    k = max(1, int(np.ceil((1 - beta) * len(costs))))
    return float(costs[:k].mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', required=True)
    a = ap.parse_args()

    assert C.E_GRID_MODE == 'official_om_nw' and DP.ARM == 'main'

    u = np.load(os.path.join(RES, f'EPS_u_{a.tag}.npy')).astype(int)
    assert len(u) == 24, len(u)

    dat = DP.prepare()
    te, dates = dat['te'], dat['dates']

    rows = []
    n_fail = 0
    for j, i in enumerate(te):
        sc = DP.test_scenario(dat, i)
        r = MG.solve_gc(sc, mode='cost', u_fix=u, gas_coupled=True,
                        ps=PS, ps2=PS, allow_shed=False)
        if r is None:
            n_fail += 1
            rows.append(dict(test_day=dates[i], cost=np.nan, carbon=np.nan, shed_MWh=np.nan))
            print(f'  WARN: 测试日 {dates[i]} 求解失败')
            continue
        sr = r['scen_rows'][0]
        rows.append(dict(test_day=dates[i],
                         cost=float(r['exp_cost']),
                         carbon=float(r['exp_carbon']),
                         shed_MWh=float(sr['shed_MWh']),
                         grid_buy_MWh=float(sr['grid_buy_MWh']),
                         gate_gas_MWh=float(sr['gate_gas_MWh'])))
        if (j + 1) % 20 == 0:
            print(f'  ... {j + 1}/100 测试日完成')

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, f'EPS_oos_{a.tag}.csv'),
              index=False, encoding='utf-8-sig')

    ok = df.dropna(subset=['cost'])
    n = len(ok)
    costs = ok['cost'].to_numpy()
    summ = dict(tag=a.tag, n_days=n, n_fail=n_fail,
                oos_mean_cost=float(costs.mean()) if n else np.nan,
                oos_cvar95=cvar_emp(costs, 0.95) if n else np.nan,
                oos_cvar90=cvar_emp(costs, 0.90) if n else np.nan,
                oos_worst_day=float(costs.max()) if n else np.nan,
                oos_mean_carbon=float(ok['carbon'].mean()) if n else np.nan,
                oos_worst_day_carbon=float(ok['carbon'].max()) if n else np.nan,
                oos_eens_e_MWh_day=float(ok['shed_MWh'].sum() / max(n, 1)),
                oos_n_days_shed=int((ok['shed_MWh'] > 1e-6).sum()) if n else 0,
                oos_mean_grid_MWh=float(ok['grid_buy_MWh'].mean()) if n else np.nan,
                oos_mean_gate_gas_MWh=float(ok['gate_gas_MWh'].mean()) if n else np.nan)
    pd.DataFrame([summ]).to_csv(os.path.join(RES, f'EPS_oossum_{a.tag}.csv'),
                                index=False, encoding='utf-8-sig')
    print(f'[eps_oos_level] {a.tag}: OOS 均值成本 {summ["oos_mean_cost"]:.2f} | '
          f'CVaR95 {summ["oos_cvar95"]:.2f} | 最差日 {summ["oos_worst_day"]:.2f} | '
          f'均值碳排 {summ["oos_mean_carbon"]:.4f} | EENS {summ["oos_eens_e_MWh_day"]:.4f}')


if __name__ == '__main__':
    main()
