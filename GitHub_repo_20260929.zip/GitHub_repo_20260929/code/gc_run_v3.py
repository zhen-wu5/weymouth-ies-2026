# -*- coding: utf-8 -*-
"""code_v3 GC 运行器：新数据层上的两阶段随机调度（可选 Weymouth 气网耦合）重跑主结果。

协议与 code_v2/gc_run.py 完全一致（265 训练/100 测试 seed=42、k=8 k-means seed=0、
Gurobi 13.0.3、MIPGap 1e-4、TimeLimit 600s、u_fix 再调度、WS=逐日完美信息），
仅数据层按 V3_ARM 切换（见 data_v3.py）、排放因子按 E_GRID_MODE 切换（见 config_v3.py）。

用法（每档独立进程，禁止同进程连跑）：
  V3_ARM=main  E_GRID_MODE=official_om_nw Y:/cuda/python.exe gc_run_v3.py B0
  ... 同理 PS50 / PS60 / PS70 / CVAR

Task 4 的方法对方法基线**不另起主链**：它就是本脚本换 V3_ARM 标签——
  V3_ARM=steady Y:/cuda/python.exe gc_run_v3.py PS70      （另有 PS50 / PS60）
'data_v3.ARMS["steady"]' 的数据层与 'main' 逐字节相同（同负荷形状、同风光配对、
同合成热曲线、同 70% 定标、同 seed=42 的 265/100 划分、同 k=8/seed=0 削减），
唯一区别是 gas_model='steady'（气网退化为 Kanelakis 式稳态输送：无管存状态、
无日循环闭合、无 p_0 一阶段变量）。因此两档之间不可能出现口径漂移，
产物为 V3_GC_<cfg>_steady_{summary,oos,gas,structure,plan}.csv。

输出（code_v3/results/）：V3_GC_<cfg>_<arm>_{summary,oos,gas}.csv、
新增 _structure.csv（结构指纹）与 _plan.csv（逐时气网方案 + 节点不平衡残差），
V3_GC_scan_carbon.csv（追加式，含 arm 列）、V3_GC_u_compare_ps70.csv（CVAR 档）。
arm=old 的 B0 档内置锚点断言（须逐位复现旧层 HEP/EEV/VSS），作为移植校验门槛。
"""
import os
import sys
import numpy as np
import pandas as pd

import config_v3 as C
import model_gc_v3 as MG
import data_v3 as DP

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

ANCHOR_EEV = 33941.95756022965
ANCHOR_HEP = 33425.63695664427
ANCHOR_VSS = 516.32060358538538

RISK_LAMBDA = 0.8
CVAR_BETA = 0.95
TOL_BAR = 1e-4
TOL_MW = 1e-4

ARM = DP.ARM
# Task 4：气网物理口径由数据臂决定（'main'/'heatreal'/... -> 'dynamic'；'steady' ->
# 'steady'）。放在模块级，是为了让"同一份运行脚本、同一套协议，只差这一个标签"这件事
# 在代码上无从回避：不存在第二条基线主链可以各走各的划分或场景数。
GAS_MODEL = DP.gas_model()


def cvar_emp(costs, beta):
    costs = np.sort(np.asarray(costs, float))[::-1]
    k = max(1, int(np.ceil((1 - beta) * len(costs))))
    return float(costs[:k].mean())


def cfg_of(cfg):
    if cfg == 'B0':
        return dict(cfg=cfg, coupled=False, ps=None, risk_lambda=0.0)
    if cfg in ('PS50', 'PS60', 'PS70'):
        return dict(cfg=cfg, coupled=True, ps=float(cfg[2:]), risk_lambda=0.0)
    if cfg == 'CVAR':
        return dict(cfg=cfg, coupled=True, ps=70.0, risk_lambda=RISK_LAMBDA)
    raise ValueError(cfg)


def rp_gas_metrics(scen_rows, met):
    ps, ps2, pd_min = met['ps'], met['ps2'], met['pd_min']
    f1max, f2max = met['f1_max'], met['f2_max']
    # 管存容量用**写进约束的有效系数** A_eff，不是几何常数 A。'steady' 档 A_eff=0，
    # 于是 lp_cap=0、lp_util 无定义（不是"利用率为 0%"，是这一层物理根本不在模型里）。
    a1 = met.get('A1_eff', met['A1'])
    a2 = met.get('A2_eff', met['A2'])
    lp_cap = a1 * (ps - pd_min) + a2 * (ps2 - pd_min)
    n = len(scen_rows)
    agg = dict(
        n_obs=n,
        p1_at_min_h=sum(1 for r in scen_rows for v in r['sched']['p1_bar'] if v <= pd_min + TOL_BAR),
        p1_at_max_h=sum(1 for r in scen_rows for v in r['sched']['p1_bar'] if v >= ps - TOL_BAR),
        p2_at_min_h=sum(1 for r in scen_rows for v in r['sched']['p2_bar'] if v <= pd_min + TOL_BAR),
        p2_at_max_h=sum(1 for r in scen_rows for v in r['sched']['p2_bar'] if v >= ps2 - TOL_BAR),
        f1_at_cap_h=sum(1 for r in scen_rows for v in r['sched']['f1'] if v >= f1max - TOL_MW),
        f1_throttle_h=sum(r['f1_throttle_h'] for r in scen_rows),
        f2_at_cap_h=sum(1 for r in scen_rows for v in r['sched']['f2'] if v >= f2max - TOL_MW),
        gate_gas_MWh=float(np.mean([r['gate_gas_MWh'] for r in scen_rows])),
        comp_fuel_MWh=float(np.mean([r['comp_fuel_MWh'] for r in scen_rows])),
        lp_swing_mean=float(np.mean([r['lp_swing'] for r in scen_rows])),
        p1_min_obs=float(min(r['p1_min'] for r in scen_rows)),
        p1_max_obs=float(max(r['p1_max'] for r in scen_rows)),
        p2_min_obs=float(min(r['p2_min'] for r in scen_rows)),
        p2_max_obs=float(max(r['p2_max'] for r in scen_rows)),
        f1_peak_obs=float(max(r['f1_max'] for r in scen_rows)),
        f2_peak_obs=float(max(r['f2_max'] for r in scen_rows)),
        # ---- 管存"到底用没用到"：从解里的逐时残差算，不看变量名、不看标签 ----
        store_h_total=int(sum(r['store_h'] for r in scen_rows)),
        store_h_max_abs_res=float(max(r['max_res_abs_h'] for r in scen_rows)),
        lp_used_MWh_mean=float(np.mean([r['lp_used_MWh'] for r in scen_rows])),
        day_end_imbal_max_abs=float(max(abs(r['day_end_imbalance_MWh']) for r in scen_rows)),
        hours_total=n * 24,
    )
    agg['lp_util_pct'] = (100 * agg['lp_swing_mean'] / lp_cap) if lp_cap > 0 else float('nan')
    agg['comp_share_pct'] = 100 * agg['comp_fuel_MWh'] / max(agg['gate_gas_MWh'], 1e-9)
    return agg


def run(cfg):
    kw = cfg_of(cfg)
    dat = DP.prepare()
    te, dates = dat['te'], dat['dates']
    base, reduced = dat['base'], dat['reduced']
    coupled, ps = kw['coupled'], kw['ps']

    model_kw = dict(gas_coupled=coupled)
    if coupled:
        model_kw.update(ps=ps, ps2=ps, gas_model=GAS_MODEL)

    # ---------- EEV 与 SP ----------
    exp_sc = DP.expected_scenario(dat)
    eev = MG.solve_gc(exp_sc, mode='cost', **model_kw)
    assert eev is not None, 'EEV 不可行'
    u_eev = eev['scen_rows'][0]['sched']['u_chp'].to_numpy()

    sp = MG.solve_gc(base, scenarios=reduced, mode='cost',
                     risk_lambda=kw['risk_lambda'], cvar_beta=CVAR_BETA, **model_kw)
    assert sp is not None, 'SP 不可行'
    u_sp = sp['scen_rows'][0]['sched']['u_chp'].to_numpy()
    policy_name = 'SC-CVaR' if kw['risk_lambda'] > 0 else 'SC'
    if coupled:
        f1max, f2max = sp['f1_max'], sp['f2_max']
        ps_, ps2_, pdmin_ = sp['ps'], sp['ps2'], sp['pd_min']
        a1_, a2_ = sp.get('A1_eff', sp['A1']), sp.get('A2_eff', sp['A2'])
        lp_cap = a1_ * (ps_ - pdmin_) + a2_ * (ps2_ - pdmin_)

    # ---------- 最小碳排 RP（carbon 模式，allow_shed=False，旧口径保留） ----------
    carb = MG.solve_gc(base, scenarios=reduced, mode='carbon', allow_shed=False, **model_kw)
    carbon_min_exp = float(carb['exp_carbon']) if carb is not None else np.nan
    carbon_min_status = int(carb['status']) if carb is not None else -1
    carbon_min_time = float(carb['solve_time']) if carb is not None else np.nan

    # ---------- 样本外评价（100 测试日）+ WS ----------
    rows = []
    for j, i in enumerate(te):
        sc = DP.test_scenario(dat, i)
        r_e = MG.solve_gc(sc, mode='cost', u_fix=u_eev, **model_kw)
        r_s = MG.solve_gc(sc, mode='cost', u_fix=u_sp, **model_kw)
        ws = MG.solve_gc(sc, mode='cost', **model_kw)
        if r_e is None or r_s is None or ws is None:
            print(f'  WARN: 测试日 {dates[i]} 求解失败 '
                  f'(eev={r_e is None}, sp={r_s is None}, ws={ws is None})')
            rows.append(dict(test_day=dates[i],
                             cost_eev=np.nan, cost_sp=np.nan, cost_ws=np.nan,
                             fail_eev=r_e is None, fail_sp=r_s is None,
                             fail_ws=ws is None))
            continue
        se, ss = r_e['scen_rows'][0], r_s['scen_rows'][0]
        row = dict(
            test_day=dates[i],
            cost_eev=float(r_e['exp_cost']), cost_sp=float(r_s['exp_cost']),
            cost_ws=float(ws['exp_cost']),
            fail_eev=False, fail_sp=False, fail_ws=False,
            shed_e_eev=float(se['shed_MWh']),
            shed_e_sp=float(ss['shed_MWh']),
            carbon_eev=float(r_e['exp_carbon']), carbon_sp=float(ss['carbon']),
            grid_eev=float(se['grid_buy_MWh']),
            grid_sp=float(ss['grid_buy_MWh']),
        )
        if coupled:
            sched_s = ss['sched']
            row.update(
                gate_gas_sp=ss['gate_gas_MWh'], comp_fuel_sp=ss['comp_fuel_MWh'],
                p1_min=ss['p1_min'], p1_max=ss['p1_max'],
                p2_min=ss['p2_min'], p2_max=ss['p2_max'],
                f1_max=ss['f1_max'], f2_max=ss['f2_max'],
                lp1_swing=ss['lp1_swing'], lp2_swing=ss['lp2_swing'],
                lp_swing=ss['lp_swing'],
                p1_at_min_h=int(sum(1 for v in sched_s['p1_bar'] if v <= pdmin_ + TOL_BAR)),
                p1_at_max_h=int(sum(1 for v in sched_s['p1_bar'] if v >= ps_ - TOL_BAR)),
                p2_at_min_h=int(sum(1 for v in sched_s['p2_bar'] if v <= pdmin_ + TOL_BAR)),
                p2_at_max_h=int(sum(1 for v in sched_s['p2_bar'] if v >= ps2_ - TOL_BAR)),
                f1_at_cap_h=int(sum(1 for v in sched_s['f1'] if v >= f1max - TOL_MW)),
                f1_throttle_h=int(ss['f1_throttle_h']),
                f2_at_cap_h=int(sum(1 for v in sched_s['f2'] if v >= f2max - TOL_MW)),
                # 管存是否真被使用（逐时残差判据）与日末闭合缺口（MWh → bar 由下游换算）
                store_h=int(ss['store_h']),
                max_res_abs_h=float(ss['max_res_abs_h']),
                lp_used_MWh=float(ss['lp_used_MWh']),
                day_end_imbal_MWh=float(ss['day_end_imbalance_MWh']),
            )
        rows.append(row)
        if (j + 1) % 20 == 0:
            print(f'  ... {j + 1}/100 测试日完成')
    df = pd.DataFrame(rows)
    ok = df.dropna(subset=['cost_eev', 'cost_sp', 'cost_ws'])
    n = len(ok)
    costs_e = ok['cost_eev'].to_numpy()
    costs_s = ok['cost_sp'].to_numpy()
    costs_w = ok['cost_ws'].to_numpy()

    summary = [
        dict(metric='cfg', value=kw['cfg'], unit=''),
        dict(metric='arm', value=ARM, unit=''),
        dict(metric='e_grid_mode', value=C.E_GRID_MODE, unit=''),
        dict(metric='e_grid', value=C.E_GRID, unit='tCO2/MWh'),
        dict(metric='gas_coupled', value=coupled, unit=''),
        # ---- Task 4 口径标签：气网物理档 + 写进约束的有效管存系数 ----
        dict(metric='gas_model', value=(GAS_MODEL if coupled else 'n/a (no gas network)'),
             unit=''),
        dict(metric='A1_eff_MWh_per_bar', value=(sp['A1_eff'] if coupled else np.nan), unit='MWh/bar'),
        dict(metric='A2_eff_MWh_per_bar', value=(sp['A2_eff'] if coupled else np.nan), unit='MWh/bar'),
        dict(metric='A1_frozen_geometry', value=(sp['A1'] if coupled else np.nan), unit='MWh/bar'),
        dict(metric='A2_frozen_geometry', value=(sp['A2'] if coupled else np.nan), unit='MWh/bar'),
        dict(metric='n_pts_frozen', value=(sp['n_pts'] if coupled else np.nan), unit=''),
        dict(metric='comp_ratio_frozen', value=(sp['comp_ratio'] if coupled else np.nan), unit=''),
        dict(metric='K_frozen', value=(sp['K1'] if coupled else np.nan), unit=''),
        dict(metric='pd_min_frozen', value=(sp['pd_min'] if coupled else np.nan), unit='bar'),
        dict(metric='gate_valve_on', value=(bool(sp['gate_valve']) if coupled else False), unit=''),
        dict(metric='p0_mode_eff', value=(sp['p0_mode'] if coupled else 'n/a'), unit=''),
        dict(metric='ps_bar', value=ps if coupled else np.nan, unit='bar'),
        dict(metric='ps2_bar', value=ps if coupled else np.nan, unit='bar'),
        dict(metric='risk_lambda', value=kw['risk_lambda'], unit=''),
        dict(metric='n_test_days', value=n, unit=''),
        dict(metric='policy', value=policy_name, unit=''),
        dict(metric='oos_mean_cost_sp', value=float(costs_s.mean()), unit='元'),
        dict(metric='oos_mean_cost_eev', value=float(costs_e.mean()), unit='元'),
        dict(metric='vss_eev_minus_sp', value=float(costs_e.mean() - costs_s.mean()), unit='元'),
        dict(metric='ws_mean_cost', value=float(costs_w.mean()), unit='元'),
        dict(metric='evpi_eev_minus_ws', value=float(costs_e.mean() - costs_w.mean()), unit='元'),
        dict(metric='oos_cvar95_sp', value=cvar_emp(costs_s, 0.95), unit='元'),
        dict(metric='oos_cvar95_eev', value=cvar_emp(costs_e, 0.95), unit='元'),
        dict(metric='oos_cvar90_sp', value=cvar_emp(costs_s, 0.90), unit='元'),
        dict(metric='oos_cvar90_eev', value=cvar_emp(costs_e, 0.90), unit='元'),
        dict(metric='oos_worst_day_sp', value=float(costs_s.max()), unit='元'),
        dict(metric='oos_worst_day_eev', value=float(costs_e.max()), unit='元'),
        dict(metric='oos_eens_e_sp_MWh_day', value=float(ok['shed_e_sp'].sum() / n), unit='MWh/日'),
        dict(metric='oos_eens_e_eev_MWh_day', value=float(ok['shed_e_eev'].sum() / n), unit='MWh/日'),
        dict(metric='oos_eens_h_sp_MWh_day', value=0.0, unit='MWh/日'),
        dict(metric='oos_n_days_shed_sp', value=int((ok['shed_e_sp'] > 1e-6).sum()), unit='天'),
        dict(metric='oos_n_days_shed_eev', value=int((ok['shed_e_eev'] > 1e-6).sum()), unit='天'),
        dict(metric='oos_mean_carbon_sp', value=float(ok['carbon_sp'].mean()), unit='tCO2/日'),
        dict(metric='oos_mean_carbon_eev', value=float(ok['carbon_eev'].mean()), unit='tCO2/日'),
        dict(metric='oos_mean_grid_sp', value=float(ok['grid_sp'].mean()), unit='MWh/日'),
        dict(metric='oos_mean_grid_eev', value=float(ok['grid_eev'].mean()), unit='MWh/日'),
        dict(metric='rp_exp_cost', value=float(sp['exp_cost']), unit='元'),
        dict(metric='rp_exp_carbon', value=float(sp['exp_carbon']), unit='tCO2'),
        dict(metric='rp_n_vars', value=int(sp['n_vars']), unit=''),
        dict(metric='rp_n_cons', value=int(sp['n_cons']), unit=''),
        dict(metric='rp_solve_time', value=float(sp['solve_time']), unit='s'),
        dict(metric='rp_mip_gap', value=float(sp['mip_gap']), unit=''),
        dict(metric='rp_status', value=int(sp['status']), unit=''),
        dict(metric='rp_cvar_model', value=(float(sp['cvar_model'])
                                            if sp.get('cvar_model') is not None else np.nan), unit='元'),
        dict(metric='eev_n_vars', value=int(eev['n_vars']), unit=''),
        dict(metric='eev_solve_time', value=float(eev['solve_time']), unit='s'),
        dict(metric='eev_mip_gap', value=float(eev['mip_gap']), unit=''),
        dict(metric='carbon_min_exp_rp', value=carbon_min_exp, unit='tCO2'),
        dict(metric='carbon_min_rp_status', value=carbon_min_status, unit=''),
        dict(metric='carbon_min_rp_time', value=carbon_min_time, unit='s'),
    ]

    # 移植校验门槛：arm=old + B0 必须逐位复现旧层锚点
    if ARM == 'old' and kw['cfg'] == 'B0':
        rel_h = abs(costs_s.mean() - ANCHOR_HEP) / ANCHOR_HEP
        rel_e = abs(costs_e.mean() - ANCHOR_EEV) / ANCHOR_EEV
        vss = costs_e.mean() - costs_s.mean()
        rel_v = abs(vss - ANCHOR_VSS) / ANCHOR_VSS
        summary += [
            dict(metric='anchor_HEP_diff_rel', value=rel_h, unit=''),
            dict(metric='anchor_EEV_diff_rel', value=rel_e, unit=''),
            dict(metric='anchor_VSS_diff_rel', value=rel_v, unit=''),
        ]
        ok_all = rel_h < 1e-9 and rel_e < 1e-9 and rel_v < 1e-9
        print(f'[anchor old/B0] HEP {costs_s.mean():.9f} vs {ANCHOR_HEP:.9f} (rel {rel_h:.2e})')
        print(f'[anchor old/B0] EEV {costs_e.mean():.9f} vs {ANCHOR_EEV:.9f} (rel {rel_e:.2e})')
        print(f'[anchor old/B0] VSS {vss:.9f} vs {ANCHOR_VSS:.9f} (rel {rel_v:.2e})')
        print(f'[anchor old/B0] 逐位复现: {"OK" if ok_all else "FAIL"}')
        if not ok_all:
            pd.DataFrame(summary).to_csv(
                os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_summary.csv'),
                index=False, encoding='utf-8-sig')
            print('STOP: 移植未逐位复现旧层基准，不要采用后续结果')
            sys.exit(2)

    # 气网侧指标
    if coupled:
        gcols = ['test_day', 'gate_gas_sp', 'comp_fuel_sp', 'p1_min', 'p1_max',
                 'p2_min', 'p2_max', 'f1_max', 'f2_max', 'lp1_swing', 'lp2_swing',
                 'p1_at_min_h', 'p1_at_max_h', 'p2_at_min_h', 'p2_at_max_h',
                 'f1_at_cap_h', 'f2_at_cap_h', 'f1_throttle_h',
                 'store_h', 'max_res_abs_h', 'lp_used_MWh', 'day_end_imbal_MWh']
        df[[c for c in gcols if c in df.columns]].to_csv(
            os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_gas.csv'),
            index=False, encoding='utf-8-sig')
        n_h = 24 * n
        gm_oos = dict(
            n_days=n,
            p1_at_min_h=int(ok['p1_at_min_h'].sum()), p1_at_max_h=int(ok['p1_at_max_h'].sum()),
            p2_at_min_h=int(ok['p2_at_min_h'].sum()), p2_at_max_h=int(ok['p2_at_max_h'].sum()),
            f1_at_cap_h=int(ok['f1_at_cap_h'].sum()), f2_at_cap_h=int(ok['f2_at_cap_h'].sum()),
            f1_throttle_h=int(ok['f1_throttle_h'].sum()),
            hours_total=n_h,
            gate_gas_MWh_day=float(ok['gate_gas_sp'].mean()),
            comp_fuel_MWh_day=float(ok['comp_fuel_sp'].mean()),
            lp_swing_mean_MWh=float(ok['lp_swing'].mean()),
            # 'steady' 档 lp_cap=0：不是"利用率 0%"，是这一层物理不在模型里。
            # 写成 inf/0% 都会误导，直接给 NaN 并落一行原因。
            lp_util_pct=(float(100 * ok['lp_swing'].mean() / lp_cap)
                         if lp_cap > 0 else float('nan')),
            lp_util_na_reason=('' if lp_cap > 0 else
                               'no line-pack state in this arm (A_eff=0); the '
                               'pressure-band swing is a solver-artifact here, not '
                               'a storage utilisation'),
            p1_min_obs=float(ok['p1_min'].min()), p1_max_obs=float(ok['p1_max'].max()),
            p2_min_obs=float(ok['p2_min'].min()), p2_max_obs=float(ok['p2_max'].max()),
            f1_peak_obs=float(ok['f1_max'].max()), f2_peak_obs=float(ok['f2_max'].max()),
            f1_max_cap=float(f1max), f2_max_cap=float(f2max),
            store_h_total=int(ok['store_h'].sum()),
            store_h_max_abs_res=float(ok['max_res_abs_h'].max()),
            lp_used_MWh_mean=float(ok['lp_used_MWh'].mean()),
            day_end_imbal_MWh_max_abs=float(ok['day_end_imbal_MWh'].abs().max()),
            # 日末压力闭合缺口（bar）= 日末残余 MWh / 有效管存系数；无管存档无定义
            day_end_closure_bar_mean=float(
                (ok['day_end_imbal_MWh'].abs() / lp_cap).mean()) if lp_cap > 0 else float('nan'),
            day_end_closure_bar_max=float(
                (ok['day_end_imbal_MWh'].abs() / lp_cap).max()) if lp_cap > 0 else float('nan'),
            lp_cap_eff_MWh=float(lp_cap),
        )
        gm_oos['comp_share_pct'] = 100 * gm_oos['comp_fuel_MWh_day'] / max(gm_oos['gate_gas_MWh_day'], 1e-9)
        summary += [dict(metric='gas_oos_' + k, value=v, unit='')
                    for k, v in gm_oos.items()]
        gm_rp = rp_gas_metrics(sp['scen_rows'], sp)
        summary += [dict(metric='gas_rp_' + k, value=v, unit='') for k, v in gm_rp.items()]

    pd.DataFrame(summary).to_csv(os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_summary.csv'),
                                 index=False, encoding='utf-8-sig')
    df.to_csv(os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_oos.csv'),
              index=False, encoding='utf-8-sig')

    # ---------- Task 4 取证面：结构指纹 + 逐时气网方案 ----------
    # structure.csv 是"约束/变量长什么样"的直接抄录（ optimize 前采集），P 节据此
    # 判定基线到底删了哪一层，而不是读任何人的措辞。
    # plan.csv 带 res1/res2（逐时节点不平衡），P 节据此从**解**里复核"管存有没有被用"。
    if coupled:
        st = sp['struct']
        srows = [('model_scalar', k, v) for k, v in sorted(st.items()) if k != 'fams']
        srows += [('constr_family', k, v) for k, v in sorted(st['fams'].items())]
        pd.DataFrame(srows, columns=['level', 'key', 'value']).to_csv(
            os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_structure.csv'),
            index=False, encoding='utf-8-sig')
        pl = []
        for r in sp['scen_rows']:
            sch = r['sched']
            pl.append(pd.DataFrame(dict(
                scenario=r['scenario'], prob=r['prob'], hour=range(len(sch)),
                p1_bar=sch['p1_bar'], p2_bar=sch['p2_bar'],
                f1=sch['f1'], f1_ub=sch['f1_ub'], f2=sch['f2'],
                g1_chp=sch['g1_chp'], g2_gb=sch['g2_gb'], comp_fuel=sch['comp_fuel'],
                lp1=sch['lp1'], lp2=sch['lp2'],
                res1=r['res1'], res2=r['res2'],
                cost_s=r['op_cost'], carbon_s=r['carbon'])))
        pd.concat(pl, ignore_index=True).to_csv(
            os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_plan.csv'),
            index=False, encoding='utf-8-sig')
        print(f'[struct {kw["cfg"]}/{ARM}] n_cons={st["n_cons"]} n_vars={st["n_vars"]} '
              f'bin={st["n_binaries"]} node1={st["n_node1"]} node2={st["n_node2"]} '
              f'p1cyc={st["n_p1cyc"]} p2cyc={st["n_p2cyc"]} '
              f'steady_node1={st["n_steady_node1"]} p1_0={st["has_p0_1"]}')

    # carbon 扫描行（追加式，含 arm）
    scan_row = dict(cfg=kw['cfg'], arm=ARM, e_grid_mode=C.E_GRID_MODE, e_grid=C.E_GRID,
                    gas_coupled=coupled, ps=ps, ps2=ps,
                    carbon_min_exp_rp=carbon_min_exp,
                    carbon_min_rp_status=carbon_min_status,
                    carbon_min_rp_time=carbon_min_time,
                    rp_exp_carbon=float(sp['exp_carbon']),
                    oos_mean_carbon_sp=float(ok['carbon_sp'].mean()),
                    oos_mean_carbon_eev=float(ok['carbon_eev'].mean()))
    scan_path = os.path.join(RES, 'V3_GC_scan_carbon.csv')
    if os.path.exists(scan_path):
        old = pd.read_csv(scan_path)
        old = old[~((old['cfg'] == kw['cfg']) & (old['arm'] == ARM))]
        pd.concat([old, pd.DataFrame([scan_row])], ignore_index=True).to_csv(
            scan_path, index=False, encoding='utf-8-sig')
    else:
        pd.DataFrame([scan_row]).to_csv(scan_path, index=False, encoding='utf-8-sig')

    # CVAR 档：u_cvar vs u_eev 逐位比对（关键验证）
    if kw['cfg'] == 'CVAR':
        u_cvar = u_sp
        cmp_df = pd.DataFrame({'hour': range(len(u_eev)),
                               'u_eev': u_eev.astype(float),
                               'u_cvar': u_cvar.astype(float)})
        cmp_df['equal'] = (cmp_df['u_eev'] == cmp_df['u_cvar']).astype(int)
        cmp_df.to_csv(os.path.join(RES, 'V3_GC_u_compare_ps70.csv'),
                      index=False, encoding='utf-8-sig')
        n_diff = int((cmp_df['equal'] == 0).sum())
        print(f'[u-compare] u_cvar vs u_eev: {len(u_eev) - n_diff}/{len(u_eev)} 小时相同, '
              f'不同 {n_diff} h @ hours {cmp_df.loc[cmp_df["equal"] == 0, "hour"].tolist()}')
        summary.append(dict(metric='u_cvar_equals_u_eev', value=bool(n_diff == 0), unit=''))
        summary.append(dict(metric='u_cvar_diff_hours', value=n_diff, unit=''))
        # 旁证：SC（风险中性）承诺与 EEV 承诺的比对
        u_hep_diff = int((u_sp.astype(int) != u_eev.astype(int)).sum())  # 占位（CVAR 档 u_sp 即 cvar）
        # 单独再解一次风险中性 SP 承诺做三方比对
        sp_rn = MG.solve_gc(base, scenarios=reduced, mode='cost', **model_kw)
        u_rn = sp_rn['scen_rows'][0]['sched']['u_chp'].to_numpy()
        cmp2 = pd.DataFrame({'hour': range(len(u_eev)),
                             'u_eev': u_eev.astype(float), 'u_rn': u_rn.astype(float)})
        cmp2['equal'] = (cmp2['u_eev'] == cmp2['u_rn']).astype(int)
        cmp2.to_csv(os.path.join(RES, 'V3_GC_u_compare_rn_ps70.csv'),
                    index=False, encoding='utf-8-sig')
        n_diff_rn = int((cmp2['equal'] == 0).sum())
        summary.append(dict(metric='u_rn_diff_hours_vs_eev', value=n_diff_rn, unit=''))
        print(f'[u-compare] u_riskneutral vs u_eev: 不同 {n_diff_rn} h '
              f'@ hours {cmp2.loc[cmp2["equal"] == 0, "hour"].tolist()}')
        pd.DataFrame(summary).to_csv(os.path.join(RES, f'V3_GC_{kw["cfg"]}_{ARM}_summary.csv'),
                                     index=False, encoding='utf-8-sig')

    print(f'[{kw["cfg"]}|{ARM}] OOS {policy_name} 均值 {costs_s.mean():.1f} | '
          f'EEV 均值 {costs_e.mean():.1f} | VSS {costs_e.mean() - costs_s.mean():.1f} '
          f'| WS 均值 {costs_w.mean():.1f} | EVPI {costs_e.mean() - costs_w.mean():.1f}')
    print(f'[{kw["cfg"]}|{ARM}] CVaR95 {policy_name} {cvar_emp(costs_s, 0.95):.1f} vs EEV '
          f'{cvar_emp(costs_e, 0.95):.1f} | 最差日 {policy_name} {costs_s.max():.1f} '
          f'vs EEV {costs_e.max():.1f}')
    print(f'[{kw["cfg"]}|{ARM}] RP 最小期望碳排 {carbon_min_exp:.3f} t | '
          f'OOS 碳排 SP {ok["carbon_sp"].mean():.3f} t/日')


if __name__ == '__main__':
    run(sys.argv[1])
    print('done')
