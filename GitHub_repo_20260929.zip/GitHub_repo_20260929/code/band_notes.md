# V3 口径带（band scan）— 图注与正文并入用笔记

生成物：
- `code_v3/band_scan_v3.py` → `code_v3/results/V3_BAND_scan.csv`（48 行 × 46 列，每行 = 一格 × 一个指标）
  与 `code_v3/results/V3_BAND_summary.csv`（3 行，每个指标一行汇总）
- 图：`submission/论文源_v2/figures/fig_band_scan.png`（+ 同名 .pdf），由
  `make_v2_figures.py::fig_band_scan()` 只读上面两个 CSV 生成，图内无手打数字

复算命令（全部现读现算，脚本不硬编码任何数字）：
```
cd code_v3
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py                    # 生成两个 CSV
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest=all      # 期望退出码 0
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest-mutation=basis_flip   # 期望非 0
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest-mutation=value_perturb
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest-mutation=b0_swap
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest-mutation=degenerate_included
PYTHONUTF8=1 Y:/cuda/python.exe -B band_scan_v3.py --selftest-mutation=degenerate_unflagged
cd ../submission/论文源_v2
PYTHONUTF8=1 Y:/cuda/python.exe -B -c "import make_v2_figures as M; M.fig_band_scan()"
```
实测退出码（轮 9）：生成 0；`--selftest=all` 0；五项变异各 1（全部翻红，且变异只打在
内存副本，跑完 `sha256sum -c` 两个 CSV 与脚本本体均 OK）。

### 1.1 退化恒等格的排除（轮 9 修正，**并入正文前必须先读**）
`D_nogas` 那格的 uplift 是"B0 与自己比"，恒等于 0.000000% —— 它是**恒等式**，不是测量值。
早先的汇总把它当成 `point_value_range` 的下界，等于宣称"认证点值区间下界 0.000%"，
审稿人一句话就能打回。现在的口径：
- 长表里给这类行加了三列显式标记 `degenerate` / `excluded_from_range` / `exclusion_reason`，
  **行不删**，原始值、basis、三块地板的证据列全部照写；
- `pool()`（点值池与界导出池都算）与 `summary` 的 `point_value_range` /
  `bound_informed_range` **一律跳过 `degenerate=True` 的行**；
- 被排除的是哪些行、为什么，写进 `V3_BAND_summary.csv` 的
  `n_degenerate_excluded` / `degenerate_excluded_cells` / `degenerate_excluded_why`
  三列，并复述进 `difference_explained`；
- 自检 ③ `degenerate-excluded`（`--selftest=degenerate-excluded`）断言：标记与恒等式
  一一对应、恒等格不进任何池、排除确实改变了下界、**任何区间端点都不是 0.000%**、
  盘上 summary 与现算一致；`--selftest-mutation=degenerate_included`（三列一致地摘掉
  标记）与 `degenerate_unflagged`（只弄错标记列）都能翻红。
修正后的认证点值跨度：`uplift_ps70` **6.771% .. 21.301%**（4 格）、
`lever_50_70` **4.648% .. 11.371%**（4 格）、`uplift_ps50` 11.975% .. 36.865%。
`n_point_cells` 从 5 变 4 就是这个排除的直接后果。


## 1. 两个指标与**分母口径**（必须写进 caption）

| 指标 | 公式 | 分母是谁 |
| --- | --- | --- |
| `lever_50_70` | (C(50 bar) − C(70 bar)) / C(50 bar) × 100 | **同一格自己**在 50 bar 下的碳地板，不是无气网地板 |
| `uplift_ps70` | (C(70 bar) − C(B0)) / C(B0) × 100 | **同热形/同排放因子**的无气网（B0）碳地板 |
| `uplift_ps50` | (C(50 bar) − C(B0)) / C(B0) × 100 | 同上 |

C(·) 一律取各臂存档字段 `carbon_min_exp_rp`（最小期望碳排，tCO2/日，RP 期望值口径，
非样本外日均）。所有对照都是**同臂同格**相除，跨格只比百分比不比绝对吨数。

分母归属的两条构造性事实（不是估计）：
- B0 无气网，`model_gc_v3.solve_gc` 在 `gas_coupled=False` 时**拒绝**任何非默认
  `gas_model`，所以 `steady` 臂的 uplift 分母沿用 main 的 B0 是恒等操作；
- 同理 B0 与拓扑无关：`V3_GC_scan_carbon.csv` 的 (main,B0)=27.361468409515215 与
  `V3_MESH_cells.csv` 的 M_B0=27.36146840951521 逐位一致（自检里断言，容差 1e-9），
  所以网状 uplift 的分母就是这条线性气帽地板。

## 2. 每格口径与取值（`V3_BAND_scan.csv` 的 6 个进带格）

| cell_id | 拓扑 | 热负荷 | 排放因子 | 气网物理 | lever_50_70 | uplift_ps70 | uplift_ps50 | basis | 碳地板状态 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `A_declared` | 两节点链 | 合成典型日 | 0.8922 | 动态管存 | 11.187842% | 20.281554% | 35.433657% | optimal_point | 全 OPTIMAL(2) |
| `B_ef055` | 两节点链 | 合成典型日 | 0.55 | 动态管存 | 4.647534% | 6.770807% | 11.974877% | optimal_point | 全 OPTIMAL(2) |
| `C_heatreal` | 两节点链 | 丹麦实测 2019 | 0.8922 | 动态管存 | 6.632672% | 6.772625% | 14.357588% | optimal_point | 全 OPTIMAL(2) |
| `D_steady` | 两节点链 | 合成典型日 | 0.8922 | 稳态输送（无管存） | 11.371445% | 21.301048% | 36.864522% | optimal_point | 全 OPTIMAL(2) |
| `D_nogas` | 两节点链 | 合成典型日 | 0.8922 | 无气网 | NOT_RUN（无源压可言） | 0.000000%（恒等） | 0.000000%（恒等） | optimal_point | B0 OPTIMAL(2) |
| `E_mesh` | GasLib-11 网状核心（5 节点/4 连线/1 源） | 合成典型日 | 0.8922 | 动态管存 | 11.620667% | 21.940921% | 37.974475% | **bound_lower** | 三耦合格全 **TIME_LIMIT(9)** |

`B_ref / C_ref / D_ref / E_ref` 是声明口径在各自维度里的**重复参照行**
（`in_range_pool=False`），数值与 `A_declared` 相同，只为让每条带两端齐整，不重复计入带。

碳地板的 gap：
- 链上各臂**没有落盘**该次最小碳排求解的 gap（`gc_run_v3.py` 只持久化
  `carbon_min_rp_status` / `_time`），CSV 里如实写 `NOT_RECORDED`，依据列写
  "求解器 MIPGap 参数 = 1e-4（`config_v3.GRB_MIPGAP`）+ 状态 OPTIMAL ⇒ gap ≤ 1e-4"；
- 网状格 gap 有落盘（`carbon_min_mip_gap`）：PS50 35.2540%、PS60 39.5675%、
  PS70 42.7779%，状态 9 = TIME_LIMIT，用时各约 600 s（冻结上限）。

热形维度的一条可比性说明（免得被追问）：`C_heatreal` 的样本外日历是 91 个实测日，
其余格是 100 日；但带里用的 C(·) 是 **RP 期望碳排的最小值**（训练侧 8 个削减场景，
`rp_n_vars` 两臂同为 4106、`rp_n_cons` 同为 3704），与样本外天数无关，所以这条对比
不受天数影响；受影响的是 `oos_mean_carbon_*` 一类指标，本带**没有**用它们。

## 3. 点值段 vs 界导出段（图上的两种视觉编码）

- **实心条 + 实心圆点** = `basis=optimal_point, certified=True`：该格的分子、分母
  两块碳地板都是 Gurobi OPTIMAL，比值是**点值**。
- **斜纹 + 虚线边条 + 空心方框** = `basis=bound_lower`：只来自 `E_mesh`（网状三格
  TIME_LIMIT，只有下界 L(p_s)）。图上**从不**把它并进实心条。
- 红星 = 声明口径格，便于读者看到头条数落在带的哪一处。

网状两格的下界导出值**性质不同**，必须分开说：
- `uplift_ps70 / uplift_ps50`：分子是下界 L、分母是认证点值 ⇒ 导出的是该指标的
  **严格下界**，图上写 `>= 21.94`，真值只会更大，**上端无界**（网状 incumbent 三格
  并列在同一零流浅层点 58.3076，按 `mesh_notes.md` 的规定不得当作地板值引用，
  所以无法给出上界）。
- `lever_50_70`：分子分母**都是**下界 ⇒ (L50−L70)/L50 = 11.62% **不是任何界**
  （L(50)、L(70) 无法把 (C50−C70)/C50 在任何方向夹住），图上明写 "not a bound"，
  只能当作"与点值同量级的提示性读数"。

## 4. 两个汇总量与差异来源（`V3_BAND_summary.csv`）

| 指标 | point_value_range（只在认证点值上） | bound_informed_range（含界导出） | 差异来自哪一格 |
| --- | --- | --- | --- |
| `lever_50_70` | **4.648% .. 11.371%**（4 格：4.648 EF0.55 / 6.633 实测热 / 11.188 声明 / 11.371 稳态） | 4.648% .. **11.621%** | 上端由 `E_mesh` 11.62% 抬高，但它是"下界之比"，**不构成界** |
| `uplift_ps70` | **6.771% .. 21.301%**（4 格：6.771 EF0.55 / 6.773 实测热 / 20.282 声明 / 21.301 稳态；恒等格 `D_nogas`=0.000 **已排除**，见 §1.1） | 6.771% .. **≥21.941%** | 上端由 `E_mesh` 21.94% 抬高，且这是**严格下界**：真值 ≥ 21.94%，无上限 |
| `uplift_ps50` | 11.975% .. 36.865%（同上排除 `D_nogas`） | 11.975% .. ≥37.974% | 同上，`E_mesh` 的 PS50 下界 |

即：两个头条数的**认证点值跨度**分别是 4.65–11.37%（杠杆）与 6.77–21.30%（耦合抬升）；
并入界导出后上端只被 `E_mesh` 一格推到 11.62%（提示性）与 ≥21.94%（严格下界、无上封）。
带内没有一格能把符号、单调方向或"气网物理抬升地板"这一结论翻掉。

## 5. 未覆盖交叉格（如实 NOT_RUN，共 7 个）

`X1` EF 0.55 × 实测热、`X2` EF 0.55 × 稳态输送、`X3` 实测热 × 稳态输送、
`X4` 网状 × EF 0.55、`X5` 网状 × 实测热、`X6` 网状 × 稳态输送，
外加 `D_nogas` 的 lever（无气网模型没有源压边界，杠杆**无定义**，不是"跑不出来"）。
这些格在 CSV 里 `basis=not_run`、`value_pct=NOT_RUN`、`missing_reason` 说明原因。

## 6. 写 caption / 正文时**不能**说的话

1. 不能说"杠杆在 4.6–11.6% 之间"或"耦合抬升在 0–21.9% 之间"这种**把点值段与界导出段
   合成一个区间**的写法；只能说"认证点值 4.65–11.37% / 6.77–21.30%，另有一格（网状）
   给出提示性 11.62% 与严格下界 ≥21.94%"。
2. 不能把网状臂的 11.62% 说成"上界/下界/置信区间/最坏情形"——它是两个下界之比，
   任何方向都不是界；也不能把 21.94% 说成"网状抬升是 21.94%"，它只是**至少**这么多。
3. 不能引用网状 incumbent（58.3076，三格并列）充当地板值或用它给带补上界。
4. 不能说"所有口径维度都已认证"：拓扑维度的耦合臂只有界，且 6 个交叉格未跑（NOT_RUN）。
5. 不要在图/caption 里出现 LaTeX 残留：图上文字是 matplotlib 纯文本（无 `$...$`、
   无 `~` 不间断空格），单位写 "bar"、"%"、"tCO2/日"；正文里若要写 `50~MW` 式
   非断空格，那是 LaTeX 侧的事，不能反向抄进图。
6. 不要说"gap 小于 X%"来描述链上各臂的碳地板：那次求解的 gap **没有落盘**，
   只能说"状态 OPTIMAL、求解器 MIPGap 参数 1e-4"。

## 7. 图的技术参数（供排版）

- 文件：`figures/fig_band_scan.png`（300 dpi，1721 × 1069 px = 5.74 × 3.56 in；轮 10 用
  `PIL.Image.size` + `info['dpi']=299.9994` 重测，原记 1717 × 1074 px = 5.72 × 3.58 in 是
  该图函数后续微调边界后的旧值，已按实测改正）与同名 .pdf
- 单栏可放：`\includegraphics[width=\columnwidth]{figures/fig_band_scan.png}`
  （按既有单栏图 `fig_pwl_accuracy`/`fig_oos_binding` 同一缩放惯例，正文 9 pt、
  条带端点标注 6 pt、图例 5.8 pt）
- 配色沿用本文件既有常量：`C_COLD`（上带=杠杆）、`C_ORANGE`（下带=耦合抬升）、
  `C_WARM` 红星（声明口径）、斜纹+虚线（界导出）；未引入新依赖。
- 该图函数已登记进 `make_v2_figures.py` 的 `__main__` 列表（第 6 个），但本次**未**
  重跑其余 5 张图，也**未**重建投稿包。
