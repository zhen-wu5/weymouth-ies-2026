# -*- coding: utf-8 -*-
"""任务五：泉州 2016-2018 实测温度 -> 小时级数据集（仅敏感性分析用，不替换主管线）

数据源：
  Y:\\科研\\电力数据集\\P01【免费公开】精选4套电力负荷数据集\\
  （1）南方某地2016-2018负荷及气象数据\\2016-2018负荷天气data-quanzhou.csv
  GBK 编码；首行说明文字，第二行才是表头；15 分钟粒度约 10.5 万行；
  列：times, 负荷, 最高温度℃, 最低温度℃, 平均温度℃, 相对湿度(平均), 降雨量（mm）。

聚合口径（一次定死）：小时平均温度 = 该小时内 4 个 15 分钟"平均温度"的算术平均；
小时负荷 = 同口径平均（单位 kW，仅随温度序列一起输出备用）。

**硬性限制（写进清单与论文说明）**：该数据 2016-2018 年，与 2019 风光数据不同年，
只允许用于"合成温度 -> 实测温度"的敏感性分析，不得替换主管线的热负荷驱动。

输出（code_v3/results/）：
  quanzhou_temp_2016_2018_hourly.csv   小时级平均/最高/最低温度、湿度、负荷
  quanzhou_temp_diag.csv               完整性诊断
"""
import os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

CSV = (r'Y:\科研\电力数据集\P01【免费公开】精选4套电力负荷数据集'
       r'\（1）南方某地2016-2018负荷及气象数据\2016-2018负荷天气data-quanzhou.csv')


def main():
    df = pd.read_csv(CSV, encoding='gbk', skiprows=1)
    df.columns = ['ts', 'load', 'tmax', 'tmin', 'tavg', 'rh', 'rain']
    df['ts'] = pd.to_datetime(df['ts'], format='%Y/%m/%d %H:%M')
    for c in ['load', 'tmax', 'tmin', 'tavg', 'rh', 'rain']:
        df[c] = pd.to_numeric(df[c], errors='coerce')

    diag = {'n_rows_15min': int(len(df)),
            'range': f'{df.ts.min()} -> {df.ts.max()}',
            'nan_load': int(df.load.isna().sum()),
            'nan_tavg': int(df.tavg.isna().sum())}
    # 逐小时聚合
    hs = df.set_index('ts').resample('1h').agg(
        {'load': 'mean', 'tavg': 'mean', 'tmax': 'max', 'tmin': 'min',
         'rh': 'mean', 'rain': 'sum'})
    diag.update({
        'n_hours': int(len(hs)),
        'n_hours_complete': int(hs.tavg.notna().sum()),
        'n_hours_nan': int(hs.tavg.isna().sum()),
        'tavg_min': float(hs.tavg.min()), 'tavg_max': float(hs.tavg.max()),
        'load_mean_kW': float(hs.load.mean()), 'load_max_kW': float(hs.load.max()),
        # 每年小时数
        'hours_2016': int(((hs.index >= '2016-01-01') & (hs.index < '2017-01-01')).sum()),
        'hours_2017': int(((hs.index >= '2017-01-01') & (hs.index < '2018-01-01')).sum()),
        'hours_2018': int(((hs.index >= '2018-01-01') & (hs.index < '2019-01-01')).sum()),
    })
    print(diag)
    hs.to_csv(os.path.join(RES, 'quanzhou_temp_2016_2018_hourly.csv'),
              encoding='utf-8-sig')
    pd.DataFrame([diag]).to_csv(os.path.join(RES, 'quanzhou_temp_diag.csv'),
                                index=False, encoding='utf-8-sig')


if __name__ == '__main__':
    main()
