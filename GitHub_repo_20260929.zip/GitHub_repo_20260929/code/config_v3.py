# -*- coding: utf-8 -*-
"""code_v3 全局参数配置：在 code/config.py 基础上固化电网排放因子的官方出处。

与 code/config.py 的差异：仅新增电网排放因子段（E_GRID 的官方溯源版本与旧值开关），
其余参数原样保留，保证与既有实验可比。
"""
import os

T = 24                      # 调度周期（小时）
DT = 1.0                    # 时间步长（h）

# ---------------- 电价 / 气价 ----------------
PRICE_TOU = {
    'valley': 300.0,        # 谷 23:00-7:00（元/MWh）
    'flat':   600.0,
    'peak':  1000.0,        # 峰 9-12, 17-21
}
VALLEY_HOURS = set(range(23, 24)) | set(range(0, 7))
PEAK_HOURS = set(range(9, 12)) | set(range(17, 21))

C_GAS = 360.0               # 天然气价格（元/MWh燃料）
E_GAS = 0.202               # 天然气排放因子（tCO2/MWh燃料）

# ---------------- 电网排放因子（官方溯源版本，任务二固化） ----------------
# 出处（已下载官方原文核对，存于 code_v3/results/mee_2019_grid_baseline_ef.pdf）：
#   生态环境部应对气候变化司. 2019年度减排项目中国区域电网基准线排放因子.
#   发布于生态环境部官网"应对气候变化—温室气体减排"栏目, 2020-12-29.
#   官方 PDF: https://www.mee.gov.cn/ywgz/ydqhbh/wsqtkz/202012/W020201229610353340851.pdf
#   （原文未附独立文号；OM 为简单 OM 方法选项 B、2015-2017 三年供电量加权平均；
#     BM 为截至 2017 年统计的事前计算值。）
# 注意：该因子体系是 CDM/CCER 减排项目基准线因子，并非全国碳市场配额核算因子；
# 论文中引用时应写明其口径（OM = 电量边际）。
REGIONAL_GRID_EF_2019 = {   # tCO2/MWh，摘自原文表2
    'north':  dict(om=0.9419, bm=0.4819),   # 华北：京津冀晋鲁蒙
    'east_ne': dict(om=1.0826, bm=0.2399),  # 东北：辽吉黑
    'east':   dict(om=0.7921, bm=0.3870),   # 华东：沪苏浙皖闽
    'central': dict(om=0.8587, bm=0.2854),  # 华中：豫鄂湘赣川渝
    'northwest': dict(om=0.8922, bm=0.4407),# 西北：陕甘青宁新
    'south':  dict(om=0.8042, bm=0.2135),   # 南方：粤桂滇黔琼
}

# 场址—区域电网对应关系（任务三补甘肃风电后，风与光同属西北区域电网）：
#   主数据集（v3 自洽口径）：甘肃风电（94.43E/40.88N）+ 甘肃光伏 -> 西北区域电网
#   旧组合（对照口径）：连云港风电（江苏）+ 甘肃光伏 -> 跨华东/西北两网，不自洽
SITE_REGION = {
    'gansu_wind': 'northwest',
    'gansu_pv':   'northwest',
    'lianyungang_wind': 'east',   # 连云港属江苏 -> 华东区域电网
}

# 排放因子选择：调度模型中电网进口电应对应"多买一度电"的边际排放，
# 取电量边际 OM（简单 OM），而非核证减排量计算用的组合边际 CM。
# 依据见 data_manifest.md 任务二小节。
GRID_REGION_DEFAULT = 'northwest'            # v3 主口径：风与光同属西北
E_GRID_OM_NW = REGIONAL_GRID_EF_2019['northwest']['om']   # 0.8922
E_GRID_OM_EAST = REGIONAL_GRID_EF_2019['east']['om']      # 0.7921
E_GRID_OLD = 0.55                            # 旧值（无出处），保留作对照开关

# 切换开关：'official_om_nw'（默认，官方西北 OM）| 'official_om_east'
#           | 'old_0.55'（旧值对照）
E_GRID_MODE = os.environ.get('E_GRID_MODE', 'official_om_nw')

def get_e_grid(mode=None):
    mode = mode or E_GRID_MODE
    return {
        'official_om_nw': E_GRID_OM_NW,
        'official_om_east': E_GRID_OM_EAST,
        'old_0.55': E_GRID_OLD,
    }[mode]

E_GRID = get_e_grid()       # 当前生效值（tCO2/MWh）

# ---------------- 设备参数（与 code/config.py 完全一致） ----------------
CHP = dict(
    pmax=3.0, eta_e=0.35, eta_h=0.45, pmin_ratio=0.30,
    ramp=1.5, c_startup=200.0, c_om=40.0,
)
GB = dict(hmax=3.0, eta=0.90, c_om=5.0)
EB = dict(hmax=2.0, eta=0.98, c_om=5.0)
HP = dict(hmax=2.0, cop=3.0, c_om=8.0)

ESS = dict(cap=2.0, pmax=1.0, eta_c=0.95, eta_d=0.95,
           soc_min=0.10, soc_max=0.90, soc0=0.50, c_om=3.0)
HSS = dict(cap=3.0, pmax=1.5, eta_c=0.95, eta_d=0.95,
           soc_min=0.10, soc_max=0.90, soc0=0.50, c_om=2.0)

C_OM_WIND = 30.0
C_OM_PV = 20.0

RATIO_WIND = 3.0
RATIO_PV = 4.0

GRB_TIME_LIMIT = 600
GRB_MIPGAP = 1e-4

# 回归闸门容差（最大**相对**偏差上限）：通用网状模型退化回两节点链，必须复现主链存档
# 到该精度，否则网状结论一律作废（R5）。
# 该常量是**唯一出处**：gc_run_mesh_v3.regress() 的闸门与 audit_v3.py 的 N3/N3b 都引用
# 它，避免"运行器卡 1e-4、审计另写一份 1e-3"这类容差漂移（弱的那一份会让回归自检失真）。
MESH_REG_TOL = 1e-4


def price_profile():
    p = []
    for t in range(T):
        if t in VALLEY_HOURS:
            p.append(PRICE_TOU['valley'])
        elif t in PEAK_HOURS:
            p.append(PRICE_TOU['peak'])
        else:
            p.append(PRICE_TOU['flat'])
    return p


if __name__ == '__main__':
    print('E_GRID (mode=%s) = %.4f tCO2/MWh' % (E_GRID_MODE, E_GRID))
    print('all modes:', {m: get_e_grid(m) for m in
                          ['official_om_nw', 'official_om_east', 'old_0.55']})
