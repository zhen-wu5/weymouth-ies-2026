# -*- coding: utf-8 -*-
"""穷举 p_s 进入网状模型的**每一个位置**，并列出 p_s 从低到高时每一项是变大还是变小。

做法：用 mesh_feas_probe 的拦截器在 optimize 前抓一份完整模型快照
（每个约束的名字 / 方向 / 右端 / 系数；每个二次约束；每个 PWL 一般约束的断点集；
每个变量基名的上下界与类型），对 ps_lo 与 ps_hi 两份快照按**同一个约束名**逐项比对。
约束名里不含 p_s，所以只要某条约束的系数或右端随 p_s 变了，它一定是 p_s 的进入点；
PWL 的断点集不进 LP 矩阵，单独抓。这样得到的清单是穷举的，不依赖人眼读代码。

用法：
  Y:/cuda/python.exe -B mesh_ps_entry_map.py --ps 50,70 --dir-mode soc,binary
输出：results/V3_MESH_PROBE_psentry_<dir_mode>.csv
"""
import argparse
import os

import numpy as np
import pandas as pd

import data_v3 as DP
import model_mesh_v3 as MM
import mesh_feas_probe as P

RES = P.RES
_SEN = {'<': 'le', '>': 'ge', '=': 'eq'}


def _base(name):
    return name.split('[')[0]


def snapshot(m):
    m.update()
    cons, qcons, pwls, vbs = {}, {}, {}, {}
    for c in m.getConstrs():
        row = m.getRow(c)
        coef = {}
        for i in range(row.size()):
            coef[_base(row.getVar(i).VarName)] = round(float(row.getCoeff(i)), 12)
        g = _base(c.ConstrName)
        d = cons.setdefault(g, dict(sense=_SEN[c.Sense], rhs=round(float(c.RHS), 12),
                                    coef=coef, n=0))
        d['n'] += 1
    for qc in m.getQConstrs():
        row = m.getQCRow(qc)
        lcoef = {}
        for i in range(row.size()):
            v1, v2 = row.getVar1(i), row.getVar2(i)
            n1 = _base(v1.VarName) if v1 is not None else 'const'
            n2 = _base(v2.VarName) if v2 is not None else 'const'
            lcoef[tuple(sorted([n1, n2]))] = round(float(row.getCoeff(i)), 12)
        g = _base(qc.QCName)
        d = qcons.setdefault(g, dict(sense=_SEN[qc.QCSense],
                                     rhs=round(float(qc.QCRHS), 12), coef=lcoef, n=0))
        d['n'] += 1
    # PWL 一般约束：p_s 通过**断点集**进入模型，LP 矩阵里看不见，必须单独抓
    for gc in m.getGenConstrs():
        nm = gc.GenConstrName
        try:
            gx, gy, xpts, ypts = m.getGenConstrPWL(gc)
        except Exception:
            continue
        key = f'PWL x={_base(gx.VarName)} y={_base(gy.VarName)}'
        d = pwls.setdefault(key, dict(
            n=0, npts=len(xpts), x_lo=round(float(xpts[0]), 9),
            x_hi=round(float(xpts[-1]), 9), y_min=round(float(min(ypts)), 9),
            y_max=round(float(max(ypts)), 9),
            second_x=round(float(xpts[1]), 6),
            last_slope=round(float((ypts[-1] - ypts[-2]) / (xpts[-1] - xpts[-2])), 6)))
        d['n'] += 1
    for v in m.getVars():
        b = _base(v.VarName)
        d = vbs.setdefault(b, dict(n=0, lb=+np.inf, ub=-np.inf, vt=set()))
        d['n'] += 1
        d['lb'] = min(d['lb'], v.LB if v.LB > -1e99 else -1e99)
        d['ub'] = max(d['ub'], v.UB if v.UB < 1e99 else 1e99)
        d['vt'].add(v.VType)
    return dict(cons=cons, qcons=qcons, varbounds=vbs, pwls=pwls,
                ncon=m.NumConstrs, nvar=m.NumVars, nqcon=m.NumQConstrs,
                ngcon=m.NumGenConstrs, nbin=m.NumBinVars)


def _cmp(kind, g, field, av, bv, n, rows):
    if av == bv:
        return
    try:
        direction = 'increase' if float(bv) > float(av) else 'decrease'
    except Exception:
        direction = 'change'
    rows.append(dict(kind=kind, group=g, item=field, lo=av, hi=bv,
                     direction=direction, n_copies=n))


def diff(s_lo, s_hi):
    rows = []
    for g in sorted(set(s_lo['cons']) | set(s_hi['cons'])):
        a, b = s_lo['cons'].get(g), s_hi['cons'].get(g)
        if a is None or b is None:
            rows.append(dict(kind='lin-constr', group=g, item='MISSING', lo=str(a),
                             hi=str(b), direction='structural-difference', n_copies=0))
            continue
        _cmp('lin-constr', g, 'sense', a['sense'], b['sense'], a['n'], rows)
        _cmp('lin-constr', g, 'rhs', a['rhs'], b['rhs'], a['n'], rows)
        for k in sorted(set(a['coef']) | set(b['coef'])):
            _cmp('lin-constr', g, f'coef[{k}]', a['coef'].get(k), b['coef'].get(k),
                 a['n'], rows)
    for g in sorted(set(s_lo['qcons']) | set(s_hi['qcons'])):
        a, b = s_lo['qcons'].get(g), s_hi['qcons'].get(g)
        if a is None or b is None:
            rows.append(dict(kind='quad-constr', group=g, item='MISSING', lo=str(a),
                             hi=str(b), direction='structural-difference', n_copies=0))
            continue
        _cmp('quad-constr', g, 'sense', a['sense'], b['sense'], a['n'], rows)
        _cmp('quad-constr', g, 'rhs', a['rhs'], b['rhs'], a['n'], rows)
        for k in sorted(set(a['coef']) | set(b['coef'])):
            _cmp('quad-constr', g, 'coef' + str(k), a['coef'].get(k), b['coef'].get(k),
                 a['n'], rows)
    for g in sorted(set(s_lo['pwls']) | set(s_hi['pwls'])):
        a, b = s_lo['pwls'].get(g), s_hi['pwls'].get(g)
        if a is None or b is None:
            rows.append(dict(kind='pwl', group=g, item='MISSING', lo=str(a), hi=str(b),
                             direction='structural-difference', n_copies=0))
            continue
        for f in ('npts', 'x_lo', 'x_hi', 'y_min', 'y_max', 'second_x', 'last_slope', 'n'):
            _cmp('pwl', g, f, a[f], b[f], a['n'], rows)
    for g in sorted(set(s_lo['varbounds']) | set(s_hi['varbounds'])):
        a, b = s_lo['varbounds'].get(g), s_hi['varbounds'].get(g)
        if a is None or b is None:
            rows.append(dict(kind='var', group=g, item='MISSING', lo=str(a), hi=str(b),
                             direction='structural-difference', n_copies=0))
            continue
        _cmp('var', g, 'lb', round(float(a['lb']), 9), round(float(b['lb']), 9),
             a['n'], rows)
        _cmp('var', g, 'ub', round(float(a['ub']), 9), round(float(b['ub']), 9),
             a['n'], rows)
        _cmp('var', g, 'vtype', ''.join(sorted(a['vt'])), ''.join(sorted(b['vt'])),
             a['n'], rows)
    return pd.DataFrame(rows)


def grab(dat, ps, dir_mode):
    out = {}

    def cb(m):
        out['snap'] = snapshot(m)
        raise P.ProbeAbort()

    P._ACTIVE['cb'] = cb
    base, reduced = dat['base'], dat['reduced']
    net = MM.build_mesh(ps=ps, ps2=ps, pd_min=P.PD_MIN, K=P.K_W, A=P.A_NODE,
                        comp_ratio=P.COMP_R, single_source=True)
    try:
        MM.solve_mesh(base, net, scenarios=reduced, mode='cost', n_pts=P.N_PTS,
                      gas_coupled=True, dir_mode=dir_mode, time_limit=1.0,
                      mipgap=1e-4, verbose=False)
    except P.ProbeAbort:
        pass
    finally:
        P._ACTIVE['cb'] = None
    return out['snap']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ps', default='50,70')
    ap.add_argument('--dir-mode', default='soc,binary')
    a = ap.parse_args()
    lo, hi = [float(x) for x in a.ps.split(',')]
    dat = DP.prepare()
    for dm in a.dir_mode.split(','):
        s_lo = grab(dat, lo, dm)
        s_hi = grab(dat, hi, dm)
        df = diff(s_lo, s_hi)
        df.insert(0, 'dir_mode', dm)
        df['ps_lo'], df['ps_hi'] = lo, hi
        path = os.path.join(RES, f'V3_MESH_PROBE_psentry_{dm}.csv')
        df.to_csv(path, index=False, encoding='utf-8-sig')
        print(f'\n===== dir_mode={dm}: p_s {lo} -> {hi} 一切随 p_s 变化的模型元素 =====')
        print(f'  规模 ps={lo}: nvar={s_lo["nvar"]} ncon={s_lo["ncon"]} '
              f'nqcon={s_lo["nqcon"]} ngcon={s_lo["ngcon"]} nbin={s_lo["nbin"]}')
        print(f'  规模 ps={hi}: nvar={s_hi["nvar"]} ncon={s_hi["ncon"]} '
              f'nqcon={s_hi["nqcon"]} ngcon={s_hi["ngcon"]} nbin={s_hi["nbin"]}')
        if df.empty:
            print('  (无任何元素随 p_s 变化 —— 不可能，检查快照)')
        else:
            with pd.option_context('display.width', 240, 'display.max_rows', 500,
                                   'display.max_colwidth', 80):
                print(df[['kind', 'group', 'item', 'lo', 'hi', 'direction', 'n_copies']]
                      .to_string(index=False))
        print(f'-> {path}')


if __name__ == '__main__':
    main()
