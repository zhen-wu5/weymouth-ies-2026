# -*- coding: utf-8 -*-
"""EPS 单档求解（每档独立进程）：两阶段随机模型 + Weymouth 气网耦合（ps=ps2=70 bar）
在 ε 碳约束下的成本最小化（碳–成本前沿的单档点）。

协议（与 gc_run_v3.py 完全一致）：
  8 场景 k-means（seed=0）、265/100 划分（seed=42）、Gurobi 13.0.3、MIPGap=1e-4、
  TimeLimit=600s、V3_ARM=main（甘肃重建负荷 + 甘肃风/甘肃光）、E_GRID=0.8922（西北 OM）。

口径声明（沿用 code_v2/gc_run.py carbon 分支的同款处理，见该文件 115-117 行）：
  allow_shed=False —— 碳约束/碳目标下若允许切负荷，"切负荷"等效于零碳零燃料，
  前沿会退化为"用切负荷换碳指标"。因此 ε 前沿全程禁止切负荷；
  "允许切负荷"的对照实验见 --shed 开关（eps_driver.py 的 ctrl_* 档）。

用法（每档独立进程，禁止同进程连跑——本项目有同进程状态污染前科）：
  Y:/cuda/python.exe eps_run_level.py --tag lev01 --mode eps --cap 40.0
  Y:/cuda/python.exe eps_run_level.py --tag end_carbon --mode carbon     # 碳排下限端点
  Y:/cuda/python.exe eps_run_level.py --tag end_cost   --mode cost       # 成本最优端点
  Y:/cuda/python.exe eps_run_level.py --tag ctrl_eps_shed --mode eps --cap 31.0 --shed

输出：
  results/EPS_rp_<tag>.csv    单行 RP 求解记录（失败也记录，含 Gurobi status）
  results/EPS_u_<tag>.npy     一阶段 CHP 承诺 u（仅求解成功时；OOS 评价用）
"""
import argparse
import contextlib
import io
import os
import re
import sys

import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_gc_v3 as MG

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

PS = 70.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', required=True)
    ap.add_argument('--mode', default='eps', choices=['eps', 'carbon', 'cost'])
    ap.add_argument('--cap', type=float, default=None)
    ap.add_argument('--shed', action='store_true', help='允许切负荷（仅对照实验）')
    a = ap.parse_args()

    assert C.E_GRID_MODE == 'official_om_nw' and DP.ARM == 'main', \
        f'口径错误: E_GRID_MODE={C.E_GRID_MODE}, V3_ARM={DP.ARM}'

    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']

    # 口径：默认 allow_shed=False（ε 前沿主口径，切负荷零碳陷阱见文件头）；
    # --shed 才允许切负荷（仅对照实验 ctrl_* 用）
    err = io.StringIO()
    with contextlib.redirect_stderr(err):
        r = MG.solve_gc(base, scenarios=reduced, mode=a.mode, cap=a.cap,
                        gas_coupled=True, ps=PS, ps2=PS,
                        allow_shed=a.shed)

    row = dict(tag=a.tag, mode=a.mode, cap=a.cap, allow_shed=a.shed,
               e_grid_mode=C.E_GRID_MODE, e_grid=C.E_GRID,
               ps=PS, ps2=PS, gas_coupled=True,
               n_scen=len(reduced), mipgap=C.GRB_MIPGAP,
               time_limit=C.GRB_TIME_LIMIT)
    if r is None:
        mfail = re.search(r'status=(\d+)', err.getvalue())
        gstatus = int(mfail.group(1)) if mfail else -1
        # Gurobi status: 2=OPTIMAL 3=INFEASIBLE 4=INF_OR_UNBD 9=TIME_LIMIT 13=SUBOPTIMAL
        row.update(status=gstatus, solved=0, exp_cost=np.nan, exp_carbon=np.nan,
                   rp_cvar_emp=np.nan, worst_scen_cost=np.nan,
                   startup_cost=np.nan, solve_time=np.nan, mip_gap=np.nan,
                   n_vars=np.nan, n_cons=np.nan, n_starts=np.nan,
                   in_sample_shed_MWh=np.nan)
        print(f'[eps_run_level] {a.tag}: 求解失败, gurobi status={gstatus}')
    else:
        u = r['scen_rows'][0]['sched']['u_chp'].to_numpy().astype(int)
        # 启动次数从场景行的 startup_cost 反推（c_startup=200 元/次）
        startup_cost = float(r['scen_rows'][0]['startup_cost'])
        n_starts = int(round(startup_cost / C.CHP['c_startup']))
        np.save(os.path.join(RES, f'EPS_u_{a.tag}.npy'), u)
        shed_ip = sum(sr['shed_MWh'] for sr in r['scen_rows'])
        row.update(status=int(r['status']), solved=1,
                   exp_cost=float(r['exp_cost']),
                   exp_carbon=float(r['exp_carbon']),
                   rp_cvar_emp=float(r['cvar_emp']),
                   worst_scen_cost=float(r['worst_cost']),
                   startup_cost=startup_cost,
                   solve_time=float(r['solve_time']),
                   mip_gap=float(r['mip_gap']),
                   n_vars=int(r['n_vars']), n_cons=int(r['n_cons']),
                   n_starts=n_starts,
                   in_sample_shed_MWh=float(shed_ip))
        print(f'[eps_run_level] {a.tag}: mode={a.mode} cap={a.cap} '
              f'cost={row["exp_cost"]:.2f} carbon={row["exp_carbon"]:.4f} '
              f'time={row["solve_time"]:.1f}s gap={row["mip_gap"]:.2e} status={row["status"]}')

    pd.DataFrame([row]).to_csv(os.path.join(RES, f'EPS_rp_{a.tag}.csv'),
                               index=False, encoding='utf-8-sig')


if __name__ == '__main__':
    main()
