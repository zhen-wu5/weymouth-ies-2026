# -*- coding: utf-8 -*-
"""样本内价值度量（in-sample VSS/EVPI 验证）+ 训练场景成本矩阵 + 共同可行集验证。

背景：VSS/EVPI 的理论不等式 0 <= VSS <= EVPI 只在样本内（优化集 = 评估集）成立；
此前各臂引用的 VSS/EVPI 均为 100 测试日样本外值（v2 臂出现 VSS > EVPI 即源于此）。
本脚本在 8 个 k-means 训练场景（含其概率）上完成三件事：

  (1) RP_train / EEV_train / WS_train 与 VSS_train / EVPI_train，
      明确验证 0 <= VSS_train <= EVPI_train；
  (2) 三个承诺 u_hep / u_eev / u_cvar 在 8 训练场景的二阶段最优成本矩阵 c_s(u)
      （3x8，附 mu / rho 汇总与两两差值）；
  (3) 共同可行集验证：三个承诺逐一代入 ps=70 气网耦合模型的二阶段问题，
      在 8 场景逐一验证可行性（u_fix 协议，与 gc_run_v3 的 OOS 评估完全一致）。

协议（与 gc_run_v3.py / 既有 OOS 协议逐项一致，未调任何求解参数）：
  - 场景库：data_v3.prepare()，seed=42 265/100 划分，k-means k=8 seed=0，
    8 场景概率 = 簇内训练日占比；V3_ARM=main（甘肃风+甘肃光+重建负荷形状）、
    E_GRID_MODE=official_om_nw（0.8922）。
  - EEV 模型场景：DP.expected_scenario（265 训练日均值曲线，既有口径）。
  - c_s(u)：单场景 u_fix 再调度（仅固定 u，第二阶段变量对场景 s 重新优化），
    c_s = op_cost + startup（与 OOS 逐日评估口径一致）。
  - 期望均按 8 场景概率加权（与 RP 的目标测度相同）；同时报告 1/8 等权版本作对照。
  - Gurobi 参数维持 config_v3 默认（MIPGap 1e-4、TimeLimit 600s），未做任何调整。

用法（每档独立进程，禁止同进程连跑）：
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe in_sample_value_v3.py b0
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe in_sample_value_v3.py ps70

输出（code_v3/results/）：
  b0   : IN_B0_in_sample_summary.csv / IN_B0_train_costs.csv / IN_B0_u_commitments.csv
  ps70 : IN_PS70_in_sample_summary.csv / IN_PS70_train_costs.csv /
         IN_PS70_cost_matrix.csv / IN_PS70_cost_matrix_wide.csv /
         IN_PS70_feasibility.csv / IN_PS70_u_commitments.csv
"""
import os
import sys
import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_gc_v3 as MG

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

RISK_LAMBDA = 0.8
CVAR_BETA = 0.95
PS = 70.0

# 既有 main 臂结果锚点（用于确认本脚本与 gc_run_v3 逐位同源；仅校验，不做门槛退出）
ANCHOR = {
    ('b0', 'rp_exp_cost'): 33933.32765119941,       # V3_GC_B0_main_summary.csv
    ('ps70', 'rp_exp_cost'): 34122.45845808811,     # V3_GC_PS70_main_summary.csv
    ('ps70', 'cvar_exp_cost'): 34251.02415374644,   # V3_GC_CVAR_main_summary.csv
}


def scen_data(dat, sc):
    return dict(wind=np.asarray(sc['wind'], float), pv=np.asarray(sc['pv'], float),
                p_load=dat['base']['p_load'], h_load=dat['base']['h_load'],
                price=dat['base']['price'], penetration=DP.PEN)


def u_of(res):
    return np.asarray(res['scen_rows'][0]['sched']['u_chp'], dtype=int)


def eval_commitment(dat, reduced, u, model_kw, label):
    """把承诺 u 代入二阶段，在 8 训练场景逐一 u_fix 再调度（可行性 + c_s 一并产出）。"""
    rows = []
    for s, sc in enumerate(reduced):
        r = MG.solve_gc(scen_data(dat, sc), mode='cost', u_fix=u, **model_kw)
        if r is None:
            rows.append(dict(commitment=label, s=s, rep_day=sc['rep_day'], prob=sc['prob'],
                             feasible=False, status=-1, c_s=np.nan, op_cost=np.nan,
                             startup=np.nan, n_starts=-1, shed_MWh=np.nan,
                             mip_gap=np.nan, solve_time=np.nan,
                             p1_min=np.nan, p1_max=np.nan,
                             p2_min=np.nan, p2_max=np.nan, f1_max=np.nan, f2_max=np.nan))
            print(f'  [INFEASIBLE] {label} @ 场景 s={s} ({sc["rep_day"]})')
            continue
        sr = r['scen_rows'][0]
        rows.append(dict(
            commitment=label, s=s, rep_day=sc['rep_day'], prob=sc['prob'],
            feasible=True, status=int(r['status']), c_s=float(r['exp_cost']),
            op_cost=float(sr['op_cost']), startup=float(sr['startup_cost']),
            n_starts=int(round(sr['startup_cost'] / C.CHP['c_startup'])),
            shed_MWh=float(sr['shed_MWh']),
            mip_gap=float(r['mip_gap']), solve_time=float(r['solve_time']),
            p1_min=sr.get('p1_min', np.nan), p1_max=sr.get('p1_max', np.nan),
            p2_min=sr.get('p2_min', np.nan), p2_max=sr.get('p2_max', np.nan),
            f1_max=sr.get('f1_max', np.nan), f2_max=sr.get('f2_max', np.nan),
        ))
    return rows


def solve_ws(dat, reduced, model_kw):
    """WS：单场景独立优化（完美信息），逐场景最优成本 c*_s。"""
    rows = []
    for s, sc in enumerate(reduced):
        r = MG.solve_gc(scen_data(dat, sc), mode='cost', **model_kw)
        if r is None:
            rows.append(dict(commitment='ws_perfect', s=s, rep_day=sc['rep_day'], prob=sc['prob'],
                             feasible=False, status=-1, c_s=np.nan, op_cost=np.nan,
                             startup=np.nan, n_starts=-1, shed_MWh=np.nan,
                             mip_gap=np.nan, solve_time=np.nan,
                             p1_min=np.nan, p1_max=np.nan,
                             p2_min=np.nan, p2_max=np.nan, f1_max=np.nan, f2_max=np.nan))
            print(f'  [INFEASIBLE] ws_perfect @ 场景 s={s} ({sc["rep_day"]})')
            continue
        sr = r['scen_rows'][0]
        rows.append(dict(
            commitment='ws_perfect', s=s, rep_day=sc['rep_day'], prob=sc['prob'],
            feasible=True, status=int(r['status']), c_s=float(r['exp_cost']),
            op_cost=float(sr['op_cost']), startup=float(sr['startup_cost']),
            n_starts=int(round(sr['startup_cost'] / C.CHP['c_startup'])),
            shed_MWh=float(sr['shed_MWh']),
            mip_gap=float(r['mip_gap']), solve_time=float(r['solve_time']),
            p1_min=sr.get('p1_min', np.nan), p1_max=sr.get('p1_max', np.nan),
            p2_min=sr.get('p2_min', np.nan), p2_max=sr.get('p2_max', np.nan),
            f1_max=sr.get('f1_max', np.nan), f2_max=sr.get('f2_max', np.nan),
        ))
    return rows


def cvar_emp(costs, beta):
    costs = np.sort(np.asarray(costs, float))[::-1]
    k = max(1, int(np.ceil((1 - beta) * len(costs))))
    return float(costs[:k].mean())


def check_anchor(tag, key, value):
    a = ANCHOR.get((tag, key))
    if a is None:
        return
    rel = abs(value - a) / abs(a)
    print(f'[anchor {tag}/{key}] {value:.9f} vs {a:.9f} (rel {rel:.2e}) -> '
          f'{"OK" if rel < 1e-6 else "MISMATCH"}')


def value_metrics(df_eval, rp_obj, rp_n_cons=''):
    """按场景概率加权汇总三个量与不等式判定。df_eval 含 u_hep/u_eev/ws_perfect 的 c_s。

    每个 metric 带 desc 列，写明"哪个承诺 + 哪个权重 + 哪个场景集"，避免同值不同名。
    场景集 = 8 个 k-means 训练场景（优化集 = 评估集，样本内口径）。
    c_s(u) 全部来自单场景 u_fix 再调度（u_fix 只固定 u，y 与第二阶段变量重优化）。
    """
    probs = df_eval[df_eval['commitment'] == 'u_hep'].sort_values('s')['prob'].to_numpy(float)
    lab_desc = {
        'u_hep': 'u_hep=两阶段随机最优解(RP)的承诺',
        'u_eev': 'u_eev=确定性期望值(EEV)模型的承诺',
        'ws_perfect': 'ws_perfect=逐场景单独优化(完美信息)的最优成本',
    }
    out = []
    for lab in ['u_hep', 'u_eev', 'ws_perfect']:
        sub = df_eval[df_eval['commitment'] == lab].sort_values('s')
        c = sub['c_s'].to_numpy(float)
        out.append(dict(metric=f'{lab}_eval_mean_prob',
                        value=float(np.nansum(probs * c)), unit='元',
                        desc=f'{lab_desc[lab]}；c_s 在 8 训练场景按场景概率(pi)加权的期望'))
        out.append(dict(metric=f'{lab}_eval_mean_uniform',
                        value=float(np.nanmean(c)), unit='元',
                        desc=f'{lab_desc[lab]}；c_s 在 8 训练场景按 1/8 等权的均值（对照口径）'))
        out.append(dict(metric=f'{lab}_eval_worst_s',
                        value=float(np.nanmax(c)), unit='元',
                        desc=f'{lab_desc[lab]}；8 训练场景中最坏场景的 c_s（非期望，仅供参考）'))
    rp_eval = [r for r in out if r['metric'] == 'u_hep_eval_mean_prob'][0]['value']
    eev_eval = [r for r in out if r['metric'] == 'u_eev_eval_mean_prob'][0]['value']
    ws_prob = [r for r in out if r['metric'] == 'ws_perfect_eval_mean_prob'][0]['value']
    ws_unif = [r for r in out if r['metric'] == 'ws_perfect_eval_mean_uniform'][0]['value']
    rp_unif = [r for r in out if r['metric'] == 'u_hep_eval_mean_uniform'][0]['value']
    eev_unif = [r for r in out if r['metric'] == 'u_eev_eval_mean_uniform'][0]['value']
    vss = eev_eval - rp_eval
    evpi = rp_eval - ws_prob
    out += [
        dict(metric='rp_train_objective', value=float(rp_obj), unit='元',
             desc='RP 模型目标值（8 场景概率加权期望 + 共享启动成本计一次），与 gc_run 的 rp_exp_cost 同源'),
        dict(metric='rp_train_eval', value=rp_eval, unit='元',
             desc='= u_hep_eval_mean_prob；RP_train 主口径（与 EEV/WS 完全相同的 u_fix 评估协议）'),
        dict(metric='rp_eval_vs_objective_rel', value=float(abs(rp_eval - rp_obj) / abs(rp_obj)), unit='',
             desc='|RP_train_eval − RP 目标值|/目标值；u_fix 评估协议与 RP 优化的对称性校验'),
        dict(metric='eev_train', value=eev_eval, unit='元',
             desc='= u_eev_eval_mean_prob；EEV_train 主口径（概率加权）'),
        dict(metric='ws_train_prob', value=ws_prob, unit='元',
             desc='= ws_perfect_eval_mean_prob；WS_train 主口径（概率加权的逐场景最优成本期望，非 max）'),
        dict(metric='ws_train_uniform', value=ws_unif, unit='元',
             desc='= ws_perfect_eval_mean_uniform；等权对照口径'),
        dict(metric='vss_train', value=vss, unit='元',
             desc='VSS_train = EEV_train − RP_train（均为主口径、同一概率测度）'),
        dict(metric='evpi_train', value=evpi, unit='元',
             desc='EVPI_train = RP_train − WS_train（均为主口径、同一概率测度）'),
        dict(metric='ineq_vss_ge_0', value=bool(vss >= 0), unit='',
             desc='判据 1：VSS_train >= 0'),
        dict(metric='ineq_vss_le_evpi', value=bool(vss <= evpi), unit='',
             desc='判据 2：VSS_train <= EVPI_train'),
        dict(metric='ineq_0_le_vss_le_evpi', value=bool(vss >= 0 and vss <= evpi), unit='',
             desc='判据 1+2 合取：0 <= VSS_train <= EVPI_train'),
        dict(metric='ineq_evpi_ge_0', value=bool(evpi >= 0), unit='',
             desc='判据 0：EVPI_train >= 0'),
        dict(metric='vss_train_uniform', value=float(eev_unif - rp_unif), unit='元',
             desc='等权对照口径的 VSS_train = u_eev 等权均值 − u_hep 等权均值'),
        dict(metric='evpi_train_uniform', value=float(rp_unif - ws_unif), unit='元',
             desc='等权对照口径的 EVPI_train = u_hep 等权均值 − WS 等权均值'),
    ]
    return out


def save_summary(tag, summary):
    path = os.path.join(RES, f'IN_{tag}_in_sample_summary.csv')
    pd.DataFrame(summary).to_csv(path, index=False, encoding='utf-8-sig')
    print(f'  -> {path}')


def run_b0():
    tag = 'B0'
    dat = DP.prepare()
    reduced = dat['reduced']
    model_kw = dict(gas_coupled=False)

    # ---- RP（两阶段随机最优，8 训练场景）----
    rp = MG.solve_gc(dat['base'], scenarios=reduced, mode='cost', **model_kw)
    assert rp is not None, 'RP 不可行'
    u_hep = u_of(rp)
    rp_obj = float(rp['exp_cost'])
    check_anchor('b0', 'rp_exp_cost', rp_obj)

    # ---- EEV（确定性期望值模型 -> 承诺 -> 8 场景评估）----
    eev = MG.solve_gc(DP.expected_scenario(dat), mode='cost', **model_kw)
    assert eev is not None, 'EEV 不可行'
    u_eev = u_of(eev)

    rows = []
    rows += eval_commitment(dat, reduced, u_hep, model_kw, 'u_hep')
    rows += eval_commitment(dat, reduced, u_eev, model_kw, 'u_eev')
    rows += solve_ws(dat, reduced, model_kw)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, 'IN_B0_train_costs.csv'), index=False, encoding='utf-8-sig')

    pd.DataFrame({'hour': range(len(u_hep)), 'u_hep': u_hep, 'u_eev': u_eev}).to_csv(
        os.path.join(RES, 'IN_B0_u_commitments.csv'), index=False, encoding='utf-8-sig')

    summary = [
        dict(metric='tag', value=tag, unit=''),
        dict(metric='arm', value=DP.ARM, unit=''),
        dict(metric='e_grid_mode', value=C.E_GRID_MODE, unit=''),
        dict(metric='e_grid', value=C.E_GRID, unit='tCO2/MWh'),
        dict(metric='gas_coupled', value=False, unit=''),
        dict(metric='n_train_scen', value=len(reduced), unit=''),
        dict(metric='scen_probs', value=';'.join(f'{sc["prob"]:.6f}' for sc in reduced), unit=''),
        dict(metric='rp_mip_gap', value=float(rp['mip_gap']), unit=''),
        dict(metric='rp_status', value=int(rp['status']), unit=''),
    ]
    summary += value_metrics(df, rp_obj)
    save_summary(tag, summary)

    vss = [r for r in summary if r['metric'] == 'vss_train'][0]['value']
    evpi = [r for r in summary if r['metric'] == 'evpi_train'][0]['value']
    rp_e = [r for r in summary if r['metric'] == 'rp_train_eval'][0]['value']
    eev_e = [r for r in summary if r['metric'] == 'eev_train'][0]['value']
    ws_p = [r for r in summary if r['metric'] == 'ws_train_prob'][0]['value']
    ok = (vss >= 0) and (vss <= evpi)
    print(f'[B0|in-sample] RP_train={rp_e:.2f} EEV_train={eev_e:.2f} WS_train={ws_p:.2f}')
    print(f'[B0|in-sample] VSS_train={vss:.2f} EVPI_train={evpi:.2f} '
          f'0<=VSS<=EVPI: {"成立" if ok else "不成立"}')


def run_ps70():
    tag = 'PS70'
    dat = DP.prepare()
    reduced = dat['reduced']
    model_kw = dict(gas_coupled=True, ps=PS, ps2=PS)

    # ---- 三个承诺（均在同一 ps=70 耦合模型下求得，可行集同源）----
    sp_rn = MG.solve_gc(dat['base'], scenarios=reduced, mode='cost', **model_kw)
    assert sp_rn is not None, 'SP(风险中性) 不可行'
    u_hep = u_of(sp_rn)
    rp_obj = float(sp_rn['exp_cost'])
    check_anchor('ps70', 'rp_exp_cost', rp_obj)

    eev = MG.solve_gc(DP.expected_scenario(dat), mode='cost', **model_kw)
    assert eev is not None, 'EEV(ps70) 不可行'
    u_eev = u_of(eev)

    sp_cvar = MG.solve_gc(dat['base'], scenarios=reduced, mode='cost',
                          risk_lambda=RISK_LAMBDA, cvar_beta=CVAR_BETA, **model_kw)
    assert sp_cvar is not None, 'SP(CVaR) 不可行'
    u_cvar = u_of(sp_cvar)
    check_anchor('ps70', 'cvar_exp_cost', float(sp_cvar['exp_cost']))

    pd.DataFrame({'hour': range(len(u_hep)),
                  'u_hep': u_hep, 'u_eev': u_eev, 'u_cvar': u_cvar}).to_csv(
        os.path.join(RES, 'IN_PS70_u_commitments.csv'), index=False, encoding='utf-8-sig')

    # ---- (2)+(3)：成本矩阵 c_s(u) 与共同可行集验证（同一批 u_fix 求解）----
    rows = []
    for lab, u in [('u_hep', u_hep), ('u_eev', u_eev), ('u_cvar', u_cvar)]:
        rows += eval_commitment(dat, reduced, u, model_kw, lab)
    rows += solve_ws(dat, reduced, model_kw)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, 'IN_PS70_train_costs.csv'), index=False, encoding='utf-8-sig')

    feas = df[df['commitment'] != 'ws_perfect'].copy()
    feas.to_csv(os.path.join(RES, 'IN_PS70_feasibility.csv'), index=False, encoding='utf-8-sig')

    piv = feas.pivot(index='commitment', columns='s', values='c_s')
    piv = piv.loc[['u_hep', 'u_eev', 'u_cvar']]
    piv.to_csv(os.path.join(RES, 'IN_PS70_cost_matrix_wide.csv'), encoding='utf-8-sig')

    # mu / rho 汇总（mu=概率加权均值；rho=CVaR95/CVaR90/最差场景，经验口径与 gc_run 相同）
    probs = feas[feas['commitment'] == 'u_hep'].sort_values('s')['prob'].to_numpy(float)
    msum = []
    for lab in ['u_hep', 'u_eev', 'u_cvar']:
        c = feas[feas['commitment'] == lab].sort_values('s')['c_s'].to_numpy(float)
        msum.append(dict(commitment=lab, mu_prob=float(np.nansum(probs * c)),
                         mu_uniform=float(np.nanmean(c)), std=float(np.nanstd(c, ddof=0)),
                         cvar95_emp=cvar_emp(c, 0.95), cvar90_emp=cvar_emp(c, 0.90),
                         worst_s=float(np.nanmax(c)),
                         n_feasible=int(feas[feas['commitment'] == lab]['feasible'].sum())))
    md = pd.DataFrame(msum)
    # 两两差值（行级计算，避免标量广播污染整列）：Δμ/Δρ 相对基准承诺 b
    deltas = []
    for a, b in [('u_cvar', 'u_hep'), ('u_cvar', 'u_eev'), ('u_eev', 'u_hep')]:
        ra = [m for m in msum if m['commitment'] == a][0]
        rb = [m for m in msum if m['commitment'] == b][0]
        deltas.append(dict(pair=f'{a}-minus-{b}',
                           dmu=ra['mu_prob'] - rb['mu_prob'],
                           dmu_uniform=ra['mu_uniform'] - rb['mu_uniform'],
                           dcvar95=ra['cvar95_emp'] - rb['cvar95_emp'],
                           dcvar90=ra['cvar90_emp'] - rb['cvar90_emp'],
                           dworst=ra['worst_s'] - rb['worst_s']))
    ddf = pd.DataFrame(deltas)
    ddf.to_csv(os.path.join(RES, 'IN_PS70_cost_deltas.csv'), index=False, encoding='utf-8-sig')
    md.to_csv(os.path.join(RES, 'IN_PS70_cost_matrix.csv'), index=False, encoding='utf-8-sig')

    summary = [
        dict(metric='tag', value=tag, unit=''),
        dict(metric='arm', value=DP.ARM, unit=''),
        dict(metric='e_grid_mode', value=C.E_GRID_MODE, unit=''),
        dict(metric='e_grid', value=C.E_GRID, unit='tCO2/MWh'),
        dict(metric='gas_coupled', value=True, unit=''),
        dict(metric='ps_bar', value=PS, unit='bar'),
        dict(metric='ps2_bar', value=PS, unit='bar'),
        dict(metric='risk_lambda', value=RISK_LAMBDA, unit=''),
        dict(metric='n_train_scen', value=len(reduced), unit=''),
        dict(metric='scen_probs', value=';'.join(f'{sc["prob"]:.6f}' for sc in reduced), unit=''),
        dict(metric='rp_rn_mip_gap', value=float(sp_rn['mip_gap']), unit=''),
        dict(metric='rp_rn_status', value=int(sp_rn['status']), unit=''),
        dict(metric='rp_cvar_mip_gap', value=float(sp_cvar['mip_gap']), unit=''),
        dict(metric='rp_cvar_status', value=int(sp_cvar['status']), unit=''),
        dict(metric='feas_all_ok',
             value=bool(feas['feasible'].all()), unit=''),
        dict(metric='feas_n_infeasible', value=int((~feas['feasible']).sum()), unit=''),
    ]
    summary += value_metrics(df, rp_obj)
    save_summary(tag, summary)

    vss = [r for r in summary if r['metric'] == 'vss_train'][0]['value']
    evpi = [r for r in summary if r['metric'] == 'evpi_train'][0]['value']
    rp_e = [r for r in summary if r['metric'] == 'rp_train_eval'][0]['value']
    eev_e = [r for r in summary if r['metric'] == 'eev_train'][0]['value']
    ws_p = [r for r in summary if r['metric'] == 'ws_train_prob'][0]['value']
    ok = (vss >= 0) and (vss <= evpi)
    print(f'[PS70|in-sample] RP_train={rp_e:.2f} EEV_train={eev_e:.2f} WS_train={ws_p:.2f}')
    print(f'[PS70|in-sample] VSS_train={vss:.2f} EVPI_train={evpi:.2f} '
          f'0<=VSS<=EVPI: {"成立" if ok else "不成立"}')
    print(f'[PS70|feasibility] 三承诺 x 8 场景全部可行: {bool(feas["feasible"].all())}')
    print(md.to_string(index=False))
    print(ddf.to_string(index=False))


if __name__ == '__main__':
    which = sys.argv[1].lower() if len(sys.argv) > 1 else ''
    if which == 'b0':
        run_b0()
    elif which == 'ps70':
        run_ps70()
    else:
        raise SystemExit('用法: in_sample_value_v3.py [b0|ps70]（每档独立进程）')
    print('done')
