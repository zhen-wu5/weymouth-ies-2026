# -*- coding: utf-8 -*-
"""code_v3 Task 4：方法对方法基线的**取数与对照**脚本。

这不是第二条主链。主链仍然是 gc_run_v3.py + data_v3.ARMS：基线档就是
`V3_ARM=steady Y:/cuda/python.exe gc_run_v3.py PS70`（同理 PS50/PS60），
产物 V3_GC_*_steady_{summary,oos,gas,structure,plan}.csv 与 main 档逐字段同构。
本脚本只做三件主链做不了的事：

  1) probe  ：在**同一个进程、同一次 prepare()、同一组 reduced 场景**下，
              对 ps=70 把 dynamic（本文）与 steady（基线）两档各解一次 RP，
              落盘两档的结构指纹与逐时方案（含节点不平衡残差），并顺带做一次
              "本文档复现存档 rp_exp_cost"的同源校验。
              —— 结构对照必须同源同进程，否则"其余口径全冻结"这句话没人能验。
  2) compare3：把 B0 / steady / main(PS70) 三列并排成一张表（同一 100 留出日）。
  3) ps_scan ：steady 的 p_s=50/60/70 三点，与 main 的同三点并列，看源压杠杆
              在"无管存"口径下是否仍存在。

输出（results/）：
  V3_BASELINE_probe.csv          两档 RP 的目标值/状态/时间 + 同源校验 + 包含关系判据
  V3_BASELINE_structure.csv      两档的模型结构指纹（长表：arm, level, key, value）
  V3_BASELINE_plan.csv           两档逐时气网方案与节点不平衡残差（8 场景 × 24 h）
  V3_BASELINE_compare3.csv       三列并排对比
  V3_BASELINE_ps_scan.csv        p_s 三点 × {main, steady}

用法：PYTHONIOENCODING=utf-8 Y:/cuda/python.exe -B gc_run_baseline_v3.py [all|probe|compare]
"""
import os
import sys
import json

import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_gc_v3 as MG

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

PS_PROBE = 70.0
PD_MIN = 20.0
TOL_BAR = 1e-4
TOL_MW = 1e-4
TOL_BOUND = 1e-5         # 压力硬边界的可判定容差（Gurobi 可行性的量级 1e-6）

# 三列：B0（无气网）、steady（Kanelakis 式稳态输送基线）、main（本文 GC）
COLS = [('B0',    'B0',    'main'),
        ('steady', 'PS70', 'steady'),
        ('main',  'PS70', 'main')]


def _sm(cfg, arm):
    return DP.load_summary(cfg, arm) if hasattr(DP, 'load_summary') else pd.read_csv(
        os.path.join(RES, f'V3_GC_{cfg}_{arm}_summary.csv')
    ).set_index('metric')['value']


def _bnum(x):
    """CSV 里的 'True'/'False'/''/数字 -> 可比较标量（与 audit P 节同名同义）。"""
    if isinstance(x, str):
        t = x.strip()
        if t.lower() == 'true':
            return True
        if t.lower() == 'false':
            return False
        if t in ('', 'nan'):
            return None
        try:
            return float(t)
        except ValueError:
            return t
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    if isinstance(x, bool):
        return x
    try:
        return float(x)
    except (TypeError, ValueError):
        return x


def _metric(s, key, default=np.nan):
    try:
        v = s[key]
    except KeyError:
        return default
    if isinstance(v, str):
        return v
    try:
        f = float(v)
    except (TypeError, ValueError):
        return v
    return f if np.isnan(f) else f


# ----------------------------------------------------------------------------
# 1) probe：同进程解两档，落结构指纹 + 逐时方案
# ----------------------------------------------------------------------------
def probe():
    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']
    arch = _sm('PS70', 'main')
    arch_rp_cost = float(arch['rp_exp_cost'])
    arch_rp_carbon = float(arch['rp_exp_carbon'])
    arch_carbon_min = float(arch['carbon_min_exp_rp'])

    rows, srows, prows = [], [], []
    got = {}
    for tag, gm in (('main', 'dynamic'), ('steady', 'steady')):
        # 目标（成本最小 RP）
        rc = MG.solve_gc(base, scenarios=reduced, mode='cost',
                         gas_coupled=True, ps=PS_PROBE, ps2=PS_PROBE, gas_model=gm)
        # 目标（碳最小，与主链同一口径：allow_shed=False）
        rk = MG.solve_gc(base, scenarios=reduced, mode='carbon', allow_shed=False,
                         gas_coupled=True, ps=PS_PROBE, ps2=PS_PROBE, gas_model=gm)
        got[tag] = (rc, rk)
        st = rc['struct']
        for k, v in sorted(st.items()):
            if k == 'fams':
                continue
            srows.append(dict(arm=tag, gas_model=gm, level='model_scalar',
                              key=k, value=v))
        for k, v in sorted(st['fams'].items()):
            srows.append(dict(arm=tag, gas_model=gm, level='constr_family',
                              key=k, value=v))
        for r in rc['scen_rows']:
            sch = r['sched']
            prows.append(pd.DataFrame(dict(
                arm=tag, gas_model=gm, scenario=r['scenario'], prob=r['prob'],
                hour=range(len(sch)),
                p1_bar=sch['p1_bar'].to_numpy(), p2_bar=sch['p2_bar'].to_numpy(),
                f1=sch['f1'].to_numpy(), f1_ub=sch['f1_ub'].to_numpy(),
                f2=sch['f2'].to_numpy(), g1_chp=sch['g1_chp'].to_numpy(),
                g2_gb=sch['g2_gb'].to_numpy(), comp_fuel=sch['comp_fuel'].to_numpy(),
                res1=np.asarray(r['res1'], float), res2=np.asarray(r['res2'], float),
                cost_s=r['op_cost'], carbon_s=r['carbon'])))
        rows.append(dict(
            arm=tag, gas_model=gm, ps=PS_PROBE,
            rp_exp_cost=rc['exp_cost'], rp_exp_carbon=rc['exp_carbon'],
            rp_status=rc['status'], rp_time_s=rc['solve_time'],
            rp_n_vars=rc['n_vars'], rp_n_cons=rc['n_cons'],
            rp_mip_gap=rc['mip_gap'],
            carbon_min_exp_rp=(rk['exp_carbon'] if rk is not None else np.nan),
            carbon_min_status=(rk['status'] if rk is not None else -1),
            carbon_min_time_s=(rk['solve_time'] if rk is not None else np.nan),
            # 管存使用度（解里的残差，不看标签）
            rp_hours=len(reduced) * 24,
            rp_store_h=sum(r['store_h'] for r in rc['scen_rows']),
            rp_max_abs_res=max(r['max_res_abs_h'] for r in rc['scen_rows']),
            rp_lp_used_MWh_mean=float(np.mean([r['lp_used_MWh'] for r in rc['scen_rows']])),
            rp_day_end_imbal_MWh_max_abs=max(abs(r['day_end_imbalance_MWh'])
                                             for r in rc['scen_rows']),
            A1_eff=rc['A1_eff'], A2_eff=rc['A2_eff'],
            A1_frozen=rc['A1'], K_frozen=rc['K1'], n_pts_frozen=rc['n_pts'],
            comp_ratio_frozen=rc['comp_ratio'], gate_valve=rc['gate_valve'],
            p0_mode_eff=rc['p0_mode'], pd_min_frozen=rc['pd_min'], ps2=rc['ps2'],
            mip_gap=rc['mip_gap'], n_scen=rc['n_scen'], T=rc['T'],
            struct_node1=st['n_node1'], struct_node2=st['n_node2'],
            struct_p1cyc=st['n_p1cyc'], struct_p2cyc=st['n_p2cyc'],
            struct_steady_node1=st['n_steady_node1'],
            struct_steady_node2=st['n_steady_node2'],
            struct_p1_0_is_var=st['has_p0_1'], struct_p2_0_is_var=st['has_p0_2'],
            struct_binaries=st['n_binaries'], struct_gen_constrs=st['n_gen_constrs'],
        ))
    df = pd.DataFrame(rows)

    # ---- 同源校验：本文档必须复现存档 rp_exp_cost（证明没换场景/种子/划分）----
    df['arch_rp_exp_cost'] = np.nan
    df['arch_carbon_min'] = np.nan
    df.loc[df['arm'] == 'main', 'arch_rp_exp_cost'] = arch_rp_cost
    df.loc[df['arm'] == 'main', 'arch_carbon_min'] = arch_carbon_min
    m = df[df['arm'] == 'main'].iloc[0]
    rel = abs(m['rp_exp_cost'] - arch_rp_cost) / abs(arch_rp_cost)
    rel_c = abs(m['rp_exp_carbon'] - arch_rp_carbon) / abs(arch_rp_carbon)
    df['probe_vs_archived_rp_cost_reldiff'] = np.nan
    df.loc[df['arm'] == 'main', 'probe_vs_archived_rp_cost_reldiff'] = rel
    df['probe_vs_archived_rp_carbon_reldiff'] = np.nan
    df.loc[df['arm'] == 'main', 'probe_vs_archived_rp_carbon_reldiff'] = rel_c
    s = df[df['arm'] == 'steady'].iloc[0]
    # ---- 包含关系判据：steady ⊆ dynamic => dynamic 不会比 steady 差 ----
    # object dtype：pandas 3 拒绝把 bool 写进由 np.nan 初始化的 float64 列。
    for _c in ('containment_cost_ok', 'containment_carbon_ok'):
        df[_c] = pd.Series([np.nan] * len(df), dtype=object)
    df.loc[df['arm'] == 'main', 'containment_cost_ok'] = bool(
        m['rp_exp_cost'] <= s['rp_exp_cost'] + 1e-6)
    df.loc[df['arm'] == 'main', 'containment_carbon_ok'] = bool(
        m['carbon_min_exp_rp'] <= s['carbon_min_exp_rp'] + 1e-6)

    df.to_csv(os.path.join(RES, 'V3_BASELINE_probe.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(srows).to_csv(os.path.join(RES, 'V3_BASELINE_structure.csv'),
                               index=False, encoding='utf-8-sig')
    pd.concat(prows, ignore_index=True).to_csv(
        os.path.join(RES, 'V3_BASELINE_plan.csv'), index=False, encoding='utf-8-sig')
    m = df[df['arm'] == 'main'].iloc[0]      # 重新取：上面新增的列不在旧的 m 里
    print('[probe] main rp_cost %.6f vs archived %.6f (rel %.2e) | carbon rel %.2e'
          % (m['rp_exp_cost'], arch_rp_cost, rel, rel_c))
    print('[probe] steady rp_cost %.6f  (steady - main = %+.3f 元/日)'
          % (s['rp_exp_cost'], s['rp_exp_cost'] - m['rp_exp_cost']))
    print('[probe] containment cost_ok=%s carbon_ok=%s'
          % (m['containment_cost_ok'], m['containment_carbon_ok']))
    return df


# ----------------------------------------------------------------------------
# 2) 三列并排
# ----------------------------------------------------------------------------
def _oos_frame(cfg, arm):
    p = os.path.join(RES, f'V3_GC_{cfg}_{arm}_oos.csv')
    return pd.read_csv(p) if os.path.exists(p) else None


def _gas_frame(cfg, arm):
    p = os.path.join(RES, f'V3_GC_{cfg}_{arm}_gas.csv')
    return pd.read_csv(p) if os.path.exists(p) else None


# (显示名, summary 里的 metric key 或 'gas:<key>', 单位, 含义)
ROWS = [
    ('gas_coupled',            'gas_coupled',            '',       '是否有气网'),
    ('gas_model',              'gas_model',              '',       '气网物理口径'),
    ('ps_bar',                 'ps_bar',                 'bar',    '源压 p_s'),
    ('n_scen',                 'rp_n_scen',              '',       '场景数（推导）'),
    ('e_grid',                 'e_grid',                 'tCO2/MWh', '电网排放因子 EF'),
    ('n_test_days',            'n_test_days',            '天',      '留出日数'),
    # ---- 成本与碳 ----
    ('oos_mean_cost_sp',       'oos_mean_cost_sp',       '元/日',  '期望成本（100 留出日，SC 承诺再调度）'),
    ('oos_mean_cost_eev',      'oos_mean_cost_eev',      '元/日',  '期望成本（EEV 承诺）'),
    ('rp_exp_cost',            'rp_exp_cost',            '元/日',  '期望成本（训练期 RP 目标值）'),
    ('rp_exp_carbon',          'rp_exp_carbon',          'tCO2',   '期望碳（RP）'),
    ('carbon_min_exp_rp',      'carbon_min_exp_rp',      'tCO2',   '期望碳（碳最小）'),
    ('oos_mean_carbon_sp',     'oos_mean_carbon_sp',     'tCO2/日', '期望碳（100 留出日）'),
    # ---- 物理咬合 ----
    ('closure_bar_mean',       'gas_oos_day_end_closure_bar_mean', 'bar', '日末压力闭合误差（均值，OOS）'),
    ('closure_bar_max',        'gas_oos_day_end_closure_bar_max',  'bar', '日末压力闭合误差（最大，OOS）'),
    ('closure_probe_bar_max',  '__closure_probe__', 'bar', '日末压力闭合误差（实测，RP 8 场景最大；两耦合档同进程同场景）'),
    ('closure_by_construction','__closure_by_construction__',       '',    '闭合是否可达（结构判据）'),
    ('day_end_imbal_MWh_rp', '__probe:rp_day_end_imbal_MWh_max_abs__', 'MWh',
     '日末管存残差（RP 8 场景最大；同进程同场景实测）'),
    ('store_h_rp',           '__probe:rp_store_h__',                'h',
     '管存被使用的小时数（RP，192 场景小时；同进程同场景实测）'),
    ('lp_used_MWh_rp',       '__probe:rp_lp_used_MWh_mean__',       'MWh',
     '日内管存使用幅度（RP；同进程同场景实测）'),
    ('gas_model_rp',         '__probe:gas_model__',                 '', '气网物理口径（probe 同源）'),
    ('rp_status_name',       '__rp_status_name__',                  '', 'Gurobi 状态名（RP）'),
    ('f1_throttle_h',          'gas_oos_f1_throttle_h',  'h',      '闸阀节流小时数（f1 严格低于 Weymouth 上界）'),
    ('pressure_viol_h',        '__pressure_viol_h__',    'h',      '压力越限小时数'),
    ('pressure_viol_days',     '__pressure_viol_days__', '天',      '压力越限天数'),
    ('p1_at_min_h',            'gas_oos_p1_at_min_h',    'h',      'p1 贴下界小时数'),
    ('p1_at_max_h',            'gas_oos_p1_at_max_h',    'h',      'p1 贴上界小时数'),
    ('f1_at_cap_h',            'gas_oos_f1_at_cap_h',    'h',      'f1 达 Weymouth 上限小时数'),
    ('store_h_total',          'gas_oos_store_h_total',  'h',      '管存被使用的小时数（逐时残差>1e-6）'),
    ('lp_used_MWh_mean',       'gas_oos_lp_used_MWh_mean', 'MWh/日', '日内管存使用幅度'),
    ('infeasible_days',        '__infeasible_days__',    '天',      '不可行日数（三档任一求解无解）'),
    ('days_shed_sp',           'oos_n_days_shed_sp',     '天',      '切负荷天数'),
    # ---- 计算 ----
    ('rp_solve_time',          'rp_solve_time',          's',      '求解时间（RP）'),
    ('eev_solve_time',         'eev_solve_time',         's',      '求解时间（EEV）'),
    ('carbon_min_time',        'carbon_min_rp_time',     's',      '求解时间（碳最小）'),
    ('rp_status',              'rp_status',              '',       'Gurobi 状态（RP，2=OPTIMAL）'),
    ('carbon_min_status',      'carbon_min_rp_status',   '',       'Gurobi 状态（碳最小）'),
    ('rp_n_vars',              'rp_n_vars',              '',       '变量数（RP）'),
    ('rp_n_cons',              'rp_n_cons',              '',       '约束数（RP）'),
]


def compare3():
    out = []
    names = [c[0] for c in COLS]
    smap = {c[0]: _sm(c[1], c[2]) for c in COLS}
    ofr = {c[0]: _oos_frame(c[1], c[2]) for c in COLS}
    # 结构指纹（main 存档没有 structure 文件，用 probe 的两档指纹；B0 无气网）
    stx = {}
    spath = os.path.join(RES, 'V3_BASELINE_structure.csv')
    if os.path.exists(spath):
        sdf = pd.read_csv(spath)
        for arm, g in sdf.groupby('arm'):
            sc = g[g['level'] == 'model_scalar'].set_index('key')['value']
            stx[arm] = sc

    for key, mkey, unit, desc in ROWS:
        row = dict(metric=key, description=desc, unit=unit)
        for col in names:
            s = smap[col]
            if mkey == 'rp_n_scen':
                row[col] = 8
                continue
            # 直接可取的走 summary；'__x__' 派生键、以及旧存档里根本没有的键走现算。
            if mkey.startswith('__') or mkey not in set(s.index):
                row[col] = _derive(col, key, mkey, ofr[col], s, stx)
            else:
                row[col] = _metric(s, mkey)
        out.append(row)
    df = pd.DataFrame(out)
    df.to_csv(os.path.join(RES, 'V3_BASELINE_compare3.csv'), index=False, encoding='utf-8-sig')
    _print_df(df)
    return df


def _derive(col, key, mkey, oof, s, stx):
    """从逐日 oos 帧 / probe 帧现算的指标（旧存档没有这些键时也能给出同一口径的值）。"""
    coupled = str(s.get('gas_coupled')) == 'True'
    if mkey.startswith('__probe:'):
        # probe 的列名 -> 三列的对应：B0 无气网，main/steady 与 probe 的 arm 同名。
        pk = mkey[len('__probe:'):-2]
        pp = os.path.join(RES, 'V3_BASELINE_probe.csv')
        if col == 'B0' or not coupled or not os.path.exists(pp):
            return 'n/a (no gas network)' if col == 'B0' else np.nan
        pr = pd.read_csv(pp, encoding='utf-8-sig').set_index('arm')
        if pk == 'gas_model':
            return str(pr.loc[col, 'gas_model'])
        return _bnum(pr.loc[col, pk]) if pk in pr.columns else np.nan
    if mkey == '__rp_status_name__':
        try:
            from model_mesh_v3 import status_name
            return status_name(int(float(s['rp_status'])))
        except Exception:
            return 'n/a'
    if mkey == '__closure_probe__':
        # 同进程两档实测：日末管存残差(MWh) / 有效管存容量 = 闭合缺口(bar)。
        # steady 的残差本身恒为 0（无闭合条件可违反），容量为 0 只意味着"无从换算"，
        # 所以残差为 0 时直接给 0.0 并在 notes 里注明是结构性 0 而非"闭合得很好"。
        pp = os.path.join(RES, 'V3_BASELINE_probe.csv')
        if not os.path.exists(pp) or col == 'B0' or not coupled:
            return 'n/a (no gas network)' if col == 'B0' else np.nan
        pr = pd.read_csv(pp, encoding='utf-8-sig').set_index('arm')
        r = pr.loc[col]
        cap = float(r['A1_eff']) * (PS_PROBE - PD_MIN) + float(r['A2_eff']) * (PS_PROBE - PD_MIN)
        res = float(r['rp_day_end_imbal_MWh_max_abs'])
        return (res / cap) if cap > 0 else (0.0 if res < 1e-9 else np.nan)
    if mkey == '__closure_by_construction__':
        if not coupled:
            return 'n/a (no gas network)'
        return {'B0': 'n/a', 'steady': 'not modelled (no line-pack state)',
                'main': 'imposed exactly: p_T == p_0'}[col]
    if mkey == '__infeasible_days__':
        if oof is None:
            return np.nan
        cols = [c for c in ('fail_eev', 'fail_sp', 'fail_ws') if c in oof.columns]
        n_fail = int((oof[cols].astype(str).isin(['True', 'true', '1'])).any(axis=1).sum()) \
            if cols else 0
        n_nan = int(oof[['cost_eev', 'cost_sp', 'cost_ws']].isna().any(axis=1).sum())
        return max(n_fail, n_nan)
    if oof is None or not coupled:
        if mkey in ('gas_oos_f1_throttle_h', '__pressure_viol_h__', '__pressure_viol_days__'):
            return 'n/a (no gas network)'
        return np.nan
    if mkey == '__pressure_viol_h__' or mkey == '__pressure_viol_days__':
        ps = float(s['ps_bar']); pd_min = PD_MIN
        bad = ((oof['p1_min'] < pd_min - TOL_BOUND) | (oof['p1_max'] > ps + TOL_BOUND)
               | (oof['p2_min'] < pd_min - TOL_BOUND) | (oof['p2_max'] > ps + TOL_BOUND))
        ndays = int(bad.sum())
        if mkey == '__pressure_viol_days__':
            return ndays
        # 逐日 min/max 都不越界 => 没有任何一小时越界（充分且必要到日粒度）
        return 0 if ndays == 0 else np.nan
    if mkey == 'gas_oos_store_h_total':
        return int(oof['store_h'].sum()) if 'store_h' in oof.columns else np.nan
    if mkey == 'gas_oos_lp_used_MWh_mean':
        return float(oof['lp_used_MWh'].mean()) if 'lp_used_MWh' in oof.columns else np.nan
    if mkey.startswith('gas_oos_day_end_closure_bar'):
        if 'day_end_imbal_MWh' not in oof.columns:
            return np.nan
        lp_cap = float(s.get('gas_oos_lp_cap_eff_MWh', np.nan))
        if not np.isfinite(lp_cap) or lp_cap <= 0:
            return 0.0 if col == 'steady' else np.nan
        a = oof['day_end_imbal_MWh'].abs() / lp_cap
        return float(a.mean()) if mkey.endswith('mean') else float(a.max())
    if mkey == 'gas_oos_f1_throttle_h':
        return int(oof['f1_throttle_h'].sum()) if 'f1_throttle_h' in oof.columns else np.nan
    return np.nan


def _print_df(df):
    print('\n=== 三列并排（同一 100 留出日）===')
    with pd.option_context('display.width', 200, 'display.max_columns', 20):
        print(df.to_string(index=False))


# ----------------------------------------------------------------------------
# 3) p_s 三点扫描：steady vs main
# ----------------------------------------------------------------------------
def ps_scan():
    rows = []
    for cfg in ('PS50', 'PS60', 'PS70'):
        for col, arm in (('main', 'main'), ('steady', 'steady')):
            p = os.path.join(RES, f'V3_GC_{cfg}_{arm}_summary.csv')
            if not os.path.exists(p):
                rows.append(dict(cfg=cfg, ps=float(cfg[2:]), gas_model=col,
                                 present=False))
                continue
            s = pd.read_csv(p).set_index('metric')['value']
            g = lambda k: float(s[k]) if k in s.index and pd.notna(s[k]) else np.nan
            oof = _oos_frame(cfg, arm)
            n_fail = np.nan
            if oof is not None:
                cols = [c for c in ('fail_eev', 'fail_sp', 'fail_ws') if c in oof.columns]
                n_fail = int((oof[cols].astype(str).isin(['True', 'true', '1'])).any(axis=1).sum()) \
                    if cols else np.nan
            rows.append(dict(
                cfg=cfg, ps=float(cfg[2:]), gas_model=col, present=True,
                rp_exp_cost=g('rp_exp_cost'), rp_exp_carbon=g('rp_exp_carbon'),
                carbon_min_exp_rp=g('carbon_min_exp_rp'),
                oos_mean_cost_sp=g('oos_mean_cost_sp'),
                oos_mean_carbon_sp=g('oos_mean_carbon_sp'),
                rp_status=g('rp_status'), carbon_min_status=g('carbon_min_rp_status'),
                rp_solve_time=g('rp_solve_time'), carbon_min_time=g('carbon_min_rp_time'),
                f1_throttle_h=g('gas_oos_f1_throttle_h'),
                store_h=g('gas_oos_store_h_total'),
                infeasible_days=n_fail,
                rp_n_cons=g('rp_n_cons'), rp_n_vars=g('rp_n_vars'),
            ))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, 'V3_BASELINE_ps_scan.csv'), index=False, encoding='utf-8-sig')
    piv = df.pivot_table(index='ps', columns='gas_model',
                         values=['carbon_min_exp_rp', 'rp_exp_cost'], aggfunc='first')
    print('\n=== p_s 三点：main vs steady ===')
    print(piv.to_string())
    for gm in ('main', 'steady'):
        sub = df[df['gas_model'] == gm].sort_values('ps')
        c = sub['carbon_min_exp_rp'].to_numpy()
        if np.isnan(c).any():
            print(f'[{gm}] 碳地板有缺格，杠杆方向不可判（present={sub["present"].tolist()}）')
            continue
        print(f'[{gm}] carbon_min(p_s=50,60,70) = {c[0]:.3f} {c[1]:.3f} {c[2]:.3f} '
              f'| 单调下降={bool(c[0] > c[1] > c[2])} '
              f'| 50->70 降幅 {c[0]-c[2]:.3f} t '
              f'| 边际 {c[0]-c[1]:.3f} / {c[1]-c[2]:.3f}')
    return df


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('all', 'probe'):
        probe()
    if what in ('all', 'compare'):
        compare3()
    if what in ('all', 'scan'):
        ps_scan()
    print('done')
