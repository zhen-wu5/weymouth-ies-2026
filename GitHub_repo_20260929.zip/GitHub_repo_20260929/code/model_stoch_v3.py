# -*- coding: utf-8 -*-
"""扩展模型：两阶段随机规划（场景法）与任意时长（多日）确定性调度

两阶段结构：
  第一阶段（此处决策）：CHP 启停 u_t 及启停事件 y_t/z_t —— 所有场景共享
  第二阶段（场景决策）：各场景下设备出力、储能、购电
目标：min Σ_s π_s·cost_s + 启动成本（± λ·期望碳排放 / 碳排上限 ε 作用于期望值）

u_fix 参数用于 EEV 再调度（固定第一阶段解，逐场景评估）。
"""
import numpy as np
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

import config_v3 as C


def solve_stoch(data, scenarios=None, mode='cost', lam=0.0, cap=None,
                u_fix=None, verbose=False, min_up=0, min_dn=0,
                grid_cap=None, voll=5000.0, allow_shed=True, gas_cap=None,
                risk_lambda=0.0, cvar_beta=0.95,
                time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP):
    """
    data : dict，含 p_load/h_load/price（长度 T 的一维数组）；wind/pv 在给出 scenarios 时被忽略
    scenarios : None 或 [{'wind':arr,'pv':arr,'prob':float}, ...]；None 时退化为确定性模型
    mode : 'cost' | 'carbon' | 'weighted' | 'eps'
    u_fix : 长度 T 的 0/1 数组，固定 CHP 启停（EEV 再调度用）
    gas_cap : None（默认，与历史逐位一致）或 MW 数值——逐时总取气 g1+g2 的静态线性上限，
              即"把气网当成一根固定容量管"的口径；不引入压力/管存/压缩机燃料。
    """
    T = len(data['p_load'])
    dt = 1.0
    S = 1 if scenarios is None else len(scenarios)
    probs = [1.0] if scenarios is None else [sc['prob'] for sc in scenarios]
    wind_avail = [np.asarray(data['wind'], float)] if scenarios is None \
        else [np.asarray(sc['wind'], float) for sc in scenarios]
    pv_avail = [np.asarray(data['pv'], float)] if scenarios is None \
        else [np.asarray(sc['pv'], float) for sc in scenarios]
    # 允许逐场景负荷（天气相关负荷情景）；缺省时共享 data 级负荷
    p_load_s = [np.asarray(data['p_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('p_load', data['p_load']), float) for sc in scenarios]
    h_load_s = [np.asarray(data['h_load'], float)] if scenarios is None \
        else [np.asarray(sc.get('h_load', data['h_load']), float) for sc in scenarios]
    p_load = np.asarray(data['p_load'], float)
    h_load = np.asarray(data['h_load'], float)
    price = np.asarray(data['price'], float)

    m = gp.Model('IES_stoch')
    m.Params.OutputFlag = 1 if verbose else 0
    m.Params.TimeLimit = time_limit
    m.Params.MIPGap = mipgap

    eta_he = C.CHP['eta_h'] / C.CHP['eta_e']
    pmax, pmin = C.CHP['pmax'], C.CHP['pmin_ratio'] * C.CHP['pmax']

    # ---------- 第一阶段变量 ----------
    u = m.addVars(T, vtype=GRB.BINARY, name='u')
    y = m.addVars(T, vtype=GRB.BINARY, name='y')
    z = m.addVars(T, vtype=GRB.BINARY, name='z')
    if u_fix is not None:
        for t in range(T):
            m.addConstr(u[t] == int(u_fix[t]), name=f'ufix_{t}')

    # ---------- 第二阶段变量（按场景） ----------
    def v(name, ub=GRB.INFINITY):
        return m.addVars(S, T, lb=0, ub=ub, name=name)

    p_wind, p_pv, p_grid, p_chp = v('p_wind'), v('p_pv'), v('p_grid'), v('p_chp')
    if grid_cap is not None:
        for s in range(S):
            for t in range(T):
                m.addConstr(p_grid[s, t] <= grid_cap, name=f'gridcap_{s}_{t}')
    p_shed = v('p_shed') if allow_shed else None   # 失负荷（VOLL 惩罚；allow_shed=False 时禁用）
    h_gb = v('h_gb', C.GB['hmax']); h_eb = v('h_eb', C.EB['hmax']); h_hp = v('h_hp', C.HP['hmax'])
    p_c, p_d = v('p_c', C.ESS['pmax']), v('p_d', C.ESS['pmax'])
    soc = m.addVars(S, T, lb=0, name='soc')
    h_c, h_d = v('h_c', C.HSS['pmax']), v('h_d', C.HSS['pmax'])
    hsoc = m.addVars(S, T, lb=0, name='hsoc')

    cost_s, carbon_s = [], []
    for s in range(S):
        for t in range(T):
            m.addConstr(p_chp[s, t] <= pmax * u[t])
            m.addConstr(p_chp[s, t] >= pmin * u[t])
            m.addConstr(p_wind[s, t] <= wind_avail[s][t])
            m.addConstr(p_pv[s, t] <= pv_avail[s][t])
            p_eb = h_eb[s, t] / C.EB['eta']
            p_hp = h_hp[s, t] / C.HP['cop']
            shed_term = p_shed[s, t] if allow_shed else 0
            m.addConstr(p_wind[s, t] + p_pv[s, t] + p_chp[s, t] + p_grid[s, t] + p_d[s, t]
                        == p_load_s[s][t] - shed_term + p_eb + p_hp + p_c[s, t],
                        name=f'bal_e_{s}_{t}')
            m.addConstr(p_chp[s, t] * eta_he + h_gb[s, t] + h_eb[s, t] + h_hp[s, t] + h_d[s, t]
                        == h_load_s[s][t] + h_c[s, t], name=f'bal_h_{s}_{t}')
            prev_soc = soc[s, t - 1] if t > 0 else C.ESS['soc0'] * C.ESS['cap']
            m.addConstr(soc[s, t] == prev_soc + (C.ESS['eta_c'] * p_c[s, t] - p_d[s, t] / C.ESS['eta_d']) * dt)
            m.addConstr(soc[s, t] <= C.ESS['soc_max'] * C.ESS['cap'])
            m.addConstr(soc[s, t] >= C.ESS['soc_min'] * C.ESS['cap'])
            prev_h = hsoc[s, t - 1] if t > 0 else C.HSS['soc0'] * C.HSS['cap']
            m.addConstr(hsoc[s, t] == prev_h + (C.HSS['eta_c'] * h_c[s, t] - h_d[s, t] / C.HSS['eta_d']) * dt)
            m.addConstr(hsoc[s, t] <= C.HSS['soc_max'] * C.HSS['cap'])
            m.addConstr(hsoc[s, t] >= C.HSS['soc_min'] * C.HSS['cap'])

        m.addConstr(soc[s, T - 1] == C.ESS['soc0'] * C.ESS['cap'])
        m.addConstr(hsoc[s, T - 1] == C.HSS['soc0'] * C.HSS['cap'])

        f_chp = [p_chp[s, t] / C.CHP['eta_e'] for t in range(T)]
        f_gb = [h_gb[s, t] / C.GB['eta'] for t in range(T)]
        if gas_cap is not None:
            # 静态线 cap 口径（轮20 B1）：逐时总取气封顶在 Weymouth 峰值供路能力上，
            # 但不引入压力状态、管存动态与压缩机燃料——与 pwl_recheck 的线性气容 RP 同一条约束。
            for t in range(T):
                m.addConstr(f_chp[t] + f_gb[t] <= gas_cap, name=f'gascap_{s}_{t}')
        carbon_s.append(gp.quicksum(
            C.E_GRID * p_grid[s, t] + C.E_GAS * (f_chp[t] + f_gb[t]) for t in range(T)))
        cost_s.append(gp.quicksum(
            price[t] * p_grid[s, t] + C.C_GAS * (f_chp[t] + f_gb[t])
            + (voll * p_shed[s, t] if allow_shed else 0)
            + C.CHP['c_om'] * p_chp[s, t] + C.GB['c_om'] * h_gb[s, t]
            + C.EB['c_om'] * h_eb[s, t] + C.HP['c_om'] * h_hp[s, t]
            + C.ESS['c_om'] * (p_c[s, t] + p_d[s, t]) + C.HSS['c_om'] * (h_c[s, t] + h_d[s, t])
            + C.C_OM_WIND * p_wind[s, t] + C.C_OM_PV * p_pv[s, t]
            for t in range(T)))

    # CHP 爬坡与启停转移（第一阶段）
    for t in range(T):
        # 各场景下电出力变化均受爬坡约束
        for s in range(S):
            up = p_chp[s, t] - (p_chp[s, t - 1] if t > 0 else 0.0)
            m.addConstr(up <= C.CHP['ramp'] + pmax * y[t])
            m.addConstr(-up <= C.CHP['ramp'] + pmax * z[t])
        m.addConstr(y[t] - z[t] == u[t] - (u[t - 1] if t > 0 else 0))

    # 最小启停时间（机组组合刚性，min_up/min_dn>0 时启用）
    if min_up > 0:
        for t in range(T):
            m.addConstr(gp.quicksum(y[tt] for tt in range(max(0, t - min_up + 1), t + 1)) <= u[t])
    if min_dn > 0:
        for t in range(T):
            m.addConstr(gp.quicksum(z[tt] for tt in range(max(0, t - min_dn + 1), t + 1)) <= 1 - u[t])

    exp_cost = gp.quicksum(probs[s] * cost_s[s] for s in range(S))
    exp_carbon = gp.quicksum(probs[s] * carbon_s[s] for s in range(S))
    startup = C.CHP['c_startup'] * gp.quicksum(y)

    # CVaR 的模糊集解释（本模型 "distributionally robust" 的确切含义）：
    #   CVaR_β(C) = max_{q ∈ Q_β} Σ_s q_s C_s,
    #   Q_β = { q : Σ_s q_s = 1, 0 ≤ q_s ≤ p̂_s/(1-β) },  p̂ 为经验概率。
    # 即在"概率密度被经验分布按 1/(1-β) 倍数界住"的密度有界模糊集上取最坏期望，
    # 属 f-散度型 DRO 的连贯风险代理；与 E25 基于 Wasserstein 距离的模糊集不同。
    # τ 为 VaR 辅助变量（Rockafellar–Uryasev 线性化）。
    cvar_expr = None
    if risk_lambda > 0:
        tau = m.addVar(lb=-GRB.INFINITY, name='tau')
        zeta = m.addVars(S, lb=0, name='zeta')
        for s in range(S):
            m.addConstr(zeta[s] >= cost_s[s] - tau)
        cvar_expr = tau + gp.quicksum(probs[s] * zeta[s] for s in range(S)) / (1 - cvar_beta)

    if mode == 'cost':
        if risk_lambda > 0:
            # 风险目标作用于含启动成本的总成本。启动成本在场景间为同一常量
            # （仅由第一阶段 y_t 决定），故 CVaR(C_op + C_start) = CVaR(C_op) + C_start，
            # 等于 (1-λr)·E[C_op] + λr·CVaR(C_op) + C_start。
            # 若原样写成 (1-λr)(E+startup) + λr·CVaR(C_op)，启动成本只被计入了
            # (1-λr) 权重，λr>0 时被系统性低估。
            m.setObjective((1 - risk_lambda) * exp_cost
                           + risk_lambda * cvar_expr + startup, GRB.MINIMIZE)
        else:
            m.setObjective(exp_cost + startup, GRB.MINIMIZE)
    elif mode == 'carbon':
        m.setObjective(exp_carbon, GRB.MINIMIZE)
    elif mode == 'weighted':
        m.setObjective(exp_cost + startup + lam * exp_carbon, GRB.MINIMIZE)
    elif mode == 'eps':
        if cap is None:
            raise ValueError("mode='eps' 需要 cap")
        m.setObjective(exp_cost + startup, GRB.MINIMIZE)
        m.addConstr(exp_carbon <= cap, name='carbon_cap')
    else:
        raise ValueError(mode)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        return None

    # ---------- 结果提取 ----------
    scen_rows = []
    for s in range(S):
        sched = pd.DataFrame({
            'wind_avail': wind_avail[s], 'pv_avail': pv_avail[s],
            'p_wind': [p_wind[s, t].X for t in range(T)],
            'p_pv': [p_pv[s, t].X for t in range(T)],
            'p_grid': [p_grid[s, t].X for t in range(T)],
            'p_chp': [p_chp[s, t].X for t in range(T)],
            'u_chp': [u[t].X for t in range(T)],
            'h_chp': [p_chp[s, t].X * eta_he for t in range(T)],
            'h_gb': [h_gb[s, t].X for t in range(T)],
            'h_eb': [h_eb[s, t].X for t in range(T)],
            'h_hp': [h_hp[s, t].X for t in range(T)],
            'p_ess_c': [p_c[s, t].X for t in range(T)],
            'p_ess_d': [p_d[s, t].X for t in range(T)],
            'soc_ess': [soc[s, t].X for t in range(T)],
            'h_hss_c': [h_c[s, t].X for t in range(T)],
            'h_hss_d': [h_d[s, t].X for t in range(T)],
            'soc_hss': [hsoc[s, t].X for t in range(T)],
            'p_load': p_load_s[s], 'h_load': h_load_s[s], 'price': price,
        })
        n_start = int(round(sum(y[t].X for t in range(T))))
        scen_rows.append(dict(
            scenario=s, prob=probs[s],
            op_cost=float(cost_s[s].getValue()),
            startup_cost=C.CHP['c_startup'] * n_start,
            carbon=float(carbon_s[s].getValue()),
            grid_buy_MWh=float(sched['p_grid'].sum() * dt),
            gas_MWh=float((sched['p_chp'].sum() / C.CHP['eta_e']
                           + sched['h_gb'].sum() / C.GB['eta']) * dt),
            re_avail_MWh=float((wind_avail[s] + pv_avail[s]).sum() * dt),
            re_used_MWh=float((sched['p_wind'] + sched['p_pv']).sum() * dt),
            shed_MWh=(float(sum(p_shed[s, t].X for t in range(T)) * dt) if allow_shed else 0.0),
            sched=sched,
        ))

    exp_total_cost = float(exp_cost.getValue()) + C.CHP['c_startup'] * int(round(sum(y[t].X for t in range(T))))
    scen_costs = np.array([float(cost_s[s].getValue()) for s in range(S)])
    scen_probs = np.array(probs)
    order = np.argsort(-scen_costs)
    cvar_emp = float(np.sum(scen_probs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]] *
                            scen_costs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]])
                     / max(1e-9, np.sum(scen_probs[order[:max(1, int(np.ceil((1 - cvar_beta) * S)))]])))
    metrics = dict(
        mode=mode, lam=lam, cap=cap, n_scen=S, T=T, u_fix=u_fix is not None,
        min_up=min_up, min_dn=min_dn, risk_lambda=risk_lambda, cvar_beta=cvar_beta,
        cvar_model=(float(cvar_expr.getValue()) if cvar_expr is not None else None),
        cvar_emp=cvar_emp, worst_cost=float(scen_costs.max()),
        exp_cost=exp_total_cost,
        exp_carbon=float(exp_carbon.getValue()),
        solve_time=float(m.Runtime), mip_gap=float(m.MIPGap),
        n_vars=int(m.NumVars), n_cons=int(m.NumConstrs), status=int(m.Status),
        scen_rows=scen_rows,
    )
    return metrics
