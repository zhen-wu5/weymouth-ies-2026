# -*- coding: utf-8 -*-
"""任务三：甘肃本地风电（5min -> 小时）与风-光同省配对数据集

数据源：
  Y:\\科研\\电力数据集\\P02【免费公开】精选5套风电及气象数据集\\
  （1）连云港2019风电及气象数据\\2019风速风功率（gansu）_步长5min.csv
  文件头：Longitude 94.433685E, Latitude 40.877926N（甘肃西北部，酒泉一带），
  2019 全年 5 分钟粒度：power (MW) 与 100m 风速 (m/s)。

小时聚合口径（一次定死）：**时间步平均功率**（不是能量积分——步长恒定 5min 时
两者等价，平均功率直接给出该小时平均出力 MW；聚合时间戳记为小时起点，
与模型 t=0..23 惯例一致）。负值/NaN 处理：功率截断为 >=0，缺失小时如实标记。

对比（论文证据）：
  A. 同省组合：甘肃风 + 甘肃光（2019，同省同年）—— v3 主口径
  B. 现用组合：连云港风（江苏）+ 甘肃光 —— 旧口径，跨华东/西北两网
  指标：逐时出力相关系数（风速小时级 8760 对 8760）、日峰时段重叠度
  （风/光各自日平均出力曲线的峰时段交集）、日内互补性（风光合成曲线的
  爬坡率与波动率）。

输出（code_v3/results/）：
  gansu_wind_2019_hourly.csv          甘肃风小时级（MW、标幺）
  wind_pv_pairing_metrics.csv         A/B 组合对比指标
"""
import os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

WIND_CSV = (r'Y:\科研\电力数据集\P02【免费公开】精选5套风电及气象数据集'
            r'\（1）连云港2019风电及气象数据\2019风速风功率（gansu）_步长5min.csv')
PV_XLSX = (r'Y:\科研\电力数据集\P03【免费公开】精选4套光伏及气象数据集'
           r'\（1）甘肃2007-2020光伏15min数据（附NWP）.xlsx')
LYG_XLSX = (r'Y:\科研\电力数据集\P02【免费公开】精选5套风电及气象数据集'
            r'\（1）连云港2019风电及气象数据\2019风电lianyungang.xlsx')
YEAR = 2019


def load_gansu_wind(refresh=False):
    cache = os.path.join(RES, 'gansu_wind_2019_hourly.csv')
    if os.path.exists(cache) and not refresh:
        return pd.read_csv(cache, index_col=0, parse_dates=True)['wind_mw']

    df = pd.read_csv(WIND_CSV, skiprows=2)
    df.columns = ['Year', 'Month', 'Day', 'Hour', 'Minute', 'power_mw', 'ws100']
    ts = pd.to_datetime(dict(year=df.Year, month=df.Month, day=df.Day,
                             hour=df.Hour, minute=df.Minute))
    df = df.assign(ts=ts).drop_duplicates('ts').set_index('ts')
    diag = {
        'n_rows_5min': int(len(df)),
        'n_expected_5min': 105120,
        'power_nan': int(df.power_mw.isna().sum()),
        'power_negative': int((df.power_mw < 0).sum()),
        'power_max_mw': float(df.power_mw.max()),
        'ws_nan': int(df.ws100.isna().sum()),
    }
    print('gansu wind 5min diag:', diag)
    # 小时聚合：时间步平均功率（5min 恒定步长，均值即平均功率）
    hs = df.resample('1h').mean()
    diag_h = {
        'n_hours': int(len(hs)),
        'n_complete': int(hs.power_mw.notna().sum()),
        'n_nan_hours': int(hs.power_mw.isna().sum()),
        'n_zero_hours': int((hs.power_mw == 0).sum()),
    }
    print('gansu wind hourly diag:', diag_h)
    out = pd.DataFrame({
        'wind_mw': hs['power_mw'].clip(lower=0),
        'wind_pu': hs['power_mw'].clip(lower=0) / hs['power_mw'].clip(lower=0).max(),
    })
    out.to_csv(cache, encoding='utf-8-sig')
    return out['wind_mw']


def load_gansu_pv_2019(refresh=False):
    """甘肃光伏 2019 -> 小时级平均功率 MW（15min 均值聚合，口径与 code/data_sites 一致）"""
    cache = os.path.join(RES, 'gansu_pv_2019_mw.csv')
    if os.path.exists(cache) and not refresh:
        return pd.read_csv(cache, index_col=0, parse_dates=True)['pv_mw']
    pv = pd.read_excel(PV_XLSX, usecols=['采样结束时刻', '实际功率'])
    pv.columns = ['ts', 'pw']
    pv['ts'] = pd.to_datetime(pv['ts'], utc=True).dt.tz_localize(None)
    pv = pv[(pv['ts'] >= f'{YEAR}-01-01') & (pv['ts'] < f'{YEAR + 1}-01-01')]
    hs = pv.set_index('ts')['pw'].clip(lower=0).resample('1h').mean()
    # 15min 采样结束时刻 -> 小时起点时间戳（-1h 对齐到小时起点）
    hs.index = hs.index - pd.Timedelta(hours=1)
    hs.name = 'pv_mw'
    hs.to_frame().to_csv(cache, encoding='utf-8-sig')
    return hs


def load_lianyungang_wind_2019():
    """连云港风电（三机组合计 191.5 MW）-> 小时级标幺"""
    df = pd.read_excel(LYG_XLSX, skiprows=1)
    df = df.iloc[:, :4]
    df.columns = ['ts', 'w1', 'w2', 'w3']
    df['ts'] = pd.to_datetime(df['ts'])
    hs = df.set_index('ts')[['w1', 'w2', 'w3']].sum(axis=1).clip(lower=0).resample('1h').mean()
    mask = (hs.index >= f'{YEAR}-01-01') & (hs.index < f'{YEAR + 1}-01-01')
    return hs[mask]


def pearson(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    m = ~(np.isnan(a) | np.isnan(b))
    return float(np.corrcoef(a[m], b[m])[0, 1])


def peak_window_overlap(a, b, hours=24):
    """日平均出力曲线（24h）的峰时段（高于均值+0.5*std 的时段）重叠度"""
    a = np.asarray(a, float); b = np.asarray(b, float)
    pa = set(np.where(a > a.mean() + 0.5 * a.std())[0])
    pb = set(np.where(b > b.mean() + 0.5 * b.std())[0])
    inter = len(pa & pb)
    union = len(pa | pb)
    return inter, union, (inter / union if union else np.nan), sorted(pa), sorted(pb)


def main():
    gw = load_gansu_wind()
    gpv = load_gansu_pv_2019()
    lyg = load_lianyungang_wind_2019()

    # 对齐到共同索引（全年 8760）
    idx = pd.date_range(f'{YEAR}-01-01', f'{YEAR + 1}-01-01', freq='h', inclusive='left')
    gw = gw.reindex(idx); gpv = gpv.reindex(idx); lyg = lyg.reindex(idx)
    print('aligned hours: gw %d nan=%d, gpv %d nan=%d, lyg %d nan=%d'
          % (len(gw), gw.isna().sum(), len(gpv), gpv.isna().sum(),
             len(lyg), lyg.isna().sum()))
    # 缺失处理口径：甘肃光伏对齐后 1 个 NaN 小时（15min 采样结束时刻右移 1h 对齐
    # 到小时起点所致的边界缺测），按小时线性插值填补，并在清单中声明。
    for s in (gw, gpv, lyg):
        n0 = int(s.isna().sum())
        if n0:
            print(f'  NaN hours before fill: {n0} -> {list(s.index[s.isna()])}')
            s.interpolate(method='linear', limit_direction='both', inplace=True)

    def hourly_pu(s):
        s = s.dropna()
        return s / s.max()

    gw_pu = gw / gw.max(); gpv_pu = gpv / gpv.max(); lyg_pu = lyg / lyg.max()

    metrics = {}
    # --- 相关性 ---
    metrics['corr_wind_gansu_vs_pv_gansu'] = pearson(gw_pu, gpv_pu)
    metrics['corr_wind_lyg_vs_pv_gansu'] = pearson(lyg_pu, gpv_pu)
    metrics['corr_wind_gansu_vs_wind_lyg'] = pearson(gw_pu, lyg_pu)
    # 风光负相关/互补：光伏为零的夜间，风电出力水平
    night = gpv_pu <= 0.01
    metrics['night_wind_share_gansu'] = float(gw_pu[night.values].mean())
    metrics['day_wind_share_gansu'] = float(gw_pu[~night.values].mean())

    # --- 日峰时段重叠度（日均出力曲线 24h）---
    gw_day = gw_pu.groupby(gw_pu.index.hour).mean()
    gpv_day = gpv_pu.groupby(gpv_pu.index.hour).mean()
    lyg_day = lyg_pu.groupby(lyg_pu.index.hour).mean()
    inter, union, jacc, pa, pb = peak_window_overlap(gw_day, gpv_day)
    metrics['peak_overlap_gansu_w_gansu_pv'] = jacc
    metrics['peak_hours_gansu_wind'] = str([int(x) for x in pa])
    metrics['peak_hours_gansu_pv'] = str([int(x) for x in pb])
    inter2, union2, jacc2, pa2, pb2 = peak_window_overlap(lyg_day, gpv_day)
    metrics['peak_overlap_lyg_w_gansu_pv'] = jacc2
    metrics['peak_hours_lyg_wind'] = str([int(x) for x in pa2])

    # --- 合成出力的日内波动与爬坡（互补性：合成曲线越平滑越好）---
    for name, combo in [
        ('gansu_w+gansu_pv', (gw_pu.fillna(0) + gpv_pu.fillna(0))),
        ('lyg_w+gansu_pv', (lyg_pu.fillna(0) + gpv_pu.fillna(0))),
    ]:
        arr = combo.values
        ramp = np.abs(np.diff(arr))
        metrics[f'ramp_mean_{name}'] = float(ramp.mean())
        metrics[f'ramp_p95_{name}'] = float(np.percentile(ramp, 95))
        metrics[f'ramp_max_{name}'] = float(ramp.max())
        metrics[f'std_{name}'] = float(arr.std())

    m = pd.DataFrame({'metric': list(metrics), 'value': list(metrics.values())})
    m.to_csv(os.path.join(RES, 'wind_pv_pairing_metrics.csv'),
             index=False, encoding='utf-8-sig')
    print(m.to_string(index=False))


if __name__ == '__main__':
    main()
