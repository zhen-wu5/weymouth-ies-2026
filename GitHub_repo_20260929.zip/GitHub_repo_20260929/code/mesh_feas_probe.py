# -*- coding: utf-8 -*-
"""MESH p_s 可行性根因诊断探针（只诊断，不改模型）。

现象：网状气网（gaslib11_core_1src）在 p_s=70 时 SolCount=0（无可行解），而 p_s=50
有 incumbent。本脚本用"最小变量、一次一个"的方式区分三种解释：
  (A) 结构不可行（约束层缺陷）   -> 连续松弛即 INFEASIBLE，可 computeIIS 定位
  (B) 整数 / 大 M / 数值找不到解 -> 松弛可行、MIP 无解
  (C) 目标把搜索拉离可行域       -> 常数目标下各档一律可行

实现方式（不触碰 model_mesh_v3.py）：拦截 gp.Model.optimize，在**已经按原代码建好**的
模型上做最小改动后再求解，记录原始状态码后抛哨兵异常中止调用方，所以
`solve_mesh` 的建模过程逐字不变。

实验（--exp）：
  grid    可行性单调性：p_s 逐档 + 常数目标，只判 Gurobi 有无可行解
  relax   连续松弛可行性：把全部二进制/整数（方向二进制 + 机组承诺）放宽为连续
  anchor  解析可行点锚定：把节点压力全钉在 p_s、方向二进制=1、u=0，剩余 LP 若可行
          即**证明**该 p_s 的原模型可行集非空（该点的约束残差与 p_s 无关）
  start   把同一解析点作为 MIP Start 注入原模型（不添加任何约束、保留原目标）
  stats   矩阵统计对照（nvar/ncon/nbin/系数极值/压力界），50 vs 70

用法：
  Y:/cuda/python.exe -B mesh_feas_probe.py --exp grid   --ps 50,55,60,65,70,75,80 --tl 120
  Y:/cuda/python.exe -B mesh_feas_probe.py --exp relax  --ps 50,60,70,80 --dir-mode soc,binary --tl 120
  Y:/cuda/python.exe -B mesh_feas_probe.py --exp anchor --ps 50,60,70,80 --dir-mode soc,binary --tl 120
  Y:/cuda/python.exe -B mesh_feas_probe.py --exp start  --ps 70 --tl 120
输出：results/V3_MESH_PROBE_<exp>.csv（新增文件，不改写既有结果）
"""
import argparse
import os
import re
import sys
import time

import numpy as np
import pandas as pd

import gurobipy as gp
from gurobipy import GRB

import config_v3 as C
import data_v3 as DP
import model_mesh_v3 as MM

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

PD_MIN = 20.0
K_W = 0.00383
A_NODE = 0.075
COMP_R = 0.02
N_PTS = 60

_ORIG_OPTIMIZE = gp.Model.optimize
_ACTIVE = {'cb': None}

# 状态码图例：直接复用 model_mesh_v3 的运行时反查导出（GRB.Status.*），不再各写一份
# 手抄表。历史上 model_mesh_v3._STATUS 是旧表（10=MEMORY_LIMIT、17=UNKNOWN 等），
# 本探针一度自带一份纠正表 _STATUS13 来比对；修 R-A 后两处已同源，故只留这一条来路。
_STATUS13 = MM._STATUS


def st_name(code):
    return MM.status_name(code)


class ProbeAbort(Exception):
    """哨兵异常：探针已在 optimize 拦截点完成求解，中止 solve_mesh 的后续结果提取。"""


def _patched_optimize(self, *a, **k):
    cb = _ACTIVE['cb']
    if cb is None:
        return _ORIG_OPTIMIZE(self, *a, **k)
    cb(self)
    raise ProbeAbort()


gp.Model.optimize = _patched_optimize


# ---------------------------------------------------------------- 名字解析
def _split(name):
    """'p_N01[3,7]' -> ('p_N01', [3,7])；'u[5]' -> ('u', [5])；'p0_N01' -> ('p0_N01', None)"""
    if '[' in name:
        base, rest = name.split('[', 1)
        idx = [int(x) for x in rest.rstrip(']').replace(' ', '').split(',') if x]
        return base, idx
    return name, None


def var_groups(m):
    agg = {}
    for v in m.getVars():
        base, _ = _split(v.VarName)
        d = agg.setdefault(base, dict(n=0, lb=+np.inf, ub=-np.inf))
        d['n'] += 1
        d['lb'] = min(d['lb'], v.LB if v.LB > -1e99 else -1e99)
        d['ub'] = max(d['ub'], v.UB if v.UB < 1e99 else 1e99)
    return agg


def matrix_stats(m):
    st = dict(nvars=m.NumVars, nconstrs=m.NumConstrs, nbin=m.NumBinVars,
              nint=m.NumIntVars, nqconstr=m.NumQConstrs, nsos=m.NumSOS,
              ngconstr=m.NumGenConstrs, nnz=m.NumNZs, nqnz=m.NumQCNZs,
              maxcoeff=m.MaxCoeff, mincoeff=m.MinCoeff,
              maxobj=m.MaxObjCoeff, minobj=m.MinObjCoeff,
              maxqccoeff=m.MaxQCCoeff, minqccoeff=m.MinQCCoeff)
    for attr in ('MaxBound', 'MinBound', 'MaxRHS', 'MinRHS'):
        try:
            st[attr.lower()] = getattr(m, attr)
        except Exception:
            st[attr.lower()] = np.nan
    return st


def collect_iis(m):
    m.computeIIS()
    lines = []
    for c in m.getConstrs():
        if c.IISConstr:
            lines.append('con:' + c.ConstrName)
    for c in m.getQConstrs():
        if c.IISQConstr:
            lines.append('qc:' + c.QCName)
    for s in m.getSOSs():
        if s.IISSOS:
            lines.append('sos:' + s.SOSName)
    for v in m.getVars():
        if v.IISLB:
            lines.append('lb:' + v.VarName)
        if v.IISUB:
            lines.append('ub:' + v.VarName)
    groups = {}
    for ln in lines:
        tag, nm = ln.split(':', 1)
        base, _ = _split(nm)
        key = f'{tag}:{base}'
        groups[key] = groups.get(key, 0) + 1
    return lines, groups


# ---------------------------------------------------------------- 变换
def relax_integrality(m):
    n = 0
    for v in m.getVars():
        if v.VType in (GRB.BINARY, GRB.INTEGER):
            v.VType = GRB.CONTINUOUS
            n += 1
    return n


def _press_bases(net):
    """气网节点压力变量的确切基名（必须精确匹配，否则会把 p_c / p_d / p_grid 一起钉死）。"""
    return {f"p_{nd['id']}" for nd in net['nodes']}


def anchor_gas_side(m, ps, press):
    """把气网侧钉到"零流解析可行点"：所有节点压力 = p_s、方向二进制 = 1、u = 0。

    该点含义：全网持压在 p_s，门站调压阀全关、压缩机不出力
    （f = sqrt(K(p_s^2 - p_s^2)) = 0）、CHP/GB 不取气，热负荷由电锅炉(2.0)+热泵(2.0)
    恰好覆盖日热峰 4.0 MW。它的每一条约束残差都**与 p_s 数值无关**（压力上界与流量界
    同时抬升、零流始终可行），所以若某个 p_s 下该锚定点被判 INFEASIBLE，问题一定出在
    约束/界的构造层而不是搜索。
    """
    n = 0
    for v in m.getVars():
        base, idx = _split(v.VarName)
        if idx is None:
            if base.startswith('p0_'):
                m.addConstr(v == ps, name=f'ANCHOR_{v.VarName}')
                n += 1
            continue
        if base in press:
            m.addConstr(v == ps, name=f'ANCHOR_{v.VarName}')
            n += 1
        elif base.startswith('y_'):        # 方向二进制 y_p02_N01_N02 / y_v01_ / y_p05_ / y_p06_
            m.addConstr(v == 1, name=f'ANCHOR_{v.VarName}')
            n += 1
        elif base == 'u':                  # 停机 -> p_chp=0 -> g_chp=0
            m.addConstr(v == 0, name=f'ANCHOR_{v.VarName}')
            n += 1
    return n


def set_mip_start_anchor(m, ps, loads, press):
    """不添加任何约束，只把解析可行点写成 MIP Start（全部命名变量）。"""
    p_load, h_load = loads
    n = 0
    for v in m.getVars():
        base, idx = _split(v.VarName)
        if idx is None:
            v.Start = ps if base.startswith('p0_') else 0.0
            n += 1 if base.startswith('p0_') else 0
            continue
        if base in press:
            v.Start = ps
            n += 1
        elif base.startswith('pi2_'):        # p^2 变量（pwl / asym 编码才有）
            v.Start = ps * ps
        elif base.startswith('y_'):
            v.Start = 1.0
        elif base == 'soc':
            v.Start = C.ESS['soc0'] * C.ESS['cap']
        elif base == 'hsoc':
            v.Start = C.HSS['soc0'] * C.HSS['cap']
        elif base == 'h_eb':
            v.Start = min(C.EB['hmax'], h_load[idx[1]])
        elif base == 'h_hp':
            v.Start = max(0.0, h_load[idx[1]] - C.EB['hmax'])
        elif base == 'p_grid':
            eb = min(C.EB['hmax'], h_load[idx[1]])
            hp = max(0.0, h_load[idx[1]] - C.EB['hmax'])
            v.Start = float(p_load[idx[1]]) + eb / C.EB['eta'] + hp / C.HP['cop']
        elif base == 'su_':
            v.Start = 2.0 * ps
        else:
            v.Start = 0.0
    # su_* 前缀（su_p02_N01_N02 等）
    for v in m.getVars():
        base, idx = _split(v.VarName)
        if base.startswith('su_'):
            v.Start = 2.0 * ps
    return n


# ---------------------------------------------------------------- 单档探针
def probe_one(dat, ps, dir_mode, exp, tl, extra_params=None, scenarios='reduced',
              mode='cost', allow_shed=True, p0_mode='periodic', verbose=False,
              lp_file=None, net_kind='mesh'):
    base, reduced = dat['base'], dat['reduced']
    sc = reduced if scenarios == 'reduced' else None
    if net_kind == 'mesh':
        net = MM.build_mesh(ps=ps, ps2=ps, pd_min=PD_MIN, K=K_W, A=A_NODE,
                            comp_ratio=COMP_R, single_source=True)
    elif net_kind == 'chain':
        net = MM.build_chain(ps=ps, ps2=ps, pd_min=PD_MIN, K=K_W, A=A_NODE,
                             comp_ratio=COMP_R)
    else:
        net = MM.build_mesh(ps=ps, ps2=ps, pd_min=PD_MIN, K=K_W, A=A_NODE,
                            comp_ratio=COMP_R, single_source=False)
    rec = dict(ps=ps, dir_mode=dir_mode, exp=exp, scen=scenarios, mode=mode,
               allow_shed=allow_shed, p0_mode=p0_mode, tl=tl, net=net_kind,
               net_name=net['name'])
    params = dict(extra_params or {})
    press = _press_bases(net)

    def cb(m):
        m.update()                      # gurobipy 13 延迟更新：不 update 会读到空模型
        rec.update(matrix_stats(m))
        groups = var_groups(m)
        rec['grp_pmax'] = max((g['ub'] for b, g in groups.items() if b in press),
                              default=np.nan)
        rec['n_var_groups'] = len(groups)
        rec['n_press_vars'] = sum(g['n'] for b, g in groups.items() if b in press)
        rec['relaxed_int'] = relax_integrality(m) if exp == 'relax' else 0
        rec['anchor_constrs'] = anchor_gas_side(m, ps, press) if exp == 'anchor' else 0
        rec['start_set'] = 0
        if exp in ('grid', 'relax', 'anchor', 'stats'):
            # 注意：常数目标对这台 MIQCP 是**退化**的探针 —— Gurobi 的 NoRel 启发式
            # 需要在受限可行集上优化一个目标，c=0 时它没有任何方向，实测连 p_s=50 都在
            # 600 s 内 SolCount=0（见 results/V3_MESH_PROBE_grid.csv）。因此"仅可行性"
            # 判据改用 exp='sol1'（保留原目标 + SolutionLimit=1）。
            m.setObjective(0.0, GRB.MINIMIZE)      # 纯可行性判定，去掉目标牵引
        if exp == 'sol1':
            # 保留真实目标，但求得第一个可行解即停 -> Runtime = 首个可行解用时
            params.setdefault('SolutionLimit', 1)
            params.setdefault('MIPFocus', 1)
        if exp == 'start':
            rec['start_set'] = set_mip_start_anchor(
                m, ps, (np.asarray(base['p_load'], float),
                        np.asarray(base['h_load'], float)), press)
        if lp_file:
            try:
                m.write(lp_file)
            except Exception as e:
                rec['lp_write_err'] = str(e)
        m.update()
        m.Params.OutputFlag = 1 if verbose else 0
        m.Params.TimeLimit = tl
        rec['params_used'] = ';'.join(f'{k}={v}' for k, v in sorted(params.items()))
        for k, v in params.items():
            setattr(m.Params, k, v)
        t0 = time.perf_counter()
        try:
            _ORIG_OPTIMIZE(m)
        except gp.GurobiError as e:
            rec.update(error=f'GurobiError {e}', status=-99, status_name='ERROR',
                       solcount=0, wall=time.perf_counter() - t0, runtime=np.nan)
            return
        rec.update(status=int(m.Status), status_name=st_name(m.Status),
                   status_name_modelapi=MM.status_name(m.Status),
                   solcount=int(m.SolCount), runtime=float(m.Runtime),
                   wall=time.perf_counter() - t0)
        try:
            rec['nodecount'] = int(m.NodeCount)
        except Exception:
            rec['nodecount'] = np.nan
        try:
            rec['itercount'] = float(m.IterCount)
        except Exception:
            rec['itercount'] = np.nan
        if rec['solcount'] > 0:
            try:
                rec['objval'] = float(m.ObjVal)
            except Exception:
                pass
        if m.Status == GRB.INFEASIBLE:
            try:
                lines, groups_i = collect_iis(m)
                rec['iis_n'] = len(lines)
                rec['iis_groups'] = ';'.join(f'{k}x{v}' for k, v in
                                             sorted(groups_i.items())[:16])
                rec['iis_sample'] = ' | '.join(lines[:16])
            except Exception as e:
                rec['iis_err'] = str(e)

    _ACTIVE['cb'] = cb
    try:
        MM.solve_mesh(base, net, scenarios=sc, mode=mode, allow_shed=allow_shed,
                      n_pts=N_PTS, gas_coupled=True, dir_mode=dir_mode,
                      p0_mode=p0_mode, time_limit=tl, mipgap=C.GRB_MIPGAP,
                      params=params or None, verbose=False)
        rec['note'] = 'no intercept (unexpected)'
    except ProbeAbort:
        pass
    finally:
        _ACTIVE['cb'] = None
    return rec


def run(dat, ps_list, dir_modes, exp, tl, scenarios='reduced', mode='cost',
        allow_shed=True, p0_mode='periodic', verbose=False, extra=None,
        out=None, lp_dir=None, net_kind='mesh'):
    rows = []
    path = os.path.join(RES, out or f'V3_MESH_PROBE_{exp}.csv')
    for dm in dir_modes:
        for ps in ps_list:
            lp = None
            if lp_dir:
                os.makedirs(lp_dir, exist_ok=True)
                lp = os.path.join(lp_dir, f'mesh_{exp}_{dm}_{int(ps)}.lp')
            r = probe_one(dat, ps, dm, exp, tl, extra_params=extra, scenarios=scenarios,
                          mode=mode, allow_shed=allow_shed, p0_mode=p0_mode,
                          verbose=verbose, lp_file=lp, net_kind=net_kind)
            rows.append(r)
            print(f'[{exp}] net={net_kind:5s} dir={dm:7s} ps={ps:5.1f} '
                  f'scen={scenarios:7s} shed={int(allow_shed)} '
                  f'status={r.get("status_name","?"):12s} '
                  f'SolCount={r.get("solcount","?")} t={r.get("wall", float("nan")):6.1f}s '
                  f'relaxed={r.get("relaxed_int")} anchor={r.get("anchor_constrs")} '
                  f'start={r.get("start_set")} iis_n={r.get("iis_n", "")} '
                  f'{r.get("error", "")}')
            if r.get('iis_sample'):
                print(f'    IIS groups: {r.get("iis_groups", "")}')
                print(f'    IIS sample: {r["iis_sample"]}')
            sys.stdout.flush()
            pd.DataFrame(rows).to_csv(path, index=False, encoding='utf-8-sig')
    df = pd.DataFrame(rows)
    print('\n---- summary ----')
    cols = [c for c in ['exp', 'net', 'dir_mode', 'ps', 'scen', 'mode', 'status_name',
                        'solcount', 'wall', 'runtime', 'nvars', 'nconstrs', 'nbin',
                        'nqconstr', 'mincoeff', 'maxcoeff', 'grp_pmax', 'iis_n']
            if c in df.columns]
    print(df[cols].to_string(index=False))
    print(f'-> {path}')
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--exp', default='grid', help='grid|relax|anchor|start|stats|all')
    ap.add_argument('--ps', default='50,55,60,65,70,75,80')
    ap.add_argument('--dir-mode', default='soc')
    ap.add_argument('--tl', type=float, default=120.0)
    ap.add_argument('--scen', default='reduced', choices=['reduced', 'single'])
    ap.add_argument('--mode', default='cost', choices=['cost', 'carbon'])
    ap.add_argument('--allow-shed', default='1')
    ap.add_argument('--p0-mode', default='periodic')
    ap.add_argument('--no-rel-heur', type=float, default=0.0)
    ap.add_argument('--heur', type=int, default=0,
                    help="1 = 复刻存档启发式臂的口径 (NoRelHeurTime=150, MIPFocus=1, "
                         'Heuristics=0.5)，用于"同口径、只加时间"的测量')
    ap.add_argument('--seed', type=int, default=-1,
                    help='>=0 时固定 Gurobi Seed，用于"同一档换种子是否翻结果"的复现检验')
    ap.add_argument('--lp-dir', default='')
    ap.add_argument('--net', default='mesh', choices=['mesh', 'chain', 'mesh2s'])
    ap.add_argument('--out', default='')
    ap.add_argument('--verbose', action='store_true')
    a = ap.parse_args()

    ps_list = [float(x) for x in a.ps.split(',')]
    dms = a.dir_mode.split(',')
    extra = {}
    if a.heur:
        extra.update(NoRelHeurTime=150.0, MIPFocus=1, Heuristics=0.5)
    if a.no_rel_heur > 0:
        extra['NoRelHeurTime'] = a.no_rel_heur
    if a.seed >= 0:
        extra['Seed'] = a.seed
    dat = DP.prepare()
    exps = ['grid', 'relax', 'anchor', 'stats'] if a.exp == 'all' else [a.exp]
    for exp in exps:
        out = a.out or f'V3_MESH_PROBE_{exp}{"_" + a.net if a.net != "mesh" else ""}.csv'
        run(dat, ps_list, dms, exp, a.tl, scenarios=a.scen, mode=a.mode,
            allow_shed=(a.allow_shed == '1'), p0_mode=a.p0_mode,
            verbose=a.verbose, extra=extra or None,
            lp_dir=a.lp_dir or None, out=out, net_kind=a.net)


if __name__ == '__main__':
    main()
