# -*- coding: utf-8 -*-
"""MESH: 通用（网状 / 多供路）气网耦合的两阶段随机调度 MILP。

Task 3 的载体。主链 `model_gc_v3.py` 的两节点拓扑里每条管道的**上游都是定压节点**
（门站 ps 或压缩机出口 ps2），所以 f = sqrt(K(p_ref^2 - p_dn^2)) 是下游压力的
一维函数，流向天然确定，PWL 一维即可 —— 它从来没有处理过流向。"两节点不具普适性"
这条审稿意见攻击的正是这一点：网状拓扑里管段流向不定。

本文件把气网抽象成一张图，其余口径全部沿用 model_gc_v3 / config_v3 / data_v3
（同一场景集与种子、同一排放因子 0.8922、同一 Weymouth 标定值 K=3.83e-3、同一管存
常数 0.075 MWh/bar 与压力下限 20 bar、同一 60 余弦 PWL 断点、同一日循环、
同一 MIPGap 1e-4 / 600 s、同一电热侧设备与负荷），只换拓扑。

图元
----
1) const_pipe（上游定压管段：门站管 / 压缩机出口管）
     pref    : 上游定压 (bar)，常数
     frm     : 被扣气节点；None = 该气量从模型外（门站）购入
     to      : 下游节点
     fuel    : 压缩机燃料率 r，节点扣气 (1+r)·f
     equality: False -> f <= 上界（门站调压阀，同 model_gc 管道1）
               True  -> f  =  上界（压缩机出口管，同 model_gc 管道2）
   Weymouth 表示为**下游压力的一维余弦 PWL**，断点构造与 model_gc_v3._pwl_pts
   逐字相同；因此两节点链退化情形与 model_gc_v3 是同一个 MILP。

2) link_pipe（两端都是变量压力的可逆管段）
     f_ij = sign(p_i^2 - p_j^2) * sqrt(K * |p_i^2 - p_j^2|)
   这才是网状的真难点：二维、方向不定。两种 MILP 线性化都实现，用 dir_mode 选：
     'binary'（默认）  每管段每小时 1 个方向二进制 y；ab = |pi2 - pj2| 由 4 条
                      线性不等式在紧界 2*ddmax 下精确锁定（不是松驰大 M）；
                      s = sqrt(K*ab) 用 [0, ddmax] 上 60 个余弦断点一维 PWL；
                      正反向流量 sp, sm 受 sp+sm = s, sp <= Fmax*y, sm <= Fmax*(1-y)
                      约束 -> f = sp - sm。该表达**精确**（无方向松弛），代价是
                      每管段每小时一个二进制。
     'pwl_asym'       直接对反对称函数 h(dd) = sign(dd)sqrt(K|dd|) 做一维 PWL，
                      dd = pi2 - pj2。零二进制，但每半支 60 点（共 119 点，共享原点）。
   两种模式都需要 p_i^2 变量，用同一余弦断点上的线性插值表示（这引入一项可量化
   的近似误差，`link_repr_error()` 给出，并在 mesh_notes.md 中与 model_gc 口径对比）。

守恒与边界
----------
   A_i (p_i,t - p_i,t-1) = Σ_in f - Σ_out (1+r) f - g_i ，dt = 1 h
   日循环 p_i,T = p_i,0（初值为一阶段场景共享变量，同 model_gc 的 p0_mode='periodic'）
   气源成本按**模型外购入量**计价（门站管流量之和），压缩机燃料计入成本与碳排 ——
   两节点链下退化为 C_GAS*Σf1 与 E_GAS(g1+g2+r f2)，与 model_gc_v3 逐项相同。

回归自检
--------
`build_chain()` 用本文件的图元重述 model_gc_v3 的两节点链；
`solve_mesh(net=build_chain(...))` 必须复现 results/V3_GC_scan_carbon.csv 的
主链碳地板与期望成本（见 gc_run_mesh_v3.py --regress、audit_v3.py N 节）。
"""
import os
import sys

import numpy as np
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

import config_v3 as C


# ---------------------------------------------------------------- 状态码图例（单一真源）
# 从 gurobipy 运行时反查导出，绝不手抄表：历史上手抄表把 10 误标为 MEMORY_LIMIT
# （实为 SOLUTION_LIMIT）、11/13/14/15/16/17 全错，直接导致过一次误读
# （见 mesh_ps70_diagnosis.md §1.3 / R-A）。本表是 model_mesh_v3 与 model_gc_v3
# **共用**的唯一一份定义（model_gc_v3 从此处 import），避免同一缺陷在各文件复发。
def _build_gurobi_status_table():
    """反查 GRB.Status.* 常量 -> {码: 名称}。gurobipy 若改版，这里自动跟随。"""
    status_cls = getattr(GRB, 'Status', None)
    if status_cls is None:                       # 极老/极新版兜底
        raise RuntimeError('gurobipy GRB.Status 不可用，无法生成状态码图例')
    table = {}
    for name in dir(status_cls):
        if name.startswith('_'):
            continue
        try:
            code = int(getattr(status_cls, name))
        except (TypeError, ValueError):
            continue
        table[code] = name
    return table


_STATUS = _build_gurobi_status_table()


def status_name(code):
    """状态码 -> 名称；未登记码返回 CODE_<n>（不谎报为 OPTIMAL/INFEASIBLE 等）。"""
    return _STATUS.get(int(code), f'CODE_{int(code)}')


def _assert_status_table_is_gurobi_consistent():
    """导入即自检：表内每个码都必须等于 GRB.Status 反查值，且覆盖 1..19。

    任一不符即非零退出——这样任何"手抄/漂移"的复发都会在 import 时被抓出，
    而不是等到读日志/CSV 时误判（正是 R-A 想根治的那一类缺陷）。
    """
    derived = _build_gurobi_status_table()
    if _STATUS != derived:
        drift = {c: (_STATUS.get(c), derived.get(c)) for c in set(_STATUS) | set(derived)
                 if _STATUS.get(c) != derived.get(c)}
        raise AssertionError(f'_STATUS 与 gurobipy GRB.Status 反查不一致：{drift}')
    missing = [c for c in range(1, 20) if c not in _STATUS]
    if missing:
        raise AssertionError(f'_STATUS 未覆盖 Gurobi 状态码 {missing}（1..19）')
    # 关键锚点：这三个码若被写反，整个"可行 vs 搜索失败"的判读都会颠倒。
    for code, name in ((2, 'OPTIMAL'), (3, 'INFEASIBLE'), (9, 'TIME_LIMIT')):
        if _STATUS.get(code) != name:
            raise AssertionError(f'_STATUS[{code}]={_STATUS.get(code)!r}，应为 {name!r}')


_assert_status_table_is_gurobi_consistent()


def _pwl_pts(n_pts, lo, hi):
    """余弦分布断点（与 model_gc_v3._pwl_pts 逐字相同）"""
    return lo + (hi - lo) * (1 - np.cos(np.pi * np.arange(n_pts) / (n_pts - 1))) / 2


# ---------------------------------------------------------------- 图元
def node(nid, pmax, pmin=20.0, A=0.075):
    return dict(id=str(nid), pmin=float(pmin), pmax=float(pmax), A=float(A))


def const_pipe(nid, pref, frm, to, K=0.00383, fuel=0.0, equality=False):
    return dict(kind='const', id=str(nid), pref=float(pref),
                frm=(None if frm is None else str(frm)), to=str(to),
                K=float(K), fuel=float(fuel), equality=bool(equality))


def link_pipe(nid, i, j, K=0.00383):
    return dict(kind='link', id=str(nid), i=str(i), j=str(j), K=float(K))


def build_chain(ps, ps2=None, pd_min=20.0, K=0.00383, A=0.075, comp_ratio=0.02):
    """model_gc_v3 两节点链的本文件等价重述（回归自检用）。

      门站(ps) --pipe1(阀)--> node1(CHP 取气) --压缩机 r--> 定压 ps2
                                            --pipe2(等式)--> node2(GB 取气)
    """
    if ps2 is None:
        ps2 = ps
    return dict(
        name='chain2',
        nodes=[node('node1', ps, pd_min, A), node('node2', ps2, pd_min, A)],
        elements=[
            const_pipe('pipe1', ps, None, 'node1', K, fuel=0.0, equality=False),
            const_pipe('pipe2', ps2, 'node1', 'node2', K, fuel=comp_ratio, equality=True),
        ],
        loads={'chp': 'node1', 'gb': 'node2'},
        purchases=['pipe1'],
        ps=ps, ps2=ps2, pd_min=pd_min, A_node=A, K=K,
        note=('two-node radial chain, identical to model_gc_v3; both pipes are fed by '
              'fixed-pressure nodes so the flow direction is implied by the variable bounds'),
    )


def build_mesh(ps, ps2=None, pd_min=20.0, K=0.00383, A=0.075, comp_ratio=0.02,
               loads=None, name=None, single_source=True):
    """GasLib-11 网状核心（拓扑取自公开算例；水力参数用主链同一标定值）。

    完整 GasLib-11 图：
      门站A entry01 (ps) --pipe01--> entry03 --CS01 压缩机(r, 出口定压 ps2)--> N01
      门站B entry02 (ps) --pipe03--> N03
      可逆联络管： pipe02 N01-N02 | V01 N01-N03 | pipe05 N02-N04 | pipe06 N03-N04
      （另有 CS02 N04-N05 与通往 exit01/02/03 的 pipe04/07/08，见 DROPPED 说明）
    环：N01 - pipe02 - N02 - pipe05 - N04 - pipe06 - N03 - V01 - N01

    single_source=True（默认，主判据用）：**只留门站 A**，即把 entry02/pipe03 从"供源"
      降级为环上的一个联络节点。理由：两节点链只有一个门站，总可交付量 =
      sqrt(K(ps^2-pmin^2))；若网状臂同时开两个门站，总可交付量直接翻倍，
      "气网是否咬合"就不再是单因素对照（换成两因素：拓扑 + 供路冗余）。
      关掉门站 B 之后，负荷节点 N02 / N04 仍有**两条互相独立的供路**
      （N01->N02->N04 与 N01->N03->N04），流向依然不定，环依然存在，
      而门站可交付量与两节点链逐项相等。
    single_source=False：完整双源网状（公开算例原样），作为冗余稳健性格。
    """
    if ps2 is None:
        ps2 = ps
    if loads is None:
        loads = {'chp': 'N02', 'gb': 'N04'}
    if name is None:
        name = 'gaslib11_core_1src' if single_source else 'gaslib11_core_2src'
    els = [const_pipe('gA_entry01_entry03', ps, None, 'entry03', K),
           const_pipe('cCS01_entry03_N01', ps2, 'entry03', 'N01', K,
                      fuel=comp_ratio, equality=True),
           link_pipe('p02_N01_N02', 'N01', 'N02', K),
           link_pipe('v01_N01_N03', 'N01', 'N03', K),
           link_pipe('p05_N02_N04', 'N02', 'N04', K),
           link_pipe('p06_N03_N04', 'N03', 'N04', K)]
    purch = ['gA_entry01_entry03']
    if not single_source:
        els.insert(2, const_pipe('gB_entry02_N03', ps, None, 'N03', K))
        purch.append('gB_entry02_N03')
    return dict(
        name=name,
        nodes=[node('entry03', ps, pd_min, A), node('N01', ps, pd_min, A),
               node('N02', ps, pd_min, A), node('N03', ps, pd_min, A),
               node('N04', ps, pd_min, A)],
        elements=els,
        loads=loads,
        purchases=purch,
        single_source=single_source,
        ps=ps, ps2=ps2, pd_min=pd_min, A_node=A, K=K,
        note=('GasLib-11 meshed core: 5 line-pack nodes, one real loop '
              'N01-N02-N04-N03-N01, 4 bidirectional interconnects, 1 compressor; '
              'gate deliverability matched to the two-node chain'
              if single_source else
              'GasLib-11 meshed core with both published gate supplies live'),
    )


# ---------------------------------------------------------------- 求解
def solve_mesh(data, net, scenarios=None, mode='cost', lam=0.0, cap=None,
               n_pts=60, dir_mode='soc', gas_coupled=True,
               p0_mode='periodic', u_fix=None, verbose=False, allow_shed=True,
               risk_lambda=0.0, cvar_beta=0.95,
               time_limit=C.GRB_TIME_LIMIT, mipgap=C.GRB_MIPGAP, params=None,
               mip_start=None):
    """通用网状气网两阶段随机 MILP。

    gas_coupled=False -> 委托 model_stoch_v3.solve_stoch（线性气帽口径）。
    该分支不含任何气网拓扑，所以 "mesh + 无气网" 与 "两节点 + 无气网" 数值恒等，
    这是结构性事实而非巧合（audit N 节把它写成断言）。

    mip_start='zero_flow' -> 只加一个解析可行起点（全网持压 p_s、零流、CHP 停、热由
      电锅炉+热泵覆盖、余电由电网补足），**不添加约束、不改目标、不改冻结参数**。
      用于把 50/60/70 三格统一到同一搜索协议上（见 gc_run_mesh_v3 / mesh_notes 统一口径）。
    """
    if not gas_coupled:
        import model_stoch_v3 as MS
        return MS.solve_stoch(data, scenarios=scenarios, mode=mode, lam=lam, cap=cap,
                              u_fix=u_fix, verbose=verbose, allow_shed=allow_shed,
                              risk_lambda=risk_lambda, cvar_beta=cvar_beta,
                              time_limit=time_limit, mipgap=mipgap)
    dir_mode = {'binary': 'pwl', 'pwl_asym': 'asym'}.get(dir_mode, dir_mode)
    if dir_mode not in ('soc', 'pwl', 'asym'):
        raise ValueError(dir_mode)

    T = len(data['p_load'])
    dt = 1.0
    S = 1 if scenarios is None else len(scenarios)
    probs = [1.0] if scenarios is None else [float(sc['prob']) for sc in scenarios]
    one = scenarios is None
    wind_s = [np.asarray(data['wind'], float)] if one else \
        [np.asarray(sc['wind'], float) for sc in scenarios]
    pv_s = [np.asarray(data['pv'], float)] if one else \
        [np.asarray(sc['pv'], float) for sc in scenarios]
    p_load_s = [np.asarray(data['p_load'], float)] if one else \
        [np.asarray(sc.get('p_load', data['p_load']), float) for sc in scenarios]
    h_load_s = [np.asarray(data['h_load'], float)] if one else \
        [np.asarray(sc.get('h_load', data['h_load']), float) for sc in scenarios]
    price = np.asarray(data['price'], float)

    nodes = {nd['id']: nd for nd in net['nodes']}
    nids = list(nodes)
    elements = net['elements']
    loads = {k: str(v) for k, v in net['loads'].items()}
    purchases = set(net['purchases'])
    pd_min, ps, ps2 = net['pd_min'], net['ps'], net['ps2']
    for k, nid in loads.items():
        if nid not in nodes:
            raise KeyError(f'load {k} attached to unknown node {nid}')
    if set(loads) != {'chp', 'gb'}:
        raise KeyError("loads must be exactly {'chp','gb'} (CHP + boiler, the paper's park)")

    m = gp.Model('IES_mesh')
    m.Params.OutputFlag = 1 if verbose else 0
    m.Params.TimeLimit = time_limit
    m.Params.MIPGap = mipgap
    # 只影响搜索/表述，不影响模型语义（冻结的 MIPGap 与 TimeLimit 不在这里覆盖）
    for k, v in (params or {}).items():
        setattr(m.Params, k, v)

    eta_he = C.CHP['eta_h'] / C.CHP['eta_e']
    pmax_chp = C.CHP['pmax']
    pmin_chp = C.CHP['pmin_ratio'] * C.CHP['pmax']

    # ---------------- 一阶段（场景共享，非预期性） ----------------
    u = m.addVars(T, vtype=GRB.BINARY, name='u')
    yup = m.addVars(T, vtype=GRB.BINARY, name='y')
    zdn = m.addVars(T, vtype=GRB.BINARY, name='z')
    if p0_mode == 'periodic':
        p_0 = {nid: m.addVar(lb=nodes[nid]['pmin'], ub=nodes[nid]['pmax'],
                             name=f'p0_{nid}') for nid in nids}
        p0_is_var = True
    elif p0_mode == 'mid':
        p_0 = {nid: 0.5 * (nodes[nid]['pmin'] + nodes[nid]['pmax']) for nid in nids}
        p0_is_var = False
    else:
        raise ValueError(p0_mode)
    if u_fix is not None:
        for t in range(T):
            m.addConstr(u[t] == int(u_fix[t]), name=f'ufix_{t}')

    # ---------------- 二阶段：电/热侧（与 model_gc_v3 逐式相同） ----------------
    def vv(name, ub=GRB.INFINITY):
        return m.addVars(S, T, lb=0, ub=ub, name=name)

    p_wind, p_pv, p_grid, p_chp = vv('p_wind'), vv('p_pv'), vv('p_grid'), vv('p_chp')
    p_shed = vv('p_shed') if allow_shed else None
    h_gb = vv('h_gb', C.GB['hmax'])
    h_eb = vv('h_eb', C.EB['hmax'])
    h_hp = vv('h_hp', C.HP['hmax'])
    p_c, p_d = vv('p_c', C.ESS['pmax']), vv('p_d', C.ESS['pmax'])
    soc = m.addVars(S, T, lb=0, name='soc')
    h_c, h_d = vv('h_c', C.HSS['pmax']), vv('h_d', C.HSS['pmax'])
    hsoc = m.addVars(S, T, lb=0, name='hsoc')

    # ---------------- 二阶段：气网侧 ----------------
    p = {nid: m.addVars(S, T, lb=nodes[nid]['pmin'], ub=nodes[nid]['pmax'],
                        name=f'p_{nid}') for nid in nids}
    g = {k: m.addVars(S, T, lb=0, name=f'g_{k}') for k in loads}

    # (a) 定压上游管段 —— 与 model_gc_v3 同构的一维 PWL
    for e in elements:
        if e['kind'] != 'const':
            continue
        dn = nodes[e['to']]
        pts = _pwl_pts(n_pts, dn['pmin'], e['pref'])
        fpt = np.sqrt(np.clip(e['K'] * (e['pref'] ** 2 - pts ** 2), 0, None))
        xs, ys = pts.tolist(), fpt.tolist()
        fmax = float(fpt.max())
        e['fmax'] = fmax
        if e['equality']:
            e['var'] = m.addVars(S, T, lb=0, ub=fmax, name=f"f_{e['id']}")
            e['ubvar'] = None
            for s_ in range(S):
                for t_ in range(T):
                    m.addGenConstrPWL(p[e['to']][s_, t_], e['var'][s_, t_], xs, ys,
                                      name=f"pwl_{e['id']}_{s_}_{t_}")
        else:
            ubv = m.addVars(S, T, lb=0, ub=fmax, name=f"ub_{e['id']}")
            fv = m.addVars(S, T, lb=0, ub=fmax, name=f"f_{e['id']}")
            e['ubvar'], e['var'] = ubv, fv
            for s_ in range(S):
                for t_ in range(T):
                    m.addGenConstrPWL(p[e['to']][s_, t_], ubv[s_, t_], xs, ys,
                                      name=f"pwl_{e['id']}_{s_}_{t_}")
                    m.addConstr(fv[s_, t_] <= ubv[s_, t_],
                                name=f"valve_{e['id']}_{s_}_{t_}")

    # (b) 可逆管段。三种可选线性化/凸化，dir_mode 选择：
    #   'soc'   （默认）旋转二阶锥：sp^2 <= K * dp * (p_i+p_j)，dp = max(p_i-p_j,0)
    #           由每管段每小时的方向二进制 y 精确激活。dp/dm >= 0 与 p_i+p_j >= 2*pmin
    #           使其成为**凸**约束，无需把 p^2 离散化，Weymouth 律逐字精确（无近似误差）。
    #           代价：模型由 MILP 变成 MIQCP（凸二次锥 + 二进制）。
    #   'pwl'   纯 MILP：pi2 = p^2 余弦 PWL + |dpi2| 的 sqrt 余弦 PWL + 方向二进制。
    #           每管段每小时 1 个方向二进制 + 每节点每小时 1 个 PWL（p^2 非凸等式会被
    #           Gurobi disjunctive 重构，8 场景下二进制数暴涨，实测 600 s 内找不到可行解，
    #           故只用于单场景对照与误差核算）。
    #   'asym'  纯 MILP 无二进制：直接对反对称 h(dd)=sign(dd)sqrt(K|dd|) 做一维 PWL。
    link_form = dir_mode
    if link_form not in ('soc', 'pwl', 'asym'):
        raise ValueError(link_form)
    link_nodes = sorted({n for e in elements if e['kind'] == 'link' for n in (e['i'], e['j'])})
    sqx, pi2 = {}, {}
    if link_form in ('pwl', 'asym'):
        for nid in link_nodes:
            nd = nodes[nid]
            pts = _pwl_pts(n_pts, nd['pmin'], nd['pmax'])
            sqx[nid] = (pts.tolist(), (pts ** 2).tolist())
            pi2[nid] = m.addVars(S, T, lb=nd['pmin'] ** 2, ub=nd['pmax'] ** 2,
                                 name=f'pi2_{nid}')
        for s_ in range(S):
            for t_ in range(T):
                for nid in link_nodes:
                    m.addGenConstrPWL(p[nid][s_, t_], pi2[nid][s_, t_], *sqx[nid],
                                      name=f'sq_{nid}_{s_}_{t_}')

    for e in elements:
        if e['kind'] != 'link':
            continue
        lo = min(nodes[e['i']]['pmin'], nodes[e['j']]['pmin'])
        hi = max(nodes[e['i']]['pmax'], nodes[e['j']]['pmax'])
        dd_max = hi ** 2 - lo ** 2
        f_max = float(np.sqrt(e['K'] * dd_max))
        e['ddmax'], e['fmax'] = float(dd_max), f_max
        e['dpmax'] = float(hi - lo)          # |p_i - p_j| 的紧界（非大 M）
        f = m.addVars(S, T, lb=-f_max, ub=f_max, name=f"f_{e['id']}")
        e['var'] = f
        if link_form == 'soc':
            Ks = float(np.sqrt(e['K']))
            e['Ksqrt'] = Ks
            yd = m.addVars(S, T, vtype=GRB.BINARY, name=f"y_{e['id']}")
            wp = m.addVars(S, T, lb=0, ub=f_max / Ks, name=f"wp_{e['id']}")
            wm = m.addVars(S, T, lb=0, ub=f_max / Ks, name=f"wm_{e['id']}")
            dp = m.addVars(S, T, lb=0, ub=e['dpmax'], name=f"dp_{e['id']}")
            dm = m.addVars(S, T, lb=0, ub=e['dpmax'], name=f"dm_{e['id']}")
            su = m.addVars(S, T, lb=2.0 * lo, ub=2.0 * hi, name=f"su_{e['id']}")
            e['_aux'] = (yd, wp, wm, dp, dm, su)
        elif link_form == 'pwl':
            yd = m.addVars(S, T, vtype=GRB.BINARY, name=f"y_{e['id']}")
            ab = m.addVars(S, T, lb=0, ub=dd_max, name=f"ab_{e['id']}")
            sv = m.addVars(S, T, lb=0, ub=f_max, name=f"s_{e['id']}")
            sp = m.addVars(S, T, lb=0, ub=f_max, name=f"sp_{e['id']}")
            sm = m.addVars(S, T, lb=0, ub=f_max, name=f"sm_{e['id']}")
            pts = _pwl_pts(n_pts, 0.0, dd_max)
            e['_aux'] = (yd, ab, sv, sp, sm, pts.tolist(),
                         np.sqrt(e['K'] * pts).tolist())
        else:
            pts = _pwl_pts(n_pts, 0.0, dd_max)
            grid = np.concatenate([-pts[::-1][:-1], pts])
            e['_aux'] = (grid.tolist(),
                         (np.sign(grid) * np.sqrt(e['K'] * np.abs(grid))).tolist())
            e['_dd'] = m.addVars(S, T, lb=-dd_max, ub=dd_max, name=f"dd_{e['id']}")

    # (c) 节点守恒的进/出项
    in_terms = {nid: [] for nid in nids}
    out_terms = {nid: [] for nid in nids}
    comp_fuel = {nid: [] for nid in nids}
    for e in elements:
        if e['kind'] == 'const':
            if e['frm'] is not None:
                out_terms[e['frm']].append((1.0 + e['fuel'], e['var']))
                if e['fuel'] > 0:
                    comp_fuel[e['frm']].append((e['fuel'], e['var']))
            in_terms[e['to']].append((1.0, e['var']))
        else:
            in_terms[e['i']].append((-1.0, e['var']))
            in_terms[e['j']].append((1.0, e['var']))

    loads_at = {nid: [k for k, nn in loads.items() if nn == nid] for nid in nids}

    for s_ in range(S):
        for t_ in range(T):
            m.addConstr(p_chp[s_, t_] <= pmax_chp * u[t_], name=f'chpmax_{s_}_{t_}')
            m.addConstr(p_chp[s_, t_] >= pmin_chp * u[t_], name=f'chpmin_{s_}_{t_}')
            m.addConstr(p_wind[s_, t_] <= wind_s[s_][t_], name=f'wcap_{s_}_{t_}')
            m.addConstr(p_pv[s_, t_] <= pv_s[s_][t_], name=f'pcap_{s_}_{t_}')
            p_eb = h_eb[s_, t_] / C.EB['eta']
            p_hp = h_hp[s_, t_] / C.HP['cop']
            shed_term = p_shed[s_, t_] if allow_shed else 0
            m.addConstr(p_wind[s_, t_] + p_pv[s_, t_] + p_chp[s_, t_] + p_grid[s_, t_]
                        + p_d[s_, t_]
                        == p_load_s[s_][t_] - shed_term + p_eb + p_hp + p_c[s_, t_],
                        name=f'bal_e_{s_}_{t_}')
            m.addConstr(p_chp[s_, t_] * eta_he + h_gb[s_, t_] + h_eb[s_, t_]
                        + h_hp[s_, t_] + h_d[s_, t_]
                        == h_load_s[s_][t_] + h_c[s_, t_], name=f'bal_h_{s_}_{t_}')
            prev_soc = soc[s_, t_ - 1] if t_ > 0 else C.ESS['soc0'] * C.ESS['cap']
            m.addConstr(soc[s_, t_] == prev_soc
                        + (C.ESS['eta_c'] * p_c[s_, t_]
                           - p_d[s_, t_] / C.ESS['eta_d']) * dt, name=f'ess_{s_}_{t_}')
            m.addConstr(soc[s_, t_] <= C.ESS['soc_max'] * C.ESS['cap'], name=f'essu_{s_}_{t_}')
            m.addConstr(soc[s_, t_] >= C.ESS['soc_min'] * C.ESS['cap'], name=f'essl_{s_}_{t_}')
            prev_h = hsoc[s_, t_ - 1] if t_ > 0 else C.HSS['soc0'] * C.HSS['cap']
            m.addConstr(hsoc[s_, t_] == prev_h
                        + (C.HSS['eta_c'] * h_c[s_, t_]
                           - h_d[s_, t_] / C.HSS['eta_d']) * dt, name=f'hss_{s_}_{t_}')
            m.addConstr(hsoc[s_, t_] <= C.HSS['soc_max'] * C.HSS['cap'], name=f'hssu_{s_}_{t_}')
            m.addConstr(hsoc[s_, t_] >= C.HSS['soc_min'] * C.HSS['cap'], name=f'hssl_{s_}_{t_}')

            m.addConstr(g['chp'][s_, t_] == p_chp[s_, t_] / C.CHP['eta_e'],
                        name=f'gchp_{s_}_{t_}')
            m.addConstr(g['gb'][s_, t_] == h_gb[s_, t_] / C.GB['eta'],
                        name=f'ggb_{s_}_{t_}')

            for nid in nids:
                prev_p = p[nid][s_, t_ - 1] if t_ > 0 else p_0[nid]
                rhs = gp.quicksum(sgn * ev[s_, t_] for sgn, ev in in_terms[nid]) \
                    - gp.quicksum(fac * ev[s_, t_] for fac, ev in out_terms[nid]) \
                    - gp.quicksum(g[k][s_, t_] for k in loads_at[nid])
                m.addConstr(nodes[nid]['A'] * (p[nid][s_, t_] - prev_p) == rhs,
                            name=f'mbal_{nid}_{s_}_{t_}')

            for e in elements:
                if e['kind'] != 'link':
                    continue
                f, i_n, j_n = e['var'], e['i'], e['j']
                tag = f'{e["id"]}_{s_}_{t_}'
                Kc = e['K']
                if link_form == 'soc':
                    yd, wp, wm, dp, dm, su = e['_aux']
                    D, Ks = e['dpmax'], e['Ksqrt']
                    pi_, pj_ = p[i_n][s_, t_], p[j_n][s_, t_]
                    m.addConstr(su[s_, t_] == pi_ + pj_, name=f'su_{tag}')
                    # dp = max(p_i - p_j, 0) 且仅当 y=1 有效；反之 dm
                    m.addConstr(dp[s_, t_] >= pi_ - pj_, name=f'dpl_{tag}')
                    m.addConstr(dp[s_, t_] <= pi_ - pj_ + D * (1 - yd[s_, t_]),
                                name=f'dpu_{tag}')
                    m.addConstr(dm[s_, t_] >= pj_ - pi_, name=f'dml_{tag}')
                    m.addConstr(dm[s_, t_] <= pj_ - pi_ + D * yd[s_, t_],
                                name=f'dmu_{tag}')
                    m.addConstr(wp[s_, t_] <= (e['fmax'] / Ks) * yd[s_, t_],
                                name=f'wpy_{tag}')
                    m.addConstr(wm[s_, t_] <= (e['fmax'] / Ks) * (1 - yd[s_, t_]),
                                name=f'wmy_{tag}')
                    # 旋转二阶锥标准形 x^2 <= y*z（sqrt(K) 吸收进流量变量，
                    # 否则 Gurobi 不按凸 SOC 识别，会退化为非凸 QC 的空间分支）
                    m.addQConstr(wp[s_, t_] * wp[s_, t_]
                                 <= dp[s_, t_] * su[s_, t_], name=f'socf_{tag}')
                    m.addQConstr(wm[s_, t_] * wm[s_, t_]
                                 <= dm[s_, t_] * su[s_, t_], name=f'socr_{tag}')
                    m.addConstr(f[s_, t_] == Ks * (wp[s_, t_] - wm[s_, t_]),
                                name=f'sign_{tag}')
                elif link_form == 'pwl':
                    yd, ab, sv, sp, sm, xs, fs = e['_aux']
                    D, F = e['ddmax'], e['fmax']
                    dd = pi2[i_n][s_, t_] - pi2[j_n][s_, t_]
                    m.addConstr(ab[s_, t_] >= dd, name=f'abp_{tag}')
                    m.addConstr(ab[s_, t_] >= -dd, name=f'abm_{tag}')
                    m.addConstr(ab[s_, t_] <= dd + 2 * D * (1 - yd[s_, t_]), name=f'abP_{tag}')
                    m.addConstr(ab[s_, t_] <= -dd + 2 * D * yd[s_, t_], name=f'abM_{tag}')
                    m.addGenConstrPWL(ab[s_, t_], sv[s_, t_], xs, fs, name=f'pwl_{tag}')
                    m.addConstr(sp[s_, t_] <= sv[s_, t_], name=f'sp1_{tag}')
                    m.addConstr(sm[s_, t_] <= sv[s_, t_], name=f'sm1_{tag}')
                    m.addConstr(sp[s_, t_] + sm[s_, t_] == sv[s_, t_], name=f'ssum_{tag}')
                    m.addConstr(sp[s_, t_] <= F * yd[s_, t_], name=f'spM_{tag}')
                    m.addConstr(sm[s_, t_] <= F * (1 - yd[s_, t_]), name=f'smM_{tag}')
                    m.addConstr(f[s_, t_] == sp[s_, t_] - sm[s_, t_], name=f'sign_{tag}')
                else:
                    xs, fs, ddv = e['_aux'][0], e['_aux'][1], e['_dd']
                    m.addConstr(ddv[s_, t_] == pi2[i_n][s_, t_] - pi2[j_n][s_, t_],
                                name=f'dd_{tag}')
                    m.addGenConstrPWL(ddv[s_, t_], f[s_, t_], xs, fs, name=f'pwl_{tag}')

        m.addConstr(soc[s_, T - 1] == C.ESS['soc0'] * C.ESS['cap'], name=f'esscyc_{s_}')
        m.addConstr(hsoc[s_, T - 1] == C.HSS['soc0'] * C.HSS['cap'], name=f'hsscyc_{s_}')
        for nid in nids:
            m.addConstr(p[nid][s_, T - 1] == p_0[nid], name=f'cyc_{nid}_{s_}')

    purch_vars = [e['var'] for e in elements
                  if e['kind'] == 'const' and e['id'] in purchases]
    if not purch_vars:
        raise ValueError('network has no external purchase pipe')

    # ---------------- 目标 ----------------
    carbon_s, cost_s = [], []
    for s_ in range(S):
        burn = gp.quicksum(g[k][s_, t_] for k in loads for t_ in range(T)) \
            + gp.quicksum(fac * ev[s_, t_] for nid in nids
                          for fac, ev in comp_fuel[nid] for t_ in range(T))
        carbon_s.append(gp.quicksum(C.E_GRID * p_grid[s_, t_] for t_ in range(T))
                        + C.E_GAS * burn)
        cost_s.append(gp.quicksum(
            price[t_] * p_grid[s_, t_]
            + C.C_GAS * gp.quicksum(pv[s_, t_] for pv in purch_vars)
            + (5000.0 * p_shed[s_, t_] if allow_shed else 0)
            + C.CHP['c_om'] * p_chp[s_, t_] + C.GB['c_om'] * h_gb[s_, t_]
            + C.EB['c_om'] * h_eb[s_, t_] + C.HP['c_om'] * h_hp[s_, t_]
            + C.ESS['c_om'] * (p_c[s_, t_] + p_d[s_, t_])
            + C.HSS['c_om'] * (h_c[s_, t_] + h_d[s_, t_])
            + C.C_OM_WIND * p_wind[s_, t_] + C.C_OM_PV * p_pv[s_, t_]
            for t_ in range(T)))

    for t_ in range(T):
        for s_ in range(S):
            up = p_chp[s_, t_] - (p_chp[s_, t_ - 1] if t_ > 0 else 0.0)
            m.addConstr(up <= C.CHP['ramp'] + pmax_chp * yup[t_], name=f'rup_{s_}_{t_}')
            m.addConstr(-up <= C.CHP['ramp'] + pmax_chp * zdn[t_], name=f'rdn_{s_}_{t_}')
        m.addConstr(yup[t_] - zdn[t_] == u[t_] - (u[t_ - 1] if t_ > 0 else 0),
                    name=f'trs_{t_}')

    exp_cost = gp.quicksum(probs[s_] * cost_s[s_] for s_ in range(S))
    exp_carbon = gp.quicksum(probs[s_] * carbon_s[s_] for s_ in range(S))
    startup = C.CHP['c_startup'] * gp.quicksum(yup)

    cvar_expr = None
    if risk_lambda > 0:
        tau = m.addVar(lb=-GRB.INFINITY, name='tau')
        zeta = m.addVars(S, lb=0, name='zeta')
        for s_ in range(S):
            m.addConstr(zeta[s_] >= cost_s[s_] - tau)
        cvar_expr = tau + gp.quicksum(probs[s_] * zeta[s_] for s_ in range(S)) / (1 - cvar_beta)

    if mode == 'cost':
        if risk_lambda > 0:
            m.setObjective((1 - risk_lambda) * exp_cost + risk_lambda * cvar_expr
                           + startup, GRB.MINIMIZE)
        else:
            m.setObjective(exp_cost + startup, GRB.MINIMIZE)
    elif mode == 'carbon':
        m.setObjective(exp_carbon, GRB.MINIMIZE)
    elif mode == 'weighted':
        m.setObjective(exp_cost + startup + lam * exp_carbon, GRB.MINIMIZE)
    elif mode == 'eps':
        if cap is None:
            raise ValueError("mode='eps' needs cap")
        m.setObjective(exp_cost + startup, GRB.MINIMIZE)
        m.addConstr(exp_carbon <= cap, name='carbon_cap')
    else:
        raise ValueError(mode)

    # ---------------- 可选：解析零流可行起点（只加起点，不改模型语义） ----------------
    # 该点：全网持压 = p_s、门站阀关、压缩机出口等式管 f=PWL(p_s)=0、可逆管零压差零流、
    # CHP 停（u=0, g=0）、热由电锅炉+热泵恰好覆盖、余电由电网补足、储保持初值。
    # 它对所有 p_s 同时满足每条约束（残差与 p_s 数值无关），故给三格一个同一的可行锚点。
    if mip_start == 'zero_flow':
        for t_ in range(T):
            u[t_].Start = 0.0
            yup[t_].Start = 0.0
            zdn[t_].Start = 0.0
        if p0_is_var:
            for nid in nids:
                p_0[nid].Start = ps
        for s_ in range(S):
            for t_ in range(T):
                h_hp_t = max(0.0, float(h_load_s[s_][t_]) - C.EB['hmax'])
                h_eb_t = float(h_load_s[s_][t_]) - h_hp_t
                h_eb[s_, t_].Start = h_eb_t
                h_hp[s_, t_].Start = h_hp_t
                p_grid[s_, t_].Start = (float(p_load_s[s_][t_])
                                        + h_eb_t / C.EB['eta'] + h_hp_t / C.HP['cop'])
                soc[s_, t_].Start = C.ESS['soc0'] * C.ESS['cap']
                hsoc[s_, t_].Start = C.HSS['soc0'] * C.HSS['cap']
                for nid in nids:
                    p[nid][s_, t_].Start = ps
                if pi2:
                    for nid in pi2:
                        pi2[nid][s_, t_].Start = ps * ps
        for e in elements:
            if e['kind'] != 'link':
                continue
            if link_form == 'soc':
                yd, wp, wm, dp, dm, su = e['_aux']
                for s_ in range(S):
                    for t_ in range(T):
                        yd[s_, t_].Start = 1.0
                        su[s_, t_].Start = 2.0 * ps
            elif link_form == 'pwl':
                yd = e['_aux'][0]
                for s_ in range(S):
                    for t_ in range(T):
                        yd[s_, t_].Start = 1.0
        m.update()

    m.optimize()
    # 如实记录 Gurobi 状态：TIME_LIMIT 但已有可行解时**保留**该解与其 gap / 界，
    # 不把超时粉饰成 OPTIMAL，也不丢弃已有上界（网状臂的排序结论要靠 bound 来判定
    # 是否"可认证"，见 mesh_notes.md 与 audit N 节）。
    if m.SolCount == 0:
        # R-B 措辞纠正（见 mesh_ps70_diagnosis.md）：SolCount==0 且状态为 TIME_LIMIT
        # 一类超时码时，含义是"本次求解在时限内未攒下可行整数解"，**不是**"模型无可行
        # 解"——只有 INFEASIBLE(3)/INF_OR_UNBD(4) 才是求解器认证的空可行集。旧措辞"无可行
        # 解"曾被读成模型不可行，制造出"更高源压反而不可行"的伪悖论。
        st = int(m.Status)
        certified_empty = st in (int(GRB.INFEASIBLE), int(GRB.INF_OR_UNBD))
        verdict = ('模型可行集为空（求解器认证 INFEASIBLE/INF_OR_UNBD）'
                   if certified_empty else
                   '本次求解在时限内未找到可行整数解（不代表模型不可行；可行集非空已由 '
                   'MIP Start 与锚定可行性判定认证，见 mesh_ps70_diagnosis.md）')
        print(f'[model_mesh] 未获得解: status={st} ({status_name(st)}), SolCount=0, '
              f'runtime={m.Runtime:.1f}s — {verdict}', file=sys.stderr)
        if os.environ.get('MESH_DEBUG_IIS') and m.Status == GRB.INFEASIBLE:
            m.computeIIS()
            print('--- IIS 约束 ---')
            for c in m.getConstrs():
                if c.IISConstr:
                    print(c.ConstrName)
            for var in m.getVars():
                if var.IISLB or var.IISUB:
                    print(f'bound: {var.VarName} lb={var.IISLB} ub={var.IISUB}')
        return None

    # ---------------- 结果提取 ----------------
    scen_rows = []
    for s_ in range(S):
        sched = pd.DataFrame({
            'p_wind': [p_wind[s_, t_].X for t_ in range(T)],
            'p_pv': [p_pv[s_, t_].X for t_ in range(T)],
            'p_grid': [p_grid[s_, t_].X for t_ in range(T)],
            'p_chp': [p_chp[s_, t_].X for t_ in range(T)],
            'u_chp': [u[t_].X for t_ in range(T)],
            'h_gb': [h_gb[s_, t_].X for t_ in range(T)],
            'h_eb': [h_eb[s_, t_].X for t_ in range(T)],
            'h_hp': [h_hp[s_, t_].X for t_ in range(T)],
            'p_load': p_load_s[s_], 'h_load': h_load_s[s_], 'price': price,
        })
        for nid in nids:
            sched[f'p_{nid}'] = [p[nid][s_, t_].X for t_ in range(T)]
            sched[f'lp_{nid}'] = [nodes[nid]['A'] * p[nid][s_, t_].X for t_ in range(T)]
        for e in elements:
            sched[f"f_{e['id']}"] = [e['var'][s_, t_].X for t_ in range(T)]
            if e['kind'] == 'const' and e['ubvar'] is not None:
                sched[f"ub_{e['id']}"] = [e['ubvar'][s_, t_].X for t_ in range(T)]
            if e['kind'] == 'link':
                if link_form in ('soc', 'pwl'):
                    sched[f"y_{e['id']}"] = [e['_aux'][0][s_, t_].X for t_ in range(T)]
                else:
                    sched[f"y_{e['id']}"] = [1.0 if e['var'][s_, t_].X >= 0 else 0.0
                                             for t_ in range(T)]
        n_start = int(round(sum(yup[t_].X for t_ in range(T))))
        purch = float(sum(e['var'][s_, t_].X for e in elements
                          if e['kind'] == 'const' and e['id'] in purchases
                          for t_ in range(T)) * dt)
        fuel = float(sum(fac * ev[s_, t_].X for nid in nids
                         for fac, ev in comp_fuel[nid] for t_ in range(T)) * dt)
        tot_lp = [sum(sched[f'lp_{nid}'][t_] for nid in nids) for t_ in range(T)]
        row = dict(scenario=s_, prob=probs[s_],
                   op_cost=float(cost_s[s_].getValue()),
                   startup_cost=C.CHP['c_startup'] * n_start,
                   carbon=float(carbon_s[s_].getValue()),
                   grid_buy_MWh=float(sched['p_grid'].sum() * dt),
                   purchase_MWh=purch, comp_fuel_MWh=fuel,
                   shed_MWh=(float(sum(p_shed[s_, t_].X for t_ in range(T)) * dt)
                             if allow_shed else 0.0),
                   lp_swing=float(max(tot_lp) - min(tot_lp)),
                   lp_total_MWh=float(np.mean(tot_lp) * dt),
                   sched=sched)
        for nid in nids:
            col = sched[f'p_{nid}']
            row[f'{nid}_min'] = float(col.min())
            row[f'{nid}_max'] = float(col.max())
            row[f'{nid}_at_min_h'] = int(sum(1 for x in col if x <= pd_min + 1e-4))
            row[f'{nid}_at_max_h'] = int(sum(1 for x in col if x >= nodes[nid]['pmax'] - 1e-4))
        for e in elements:
            col = sched[f"f_{e['id']}"]
            eid = e['id']
            row[f'{eid}_peak_abs'] = float(max(abs(x) for x in col))
            row[f'{eid}_peak_fmax'] = e['fmax']
            row[f'{eid}_sum_MWh'] = float(sum(col) * dt)
            if e['kind'] == 'const' and e['ubvar'] is not None:
                row[f'{eid}_throttle_h'] = int(sum(
                    1 for t_ in range(T) if sched[f'ub_{eid}'][t_] - col[t_] > 1e-4))
            if e['kind'] == 'link':
                row[f'{eid}_rev_h'] = int(sum(1 for x in col if x < -1e-6))
                row[f'{eid}_fwd_h'] = int(sum(1 for x in col if x > 1e-6))
                row[f'{eid}_zero_h'] = int(sum(1 for x in col if abs(x) <= 1e-6))
        scen_rows.append(row)

    scen_costs = np.array([float(cost_s[s_].getValue()) for s_ in range(S)])
    scen_probs = np.array(probs)
    order = np.argsort(-scen_costs)
    nk = max(1, int(np.ceil((1 - cvar_beta) * S)))
    cvar_emp = float(np.sum(scen_probs[order[:nk]] * scen_costs[order[:nk]])
                     / max(1e-9, np.sum(scen_probs[order[:nk]])))
    lp_cap = float(sum(nodes[nid]['A'] * (nodes[nid]['pmax'] - nodes[nid]['pmin'])
                       for nid in nids))
    met = dict(
        net=net['name'], mode=mode, lam=lam, cap=cap, n_scen=S, T=T,
        gas_coupled=True, dir_mode=dir_mode, n_pts=n_pts, p0_mode=p0_mode,
        mip_start=mip_start,
        p0_is_var=p0_is_var, u_fix=u_fix is not None, allow_shed=allow_shed,
        ps=ps, ps2=ps2, pd_min=pd_min, A_node=net.get('A_node'), K=net.get('K'),
        comp_ratio=max([e['fuel'] for e in elements if e['kind'] == 'const'] or [0.0]),
        lp_cap=lp_cap,
        n_gas_nodes=len(nids), n_elements=len(elements),
        n_links=sum(1 for e in elements if e['kind'] == 'link'),
        n_const=sum(1 for e in elements if e['kind'] == 'const'),
        risk_lambda=risk_lambda, cvar_beta=cvar_beta, cvar_emp=cvar_emp,
        cvar_model=(float(cvar_expr.getValue()) if cvar_expr is not None else None),
        exp_cost=float(exp_cost.getValue())
        + C.CHP['c_startup'] * int(round(sum(yup[t_].X for t_ in range(T)))),
        exp_carbon=float(exp_carbon.getValue()),
        solve_time=float(m.Runtime), mip_gap=float(m.MIPGap),
        obj_bound=float(m.ObjBound), obj_val=float(m.ObjVal),
        n_vars=int(m.NumVars), n_cons=int(m.NumConstrs), n_bin=int(m.NumBinVars),
        status=int(m.Status), status_name=status_name(m.Status),
        scen_rows=scen_rows,
    )
    return met


# ---------------------------------------------------------------- 表示误差体检
def const_pipe_error(K, p_ref, p_dn_lo, n_pts=60, n_grid=20001):
    """定压上游管段：一维余弦 PWL vs 精确 Weymouth 的最大误差（model_gc 同口径）。"""
    pts = _pwl_pts(n_pts, p_dn_lo, p_ref)
    fpt = np.sqrt(np.clip(K * (p_ref ** 2 - pts ** 2), 0, None))
    grid = np.linspace(p_dn_lo, p_ref, n_grid)
    fe = np.sqrt(np.clip(K * (p_ref ** 2 - grid ** 2), 0, None))
    fa = np.interp(grid, pts, fpt)
    err = np.abs(fa - fe)
    m_ = int(err.argmax())
    return dict(max_abs_MW=float(err[m_]), at_p_bar=float(grid[m_]),
                pct_of_fmax=float(100 * err.max() / max(fe.max(), 1e-12)))


def link_repr_error(K, p_lo, p_hi, n_pts=60, n_grid=161, dir_mode='binary'):
    """可逆管段：两层 PWL（p^2 线性插值 + sqrt 线性插值）合成后的最大误差。

    对 (p_i, p_j) 网格：
      dd_apx  = PWL(p_i^2) - PWL(p_j^2)
      f_apx   = binary:  sign(dd_apx) * interp(|dd_apx|; sqrt 网格)
                asym :   interp(dd_apx; 反对称网格)
      f_exact = sign(p_i^2-p_j^2) * sqrt(K|p_i^2-p_j^2|)
    误差同时包含"平方压力插值"与"开方插值"两项，是 link 表达的真实表示误差。
    """
    pts = _pwl_pts(n_pts, p_lo, p_hi)
    grid = np.linspace(p_lo, p_hi, n_grid)
    q_apx = np.interp(grid, pts, pts ** 2)
    dd_max = p_hi ** 2 - p_lo ** 2
    spts = _pwl_pts(n_pts, 0.0, dd_max)
    svals = np.sqrt(K * spts)
    apts = np.concatenate([-spts[::-1][:-1], spts])
    avals = np.sign(apts) * np.sqrt(K * np.abs(apts))
    best = (0.0, None)
    for a in range(n_grid):
        for b in range(n_grid):
            dd_true = grid[a] ** 2 - grid[b] ** 2
            f_true = np.sign(dd_true) * np.sqrt(max(K * abs(dd_true), 0.0))
            dd_apx = q_apx[a] - q_apx[b]
            if dir_mode == 'binary':
                f_apx = np.sign(dd_apx) * float(np.interp(abs(dd_apx), spts, svals))
            else:
                f_apx = float(np.interp(dd_apx, apts, avals))
            err = abs(f_apx - f_true)
            if err > best[0]:
                best = (float(err), (float(grid[a]), float(grid[b]),
                                     float(f_true), float(f_apx)))
    fmax = float(np.sqrt(K * dd_max))
    return dict(max_abs_MW=best[0], at_pi_pj=best[1], fmax_MW=fmax,
                pct_of_fmax=100 * best[0] / fmax, dir_mode=dir_mode)


if __name__ == '__main__':
    print('Weymouth 表示误差（K=3.83e-3, pd_min=20, 60 余弦断点）')
    for ps in (50.0, 60.0, 70.0):
        e = const_pipe_error(0.00383, ps, 20.0)
        print(f'  const pipe @ps={ps:.0f}: max|err| = {e["max_abs_MW"]:.6f} MW '
              f'({e["pct_of_fmax"]:.4f}% of fmax @ p={e["at_p_bar"]:.2f} bar)')
    for dm in ('binary', 'pwl_asym'):
        for ps in (50.0, 70.0):
            e = link_repr_error(0.00383, 20.0, ps, dir_mode=dm, n_grid=81)
            print(f'  link[{dm}] @ps={ps:.0f}: max|err| = {e["max_abs_MW"]:.6f} MW '
                  f'= {e["pct_of_fmax"]:.4f}% of fmax={e["fmax_MW"]:.4f}; worst at '
                  f'(pi,pj)={e["at_pi_pj"][0]:.2f},{e["at_pi_pj"][1]:.2f} '
                  f'f_exact={e["at_pi_pj"][2]:.4f}')
