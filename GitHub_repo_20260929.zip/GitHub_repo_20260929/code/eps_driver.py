# -*- coding: utf-8 -*-
"""EPS 碳–成本 ε 前沿驱动器（v3 耦合两阶段随机模型，ps=ps2=70 bar）。

三阶段流程（每档独立子进程，禁止同进程连跑）：

  A. 端点锚定（模型输出，非外生假设）：
     - end_carbon: mode='carbon', allow_shed=False → 期望碳排下限 c_lo
     - end_cost:   mode='cost',   allow_shed=False → 成本最优点的期望碳排 c_hi
     - probe_low:  mode='eps', cap=0.98*c_lo → 低端不可行性探针（可达性证书）

  B. 自适应档位选取（算法见 EPS_notes.md §3）：
     - 粗网格: [c_lo, c_hi] 内部 5 个等距档（linspace 7 点去两端）
     - 细化迭代: 对已有点按碳排排序，计算相邻区段的边际减碳成本
       （割线斜率 s_i = Δcost/Δcarbon，元/tCO2）。在每个碳排区间上取
       score(j) = max(|s_j - s_{j-1}|, |s_{j+1} - s_j|)（该区间两端折点的
       斜率变化），在得分最大的区间中点插入新档；迭代直至
       max score < TOL_SLOPE_CHANGE（斜率变化收敛判据）或达轮数上限，
       且不产生宽度 < MIN_WIDTH 的区间。
     - 与等距枚举对比：等距 CAPS_N=14 档（v2 做法）对膝点分辨率均匀；
       本算法在斜率变化最大处（膝点附近）加密，同等档数下膝点区段
       分辨率更高（效率对比数字见 EPS_notes.md）。

  C. 全部可行档的样本外评价（eps_oos_level.py，100 测试日 u_fix 重调度）
     + 对照实验（允许切负荷，证明口径必要性）
     + 汇总 EPS_frontier.csv（含边际减碳成本列）。

用法：
  Y:/cuda/python.exe eps_driver.py            # 全流程（可断点续跑：已完成的档自动跳过）
  Y:/cuda/python.exe eps_driver.py --skip-oos # 只做 RP 求解与自适应细化
"""
import argparse
import os
import subprocess
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
PY = sys.executable

PS = 70.0
N_COARSE = 5            # 粗网格内部档数
R_MAX = 3               # 自适应细化最大轮数
TOL_SLOPE_CHANGE = 50.0  # 元/tCO2：相邻区段斜率变化低于此值视为收敛
MIN_WIDTH = 0.05         # tCO2：相邻档最小碳排间距
PROBE_ALPHA = 0.98       # 低端不可行探针：cap = PROBE_ALPHA * c_lo

ENV = dict(os.environ)
ENV['E_GRID_MODE'] = 'official_om_nw'
ENV['V3_ARM'] = 'main'
ENV['PYTHONIOENCODING'] = 'utf-8'


def run_level(tag, mode, cap=None, shed=False):
    """单档 RP 求解（独立子进程）。已完成的档跳过（断点续跑）。"""
    out = os.path.join(RES, f'EPS_rp_{tag}.csv')
    if os.path.exists(out):
        print(f'[driver] {tag} 已有结果，跳过')
        return
    cmd = [PY, os.path.join(HERE, 'eps_run_level.py'),
           '--tag', tag, '--mode', mode]
    if cap is not None:
        cmd += ['--cap', f'{cap:.6f}']
    if shed:
        cmd += ['--shed']
    print(f'[driver] 运行 {tag}: mode={mode} cap={cap} shed={shed}')
    subprocess.run(cmd, cwd=HERE, env=ENV, check=True)


def run_oos(tag):
    out = os.path.join(RES, f'EPS_oossum_{tag}.csv')
    if os.path.exists(out):
        print(f'[driver] OOS {tag} 已有结果，跳过')
        return
    ufile = os.path.join(RES, f'EPS_u_{tag}.npy')
    if not os.path.exists(ufile):
        print(f'[driver] OOS {tag}: 无承诺文件，跳过（该档求解失败）')
        return
    print(f'[driver] OOS 评价 {tag}（100 测试日）')
    subprocess.run([PY, os.path.join(HERE, 'eps_oos_level.py'), '--tag', tag],
                   cwd=HERE, env=ENV, check=True)


def read_rp(tag):
    p = os.path.join(RES, f'EPS_rp_{tag}.csv')
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    return df.iloc[0].to_dict()


def frontier_points(rows):
    """可行档 → 按 exp_carbon 排序的 (carbon, cost, tag) 列表"""
    pts = [(r['exp_carbon'], r['exp_cost'], r['tag'])
           for r in rows if r.get('solved') == 1 and np.isfinite(r.get('exp_carbon', np.nan))]
    return sorted(pts)


def refine_scores(pts):
    """各区间的自适应得分：区间 j 的两端折点斜率变化的最大值。
    s_i = (k_{i+1}-k_i)/(c_{i+1}-c_i)（元/tCO2，i 为区段号）。
    score(j) = max(|s_j - s_{j-1}|, |s_{j+1} - s_j|)，区间 j 指点 j 与 j+1 之间。
    """
    c = np.array([p[0] for p in pts])
    k = np.array([p[1] for p in pts])
    n = len(pts)
    if n < 3:
        return [np.inf] * (n - 1)
    s = (k[1:] - k[:-1]) / (c[1:] - c[:-1])          # n-1 个区段斜率
    ds = np.abs(np.diff(s))                           # n-2 个折点斜率变化
    scores = []
    for j in range(n - 1):
        cand = []
        if j >= 1 and j - 1 < len(ds):
            cand.append(ds[j - 1])
        if j < len(ds):
            cand.append(ds[j])
        scores.append(max(cand) if cand else 0.0)
    return scores


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--skip-oos', action='store_true')
    a = ap.parse_args()

    # ---------------- A. 端点锚定 ----------------
    print('=== A. 端点锚定（模型输出） ===')
    run_level('end_carbon', 'carbon')
    run_level('end_cost', 'cost')
    rp_carb, rp_cost = read_rp('end_carbon'), read_rp('end_cost')
    assert rp_carb and rp_carb.get('solved') == 1, 'carbon 端点求解失败'
    assert rp_cost and rp_cost.get('solved') == 1, 'cost 端点求解失败'
    c_lo = float(rp_carb['exp_carbon'])
    c_hi = float(rp_cost['exp_carbon'])
    print(f'[driver] 端点: c_lo={c_lo:.4f} (cost {rp_carb["exp_cost"]:.2f}) | '
          f'c_hi={c_hi:.4f} (cost {rp_cost["exp_cost"]:.2f})')
    assert c_lo < c_hi, '端点异常：碳排下限应小于成本最优碳排'

    # 低端不可行探针
    run_level('probe_low', 'eps', cap=PROBE_ALPHA * c_lo)
    rp_probe = read_rp('probe_low')
    print(f'[driver] 探针 cap={PROBE_ALPHA * c_lo:.4f} → status={rp_probe["status"]} '
          f'({"不可行，下界证书成立" if rp_probe["status"] in (3, 4) else "意外：可行，需复查"})')

    # ---------------- B. 自适应档位选取 ----------------
    print('=== B. 自适应档位选取 ===')
    coarse = np.linspace(c_lo, c_hi, N_COARSE + 2)[1:-1]
    for j, cp in enumerate(coarse):
        run_level(f'lev_r0_{j}', 'eps', cap=float(cp))

    rows = [read_rp(t) for t in
            ['end_carbon', 'end_cost'] + [f'lev_r0_{j}' for j in range(N_COARSE)]]
    log = []
    for rnd in range(1, R_MAX + 1):
        pts = frontier_points(rows)
        scores = refine_scores(pts)
        widths = np.diff([p[0] for p in pts])
        jbest = int(np.argmax(scores))
        sbest = scores[jbest]
        log.append(dict(round=rnd, n_points=len(pts), max_score=sbest,
                        interval=jbest,
                        c_left=pts[jbest][0], c_right=pts[jbest + 1][0],
                        width=pts[jbest + 1][0] - pts[jbest][0]))
        if sbest < TOL_SLOPE_CHANGE:
            print(f'[driver] 轮 {rnd}: 最大斜率变化 {sbest:.1f} < {TOL_SLOPE_CHANGE} 元/tCO2，收敛')
            break
        c_new = 0.5 * (pts[jbest][0] + pts[jbest + 1][0])
        # 防止过密
        if (pts[jbest + 1][0] - pts[jbest][0]) < 2 * MIN_WIDTH:
            print(f'[driver] 轮 {rnd}: 最陡区间过窄，停止细化')
            break
        print(f'[driver] 轮 {rnd}: 最陡区间 [{pts[jbest][0]:.4f}, {pts[jbest + 1][0]:.4f}] '
              f'得分 {sbest:.1f} 元/tCO2 → 插入 cap={c_new:.4f}')
        run_level(f'lev_r{rnd}_j{jbest}', 'eps', cap=c_new)
        rows.append(read_rp(f'lev_r{rnd}_j{jbest}'))

    pd.DataFrame(log).to_csv(os.path.join(RES, 'EPS_adaptive_log.csv'),
                             index=False, encoding='utf-8-sig')

    # ---------------- 对照实验：允许切负荷（口径必要性证据） ----------------
    print('=== C0. 对照实验（允许切负荷） ===')
    # ctrl 1: 碳目标 + 允许切负荷 → 检验"切负荷零碳"退化（碳排下限被人为压低）
    run_level('ctrl_carbon_shed', 'carbon', shed=True)
    # ctrl 2: ε 约束低于无切负荷下界 + 允许切负荷 → 只有切负荷才可达，前沿伪造延伸
    run_level('ctrl_eps_shed', 'eps', cap=0.94 * c_lo, shed=True)

    if a.skip_oos:
        print('[driver] --skip-oos，跳过样本外评价')
        return

    # ---------------- C. 样本外评价 ----------------
    print('=== C. 样本外评价（全部可行档） ===')
    pts = frontier_points(rows)
    for _, _, tag in pts:
        run_oos(tag)

    # ---------------- 汇总 ----------------
    print('=== 汇总 EPS_frontier.csv ===')
    recs = []
    for carbon, cost, tag in pts:
        rp = read_rp(tag)
        oos_p = os.path.join(RES, f'EPS_oossum_{tag}.csv')
        rec = dict(tag=tag, kind=('endpoint_carbon' if tag == 'end_carbon' else
                                  'endpoint_cost' if tag == 'end_cost' else 'eps'),
                   carbon_cap=(np.nan if tag == 'end_carbon' else
                               rp['cap'] if tag == 'end_cost' else rp['cap']),
                   status=rp['status'], solved=rp['solved'],
                   rp_exp_cost=cost, rp_exp_carbon=carbon,
                   rp_mip_gap=rp['mip_gap'], rp_solve_time=rp['solve_time'],
                   rp_cvar_emp=rp['rp_cvar_emp'], n_starts=rp['n_starts'],
                   n_vars=rp['n_vars'], n_cons=rp['n_cons'],
                   in_sample_shed_MWh=rp['in_sample_shed_MWh'])
        if os.path.exists(oos_p):
            oos = pd.read_csv(oos_p).iloc[0].to_dict()
            rec.update(oos_mean_cost=oos['oos_mean_cost'],
                       oos_cvar95=oos['oos_cvar95'],
                       oos_worst_day=oos['oos_worst_day'],
                       oos_mean_carbon=oos['oos_mean_carbon'],
                       oos_eens_e_MWh_day=oos['oos_eens_e_MWh_day'],
                       oos_n_fail=oos['n_fail'])
        else:
            rec.update(oos_mean_cost=np.nan, oos_cvar95=np.nan,
                       oos_worst_day=np.nan, oos_mean_carbon=np.nan,
                       oos_eens_e_MWh_day=np.nan, oos_n_fail=np.nan)
        recs.append(rec)
    fr = pd.DataFrame(recs).sort_values('rp_exp_carbon').reset_index(drop=True)
    # 边际减碳成本（割线，正数 = 每多减 1 kgCO2 需要额外多少元）
    fr['secant_yuan_per_tCO2'] = np.nan
    for i in range(1, len(fr)):
        dc = fr.loc[i, 'rp_exp_carbon'] - fr.loc[i - 1, 'rp_exp_carbon']
        dk = fr.loc[i - 1, 'rp_exp_cost'] - fr.loc[i, 'rp_exp_cost']
        fr.loc[i, 'secant_yuan_per_tCO2'] = dk / dc if dc > 1e-9 else np.nan
    fr['secant_yuan_per_kgCO2'] = fr['secant_yuan_per_tCO2'] / 1000.0
    fr.to_csv(os.path.join(RES, 'EPS_frontier.csv'),
              index=False, encoding='utf-8-sig')

    # 对照组与探针单独落表
    ctrl_rows = []
    for tag in ['probe_low', 'ctrl_carbon_shed', 'ctrl_eps_shed']:
        rp = read_rp(tag)
        if rp:
            ctrl_rows.append(rp)
    pd.DataFrame(ctrl_rows).to_csv(os.path.join(RES, 'EPS_controls.csv'),
                                   index=False, encoding='utf-8-sig')

    print('[driver] 前沿点数:', len(fr))
    print(fr[['tag', 'rp_exp_carbon', 'rp_exp_cost', 'secant_yuan_per_tCO2']]
          .to_string(index=False))
    print('done')


if __name__ == '__main__':
    main()
