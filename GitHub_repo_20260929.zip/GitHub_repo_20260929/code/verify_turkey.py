# -*- coding: utf-8 -*-
"""任务四：土耳其风电加载器可用性验证（只验证，不跑模型实验）

验证对象：code/data_sites.py:37 load_turkey_wind() 及其缓存 code/results/turkey_wind_2018.csv
源文件：Y:\\科研\\电力数据集\\P02【免费公开】精选5套风电及气象数据集\\（4）2018年土耳其风电数据.xlsx

输出：code_v3/results/turkey_loader_check.csv
"""
import os
import sys
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
CODE = os.path.normpath(os.path.join(HERE, '..', 'code'))
sys.path.insert(0, CODE)

TR_XLSX = (r'Y:\科研\电力数据集\P02【免费公开】精选5套风电及气象数据集'
           r'\（4）2018年土耳其风电数据.xlsx')


def main():
    rows = []

    def add(k, v):
        rows.append({'item': k, 'value': str(v)})
        print(f'{k}: {v}')

    cache = os.path.join(CODE, 'results', 'turkey_wind_2018.csv')
    add('cache_exists', os.path.exists(cache))
    if os.path.exists(cache):
        s = pd.read_csv(cache, index_col=0, parse_dates=True).iloc[:, 0]
        add('cache_rows', len(s))
        add('cache_range', f'{s.index.min()} -> {s.index.max()}')
        add('cache_nan', int(s.isna().sum()))
        add('cache_unit', '标幺（按观测最大出力归一，峰值=1）')

    # 加载器本身（只读缓存路径，不触发刷新）
    import data_sites
    s2 = data_sites.load_turkey_wind()
    add('loader_return_rows', len(s2))
    add('loader_readable', True)

    # 源文件实际覆盖范围（决定"跨站点检查"可用时长）
    df = pd.read_excel(TR_XLSX, usecols=['Date/Time', 'LV ActivePower (kW)'])
    add('source_rows_10min', len(df))
    add('source_range_raw', f'{df["Date/Time"].min()} -> {df["Date/Time"].max()}')
    add('source_days', round(len(df) / 144, 2))   # 10min -> 144 点/天

    pd.DataFrame(rows).to_csv(os.path.join(RES, 'turkey_loader_check.csv'),
                              index=False, encoding='utf-8-sig')


if __name__ == '__main__':
    main()
