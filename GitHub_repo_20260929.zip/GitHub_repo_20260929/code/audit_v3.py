# -*- coding: utf-8 -*-
"""code_v3 数据与结果审计：论文 v3 主口径每个关键数字 vs results/ 原始数据核对。

覆盖（与 submission/v2/audit_notes.md 一一对应）：
  A. 源压减排杠杆（贡献 1）          —— V3_GC_scan_carbon.csv
  B. 气网咬合诊断（贡献 4 量化基础）  —— V3_GC_PS70_main_summary.csv + _oos 逐日文件
  C. ε 前沿（贡献 3）                —— EPS_rp_* 全档位 + 对照
  D. E28 / E29（贡献 2）             —— PWL_E28_* / PWL_E29_accuracy.csv
  E. 随机承诺价值（贡献 5）          —— IN_* / BOOT_*
  F. 电网受入容量与边界              —— V3_all_cap_summary_table.csv
  G. 数据层口径                      —— data_manifest.md / 官方 EF PDF / config_v3.py
  H. 旧口径隔离                      —— 旧口径数字在 v3 结果与 v2 tex 中的出现语境

容差依据（每处检查的注释里也写明）：
  - 理论恒等式 / 同一数字在两个文件间的转抄：逐位或 1e-9/1e-6（受 CSV 6 位小数
    存储精度限制时用 5e-7 = 6 位小数的半 ulp）。
  - 求解器输出（目标值、统计量）：与论文引用值按其有效位数对齐（论文给 2 位小数
    则半位容差 0.005；给 1 位小数则 0.05）。
  - 论文四舍五入后引用的百分比：与现算值差不超过末位半单位（0.01pp 或 0.05pp）。
  - 压力下界容差：Gurobi 默认可行性容差量级 1e-6，论文若声称"无压力越限"必须
    给出该容差；审计断言观测偏差 < 1e-5 并记录实际量级。

本脚本只读，不修改任何既有文件；核对明细写 results/audit_v3_check.csv。
用法：python audit_v3.py   （退出码 0 全过 / 1 有 FAIL）
"""
import csv
import os
import re
import sys
import glob
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
ROOT = os.path.dirname(HERE)
SUB_V2 = os.path.join(ROOT, 'submission', '论文源_v2')

PASS, FAIL = 'PASS', '**FAIL**'
SKIPPED = 'SKIPPED'
results = []


def check(claim, source, expect, actual, tol=None, detail='', skip=None):
    """tol=None：布尔/逐位恒等；否则 |actual-expect| <= tol。detail 记录补充语境。

    skip 非空 -> 记为 SKIPPED（既非 PASS 也非 FAIL），skip 文本即"该断言为何未判定"的
    原因，必须出现在汇总里并计数。用于"该格数据/口径不满足判据前提时不得静默通过"。
    """
    if skip:
        results.append(dict(claim=claim, source=source, expect=expect,
                            actual='(skip)', status=SKIPPED, detail=f'SKIP 原因：{skip}'))
        print(f'  [{SKIPPED}] {claim}: {skip}')
        return None
    if tol is None:
        ok = (actual == expect)
    else:
        ok = (actual is not None) and abs(float(actual) - float(expect)) <= tol
    act_s = actual if isinstance(actual, str) else (
        repr(actual) if isinstance(actual, (bool, list, tuple, dict, set)) else
        (None if actual is None else round(float(actual), 6) if abs(float(actual)) < 1e6 else round(float(actual), 2)))
    results.append(dict(claim=claim, source=source, expect=expect,
                        actual=act_s, status=PASS if ok else FAIL, detail=detail))
    print(f'  [{results[-1]["status"]}] {claim}: 期望={expect} 实测={act_s}'
          + (f'（tol={tol}）' if tol is not None else '')
          + (f'  | {detail}' if detail else ''))
    return ok


def load_long_summary(name):
    """V3_GC_*_main_summary.csv：三列 metric/value/unit 的竖表 → Series(value)。"""
    df = pd.read_csv(os.path.join(RES, name))
    return df.set_index(df.columns[0])[df.columns[1]]


def _f(series, key):
    return float(series[key])


print('=== A. 源压减排杠杆（贡献 1）===')
scan = pd.read_csv(os.path.join(RES, 'V3_GC_scan_carbon.csv'))
main = scan[scan['arm'] == 'main'].set_index('cfg')
# 期望值取自运行产物全精度值（论文引用为其 3 位小数舍入）；理论恒等：同一求解
# 结果的转抄，故容差 1e-6（远小于求解器可复现差异，实际应逐位一致）。
for cfg, exp in [('B0', 27.36146840951521), ('PS50', 37.0566372352305),
                 ('PS60', 34.621424177933385), ('PS70', 32.910799310287025)]:
    check(f'A{["B0","PS50","PS60","PS70"].index(cfg)+1} carbon_min_exp_rp[{cfg}]',
          'V3_GC_scan_carbon.csv', exp, float(main.loc[cfg, 'carbon_min_exp_rp']),
          1e-6, detail=f'论文引用 {round(exp, 3)}')
c50 = float(main.loc['PS50', 'carbon_min_exp_rp'])
c70 = float(main.loc['PS70', 'carbon_min_exp_rp'])
c_b0 = float(main.loc['B0', 'carbon_min_exp_rp'])
# 论文给 11.19%（2 位小数）→ 现算值允许末位半单位 0.01pp。
check('A5 源压 50→70 碳最低降幅 = 11.19%', 'A 端点现算', 11.19,
      100 * (c50 - c70) / c50, 0.01, detail='由 A2/A4 端点现算')
# 论文给 +20.3%（1 位小数）→ 半单位 0.05pp。
check('A6 耦合抬升碳地板（B0→PS70）= +20.3%', 'A 端点现算', 20.3,
      100 * (c70 - c_b0) / c_b0, 0.05, detail='论文 1 位小数，半单位 0.05pp')
check('A7 四档 carbon_min_rp_status 均 = 2 (OPTIMAL)', 'V3_GC_scan_carbon.csv', True,
      all(int(main.loc[c, 'carbon_min_rp_status']) == 2 for c in ['B0', 'PS50', 'PS60', 'PS70']))

print('=== B. 气网咬合诊断（贡献 4 的量化基础）===')
s70 = load_long_summary('V3_GC_PS70_main_summary.csv')
check('B1 gas_oos_f1_throttle_h = 1776', 'V3_GC_PS70_main_summary.csv', 1776,
      _f(s70, 'gas_oos_f1_throttle_h'), 0)
check('B2 gas_oos_p1_at_min_h = 999', 'V3_GC_PS70_main_summary.csv', 999,
      _f(s70, 'gas_oos_p1_at_min_h'), 0)
check('B3 gas_oos_p2_at_max_h = 1815', 'V3_GC_PS70_main_summary.csv', 1815,
      _f(s70, 'gas_oos_p2_at_max_h'), 0)
check('B4 gas_oos_f1_at_cap_h = 125', 'V3_GC_PS70_main_summary.csv', 125,
      _f(s70, 'gas_oos_f1_at_cap_h'), 0)
# 论文引用 48.2 / 0.065（3 位有效舍入）→ 半位容差。
check('B5 gas_oos_lp_util_pct ≈ 48.2', 'V3_GC_PS70_main_summary.csv', 48.2,
      _f(s70, 'gas_oos_lp_util_pct'), 0.05)
check('B6 gas_oos_comp_share_pct ≈ 0.065', 'V3_GC_PS70_main_summary.csv', 0.065,
      _f(s70, 'gas_oos_comp_share_pct'), 0.0005,
      detail='交叉核对 V3_all_gc_summary_table comp=0.064680')
# 分母恒等式：100 测试日 × 24 h，逐位。
check('B7 gas_oos_hours_total = 2400 = 100 日 × 24 h（分母正确）',
      'V3_GC_PS70_main_summary.csv', True,
      _f(s70, 'gas_oos_hours_total') == 2400.0
      and _f(s70, 'gas_oos_n_days') == 100.0
      and _f(s70, 'gas_oos_hours_total') == _f(s70, 'gas_oos_n_days') * 24)
# p1 下界容差：Gurobi 可行性容差量级 1e-6；断言 < 1e-5 并记录量级。
# 注意：任务卡给出的 19.99999913（偏差 8.7e-7）与结果文件实测 19.99999895
# （偏差 1.048e-6）在同一量级、同样 < 1e-5；以结果文件为准，论文表述应写 "~1e-6"。
p1min_obs = _f(s70, 'gas_oos_p1_min_obs')
dev = 20.0 - p1min_obs
check('B8 p1 下界容差：gas_oos_p1_min_obs 低于 20 bar 不足 1e-5', 'V3_GC_PS70_main_summary.csv',
      True, dev < 1e-5, detail=f'实测 p1_min_obs={p1min_obs!r}，偏差={dev:.3e} bar（量级 1e-6）')
# 同一数字两处转抄：summary 汇总 vs 逐日文件最小值，逐位（1e-9）。
oos = pd.read_csv(os.path.join(RES, 'V3_GC_PS70_main_oos.csv'))
check('B9 逐日文件 p1_min 最小值与 summary 一致（1e-9）',
      'V3_GC_PS70_main_oos.csv', p1min_obs, float(oos['p1_min'].min()), 1e-9,
      detail=f'最低日 {oos.loc[oos["p1_min"].idxmin(), "test_day"]}')

print('=== C. ε 前沿（贡献 3）===')
end_carbon = pd.read_csv(os.path.join(RES, 'EPS_rp_end_carbon.csv')).iloc[0]
end_cost = pd.read_csv(os.path.join(RES, 'EPS_rp_end_cost.csv')).iloc[0]
probe = pd.read_csv(os.path.join(RES, 'EPS_rp_probe_low.csv')).iloc[0]
# 端点锚定交叉校验。EPS 文件按 6 位小数存储，故判据为：
#   (a) 存储值 == round(参照值, 6)（逐位）；(b) 差 ≤ 5e-7（6 位小数半 ulp）。
# 任务卡所写 1e-9 在 6 位小数存储下不可达；5e-7 是存储精度的如实上界，非放宽。
ec_ref = c70
ec_stored = float(end_carbon['exp_carbon'])
check('C1 碳端点 exp_carbon 锚定 = PS70 carbon_min_exp_rp（≤5e-7，逐位一致性记入明细）',
      'EPS_rp_end_carbon.csv vs V3_GC_scan_carbon.csv', True,
      abs(ec_stored - ec_ref) <= 5e-7,
      detail=f'存储={ec_stored!r}，参照={ec_ref!r}，逐位一致={ec_stored == ec_ref}')
check('C2 成本端点 exp_cost = PS70 rp_exp_cost', 'EPS_rp_end_cost.csv vs V3_GC_PS70_main_summary.csv',
      _f(s70, 'rp_exp_cost'), float(end_cost['exp_cost']), 5e-7)
check('C3 成本端点 exp_carbon = PS70 rp_exp_carbon', 'EPS_rp_end_cost.csv vs V3_GC_PS70_main_summary.csv',
      _f(s70, 'rp_exp_carbon'), float(end_cost['exp_carbon']), 5e-7)
check('C4 低端探针 status = 3 (INFEASIBLE)', 'EPS_rp_probe_low.csv', 3, int(probe['status']), 0)
check('C5 低端探针 solved = 0', 'EPS_rp_probe_low.csv', 0, int(probe['solved']), 0)

lev_files = sorted(glob.glob(os.path.join(RES, 'EPS_rp_lev_*.csv')))
levs = [pd.read_csv(f).iloc[0] for f in lev_files]
# 硬断言（项目踩过的坑）：除两份 allow_shed 对照外，全部 ε 档位禁切负荷。
check('C6 全部 ε 档位 + 端点 + 探针 allow_shed = False（硬断言）',
      'EPS_rp_lev_*/end_*/probe_low', True,
      all(not bool(r['allow_shed']) for r in levs)
      and not bool(end_carbon['allow_shed']) and not bool(end_cost['allow_shed'])
      and not bool(probe['allow_shed']))
ctrl_shed_c = pd.read_csv(os.path.join(RES, 'EPS_rp_ctrl_carbon_shed.csv')).iloc[0]
ctrl_shed_e = pd.read_csv(os.path.join(RES, 'EPS_rp_ctrl_eps_shed.csv')).iloc[0]
check('C7 两份切负荷对照 allow_shed = True（确为对照档）',
      'EPS_rp_ctrl_*_shed.csv', True,
      bool(ctrl_shed_c['allow_shed']) and bool(ctrl_shed_e['allow_shed']))
alog = pd.read_csv(os.path.join(RES, 'EPS_adaptive_log.csv'))
check('C8 自适应三轮 max_score 单调增', 'EPS_adaptive_log.csv', True,
      bool((alog['max_score'].diff().dropna() > 0).all()))
check('C9 自适应切分区间全部在 interval 0', 'EPS_adaptive_log.csv', True,
      bool((alog['interval'] == 0).all()))
check('C10 全部 ε 档位 status = 2 (OPTIMAL)', 'EPS_rp_lev_*.csv', True,
      all(int(r['status']) == 2 for r in levs))
# mipgap 上限 = 求解器设定 GRB_MIPGAP=1e-4（config_v3.py）；r0_2 实测 8.9e-5 < 1e-4。
check('C11 全部 ε 档位 mip_gap ≤ 1e-4（= GRB_MIPGAP 设定）', 'EPS_rp_lev_*.csv', True,
      all(float(r['mip_gap']) <= 1e-4 for r in levs))
# 前沿单调性：碳上限越低、成本越高。10 档 = 8 个 lev + 2 个端点。
pts = ([(float(r['exp_carbon']), float(r['exp_cost'])) for r in levs]
       + [(float(end_cost['exp_carbon']), float(end_cost['exp_cost'])),
          (float(end_carbon['exp_carbon']), float(end_carbon['exp_cost']))])
pts_sorted = sorted(pts, key=lambda p: -p[0])
costs = [p[1] for p in pts_sorted]
check('C12 前沿单调性：10 档碳上限降→成本升（严格单调）', 'EPS_rp_lev_* + endpoints', True,
      all(b > a for a, b in zip(costs, costs[1:])),
      detail='碳上限从 %.3f 降到 %.3f，成本 %d → %d 元' % (pts_sorted[0][0], pts_sorted[-1][0],
                                                    round(costs[0]), round(costs[-1])))
check('C13 对照1(carbon+shed) 切负荷>0 且 exp_carbon=0（退化佐证）',
      'EPS_rp_ctrl_carbon_shed.csv', True,
      float(ctrl_shed_c['in_sample_shed_MWh']) > 0 and float(ctrl_shed_c['exp_carbon']) == 0.0,
      detail=f"shed={float(ctrl_shed_c['in_sample_shed_MWh']):.2f} MWh, exp_carbon=0 << 32.911")
check('C14 对照2(eps+shed) 切负荷>0 且 exp_carbon 低于无约束碳最小（退化佐证）',
      'EPS_rp_ctrl_eps_shed.csv', True,
      float(ctrl_shed_e['in_sample_shed_MWh']) > 0
      and float(ctrl_shed_e['exp_carbon']) < c70,
      detail=f"shed={float(ctrl_shed_e['in_sample_shed_MWh']):.2f} MWh, "
             f"exp_carbon={float(ctrl_shed_e['exp_carbon']):.3f} < {c70:.3f}")

print('=== D. E28 / E29（贡献 2）===')
for ps in (50, 60, 70):
    r = pd.read_csv(os.path.join(RES, f'PWL_E28_ps{ps}.csv')).set_index('item')['value']
    # 不越限是改写后主张的核心 → 硬断言，逐位 0。
    check(f'D1-{ps} linear_viol_h_p1/p2_expected 均 = 0（不越限，硬断言）',
          f'PWL_E28_ps{ps}.csv', True,
          float(r['linear_viol_h_p1_expected']) == 0.0
          and float(r['linear_viol_h_p2_expected']) == 0.0)
# 管存闭合误差 = (ps-20)/2。闭合恒等式的理论值 15/20/25。p2 列逐档满足到
# 1e-3；p1 列含 ~0.005 bar 的系统性偏差（三档一致，见 notes 诊断），因此论文
# 正文写的是"等于 (ps-p_min)/2 到 0.005 bar 以内"。D2 断言严格恒等式，D3 断言
# 论文实际写下的容差并把偏差打进 detail——不放宽到 1e-2 去凑全绿，也不断言
# 一个论文没写过的严格值。
for ps in (50, 60, 70):
    r = pd.read_csv(os.path.join(RES, f'PWL_E28_ps{ps}.csv')).set_index('item')['value']
    exp_cl = (ps - 20) / 2.0
    check(f'D2-{ps} 闭合误差 p2 均值 = (ps-20)/2 = {exp_cl}', f'PWL_E28_ps{ps}.csv',
          exp_cl, float(r['linear_closure_err_p2_bar_mean']), 1e-3)
    p1_dev = abs(float(r['linear_closure_err_p1_bar_mean']) - exp_cl)
    check(f'D3-{ps} 闭合误差 p1 均值 = (ps-20)/2 = {exp_cl}', f'PWL_E28_ps{ps}.csv',
          True, p1_dev <= 0.005, None,
          detail=f'p1 列系统性偏差 {p1_dev:.6f} bar，论文表述为"到 0.005 bar 以内"')
# 成本劣化 = 线性方案相对 Weymouth 的期望成本差（线性 − Weymouth）。
for ps, exp_deg in [(50, 348.39), (60, 398.89), (70, 392.88)]:
    r = pd.read_csv(os.path.join(RES, f'PWL_E28_ps{ps}.csv')).set_index('item')['value']
    deg = float(r['linear_rp_exp_cost']) - float(r['wey_rp_exp_cost_summary'])
    # 论文引用 2 位小数 → 半位 0.005；这里按任务卡给 0.1（求解重复可复现量级）。
    check(f'D4-{ps} 成本劣化 = +{exp_deg} 元/日', f'PWL_E28_ps{ps}.csv',
          exp_deg, deg, 0.1,
          detail=f"自校验 wey_cost_crosscheck_reldiff={float(r['wey_cost_crosscheck_reldiff']):.1e}")
# 求解时间差 2 个数量级：ratio = wey/linear > 100（log10 > 2）。
for ps in (50, 60, 70):
    r = pd.read_csv(os.path.join(RES, f'PWL_E28_ps{ps}.csv')).set_index('item')['value']
    ratio = float(r['wey_rp_solve_time_s']) / float(r['linear_rp_solve_time_s'])
    check(f'D5-{ps} Weymouth/线性求解时间比 > 100（2 个数量级）', f'PWL_E28_ps{ps}.csv',
          True, ratio > 100.0, detail=f'实测 {ratio:.0f} 倍'
          f"（线性 {float(r['linear_rp_solve_time_s']):.3f}s vs Weymouth {float(r['wey_rp_solve_time_s']):.1f}s）")
# E29：24 组（3 ps × 4 区间数 {20,40,60,120}）余弦 vs 均匀逐一比较。
e29 = pd.read_csv(os.path.join(RES, 'PWL_E29_accuracy.csv'))
n_cmp = 0
all_cosine_better = True
for ps in (50, 60, 70):
    sub = e29[e29['ps'] == ps]
    for n_int in (20, 40, 60, 120):
        u = float(sub[sub['scheme'] == f'uniform-{n_int}int']['max_rel_err_pct'].iloc[0])
        cv = float(sub[sub['scheme'] == f'cosine-{n_int}int']['max_rel_err_pct'].iloc[0])
        n_cmp += 1
        all_cosine_better &= (cv < u)
        results.append(dict(claim=f'D6 ps={ps} n_int={n_int} 余弦({cv:.4f}%) < 均匀({u:.4f}%)',
                            source='PWL_E29_accuracy.csv', expect=f'< {round(u, 4)}',
                            actual=round(cv, 4), status=PASS if cv < u else FAIL, detail=''))
check(f'D6 E29 全部 12 组（3 ps × 4 区间数）余弦误差 < 同档均匀误差', 'PWL_E29_accuracy.csv',
      True, all_cosine_better, detail=f'{n_cmp} 组逐一比较，逐组明细见 audit_v3_check.csv')
u60 = float(e29[(e29['ps'] == 70) & (e29['scheme'] == 'uniform-60int')]['max_rel_err_pct'].iloc[0])
c60v = float(e29[(e29['ps'] == 70) & (e29['scheme'] == 'cosine-60int')]['max_rel_err_pct'].iloc[0])
check('D7 ps=70 / 60 区间 余弦 max_rel_err_pct ≈ 0.816%', 'PWL_E29_accuracy.csv', 0.816, c60v, 0.01)
check('D8 ps=70 / 60 区间 均匀 max_rel_err_pct ≈ 4.031%', 'PWL_E29_accuracy.csv', 4.031, u60, 0.01)

print('=== E. 随机承诺价值（贡献 5）===')
for tag, vss_q, evpi_q in [('B0', 124.99, 502.12), ('PS70', 88.49, 596.25)]:
    s = pd.read_csv(os.path.join(RES, f'IN_{tag}_in_sample_summary.csv')).set_index('metric')['value']
    vss, evpi = float(s['vss_train']), float(s['evpi_train'])
    check(f'E1-{tag} ineq_0_le_vss_le_evpi = True', f'IN_{tag}_in_sample_summary.csv',
          True, str(s['ineq_0_le_vss_le_evpi']).strip() == 'True')
    # 恒等式 VSS = EEV_train − RP_train（同一 CSV 内字段相减，容差 1e-6 仅为浮点余量）。
    check(f'E2-{tag} VSS 恒等式 EEV−RP 逐位成立（1e-6）', f'IN_{tag}_in_sample_summary.csv',
          True, abs(vss - (float(s['eev_train']) - float(s['rp_train_eval']))) <= 1e-6,
          detail=f'vss_train={vss!r}')
    # 论文引用 2 位小数 → 半位容差 0.005。
    check(f'E3-{tag} vss_train = {vss_q}（论文 2 位小数）', f'IN_{tag}_in_sample_summary.csv',
          vss_q, vss, 0.005)
    check(f'E4-{tag} EVPI 恒等式 RP−WS 逐位成立（1e-6）', f'IN_{tag}_in_sample_summary.csv',
          True, abs(evpi - (float(s['rp_train_eval']) - float(s['ws_train_prob']))) <= 1e-6,
          detail=f'evpi_train={evpi!r}')
    check(f'E5-{tag} evpi_train = {evpi_q}（论文 2 位小数）', f'IN_{tag}_in_sample_summary.csv',
          evpi_q, evpi, 0.005)
feas = pd.read_csv(os.path.join(RES, 'IN_PS70_feasibility.csv'))
check('E6 三承诺 × 8 场景 = 24 行全部 feasible = True', 'IN_PS70_feasibility.csv', True,
      len(feas) == 24 and bool(feas['feasible'].all()),
      detail=f'{len(feas)} 行，不可行 {int((~feas["feasible"]).sum())} 行')
boot_b0 = pd.read_csv(os.path.join(RES, 'BOOT_B0_v3.csv')).set_index('statistic')
boot_p70 = pd.read_csv(os.path.join(RES, 'BOOT_PS70_v3.csv')).set_index('statistic')
# 任务卡引用 383.41 / 348.14（2 位小数）→ 半位 0.005；另做同源交叉核对（1e-6）。
check('E7 BOOT_B0 POINT_vss_cny = 383.41', 'BOOT_B0_v3.csv', 383.41,
      float(boot_b0.loc['POINT_vss_cny', 'point']), 0.005,
      detail=f"全精度 {float(boot_b0.loc['POINT_vss_cny', 'point'])!r}")
check('E8 BOOT_PS70 POINT_vss_cny = 348.14', 'BOOT_PS70_v3.csv', 348.14,
      float(boot_p70.loc['POINT_vss_cny', 'point']), 0.005,
      detail=f"全精度 {float(boot_p70.loc['POINT_vss_cny', 'point'])!r}")
# 交叉核对：bootstrap POINT 应与主结果逐位同源（1e-6 = CSV 6 位小数余量）。
cap_tab = pd.read_csv(os.path.join(RES, 'V3_all_cap_summary_table.csv'))
vss_inf = float(cap_tab[(cap_tab['cap'].isna()) & (cap_tab['arm'] == 'main')]['vss'].iloc[0])
check('E9 BOOT_B0 POINT_vss_cny 与 V3_all_cap_summary_table(inf,main) 同源（1e-6）',
      'BOOT_B0_v3.csv vs V3_all_cap_summary_table.csv', vss_inf,
      float(boot_b0.loc['POINT_vss_cny', 'point']), 1e-6)
p70sum = load_long_summary('V3_GC_PS70_main_summary.csv')
check('E10 BOOT_PS70 POINT_vss_cny 与 PS70 主结果 vss_eev_minus_sp 同源（1e-6）',
      'BOOT_PS70_v3.csv vs V3_GC_PS70_main_summary.csv', _f(p70sum, 'vss_eev_minus_sp'),
      float(boot_p70.loc['POINT_vss_cny', 'point']), 1e-6)
check('E11 VSS bootstrap CI 下界 > 0（B0 与 PS70，断言显著为正）', 'BOOT_*_v3.csv', True,
      float(boot_b0.loc['vss_cny', 'ci_lo']) > 0 and float(boot_p70.loc['vss_cny', 'ci_lo']) > 0,
      detail=f"B0 ci_lo={float(boot_b0.loc['vss_cny', 'ci_lo']):.2f}，"
             f"PS70 ci_lo={float(boot_p70.loc['vss_cny', 'ci_lo']):.2f}")
# 列名纪律：bootmean_* 行存在，且必须带"非样本外期望"标注。正文禁引该行作为
# 样本外期望成本——它是对逐日差分重抽样分布的均值，量纲虽是"元"但语义不同。
bm_ok = True
bm_note = []
for name, b in [('BOOT_B0_v3.csv', boot_b0), ('BOOT_PS70_v3.csv', boot_p70)]:
    bm = [i for i in b.index if str(i).startswith('bootmean_')]
    bm_ok &= len(bm) == 2 and all('非样本外期望' in i for i in bm)
    bm_note.append(f'{name}: {bm}')
check('E12 列名纪律：BOOT_* 存在 bootmean_* 行且行名含"非样本外期望"标注', 'BOOT_*_v3.csv',
      True, bm_ok, detail='；'.join(bm_note)
      + '。>>> 正文纪律：bootmean_* 是重抽样分布均值、不是样本外期望成本、正文禁引 <<<')
sig = pd.read_csv(os.path.join(RES, 'BOOT_significance_v3.csv'))
check('E13 Wilcoxon p < 1e-5（B0 与 PS70）', 'BOOT_significance_v3.csv', True,
      bool((sig['wilcoxon_p'] < 1e-5).all()),
      detail='；'.join(f"{r['cfg']}: p={r['wilcoxon_p']:.2e}" for _, r in sig.iterrows()))

print('=== F. 电网受入容量与边界 ===')
cap_sp = cap_tab[cap_tab['mode'] == 'sp'].copy()
caps_sorted = sorted(cap_sp['cap'].dropna().unique(), reverse=True)  # 大→小
first_pos = None
for cp in caps_sorted:
    if float(cap_sp[np.isclose(cap_sp['cap'], cp)]['eens_e'].iloc[0]) > 0:
        first_pos = cp
        break
check('F1 EENS 首正档位（自大向小扫描）= 3.5 MW', 'V3_all_cap_summary_table.csv', 3.5, first_pos, 1e-9,
      detail='inf/6.25/5.0 档 eens_e=0，3.5 档首正')
r35 = cap_sp[np.isclose(cap_sp['cap'], 3.5)].iloc[0]
check('F2 3.5 档 VSS ≈ 3202.3 元', 'V3_all_cap_summary_table.csv', 3202.3,
      float(r35['vss']), 0.05)
check('F3 3.5 档 EENS ≈ 0.0289 MWh/日', 'V3_all_cap_summary_table.csv', 0.0289,
      float(r35['eens_e']), 0.0005)
e30 = float(cap_sp[np.isclose(cap_sp['cap'], 3.0)]['eens_e'].iloc[0])
e35 = float(r35['eens_e'])
# 非单调性断言：3.5 档 EENS > 3.0 档 → "约束越紧价值越大"式表述不成立。
check('F4 非单调断言：EENS(3.5) > EENS(3.0)（3.5 > 3.0，非单调）', 'V3_all_cap_summary_table.csv',
      True, e35 > e30, detail=f'EENS(3.5)={e35:.6f} > EENS(3.0)={e30:.6f}'
      '。>>> 正文纪律：不得声称"电网约束越紧、随机规划价值/EENS 越大"，'
      '3.0 档两项均低于 3.5 档（非单调）<<<')

print('=== G. 数据层口径 ===')
man_path = os.path.join(HERE, 'data_manifest.md')
check('G1 code_v3/data_manifest.md 存在', 'data_manifest.md', True, os.path.isfile(man_path))
if os.path.isfile(man_path):
    man = open(man_path, encoding='utf-8').read()
    # 总览表 9 个数据源，每个必须标注 实测/重建/合成 三者之一（加粗标注列）。
    n_src_rows = len(re.findall(r'^\|\s*\d+\s*\|', man, re.M))
    has_cls = all(k in man for k in ['实测', '重建', '合成'])
    check('G2 manifest 对每个数据源标注 实测/重建/合成（总览表 9 行且三类标注齐备）',
          'data_manifest.md', True, n_src_rows >= 9 and has_cls,
          detail=f'总览表 {n_src_rows} 行；标注关键词齐备={has_cls}')
else:
    check('G2 manifest 对每个数据源标注 实测/重建/合成', 'data_manifest.md', True, False)
pdf_path = os.path.join(RES, 'mee_2019_grid_baseline_ef.pdf')
pdf_ok = os.path.isfile(pdf_path) and os.path.getsize(pdf_path) > 0
if pdf_ok:
    with open(pdf_path, 'rb') as fh:
        pdf_ok = fh.read(5) == b'%PDF-'
check('G3 官方排放因子原文存档 mee_2019_grid_baseline_ef.pdf 存在且为有效 PDF',
      'code_v3/results/', True, pdf_ok)
cfg_src = open(os.path.join(HERE, 'config_v3.py'), encoding='utf-8').read()
check('G4 config_v3.py E_GRID_MODE 默认 = official_om_nw', 'config_v3.py', True,
      bool(re.search(r"E_GRID_MODE\s*=\s*os\.environ\.get\(\s*'E_GRID_MODE'\s*,\s*'official_om_nw'\s*\)",
                     cfg_src)))
check('G5 config_v3.py 西北 OM = 0.8922', 'config_v3.py', True,
      bool(re.search(r"'northwest':\s*dict\(om=0\.8922", cfg_src)),
      detail="REGIONAL_GRID_EF_2019['northwest']['om'] = 0.8922 tCO2/MWh")

print('=== H. 旧口径隔离 ===')
OLD_NUMS = ['6.73%', '22.502', '26.452', '25.423', '24.672', '516.32', '951.68', '293.12']
# 放行规则（逐命中判定，逐条记录）：
#   (a) 文件名含 _old / old_vs_new / comparison → 旧口径对照专档；
#   (b) CSV 行内有精确单元格 'old' / 'old_0.55' → 旧口径对照行（精确匹配，
#       避免误放行 'efold' 臂）；
#   (c) md/tex 命中行含 '旧' / 'v2' / 'old' → 明确标注旧口径对照；
#   (d) quanzhou_temp_*.csv → 气温观测值，非语义命中；
#   其余 → 报警（FAIL）。


def _row_allowed(cells, fname):
    base = os.path.basename(fname).lower()
    if '_old' in base or 'old_vs_new' in base or 'comparison' in base:
        return '对照专档(文件名)'
    if any(c.strip() in ('old', 'old_0.55') for c in cells):
        return '对照行(行内 old 标注)'
    return None


def _text_line_allowed(line):
    if ('旧' in line) or ('v2' in line.lower()) or ('old' in line.lower()):
        return '标注旧口径对照'
    return None


def _cell_hits(cell, n):
    """数字单元格按数值相等判定，非数字单元格才做子串匹配。

    实测数据缓存里 1526.452 这类第三方计量值会子串命中旧口径数字 '26.452'，
    但那不是泄漏；旧口径数字全是模型输出，数值相等才算命中。
    """
    s = (cell or '').strip()
    if not s:
        return False
    try:
        return abs(float(s) - float(n)) < 5e-4
    except ValueError:
        return n in s


hits, alarms = [], []
for f in sorted(glob.glob(os.path.join(RES, '*.csv'))) + \
         sorted(glob.glob(os.path.join(RES, '*.md'))) + \
         sorted(glob.glob(os.path.join(SUB_V2, '*.tex'))):
    base = os.path.basename(f)
    if base == 'audit_v3_check.csv':
        continue
    if base.endswith('.csv'):
        with open(f, encoding='utf-8-sig', errors='ignore', newline='') as fh:
            for row in csv.reader(fh):
                for cell in row:
                    for n in OLD_NUMS:
                        if _cell_hits(cell, n):
                            why = ('气温观测值，非语义命中' if base.startswith('quanzhou_temp')
                                   else _row_allowed(row, f))
                            (hits if why else alarms).append(
                                f'{base}: {n}（{why or "无旧口径标注"}）')
    else:
        for i, line in enumerate(open(f, encoding='utf-8', errors='ignore'), 1):
            for n in OLD_NUMS:
                if n in line:
                    why = _text_line_allowed(line)
                    (hits if why else alarms).append(f'{base}:{i}: {n}（{why or "无标注"}）')
check('H1 旧口径数字未流入 v3 结果主口径（命中均为对照语境或非语义命中）',
      'code_v3/results/*', True, len(alarms) == 0,
      detail=(f'{len(hits)} 处命中全部放行；' + '；'.join(hits[:12])
              + ('…' if len(hits) > 12 else '')) if hits else '无命中',
      )
check('H2 旧口径数字未流入 submission/论文源_v2/*.tex', 'submission/论文源_v2/*.tex', True,
      not any(a.startswith(('sec_ii_related.tex', 'sec_ii_notes.md')) for a in alarms),
      detail='v2 tex 中 0 处命中' if not any(
          a.split(':')[0].endswith('.tex') for a in alarms)
      else '；'.join(a for a in alarms if a.split(':')[0].endswith('.tex')))
if alarms:
    print('  [!!] 旧口径隔离报警明细：')
    for a in alarms:
        print('       -', a)

print('=== I. 电网排放因子敏感性（efold 臂，E_grid=0.55）===')
# 论文 sec_v_results.tex 新增段落引用：0.55 对比档的四条碳地板与派生百分比。
# 期望值取运行产物全精度，容差与 A 段同源（转抄 1e-6；百分比按论文位数取半位）。
efold = scan[(scan['arm'] == 'efold')].set_index('cfg')
EF_CFGS = ['B0', 'PS50', 'PS60', 'PS70']
for i, (cfg, exp) in enumerate([('B0', 24.263239312090487),
                                ('PS50', 27.1687323799198),
                                ('PS60', 26.43985576508102),
                                ('PS70', 25.90605634962081)], start=1):
    check(f'I{i} carbon_min_exp_rp[{cfg}|efold]', 'V3_GC_scan_carbon.csv', exp,
          float(efold.loc[cfg, 'carbon_min_exp_rp']), 1e-6,
          detail=f'论文引用 {round(exp, 3)}')
check('I5 efold 四档 carbon_min_rp_status 均 = 2 (OPTIMAL)',
      'V3_GC_scan_carbon.csv', True,
      all(int(efold.loc[c, 'carbon_min_rp_status']) == 2 for c in EF_CFGS))
e_b0 = float(efold.loc['B0', 'carbon_min_exp_rp'])
e_50 = float(efold.loc['PS50', 'carbon_min_exp_rp'])
e_60 = float(efold.loc['PS60', 'carbon_min_exp_rp'])
e_70 = float(efold.loc['PS70', 'carbon_min_exp_rp'])
check('I6 耦合抬升碳地板（B0→PS70）@0.55 = +6.8%', 'I 端点现算', 6.8,
      100 * (e_70 - e_b0) / e_b0, 0.05, detail='论文 1 位小数')
check('I7 耦合抬升碳地板（B0→PS50）@0.55 = +12.0%', 'I 端点现算', 12.0,
      100 * (e_50 - e_b0) / e_b0, 0.05, detail='论文 1 位小数')
check('I8 源压 50→70 碳最低降幅 @0.55 = 4.65%', 'I 端点现算', 4.65,
      100 * (e_50 - e_70) / e_50, 0.01, detail='论文 2 位小数')
check('I9 源压杠杆绝对量 @0.55 = 1.263 tCO2/d', 'I 端点现算', 1.263,
      e_50 - e_70, 0.0005, detail='论文 3 位小数')
check('I10 步长 50→60 = -0.729 tCO2/d', 'I 端点现算', 0.729, e_50 - e_60, 0.0005)
check('I11 步长 60→70 = -0.534 tCO2/d', 'I 端点现算', 0.534, e_60 - e_70, 0.0005)
# 成本侧对 E_grid 完全不变（因子只进碳目标）：逐位相等，非近似。
k = 12
for cfg in ['B0', 'PS70']:
    m = load_long_summary(f'V3_GC_{cfg}_main_summary.csv')
    e = load_long_summary(f'V3_GC_{cfg}_efold_summary.csv')
    check(f'I{k} oos_mean_cost_sp[{cfg}] main == efold（逐位）',
          f'V3_GC_{cfg}_main/efold_summary.csv', float(m['oos_mean_cost_sp']),
          float(e['oos_mean_cost_sp']), 0)
    check(f'I{k+1} vss_eev_minus_sp[{cfg}] main == efold（逐位）',
          f'V3_GC_{cfg}_main/efold_summary.csv', float(m['vss_eev_minus_sp']),
          float(e['vss_eev_minus_sp']), 0)
    k += 2

print('=== J. 块 bootstrap 稳健性（BOOT_block_v3.csv）===')
# 论文引用：相邻日历日 25/99、lag-1 自相关 +0.14、L=7 区间 [268,492] 与 [225,464]。
blk = pd.read_csv(os.path.join(RES, 'BOOT_block_v3.csv'))
diag = blk[blk['method'] == 'diagnostic'].set_index('cfg')
l7 = blk[(blk['method'] == 'block') & (blk['L'] == 7)].set_index('cfg')
for cfg in ['B0', 'PS70']:
    ac1 = float(diag.loc[cfg, 'lag1_autocorr'])
    check(f'J1 相邻日历日对[{cfg}] = 25 / 99', 'BOOT_block_v3.csv', 25,
          int(diag.loc[cfg, 'adjacent_day_pairs']), 0)
    check(f'J2 lag-1 自相关[{cfg}] ≈ +0.14', 'BOOT_block_v3.csv', 0.14,
          ac1, 0.005, detail=f'实算 {ac1:.4f}')
for cfg, (lx, hx) in {'B0': (268.0, 492.0), 'PS70': (225.0, 464.0)}.items():
    check(f'J3 L=7 区间下界[{cfg}] = {lx:.0f}', 'BOOT_block_v3.csv', lx,
          float(l7.loc[cfg, 'ci_lo']), 0.5, detail='论文取整数位')
    check(f'J4 L=7 区间上界[{cfg}] = {hx:.0f}', 'BOOT_block_v3.csv', hx,
          float(l7.loc[cfg, 'ci_hi']), 0.5, detail='论文取整数位')
    check(f'J5 L=7 区间下界[{cfg}] > 0（显著性在依赖结构下存活）',
          'BOOT_block_v3.csv', True, bool(float(l7.loc[cfg, 'ci_lo']) > 0))

print('=== K. 实测热负荷稳健性臂（heatreal，V3_GC_*_heatreal_*）===')
hr = {r['cfg']: float(r['carbon_min_exp_rp']) for r in csv.DictReader(
    open(os.path.join(RES, 'V3_GC_scan_carbon.csv'), encoding='utf-8-sig'))
    if r.get('arm') == 'heatreal'}
for i, (cfg, exp) in enumerate([('B0', 29.401), ('PS50', 33.622),
                                ('PS60', 32.397), ('PS70', 31.392)], start=1):
    check(f'K{i} heatreal carbon_min_exp_rp[{cfg}] = {exp}',
          'V3_GC_scan_carbon.csv', exp, hr.get(cfg), 0.0005)
check('K5 heatreal 源压杠杆 50->70 = 6.63%', 'V3_GC_scan_carbon.csv', 6.63,
      (hr['PS50'] - hr['PS70']) / hr['PS50'] * 100, 0.005)
check('K6 heatreal 耦合抬升 @70 = +6.8%', 'V3_GC_scan_carbon.csv', 6.8,
      (hr['PS70'] - hr['B0']) / hr['B0'] * 100, 0.05)
check('K7 heatreal 耦合抬升 @50 = +14.4%', 'V3_GC_scan_carbon.csv', 14.4,
      (hr['PS50'] - hr['B0']) / hr['B0'] * 100, 0.05)
check('K8 定性结构存活：碳地板随 p_s 单调下降',
      'V3_GC_scan_carbon.csv', True,
      hr['PS50'] > hr['PS60'] > hr['PS70'])
check('K9 定性结构存活：耦合仍抬高碳地板（heatreal）',
      'V3_GC_scan_carbon.csv', True, hr['PS70'] > hr['B0'])

# 实测热数据完整性：这一年真的能当负荷用
heat = pd.read_csv(os.path.join(RES, 'heat_dma_2019_hourly.csv'),
                   encoding='utf-8-sig')
hcol = heat['dma_b'].to_numpy(float)
hpu = hcol / hcol.max()
hd = hpu.reshape(-1, 24)
check('K10 实测热数据为 2019 全年 8760 小时', 'heat_dma_2019_hourly.csv',
      8760, len(hcol), 0)
check('K11 实测热数据无缺测（逐时步长 1 h）', 'heat_dma_2019_hourly.csv',
      0, int((pd.Series(pd.to_datetime(heat['ts'])).diff()
              .dropna() != pd.Timedelta('1h')).sum()), 0)
check('K12 峰值归一后最大值为 1', 'heat_dma_2019_hourly.csv', 1.0,
      float(hpu.max()), 1e-12)
check('K13 同峰下实测日均热量 37.1 MWh_th（合成 57.2）',
      'heat_dma_2019_hourly.csv', 37.1, float(hd.sum(axis=1).mean() * 4.0), 0.05)

oos = pd.read_csv(os.path.join(RES, 'V3_GC_PS70_heatreal_oos.csv'),
                  encoding='utf-8-sig')
check('K14 heatreal 确定性承诺样本外不可行天数 = 9/100',
      'V3_GC_PS70_heatreal_oos.csv', 9, int(oos['fail_eev'].sum()), 0)
check('K15 heatreal 随机承诺样本外不可行天数 = 0/100',
      'V3_GC_PS70_heatreal_oos.csv', 0, int(oos['fail_sp'].sum()), 0)
main_oos = pd.read_csv(os.path.join(RES, 'V3_GC_PS70_main_oos.csv'),
                       encoding='utf-8-sig')
check('K16 main（合成热）确定性承诺不可行天数 = 0（对照）',
      'V3_GC_PS70_main_oos.csv', 0, int(main_oos['cost_eev'].isna().sum()), 0)
bad_days = oos.loc[oos['fail_eev'], 'test_day'].tolist()
day_idx = {d: k for k, d in enumerate(
    pd.date_range('2019-01-01', periods=365, freq='D').strftime('%Y-%m-%d'))}
bad_heat = np.array([hd[day_idx[d]].sum() * 4.0 for d in bad_days])
med_heat = float(np.median(hd.sum(axis=1) * 4.0))
check('K17 不可行日全为低热日（最高 11.1 < 全年中位 34.3 MWh_th）',
      'heat_dma_2019_hourly.csv', True, bool(bad_heat.max() < med_heat),
      detail=f'不可行日热量 {bad_heat.min():.1f}-{bad_heat.max():.1f}, 中位 {med_heat:.1f}')
check('K18 不可行日数与论文所引 9 个夏季日一致',
      'V3_GC_PS70_heatreal_oos.csv', 9,
      sum(1 for d in bad_days if d.startswith(('2019-07', '2019-08'))), 0)

print('=== N. 网状气网复现（Task 3：meshed / multi-path gas network）===')
# 这一节把"两节点不具普适性"从"未验证的担心"变成"已复核的边界"。
# 纪律：① 只判方向与次序，**不**断言任何百分比等于某值；② 断言的是"通用网状模型
# 退化回两节点必须复现主链存档"，这是新模型的正确性门槛，不过则整个网状结论作废；
# ③ 允许失败——N4（量级差 >10 倍）与 N6（边际递减）是可以真的不成立的判据，
#    不成立就如实写"部分成立"。
import json

MESHP = {'reg': 'V3_MESH_regression.csv', 'cells': 'V3_MESH_cells.csv',
         'topo': 'V3_MESH_topology.csv', 'net': 'mesh_source/GasLib-11/GasLib-11.net',
         'zip': 'mesh_source/GasLib-11.zip', 'verdict': 'V3_MESH_verdict.csv'}
have = {k: os.path.exists(os.path.join(RES, v)) for k, v in MESHP.items()}
# verdict.csv 必须在存在性清单里：它一旦丢失，下面的 `if have['verdict']` 会静默跳过
# N10 + N12a–N12e 共 6 条"C1 锁死"断言，而 FAIL 仍为 0（复核方要求的并入前置）。
for k in ('reg', 'cells', 'topo', 'net', 'zip', 'verdict'):
    check(f'N0 网状产物存在：{MESHP[k]}', 'results/' + MESHP[k], True, have[k],
          detail='缺失即本任务未跑通，后续断言不作数')

if have['net'] and have['zip'] and have['topo']:
    import hashlib

    def _sha(p):
        return hashlib.sha256(open(os.path.join(RES, p), 'rb').read()).hexdigest()

    topo = pd.read_csv(os.path.join(RES, MESHP['topo']), encoding='utf-8-sig')
    tmap = dict(zip(topo['item'], topo['value']))
    for key, fp in [('sha256[mesh_source/GasLib-11.zip]', MESHP['zip']),
                    ('sha256[mesh_source/GasLib-11/GasLib-11.net]', MESHP['net'])]:
        check(f'N1 GasLib-11 原始文件哈希与清单一致 {key.split("[")[-1][:-1]}',
              key, tmap.get(key, 'MISSING'), _sha(fp))
    check('N2 拓扑为网状：原始图含环', 'V3_MESH_topology.csv', 'True',
          str(tmap.get('raw_graph_has_cycle')))
    check('N2b 拓扑为网状：所用核心含环', 'V3_MESH_topology.csv', 'True',
          str(tmap.get('core_has_cycle')))
    check('N2c 核心气网节点数 >= 3', 'V3_MESH_topology.csv', True,
          int(float(tmap.get('core_n_nodes', 0))) >= 3,
          detail=f"core_n_nodes={tmap.get('core_n_nodes')}")
    check('N2d 核心管段数 >= 3', 'V3_MESH_topology.csv', True,
          int(float(tmap.get('core_n_edges', 0))) >= 3,
          detail=f"core_n_edges={tmap.get('core_n_edges')}")
    alt = json.loads(str(tmap.get('alternate_paths_core', '{}')).replace("'", '"'))
    # ---- I2：支撑"不是加长链"的真正指标 = 从**进环节点**出发的边不相交供路数 ----
    # 旧 N2e 读的是 alternate_paths_core，其定义是"能到达该负荷的**源个数**"，且算在
    # **双源**完整核心上 —— 与主判据拓扑（单源核心）和"独立供路"的措辞双重错位。
    # 现在改为断言落盘指标 core1s_edge_disjoint_routes_from_injection（定义见
    # data_mesh_v3.edge_disjoint_routes：单位容量最大流给出的边不相交路径条数，源=N01，
    # 即气体进入环之后的那个节点；"任一条管段退出运行，另一条供路仍成立"）。
    routes_inj = json.loads(str(tmap.get('core1s_edge_disjoint_routes_from_injection',
                                        '{}')).replace("'", '"'))
    check('N2e 单源核心：从进环节点 N01 到每个取气点的**边不相交供路数** >= 2'
          '（"不是加长链"的取证指标）',
          'V3_MESH_topology.csv', True,
          bool(routes_inj) and all(int(v) >= 2 for v in routes_inj.values()),
          detail=f'core1s_edge_disjoint_routes_from_injection={routes_inj}；定义=以 N01 为源、'
                 f'单位容量最大流给出的边不相交路径条数。注意**不是**"去任一源仍可达"'
                 f'——单源核心只有 1 个门站，删掉它谁都不可达')
    routes_gate = json.loads(str(tmap.get('core1s_edge_disjoint_routes', '{}'))
                             .replace("'", '"'))
    check('N2e2 单源核心：从**门站 entry01** 出发的边不相交供路数 == 1'
          '（进气口子数与两节点链相同，R4 对齐的图论表述）',
          'V3_MESH_topology.csv', True,
          bool(routes_gate) and all(int(v) == 1 for v in routes_gate.values()),
          detail=f'core1s_edge_disjoint_routes={routes_gate}；entry01 只有 pipe01 一条进环'
                 f'引线 ⇒ 总可交付量 = 单条 F_gate(p_s) = 链侧值（另见 N4d）')
    check('N2e3 双源核心的"可达源个数"仅作登记，不作"独立供路"判据（口径已澄清）',
          'V3_MESH_topology.csv', True,
          bool(alt) and all(int(v) >= 1 for v in alt.values()),
          detail=f'alternate_paths_core={alt} 的定义是"能到达该负荷的源个数"，算在**双源**'
                 f'完整核心上，与主判据拓扑不同，故只留痕不判"网状性"')
    for it, lbl in [('license', 'N2f 数据来源许可已记录'),
                    ('required_citation', 'N2g 数据来源引用义务已记录'),
                    ('retrieved_from', 'N2h 数据获取路径已记录')]:
        check(lbl, 'V3_MESH_topology.csv', True, bool(str(tmap.get(it, 'nan')).strip())
              and str(tmap.get(it, 'nan')) != 'nan')

    # 拓扑数据完整性：直接核对从 .net 解出的原始节点/管段表，计数与 GasLib-11 官方
    # 一致、结构字段无缺失。只断言"计数相等 / 字段非空"这类可失败的事实，
    # 不断言任何百分比（百分比进正文与否由 N6/N6c/N6d 的方向与量级判据负责）。
    rn_path = os.path.join(RES, 'V3_MESH_topology_raw_nodes.csv')
    rc_path = os.path.join(RES, 'V3_MESH_topology_raw_connections.csv')
    if os.path.exists(rn_path) and os.path.exists(rc_path):
        rn = pd.read_csv(rn_path, encoding='utf-8-sig')
        rc = pd.read_csv(rc_path, encoding='utf-8-sig')
        check('N2i GasLib-11 原始节点数 == 11（3 源 + 3 荷 + 5 联络）',
              'V3_MESH_topology_raw_nodes.csv', 11, len(rn), 0)
        check('N2j GasLib-11 原始管段/连接数 == 11（8 pipe + 1 valve + 2 compressor）',
              'V3_MESH_topology_raw_connections.csv', 11, len(rc), 0)
        kmap = rc['ctype'].value_counts().to_dict()
        check('N2k 连接类型分解 pipe/valve/compressor = 8/1/2',
              'V3_MESH_topology_raw_connections.csv',
              '8/1/2', f"{kmap.get('pipe', 0)}/{kmap.get('valve', 0)}"
              f"/{kmap.get('compressorStation', 0)}")
        check('N2l 节点表无缺失（每个节点都有压力上下限与类型）',
              'V3_MESH_topology_raw_nodes.csv', 0,
              int(rn[['pressure_min_bar', 'pressure_max_bar']].isna().sum().sum()
                  + rn['node'].isna().sum() + rn['kind'].isna().sum()), 0)
        check('N2m 连接表无缺失（每条连接都有 from 与 to 端点）',
              'V3_MESH_topology_raw_connections.csv', 0,
              int(rc[['frm', 'to']].isna().sum().sum() + rc['element'].isna().sum()), 0)
        pipes = rc[rc['ctype'] == 'pipe']
        check('N2n 8 条管道的长度/直径/粗糙度字段齐全（拓扑来源完整）',
              'V3_MESH_topology_raw_connections.csv', 0,
              int(pipes[['length_km', 'diameter_mm']].isna().sum().sum()), 0)
        # 核心子图与全图关系：单源核心保留环，且节点/边数与清单登记一致
        check('N2o 单源核心仍含环（网状性未在对齐时丢失）', 'V3_MESH_topology.csv',
              'True', str(tmap.get('core1s_has_cycle')))
        check('N2p 单源核心边数 == 6、含环节点集为 N01/N02/N03/N04',
              'V3_MESH_topology.csv', '6', str(tmap.get('core1s_n_edges')))
    else:
        check('N2i 拓扑原始表存在（缺文件即无法核对完整性）',
              'V3_MESH_topology_raw_*.csv', True, False)

if have['reg']:
    # I5：回归闸门容差**引用运行器同一常量**（config_v3.MESH_REG_TOL=1e-4），不再另写一份。
    # 旧代码这里 N3b 用 1e-3，比 gc_run_mesh_v3.regress() 的闸门松 10 倍，会让"回归自检
    # 通过、审计也通过"同时掩盖 1e-4~1e-3 量级的复现偏差。
    import config_v3 as C3
    REG_TOL = C3.MESH_REG_TOL
    check('N3tol 审计与运行器共用同一回归容差常量（config_v3.MESH_REG_TOL）',
          'config_v3.py', 1e-4, REG_TOL, 0,
          detail='gc_run_mesh_v3.TOL_H 与本节 N3/N3b 都取自该常量（单一出处）')
    reg = pd.read_csv(os.path.join(RES, MESHP['reg']), encoding='utf-8-sig')
    for _, r in reg.iterrows():
        cfg = r['cfg']
        check(f'N3 通用模型退化回两节点：碳地板复现主链存档 [{cfg}]',
              'V3_MESH_regression.csv', True,
              bool(np.isfinite(r['reldiff_carbon']) and r['reldiff_carbon'] < REG_TOL),
              detail=f"|Δ|={r['absdiff_carbon']:.3e} rel={r['reldiff_carbon']:.2e} "
                     f"status={r['carbon_status_name']} "
                     f"generic={r['carbon_generic']:.9f} archived={r['carbon_archived']:.9f} "
                     f"tol={REG_TOL:.0e}")
        check(f'N3b 通用模型退化回两节点：RP 期望成本复现 [{cfg}]',
              'V3_MESH_regression.csv', True,
              bool(np.isfinite(r['reldiff_cost']) and r['reldiff_cost'] < REG_TOL),
              detail=f"rel={r['reldiff_cost']:.2e} tol={REG_TOL:.0e}")

if have['cells']:
    cl = pd.read_csv(os.path.join(RES, MESHP['cells']), encoding='utf-8-sig')
    cx = cl.set_index('cell')
    need = [c for c in ('M_B0', 'M_PS50', 'M_PS60', 'M_PS70') if c in cx.index]
    check('N4 三格（+PS60）齐全', 'V3_MESH_cells.csv', True,
          all(c in cx.index for c in ('M_B0', 'M_PS50', 'M_PS70')),
          detail=f'present={need}')
    # 求解器诚实性：状态码原样记录，超时不粉饰
    for c in need:
        st = int(cx.loc[c, 'carbon_min_status'])
        check(f'N4b[{c}] 可达碳地板求解有解（status 原样记录）', 'V3_MESH_cells.csv',
              True, st in (2, 8, 9), detail=f'carbon_min_status={st} '
              f'({cx.loc[c, "carbon_min_status_name"]}), '
              f'rp_status={int(cx.loc[c, "rp_status"])} ({cx.loc[c, "rp_status_name"]})')
    # 线性气帽格与拓扑无关（模型里没有气网），必须与两节点存档恒等
    b0_arch = float(scan[scan['arm'] == 'main'].set_index('cfg').loc['B0',
                                                                     'carbon_min_exp_rp'])
    if 'M_B0' in cx.index:
        check('N5 mesh+无气网 == 两节点+无气网（线性气帽与拓扑无关，恒等）',
              'V3_MESH_cells.csv', b0_arch, float(cx.loc['M_B0', 'carbon_min_exp_rp']), 1e-6)

    # ============ I5：R4「门站可交付量对齐」的审计锁定（此前**无任何**断言核对）============
    # (a) 解析恒等：cells.gate_deliverability_MWh_h == sqrt(K(p_s^2 - p_min^2))，其中
    #     K/p_min/p_s 全部取自同一行 —— 与模型里"PWL 表取 max"是两条独立代码路径；
    # (b) **与两节点链存档相等**：V3_GC_<cfg>_main_summary.csv 的 gas_oos_f1_max_cap 由
    #     model_gc_v3/gc_run_v3 产出，与网状臂完全无关 ⇒ 这是真正的外部对照。两条合起来
    #     才是"只换拓扑、不混入进气口子翻倍"这一 R4 前提的实测证据。
    for _c, _cfg in (('M_PS50', 'PS50'), ('M_PS60', 'PS60'), ('M_PS70', 'PS70')):
        if _c not in cx.index:
            continue
        gd = float(cx.loc[_c, 'gate_deliverability_MWh_h'])
        _K, _pmin, _ps = (float(cx.loc[_c, 'K_pipe']), float(cx.loc[_c, 'pd_min']),
                          float(cx.loc[_c, 'ps']))
        ana = float(np.sqrt(_K * (_ps ** 2 - _pmin ** 2)))
        chain_cap = float(load_long_summary(
            f'V3_GC_{_cfg}_main_summary.csv')['gas_oos_f1_max_cap'])
        check(f'N4d[{_c}] R4 解析恒等：网状门站可交付量 == sqrt(K(p_s^2-p_min^2))',
              'V3_MESH_cells.csv', ana, gd, 1e-9,
              detail=f'p_s={_ps:.0f} bar、K={_K}、p_min={_pmin:.0f} ⇒ {ana:.9f} MWh/h；'
                     f'落盘 {gd:.9f}')
        check(f'N4e[{_c}] R4 对齐：网状门站可交付量 == 两节点链存档 gas_oos_f1_max_cap'
              '（两拓扑逐时相等 ⇒ 差别只剩拓扑本身）',
              'V3_MESH_cells.csv', chain_cap, gd, 1e-9,
              detail=f'链侧 {chain_cap:.9f} vs 网状 {gd:.9f}，|Δ|={abs(chain_cap - gd):.2e}'
                     f'（双源臂会是此值的 2 倍，故弃用于主判据）')
    coupled_cells_r4 = [c for c in ('M_PS50', 'M_PS60', 'M_PS70') if c in cx.index]
    check('N4f 主判据三格都是"单源核心 + 1 个门站进气口"（对齐未被悄悄放开）',
          'V3_MESH_cells.csv', True,
          all(bool(cx.loc[c, 'single_source']) and int(cx.loc[c, 'gate_purchases']) == 1
              and str(cx.loc[c, 'net']) == 'gaslib11_core_1src'
              for c in coupled_cells_r4),
          detail=f'gate_purchases='
                 f'{[int(cx.loc[c, "gate_purchases"]) for c in coupled_cells_r4]} '
                 f'net={[str(cx.loc[c, "net"]) for c in coupled_cells_r4]}')

    # ============ I2：mesh_notes 的"网状性逐项清单"落到可机核的断言 ============
    # 把"被检验的网状物理一个没少"这句换成逐项对照：环数 / 双向可逆管数 / 供路数 /
    # 压缩机与调节阀构成，每一项都同时给出 (.net 原始算例侧) 与 (优化模型实际建出侧) 两个
    # 独立来源，二者必须一致；链侧作为对照列在同一 detail 里。
    if have['topo'] and os.path.exists(os.path.join(RES, 'V3_MESH_topology_raw_connections.csv')):
        import ast
        _tp = pd.read_csv(os.path.join(RES, MESHP['topo']), encoding='utf-8-sig')
        tmap2 = dict(zip(_tp['item'], _tp['value']))
        kept1 = ast.literal_eval(str(tmap2.get('kept_1src')))
        rc2 = pd.read_csv(os.path.join(RES, 'V3_MESH_topology_raw_connections.csv'),
                          encoding='utf-8-sig')
        ct = rc2[rc2['element'].isin(kept1)]['ctype'].value_counts().to_dict()
        n_pipe, n_valve, n_comp = (int(ct.get('pipe', 0)), int(ct.get('valve', 0)),
                                   int(ct.get('compressorStation', 0)))
        n_cyc = len(ast.literal_eval(str(tmap2.get('core1s_cycles', '[]'))))
        m = cx.loc['M_PS70'] if 'M_PS70' in cx.index else cx.loc[coupled_cells_r4[0]]
        check('N2q 网状性逐项构成：.net 的 ctype 分解 == 模型实际建出的元素构成'
              '（与链侧对照：链 0 环 / 0 双向管 / 1 阀 + 1 压缩机）',
              'V3_MESH_cells.csv vs V3_MESH_topology*.csv', True,
              int(m['n_elements']) == len(kept1) == n_pipe + n_valve + n_comp
              and int(m['n_links']) == (n_pipe - 1) + n_valve
              and int(m['n_const']) == 1 + n_comp
              and int(m['n_gas_nodes']) == int(float(tmap2.get('core1s_n_nodes'))) - 1
              and n_cyc >= 1,
              detail=f'.net 单源核心 {len(kept1)} 边 = {n_pipe} pipe + {n_valve} valve + '
                     f'{n_comp} compressor；模型建出 n_elements={int(m["n_elements"])} '
                     f'n_links(双向可逆)={int(m["n_links"])} n_const(单向:门站+压缩机)='
                     f'{int(m["n_const"])} n_gas_nodes={int(m["n_gas_nodes"])}；'
                     f'环数={n_cyc}（拓扑 CSV）；供路数={tmap2.get("core1s_edge_disjoint_routes_from_injection")}'
                     f'。链侧对照（model_mesh_v3.build_chain / V3_GC_*_main_summary 的 '
                     f'p1/p2+f1/f2）：2 节点 / 2 单向管（门站阀 equality=False + 压缩机 '
                     f'equality=True）/ 0 双向可逆管 / 0 环 / 每取气点 1 条供路')
        check('N2r 网状臂确有管存自由度增量（管容 = 链的 2.5 倍，且刻意不对齐）',
              'V3_MESH_cells.csv', True,
              all(abs(float(cx.loc[c, 'lp_cap_MWh'])
                      - 0.075 * (float(cx.loc[c, 'ps']) - float(cx.loc[c, 'pd_min']))
                      * int(cx.loc[c, 'n_gas_nodes'])) < 1e-9
                  for c in coupled_cells_r4),
              detail='lp_cap = A_NODE·(p_s−p_min)·节点数；链为 2 节点、单源网状为 5 节点 '
                     '⇒ 11.25/15.00/18.75 vs 4.50/6.00/7.50 MWh（2.5 倍，属被检验的气网物理）')
    f50 = float(cx.loc['M_PS50', 'carbon_min_exp_rp']) if 'M_PS50' in cx.index else np.nan
    f60 = float(cx.loc['M_PS60', 'carbon_min_exp_rp']) if 'M_PS60' in cx.index else np.nan
    f70 = float(cx.loc['M_PS70', 'carbon_min_exp_rp']) if 'M_PS70' in cx.index else np.nan
    c50 = float(cx.loc['M_PS50', 'rp_exp_cost']) if 'M_PS50' in cx.index else np.nan
    c70 = float(cx.loc['M_PS70', 'rp_exp_cost']) if 'M_PS70' in cx.index else np.nan
    # 碳地板的**下界**（认证用）：网状臂在冻结 600s/8 场景下未收敛到 1e-4，incumbent 只是
    # 上界；判方向一律用下界 bound（保守），绝不用未收敛的 incumbent 冒充"碳地板值"。
    bd50 = float(cx.loc['M_PS50', 'carbon_min_obj_bound']) if 'M_PS50' in cx.index else np.nan
    bd60 = float(cx.loc['M_PS60', 'carbon_min_obj_bound']) if 'M_PS60' in cx.index else np.nan
    bd70 = float(cx.loc['M_PS70', 'carbon_min_obj_bound']) if 'M_PS70' in cx.index else np.nan
    cb0 = float(scan[scan['arm'] == 'main'].set_index('cfg').loc['B0', 'rp_exp_carbon'])
    cb0_cost = float(load_long_summary('V3_GC_B0_main_summary.csv')['rp_exp_cost'])

    # ---- 统一声明口径核对：三格（+PS60）必须同协议、同方向线性化，才允许比较单调性 ----
    coupled_cells = [c for c in ('M_PS50', 'M_PS60', 'M_PS70') if c in cx.index]
    protos = sorted({str(cx.loc[c, 'protocol']) for c in coupled_cells}
                    ) if 'protocol' in cx.columns else ['<无 protocol 列>']
    dirs = sorted({str(cx.loc[c, 'dir_mode']) for c in coupled_cells})
    same_protocol = (len(protos) == 1 and protos[0] == 'mipstart'
                     and len(dirs) == 1 and dirs[0] == 'soc')
    check('N6pre 三格统一声明口径（同一 protocol=mipstart + dir_mode=soc，非各格各口径）',
          'V3_MESH_cells.csv', True, same_protocol,
          detail=f'protocol={protos} dir_mode={dirs}；混口径则下面所有单调性判定不作数')

    # 结论一：去掉气网物理低估可达碳地板（方向用 bound 保守认证）
    check('N6 结论一(方向·bound认证)：网状碳地板下界 > 线性气帽地板 @50',
          'V3_MESH_cells.csv', True, bool(np.isfinite(bd50) and bd50 > b0_arch),
          detail=f'bound(PS50)={bd50:.3f} > linecap {b0_arch:.3f}（incumbent {f50:.3f}, gap 未收敛）')
    check('N6b 结论一(方向·bound认证)：@70 同样成立（下界越线，与 incumbent 是否收敛无关）',
          'V3_MESH_cells.csv', True, bool(np.isfinite(bd70) and bd70 > b0_arch),
          detail=f'bound(PS70)={bd70:.3f} > linecap {b0_arch:.3f}（统一 MIP-start 口径下 '
                 f'M_PS70 已求得有限 incumbent {f70:.3f}/bound，R-B：旧"无可行解"措辞已废止）')
    # 碳/成本失真不对称：碳侧取下界（保守低估失真），成本侧取 incumbent（偏乐观），
    # 若"碳下界失真 > 成本 incumbent 失真"仍成立，则不对称方向是稳的。
    cd50 = 100 * (bd50 - b0_arch) / b0_arch if np.isfinite(bd50) else np.nan
    cc50 = 100 * (c50 - cb0_cost) / cb0_cost if np.isfinite(c50) else np.nan
    cd70 = 100 * (bd70 - b0_arch) / b0_arch if np.isfinite(bd70) else np.nan
    cc70 = 100 * (c70 - cb0_cost) / cb0_cost if np.isfinite(c70) else np.nan
    check('N6c 结论一(不对称·方向)：网状上碳侧相对失真 > 成本侧相对失真',
          'V3_MESH_cells.csv', True,
          bool(np.isfinite(cd50) and np.isfinite(cc50) and cd50 > cc50),
          detail=f'carbon(下界) {cd50:.2f}% > cost(incumbent) {cc50:.2f}%')
    # R-A/R-B 口径下的"量级"判据改为与实测相称的真判定：网状臂只支撑到 ~5×，
    # 因此认证的是"未达一个数量级（<10×）"这一降级结论；若未来收敛到 ≥10× 该条会翻红，
    # 提示可把"大一个数量级"重新纳入网状表述（双向可失败）。
    ratio50 = cd50 / max(cc50, 1e-12) if (np.isfinite(cd50) and np.isfinite(cc50)) else np.nan
    # 措辞纪律（mesh_notes.md:313）：5.4× 是**下界**，界不夹住真值，故本条只能证
    # "认证不到 ≥10×"，不能证"数量级说法已证伪"。标题不得写"不成立"。
    check('N6d 结论一(量级·认证降级)：碳/成本失真比 < 10×，故"大一个数量级"在网状未达认证',
          'V3_MESH_cells.csv', True, bool(np.isfinite(ratio50) and ratio50 < 10),
          detail=f'保守比 ≈ {ratio50:.1f}×（< 10×，且该比是**下界**）——"一到两个数量级"仅可'
                 f'限定于两节点算例，不得外推到网状；下界性质只支持"未达认证"，不支持"已证伪"')
    # ---- 结论二：源压杠杆。只判可比较的量：认证式 U(70) < L(50)（即 incumbent70 < bound50）。
    have3f = all(np.isfinite(v) for v in (f50, f60, f70))
    have3b = all(np.isfinite(v) for v in (bd50, bd60, bd70))
    bound_dir = bool(have3b and bd50 >= bd60 >= bd70)          # 下界随 p_s 单调不增（方向一致）
    certified_decline = bool(have3f and have3b and bd50 > f70)  # 界认证：floor50 > floor70
    c2_verdict = ('成立(界认证)' if certified_decline
                  else ('方向一致但未认证' if (same_protocol and have3f and have3b and bound_dir)
                        else '不可判定'))
    # incumbent 差在 1e-6 量级即求解噪声（零流锚点使三格 incumbent 同为 58.3076…），
    # 不得据此"凑单调"。incumbent 序/严格单调只有超过 0.1% 相对阈才视为真下降。
    INC_TIE = abs(f50) * 1e-3 if have3f else np.inf
    inc_decline_50_70 = bool(have3f and (f50 - f70) > INC_TIE)
    inc_strict_506070 = bool(have3f and (f50 - f60) > INC_TIE and (f60 - f70) > INC_TIE)
    check('N7a 结论二·可比性前提：三格在同口径下均有有限 incumbent 与 bound',
          'V3_MESH_cells.csv', True, bool(same_protocol and have3f and have3b),
          detail=f'incumbent=({f50:.3f},{f60:.3f},{f70:.3f}) bound=({bd50:.3f},{bd60:.3f},'
                 f'{bd70:.3f})')
    check('N7b 结论二(界层面·方向)：网状碳地板下界随 p_s 单调不增 L(50)>=L(60)>=L(70)',
          'V3_MESH_cells.csv', True, bound_dir,
          detail=f'bound {bd50:.3f}>={bd60:.3f}>={bd70:.3f} —— 与"源压抬高降低地板"方向一致')
    check('N7c 结论二(认证式，未达即如实记)：incumbent(70) < bound(50) 才认证"源压降低碳地板"',
          'V3_MESH_cells.csv', True, bool(not certified_decline),
          detail=f'incumbent(PS70)={f70:.3f} vs bound(PS50)={bd50:.3f}：{f70:.3f} < '
                 f'{bd50:.3f} 为 {"真→认证成立" if certified_decline else "假→未认证"}。'
                 f'零流 MIP-start 把三档 incumbent 同钉在 58.31（上界不分离），下界虽降'
                 f'但不构成认证，故判"方向一致但未认证"（c2_verdict={c2_verdict}）；一旦某次'
                 f'运行使 incumbent(70)<bound(50)，本条翻红并应升级为"成立"')
    # incumbent 严格序 / 严格单调 / 边际递减：三格 incumbent 在锚点下恒等于 58.3076
    # （相对差 <1e-6，属求解噪声），据此判"下降"是"混口径凑单调"，故按前提不满足
    # **显式 SKIPPED**（不静默通过、不记为 PASS）。若真得到 >0.1% 分离的 incumbent 才转真判定。
    _anchor_reason = ('统一口径为零流 MIP-start：三格 incumbent 被同一可行锚点钳制'
                      f'（差 <1e-6，视为并列 {f50:.3f}），incumbent 序/严格单调/边际递减在此口径'
                      '下不可判；源压杠杆的判定一律走 bound（见 N7b/N7c）')
    check('N7 结论二(incumbent 序 50>70，超 0.1% 阈)', 'V3_MESH_cells.csv', True,
          inc_decline_50_70, detail=f'incumbent {f50:.4f} vs {f70:.4f}',
          skip=None if inc_decline_50_70 else _anchor_reason)
    check('N7d 结论二(incumbent 严格单调 50>60>70，超 0.1% 阈)', 'V3_MESH_cells.csv', True,
          inc_strict_506070, detail=f'{f50:.4f}/{f60:.4f}/{f70:.4f}',
          skip=None if inc_strict_506070 else _anchor_reason)
    if have3f:
        s1, s2 = f50 - f60, f60 - f70
        check('N7e 结论二(incumbent 边际递减)', 'V3_MESH_cells.csv', True, bool(s2 < s1),
              detail=f'50->60={s1:.6f}t, 60->70={s2:.6f}t',
              skip=_anchor_reason)
    # 超时排序的可认证性：incumbent(70) < bound(50) 才是合法界认证（inc 比 bound，非 inc 比 inc）。
    check('N8 结论二界认证量（incumbent70 < bound50）与判定表一致',
          'V3_MESH_cells.csv', True,
          bool(have3f and have3b and ((bd50 > f70) == certified_decline)),
          detail=f'bound(PS50)={bd50:.4f} vs incumbent(PS70)={f70:.4f} → certified={certified_decline}')
    # 网状是否"活"：可逆管段是否真反过向。取有 RP 解的那一格（优先 M_PS50，退 M_PS70）。
    if 'gas_links_rev_h_total' in cl.columns:
        rp_cell = next((c for c in ('M_PS50', 'M_PS60', 'M_PS70')
                        if c in cx.index and pd.notna(cx.loc[c, 'rp_exp_cost'])), None)
        if rp_cell is None:
            rev, den = np.nan, np.nan
        else:
            rev = float(cx.loc[rp_cell, 'gas_links_rev_h_total'])
            den = float(cx.loc[rp_cell, 'gas_links_h_denom'])
        _rev_reason = ('RP 格起点即零流点（MIP-start 锚点为全网 f=0），incumbent 是否出现'
                       '反向流受锚点支配、不判定"流向不定"；须由自由求解/单场景格观测'
                       '（见 mesh_notes §7、V3_MESH_PROBE_sol1_single.csv）')
        check('N9 流向不定：RP 可行解中可逆管段出现过反向流（>0 小时）',
              'V3_MESH_cells.csv', True, bool(np.isfinite(rev) and rev > 0),
              detail=f'cell={rp_cell} reverse-flow pipe-hours {rev:.0f}/{den:.0f}',
              skip=_rev_reason)
    # R-B：M_PS70 的"无可行解"旧措辞废止。真实态：统一口径下 M_PS70 已求得有限
    # incumbent+bound，结论二卡在"界认证不可达"而非"无解"。故本条改为真判定：
    # 断言 M_PS70 碳地板在场（若退回无解即翻红）。
    ps70_has_floor = bool('M_PS70' in cx.index and np.isfinite(f70))
    check('N11 口径纠正：M_PS70 在统一口径下已有有限碳地板（旧"无可行解"= 搜索失败措辞，已废止）',
          'V3_MESH_cells.csv', True, ps70_has_floor,
          detail=f'M_PS70 incumbent={f70:.3f} bound={bd70:.3f} status='
                 f'{int(cx.loc["M_PS70", "carbon_min_status"]) if "M_PS70" in cx.index else -1}；'
                 f'可行集非空另由 MIP Start 与锚定可行性判定认证（mesh_ps70_diagnosis.md）')
    if have['verdict']:
        vdc = pd.read_csv(os.path.join(RES, MESHP['verdict']), encoding='utf-8-sig')
        vd = vdc.iloc[0]
        vcols = list(vdc.columns)

        def vv(k):
            """取 verdict 的数值列；列缺失或非数 -> NaN（让结构性错误显式翻红）。"""
            return float(vd[k]) if (k in vcols and pd.notna(vd[k])) else np.nan

        def vbool(k):
            if k not in vcols or pd.isna(vd[k]):
                return None
            return str(vd[k]).strip().lower() in ('true', '1', '1.0')

        # ================= C1 锁死：判定表不得把未收敛 incumbent 当碳地板真值 =================
        # 背景（审查 Critical C1）：旧 verdict 用 incumbent(58.3076) 算 c1_carbon_distort_pct_*
        # 与 c1_ratio_*，落盘出 113.101% / 16.095×，与 mesh_notes §8 的诚实结论（保守比
        # ≈5.4×、结论二"方向一致但未认证"）直接矛盾，且违反"任何网状 incumbent 吨数/百分比
        # 不得进正文"。旧 N10 只做 incumbent-vs-incumbent 自洽，结构上抓不到这种"自我一致
        # 的错基"。下面五条把"c1_* 必须由 bound（下界）派生"锁死：改回 incumbent 基即翻红。
        exp_c1_50 = 100 * (bd50 - b0_arch) / b0_arch if np.isfinite(bd50) else np.nan
        exp_c1_70 = 100 * (bd70 - b0_arch) / b0_arch if np.isfinite(bd70) else np.nan
        forbidden_c1_50 = 100 * (f50 - b0_arch) / b0_arch if np.isfinite(f50) else np.nan
        exp_ratio_50 = exp_c1_50 / abs(cc50) if (np.isfinite(exp_c1_50) and np.isfinite(cc50)) else np.nan
        exp_ratio_70 = exp_c1_70 / abs(cc70) if (np.isfinite(exp_c1_70) and np.isfinite(cc70)) else np.nan

        check('N10 判定表与逐格重算一致（结论一方向·bound 基）', 'V3_MESH_verdict.csv', True,
              vbool('c1_floor_above_linecap_PS70') is not None
              and bool(vbool('c1_floor_above_linecap_PS70'))
              == bool(np.isfinite(bd70) and bd70 > b0_arch),
              detail=f'审计侧现算：bound(PS70)={bd70:.4f} > linecap {b0_arch:.4f} '
                     f'→ {bool(np.isfinite(bd70) and bd70 > b0_arch)}（不再用 incumbent 自证）')
        check('N12a verdict.c1_carbon_distort_pct_* 必须由 bound(下界) 现算，逐位一致',
              'V3_MESH_verdict.csv', True,
              bool(np.isfinite(exp_c1_50) and np.isfinite(exp_c1_70))
              and abs(vv('c1_carbon_distort_pct_PS50') - exp_c1_50) <= 1e-9
              and abs(vv('c1_carbon_distort_pct_PS70') - exp_c1_70) <= 1e-9,
              detail=f'bound 基应为 {exp_c1_50:.4f}% (PS50) / {exp_c1_70:.4f}% (PS70)；'
                     f'verdict 实测 {vv("c1_carbon_distort_pct_PS50"):.4f}% / '
                     f'{vv("c1_carbon_distort_pct_PS70"):.4f}%。'
                     f'**被禁止的 incumbent 基会给 {forbidden_c1_50:.3f}%**')
        check('N12b verdict.c1_ratio_* 与 bound 现算一致且 < 10×（"大一个数量级"未被认证）',
              'V3_MESH_verdict.csv', True,
              bool(np.isfinite(exp_ratio_50) and np.isfinite(exp_ratio_70))
              and abs(vv('c1_ratio_PS50') - exp_ratio_50) <= 1e-9
              and abs(vv('c1_ratio_PS70') - exp_ratio_70) <= 1e-9
              and exp_ratio_50 < 10 and exp_ratio_70 < 10
              and vbool('c1_ge10x_certified_PS50') == bool(exp_ratio_50 >= 10),
              detail=f'保守比应为 {exp_ratio_50:.3f}× (PS50) / {exp_ratio_70:.3f}× (PS70)，'
                     f'verdict 实测 {vv("c1_ratio_PS50"):.3f}× / {vv("c1_ratio_PS70"):.3f}×；'
                     f'incumbent 基会给出 16.095× 并冒充"数量级成立"。若将来真的收敛到'
                     f' ≥10×，本条与 N6d 一起翻红，提示把"大一个数量级"重新纳入网状表述')
        check('N12c verdict 结构：incumbent 不得占 floor_* 列名，且不得保留 incumbent 基的'
              '"单调下降/边际递减"字段', 'V3_MESH_verdict.csv', True,
              not [c for c in vcols if c.startswith('floor_M_PS')]
              and not [c for c in vcols if c.startswith('floor_M2S')]
              and 'c2_monotone_decline' not in vcols
              and 'c2_strict_monotone_506070' not in vcols
              and 'c2_diminishing' not in vcols,
              detail=f'违例列={[c for c in vcols if c.startswith("floor_M") or c in ("c2_monotone_decline","c2_strict_monotone_506070","c2_diminishing")]}')
        check('N12d verdict.c2_* 与 bound 现算一致：certified=False、方向一致由下界给出',
              'V3_MESH_verdict.csv', True,
              vbool('c2_certified_by_bound') == certified_decline
              and vbool('c2_direction_consistent_by_bound') == bool(bd50 > bd60 > bd70)
              and vbool('c2_certified_by_bound') is False,
              detail=f'certified={vbool("c2_certified_by_bound")}（审计现算 {certified_decline}）'
                     f' direction_consistent_by_bound={vbool("c2_direction_consistent_by_bound")}'
                     f'（现算 {bool(bd50 > bd60 > bd70)}）；c2_verdict='
                     f'{vd.get("c2_verdict")!r}')
        check('N12e verdict 的 incumbent 列必须自带"上界、非碳地板值、不可判序"标注',
              'V3_MESH_verdict.csv', True,
              vbool('incumbent_is_upper_bound_not_floor') is True
              and vbool('incumbent_usable_for_c2_ranking') is False
              and vbool('c1_basis_is_bound') is True,
              detail='缺标注即允许下游把 58.3076 误读成碳地板真值')

print('=== N13. 正文（IV-J 网状复现 + 引言/讨论章改写句）引用的网状数字 vs CSV 字段 ===')
# 本项目硬约定：**进正文的新数字必须先成为断言**。N13 把 IV-J（sec:meshrep）以及本轮
# 为并入而新写的每个网状量对到 V3_MESH_{cells,verdict,topology,regression}.csv 与链侧
# 存档字段上；期望值一律由 CSV 现读现格式化，绝不反过来把正文里的常数抄进脚本。
# 因此它是双向可失败的：正文改了数字而 CSV 未重跑 -> 红；CSV 重跑动了数字而正文没跟 -> 红。
import io as _io


def _tex(*names):
    return '\n'.join(_io.open(os.path.join(SUB_V2, n), encoding='utf-8').read()
                     for n in names)


def _flat(s):
    return re.sub(r'\s+', ' ', s)


RESULTS_TEX_RAW = _tex('sec_v_results.tex')
_m_ivj = re.search(r'\\subsection\{Replication on a Meshed Gas Network\}',
                   RESULTS_TEX_RAW)
IVJ = _flat(RESULTS_TEX_RAW[_m_ivj.start():]) if _m_ivj else ''
ALLTEX = _flat(_tex('manuscript_v2.tex', 'sec_i_intro.tex', 'sec_ii_related.tex',
                    'sec_iii_framework.tex', 'sec_v_results.tex',
                    'sec_vi_vii_discussion.tex', 'bibliography_v2.tex'))
check('N13a 正文存在 IV-J 网状复现小节（小节缺失则以下正文断言全部失去对象）',
      'sec_v_results.tex', True, bool(_m_ivj),
      detail='\\subsection{Replication on a Meshed Gas Network} + \\label{sec:meshrep}')
check('N13b IV-J 带 \\label{sec:meshrep} 且被引言/讨论章前指',
      'sec_v_results.tex / sec_i_intro.tex', True,
      '\\label{sec:meshrep}' in RESULTS_TEX_RAW
      and 'sec:meshrep' in _flat(_tex('sec_i_intro.tex'))
      and 'sec:meshrep' in _flat(_tex('sec_vi_vii_discussion.tex')),
      detail='并入的真正目的是让 headline 句前指本节，不是只加一节孤立结果')


def bnum(label, value, fmt, source, where=None, extra=''):
    """断言"正文印出的串 == 把 CSV 字段按 fmt 格式化出来的串"（先红后绿的主体）。"""
    s = format(value, fmt)
    w = IVJ if where is None else where
    return check(f'N13 正文数字 {label}', source, True, bool(s) and s in w,
                 detail=f'CSV 现读 -> "{s}"（{fmt}）；正文命中={bool(s) and s in w}'
                        + (f'；{extra}' if extra else ''))


if have['cells'] and have['verdict'] and have['reg'] and have['topo']:
    cl13 = pd.read_csv(os.path.join(RES, MESHP['cells']), encoding='utf-8-sig')
    cx13 = cl13.set_index('cell')
    v13 = pd.read_csv(os.path.join(RES, MESHP['verdict']), encoding='utf-8-sig').iloc[0]
    t13 = pd.read_csv(os.path.join(RES, MESHP['topo']), encoding='utf-8-sig')
    tm13 = dict(zip(t13['item'], t13['value']))
    rg13 = pd.read_csv(os.path.join(RES, MESHP['reg']), encoding='utf-8-sig')

    # ---- 门站可交付量：R4 对齐（正文"逐项相等"的那三个数）----
    for _c, _cfg in (('M_PS50', 'PS50'), ('M_PS60', 'PS60'), ('M_PS70', 'PS70')):
        gd = float(cx13.loc[_c, 'gate_deliverability_MWh_h'])
        chain = float(load_long_summary(f'V3_GC_{_cfg}_main_summary.csv')
                      ['gas_oos_f1_max_cap'])
        bnum(f'网状门站逐时可交付 @{_cfg} (MWh/h)', gd, '.3f', 'V3_MESH_cells.csv',
             extra=f'链侧存档 {chain:.9f}，|Δ|={abs(gd - chain):.2e}')
        check(f'N13 正文"两拓扑逐时相等"断言成立（|Δ| < 1e-9，两条独立代码路径）',
              'V3_MESH_cells.csv vs V3_GC_*_main_summary.csv', True,
              abs(gd - chain) < 1e-9, detail=f'{_c} vs {_cfg}')
    bnum('网状管存容量 @50 (MWh)', float(cx13.loc['M_PS50', 'lp_cap_MWh']), '.2f',
         'V3_MESH_cells.csv')
    bnum('网状管存容量 @60 (MWh)', float(cx13.loc['M_PS60', 'lp_cap_MWh']), '.2f',
         'V3_MESH_cells.csv')
    bnum('网状管存容量 @70 (MWh)', float(cx13.loc['M_PS70', 'lp_cap_MWh']), '.2f',
         'V3_MESH_cells.csv')
    # 链侧管容刻意不对齐：正文写了 4.50/6.00/7.50，须能追溯到"2 节点 × A(p_s−p_min)"，
    # 且"2 节点"本身要有机核证据（链侧存档只有 p1/p2 两组压力计数器，没有 p3）。
    ch70s = load_long_summary('V3_GC_PS70_main_summary.csv')
    _pcols = [k for k in ch70s.index if re.match(r'gas_oos_p\d+_at_min_h$', str(k))]
    check('N13 链侧为 2 个压力节点（存档计数器 p1/p2 存在、无 p3 ⇒ 正文 4.50/6.00/7.50 的分母）',
          'V3_GC_PS70_main_summary.csv',
          'gas_oos_p1_at_min_h,gas_oos_p2_at_min_h', ','.join(sorted(_pcols)),
          detail=f'计数器列={sorted(_pcols)}')
    for _c, _cfg, _exp in (('M_PS50', 'PS50', 4.50), ('M_PS60', 'PS60', 6.00),
                           ('M_PS70', 'PS70', 7.50)):
        A = float(cx13.loc[_c, 'A_node'])
        pmin = float(cx13.loc[_c, 'pd_min'])
        ps = float(cx13.loc[_c, 'ps'])
        bnum(f'链侧管存容量 @{_cfg} (MWh，刻意不对齐)', A * (ps - pmin) * len(_pcols),
             '.2f', 'V3_MESH_cells.csv (A_NODE,ps,p_min) × 2 节点',
             extra=f'网状/链 = {float(cx13.loc[_c, "lp_cap_MWh"]) / (A * (ps - pmin) * len(_pcols)):.2f} 倍'
                   f'（正文口径 2.5 倍；CSV 实测 {_exp}）')

    # ---- 拓扑计数：正文"6 elements / 5 nodes / 4 reversible / 2 one-directional / 1 cycle" ----
    m70 = cx13.loc['M_PS70']
    check('N13 正文"6 elements, 5 nodes carrying a pressure state, 4 links ... 2 one-directional"'
          '与模型实际建出的构成一致',
          'V3_MESH_cells.csv + V3_MESH_topology.csv', True,
          all(s in IVJ for s in ('6 elements', '5 nodes carrying a pressure state',
                                 '4 links modeled as bidirectionally reversible',
                                 '2 one-directional'))
          and int(m70['n_elements']) == 6 and int(m70['n_gas_nodes']) == 5
          and int(m70['n_links']) == 4 and int(m70['n_const']) == 2,
          detail=f'cells: n_elements={int(m70["n_elements"])} n_gas_nodes='
                 f'{int(m70["n_gas_nodes"])} n_links={int(m70["n_links"])} n_const='
                 f'{int(m70["n_const"])}；topo core1s_n_edges={tm13.get("core1s_n_edges")}')
    import ast as _ast
    _cyc = _ast.literal_eval(str(tm13.get('core1s_cycles', '[]')))
    check('N13 正文"one real cycle"与环的节点集合 == CSV 登记（正文写出的环路须与同一环一致）',
          'V3_MESH_topology.csv', True,
          len(_cyc) == 1 and 'one real cycle' in IVJ
          and 'N01$\\to$N02$\\to$N04$\\to$N03$\\to$N01' in IVJ
          and set(_cyc[0]) == {'N01', 'N02', 'N03', 'N04'},
          detail=f'core1s_cycles={_cyc}（次序无路径含义，故比集合）')
    _routes13 = _ast.literal_eval(str(tm13.get(
        'core1s_edge_disjoint_routes_from_injection', '{}')))
    check('N13 正文"two edge-disjoint routes from the injection node"= 落盘指标 2/2',
          'V3_MESH_topology.csv', True,
          'two edge-disjoint routes' in IVJ and bool(_routes13)
          and all(int(v) == 2 for v in _routes13.values()),
          detail=f'core1s_edge_disjoint_routes_from_injection={_routes13}')
    check('N13 正文未把冗余写成"去任一源仍可达"（单源核心只有 1 个门站，那种说法是假的）',
          'sec_v_results.tex', True,
          'either source' not in IVJ and 'removing either' not in IVJ,
          detail='mesh_notes §1 措辞纠正：正确的冗余表述是"去任一条管段仍可达"')
    _raw_counts = {'原始节点数': ('n_nodes_raw', '11 nodes'),
                   '原始连接数': ('n_connections_raw', '11 connections'),
                   '原始管道数': ('n_pipes_raw', '8 pipelines'),
                   '原始调节阀数': ('n_valves_raw', '1 control valve'),
                   '原始压缩机数': ('n_compressors_raw', '2 compressor stations')}
    check('N13 GasLib-11 原始图规模：CSV 计数 11/11/8/1/2 与正文那句逐项一致',
          'V3_MESH_topology.csv', '11,11,8,1,2',
          ','.join(str(int(float(tm13[k]))) for k, _ in _raw_counts.values()),
          detail='正文："11 nodes and 11 connections (8 pipelines, 1 control valve, '
                 '2 compressor stations)"')
    check('N13 正文那句原始图规模的措辞确实在场（防"数值对但句子被删"）',
          'sec_v_results.tex', True,
          all(ph in IVJ for _, ph in _raw_counts.values()),
          detail='；'.join(ph.replace('\n', ' ') for _, ph in _raw_counts.values()))
    check('N13 许可/引用义务口径与留档一致（CC BY 3.0、MIT 镜像、ZIB-Report 12-41 已引）',
          'V3_MESH_topology.csv + bibliography_v2.tex', True,
          'CC BY 3.0' in str(tm13.get('license')) and 'CC BY 3.0' in IVJ
          and 'MIT' in str(tm13.get('retrieved_from')) and 'MIT-licensed' in IVJ
          and 'ZIB-Report 12-41' in str(tm13.get('required_citation'))
          and 'ZIB-Report 12-41' in _flat(_tex('bibliography_v2.tex'))
          and '\\bibitem{pfetsch2012gaslib}' in _tex('bibliography_v2.tex')
          and '\\cite{pfetsch2012gaslib}' in RESULTS_TEX_RAW,
          detail='正文引用点、文献条目与 CSV 登记的引用义务三处必须同时在场')

    # ---- 方向与量级：结论一 / 结论二（全部走 bound，incumbent 不进正文）----
    bnum('线性气帽碳地板（与拓扑无关）', float(v13['floor_linecap']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('网状碳地板下界 L(50)', float(v13['bound_M_PS50']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('网状碳地板下界 L(60)', float(v13['bound_M_PS60']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('网状碳地板下界 L(70)', float(v13['bound_M_PS70']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('下界步长 50→60', float(v13['c2_bound_step_50_to_60']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('下界步长 60→70', float(v13['c2_bound_step_60_to_70']), '.3f',
         'V3_MESH_verdict.csv')
    bnum('链臂碳地板 @50', float(main.loc['PS50', 'carbon_min_exp_rp']), '.3f',
         'V3_GC_scan_carbon.csv')
    bnum('链臂碳地板 @60', float(main.loc['PS60', 'carbon_min_exp_rp']), '.3f',
         'V3_GC_scan_carbon.csv')
    bnum('链臂碳地板 @70', float(main.loc['PS70', 'carbon_min_exp_rp']), '.3f',
         'V3_GC_scan_carbon.csv')
    bnum('网状保守比下界 PS50 (×)', float(v13['c1_ratio_PS50']), '.1f',
         'V3_MESH_verdict.csv', extra=f'c1_ratio_is_lower_bound='
                                      f'{v13["c1_ratio_is_lower_bound"]}')
    bnum('网状保守比下界 PS70 (×)', float(v13['c1_ratio_PS70']), '.1f',
         'V3_MESH_verdict.csv')
    bnum('链臂碳/成本失真比 @50 (×)', float(v13['c1_2node_ratio_PS50']), '.1f',
         'V3_MESH_verdict.csv')
    bnum('链臂碳/成本失真比 @60 (×)', float(v13['c1_2node_ratio_PS60']), '.1f',
         'V3_MESH_verdict.csv')
    bnum('链臂碳/成本失真比 @70 (×)', float(v13['c1_2node_ratio_PS70']), '.1f',
         'V3_MESH_verdict.csv')
    check('N13 结论二措辞：正文写"未认证"且判定表 certified=False、tied_at_anchor=True',
          'V3_MESH_verdict.csv', True,
          str(v13['c2_certified_by_bound']).lower() in ('false', '0')
          and str(v13['c2_incumbent_tied_at_anchor']).lower() in ('true', '1')
          and 'not certified' in IVJ and 'less than $10^{-6}$ relative' in IVJ,
          detail='正文必须同时给出"界层面方向下降"与"认证式不满足"，不得只留一半')
    check('N13 结论一措辞：5.4× 是**下界**，正文不得写成"已证伪/不成立"',
          'mesh_notes.md:313 纪律', True,
          str(v13['c1_ratio_is_lower_bound']).lower() in ('true', '1')
          and 'not certified' in IVJ and 'not that it was falsified' in IVJ,
          detail='界不夹住真值：只能写"未达认证"')
    check('N13 正文未声称"网状臂完整复现两条结论"（mesh_notes 禁入清单第 6 条）',
          'sec_v_results.tex', True,
          'it does not replicate both claims' in IVJ
          and 'replicates both conclusions' not in IVJ,
          detail='只认证了结论一的方向；结论二未认证')

    # ---- 求解诚实性：gap、方向二进制、超时口径 ----
    for _c in ('M_PS50', 'M_PS60', 'M_PS70'):
        bnum(f'网状碳地板 gap {[_c][-3:]} (%)',
             100 * float(cx13.loc[_c, 'carbon_min_mip_gap']), '.1f',
             'V3_MESH_cells.csv',
             extra=f'status={int(cx13.loc[_c, "carbon_min_status"])} '
                   f'({cx13.loc[_c, "carbon_min_status_name"]})——超时不粉饰')
    check('N13 三格状态一律 TIME_LIMIT（9），正文未把超时写成 OPTIMAL',
          'V3_MESH_cells.csv', True,
          all(int(cx13.loc[c, 'carbon_min_status']) == 9
              and int(cx13.loc[c, 'rp_status']) == 9
              for c in ('M_PS50', 'M_PS60', 'M_PS70'))
          and 'TIME\\_LIMIT' in IVJ and '35.3\\%, 39.6\\% and 42.8\\%' in IVJ,
          detail='正文引用的 35.3/39.6/42.8% 与逐格 gap 必须同源')
    _den = int(m70['gas_links_h_denom'])
    check('N13 正文"768 direction binaries"= 可逆管数 × 24 h × 8 场景（分母可核）',
          'V3_MESH_cells.csv', _den,
          int(m70['n_links']) * 24 * 8 if _den else -1, 0,
          detail=f'gas_links_h_denom={_den}；n_links={int(m70["n_links"])}；'
                 f'正文 "768 direction binaries" 命中={"768 direction binaries" in IVJ}')
    check('N13 SOC 是外近似：正文不得出现未否定的"精确凸重构/零表示误差"',
          'mesh_notes §3（修复轮 1 / I4）', True,
          IVJ.count('exact convex reformulation')
          == IVJ.count('not an exact convex reformulation')
          and 'outer approximation' in IVJ,
          detail='否定式（"not an exact convex reformulation"）允许；肯定式禁止')
    check('N13 反向流未被声称"实际发生"（本口径 incumbent 反向流 0/768）',
          'V3_MESH_cells.csv', True,
          int(m70['gas_links_rev_h_total']) == 0
          and 'no reversible link runs backwards' in IVJ,
          detail=f'gas_links_rev_h_total={int(m70["gas_links_rev_h_total"])}')

    # ---- 回归闸门（阈值单一出处 config_v3.MESH_REG_TOL）----
    import config_v3 as C313
    _tol = C313.MESH_REG_TOL
    _maxc = float(rg13['reldiff_carbon'].max())
    _maxall = float(rg13[['reldiff_carbon', 'reldiff_cost',
                          'reldiff_rp_carbon']].max().max())
    check('N13 回归阈值：正文写的 10^{-4} == config_v3.MESH_REG_TOL 且实测偏差低于它',
          'config_v3.py + V3_MESH_regression.csv', True,
          _tol == 1e-4 and '10^{-4}$ acceptance gate' in IVJ and _maxall < _tol,
          detail=f'tol={_tol:g}，碳地板最大相对偏差={_maxc:.3e}，三量最大={_maxall:.3e}')
    check('N13 正文回归尾数"2.6"来自 CSV：碳地板最大相对偏差现算 == 2.6e-05',
          'V3_MESH_regression.csv', '2.6e-05', format(_maxc, '.1e'),
          detail=f'实测 {_maxc:.6e}')
    check('N13 正文回归尾数"8.2"来自 CSV：三量最大相对偏差现算 == 8.2e-05',
          'V3_MESH_regression.csv', '8.2e-05', format(_maxall, '.1e'),
          detail=f'实测 {_maxall:.6e}')
    check('N13 正文回归尾数与 CSV 一致（2.6e-05 / 8.2e-05 两个串都在 IV-J 里）',
          'V3_MESH_regression.csv', True,
          format(_maxc, '.1e') == '2.6e-05' and format(_maxall, '.1e') == '8.2e-05'
          and '2.6$\\times10^{-5}$' in IVJ and '8.2$\\times10^{-5}$' in IVJ,
          detail=f'现算 {format(_maxc, ".1e")} / {format(_maxall, ".1e")}')
    check('N13 四档回归全 OPTIMAL（正文 "all four configurations OPTIMAL"）',
          'V3_MESH_regression.csv', True,
          all(int(r['carbon_status']) == 2 and int(r['cost_status']) == 2
              for _, r in rg13.iterrows()) and '4 configs' in IVJ,
          detail=f'cfg={list(rg13["cfg"])}')

    # ---- "模型可行"与"算得起"分开：单场景探针实测（禁"单场景 2.1 s OPTIMAL"）----
    _probe = os.path.join(RES, 'V3_MESH_PROBE_sol1_single.csv')
    if os.path.exists(_probe):
        sp = pd.read_csv(_probe, encoding='utf-8-sig')
        _lo, _hi = float(sp['runtime'].min()), float(sp['runtime'].max())
        bnum('单场景首解用时下界 (s)', _lo, '.1f', 'V3_MESH_PROBE_sol1_single.csv',
             extra=f'{len(sp)} 行全为 SOLUTION_LIMIT' if
             set(sp['status']) == {10} else '状态非 10，须重看措辞')
        bnum('单场景首解用时上界 (s)', _hi, '.1f', 'V3_MESH_PROBE_sol1_single.csv')
        check('N13 正文"1.6--4.2 s"与探针一致，且那批解确实只到 SOLUTION_LIMIT',
              'V3_MESH_PROBE_sol1_single.csv', True,
              '1.6--4.2~s' in IVJ and set(sp['status']) == {10}
              and int(sp['solcount'].min()) >= 1,
              detail=f'runtime {format(_lo, ".1f")}–{format(_hi, ".1f")} s；'
                     f'status={sorted(set(sp["status_name"]))}')
    else:
        check('N13 单场景探针文件存在（缺失则"可行≠算得起"无从取证）',
              'V3_MESH_PROBE_sol1_single.csv', True, False)

    # ---- 禁入清单：mesh_notes.md:371-391 的每个量都做一次"全文反向守卫" ----
    BANNED = {
        '网状 incumbent 吨数 58.3076（三档并列，非碳地板值）': ['58.307', '58.308', '58.31'],
        '网状 RP 成本 incumbent 36317.84': ['36317', '36{,}317'],
        'incumbent 基的失真百分比 7.03% / 113.101% / 比值 16.095×': ['7.03', '113.1', '16.095'],
        '双源格 M2S_PS70（本轮未跑，verdict 为 NaN）': ['M2S'],
        '"单场景 2.1 s OPTIMAL"': ['2.1 s', '2.1~s'],
    }
    for lbl, toks in BANNED.items():
        hits = [t for t in toks if t in ALLTEX]
        check(f'N13 禁入正文：{lbl}', 'mesh_notes.md:371-391', 'none',
              ', '.join(hits) or 'none',
              detail='命中的源文件须一并清除；这些量是未收敛上界或未跑的格，不是结果')
    check('N13 禁入正文："M_PS70 无可行解 / 不可判定"（正确口径：时限内未找到可行整数解、'
          '可行集非空由 MIP-start 认证）', 'mesh_notes.md §5/§7', True,
          'no feasible solution' not in ALLTEX and 'not decidable' not in ALLTEX
          and 'M_PS70' not in ALLTEX,
          detail='内部格名也不得进正文；正文只描述协议与界')

# ---------- P. 方法对方法基线臂（Task 4：steady = Kanelakis 式稳态气网耦合）----------
# 这一节回答"compared to what"。纪律与 N 节相同：
#   ① 只判**结构事实**与**方向**，不断言任何百分比等于某值；
#   ② "基线去掉了管存"这类主张一律由 Gurobi 模型的约束/变量家族计数、以及**解里的
#      逐时节点不平衡残差**来判定，绝不由注释、标签或正文措辞来判定；
#   ③ 允许失败：P3 的包含关系（本文档不劣于基线）与 P4 的单调性都是可真可不真的
#      判据，不成立就如实改结论，不许反过来调基线。
# 基线走 data_v3.ARMS 机制（V3_ARM=steady），与 main 共用同一次 prepare()、同一
# seed=42 的 265/100 划分、同一 k=8/seed=0 削减，所以"口径同源"这件事有 P2.4 那种
# 逐日 test_day 集合相等的硬证据，而不是靠"我保证没改"。
print('=== P. 方法对方法基线（Task 4：steady 稳态气网耦合臂）===')
BASEP = {
    'probe': 'V3_BASELINE_probe.csv',
    'struct': 'V3_BASELINE_structure.csv',
    'plan': 'V3_BASELINE_plan.csv',
    'cmp': 'V3_BASELINE_compare3.csv',
    'scan': 'V3_BASELINE_ps_scan.csv',
    'steady70': 'V3_GC_PS70_steady_summary.csv',
    'main70': 'V3_GC_PS70_main_summary.csv',
    'b0': 'V3_GC_B0_main_summary.csv',
}
_have_b = {k: os.path.exists(os.path.join(RES, v)) for k, v in BASEP.items()}
for _k, _v in BASEP.items():
    check(f'P0 基线产物存在：{_v}', 'results/' + _v, True, _have_b[_k],
          detail='缺失即 Task 4 未跑通（probe 未在同进程解两档，或 steady 档未跑），'
                 '后续 P 节断言不作数')
for _cfg in ('PS50', 'PS60', 'PS70'):
    _f = f'V3_GC_{_cfg}_steady_summary.csv'
    check(f'P0 steady {_cfg} 格存在：{_f}', 'results/' + _f, True,
          os.path.exists(os.path.join(RES, _f)))

if all(_have_b.values()):
    import json as _json

    def _bnum(x):
        """把 CSV 里的 'True'/'False'/'' /数字统一成可比较的标量。"""
        if isinstance(x, str):
            s = x.strip()
            if s.lower() == 'true':
                return True
            if s.lower() == 'false':
                return False
            if s in ('', 'nan'):
                return None
            try:
                return float(s)
            except ValueError:
                return s
        if x is None or (isinstance(x, float) and np.isnan(x)):
            return None
        if isinstance(x, bool):
            return x
        try:
            return float(x)
        except (TypeError, ValueError):
            return x

    prb = pd.read_csv(os.path.join(RES, BASEP['probe']), encoding='utf-8-sig')
    stx = pd.read_csv(os.path.join(RES, BASEP['struct']), encoding='utf-8-sig')
    pln = pd.read_csv(os.path.join(RES, BASEP['plan']), encoding='utf-8-sig')
    cmp3 = pd.read_csv(os.path.join(RES, BASEP['cmp']), encoding='utf-8-sig')
    scan_b = pd.read_csv(os.path.join(RES, BASEP['scan']), encoding='utf-8-sig')
    smain = load_long_summary('V3_GC_PS70_main_summary.csv')
    sstd = load_long_summary('V3_GC_PS70_steady_summary.csv')
    sb0 = load_long_summary('V3_GC_B0_main_summary.csv')

    SC = {a: g[g['level'] == 'model_scalar'].set_index('key')['value']
          for a, g in stx.groupby('arm')}
    FAM = {a: g[g['level'] == 'constr_family'].set_index('key')['value']
           for a, g in stx.groupby('arm')}
    P = {a: r for a, r in prb.set_index('arm').iterrows()}
    T_H = int(_bnum(SC['main']['expected_dyn_cons']) / 2)   # = S*T（场景小时总数）

    # ---- P1 基线确实去掉了管存状态与日循环闭合（结构事实，非措辞）----
    check('P1.1 steady 模型里管存动态约束 node1_* 家族计数 == 0',
          'V3_BASELINE_structure.csv', 0, int(_bnum(SC['steady']['n_node1'])),
          detail='不是"注释说去掉了"，是 Gurobi 约束表里查不到这一族')
    check('P1.2 steady 模型里管存动态约束 node2_* 家族计数 == 0',
          'V3_BASELINE_structure.csv', 0, int(_bnum(SC['steady']['n_node2'])))
    check('P1.3 steady 模型里日循环闭合 p1cyc_*/p2cyc_* 计数均为 0',
          'V3_BASELINE_structure.csv', (0, 0),
          (int(_bnum(SC['steady']['n_p1cyc'])), int(_bnum(SC['steady']['n_p2cyc']))),
          detail='闭合条件在 steady 里整条删除；留着会给基线加一条与自身物理无关的'
                 '额外约束，那是人为加严（strawman）')
    check('P1.4 steady 模型里 p1_0/p2_0 不是一阶段变量',
          'V3_BASELINE_structure.csv', (False, False),
          (bool(_bnum(SC['steady']['has_p0_1'])), bool(_bnum(SC['steady']['has_p0_2']))),
          detail='无管存状态 => 无可初始化量')
    check('P1.5 steady 仍保留逐时节点平衡（steady_node1/steady_node2 各 = S*T）',
          'V3_BASELINE_structure.csv', (T_H, T_H),
          (int(_bnum(SC['steady']['n_steady_node1'])),
           int(_bnum(SC['steady']['n_steady_node2']))),
          detail='去掉的是 A·Δp 这一项，不是去掉质量守恒——基线不欠平衡')
    check('P1.6 main 保留管存动态与闭合（node1=node2=S*T、p1cyc=p2cyc=S）',
          'V3_BASELINE_structure.csv', True,
          int(_bnum(SC['main']['n_node1'])) == T_H and int(_bnum(SC['main']['n_node2'])) == T_H
          and int(_bnum(SC['main']['n_p1cyc'])) == int(_bnum(SC['main']['n_node1']) / 24)
          and int(_bnum(SC['main']['n_p2cyc'])) == int(_bnum(SC['main']['n_node1']) / 24),
          detail=f'S*T={T_H}，S={T_H // 24}')
    check('P1.7 main 的 p1_0/p2_0 是一阶段变量（periodic 边界条件）',
          'V3_BASELINE_structure.csv', (True, True),
          (bool(_bnum(SC['main']['has_p0_1'])), bool(_bnum(SC['main']['has_p0_2']))))
    GAS_FAMS = {'node1', 'node2', 'p1cyc', 'p2cyc', 'steady_node1', 'steady_node2'}
    common = (set(FAM['main'].index) & set(FAM['steady'].index)) - GAS_FAMS
    diff_fam = sorted(k for k in common if int(FAM['main'][k]) != int(FAM['steady'][k]))
    check('P1.8 除气平衡族外，两档约束家族计数逐个相等（其余口径确实冻结）',
          'V3_BASELINE_structure.csv', [], diff_fam,
          detail=f'比对的家族数={len(common)}；任何一项不同都说明基线顺手改了别的约束')
    only_m = sorted((set(FAM['main'].index) - set(FAM['steady'].index)) - GAS_FAMS)
    only_s = sorted((set(FAM['steady'].index) - set(FAM['main'].index)) - GAS_FAMS)
    check('P1.8b 两档约束家族集合之差只含气平衡族（无凭空空出的约束族）',
          'V3_BASELINE_structure.csv', ([], []), (only_m, only_s))
    check('P1.9 两档一阶段二元变量数相等（承诺层完全相同）',
          'V3_BASELINE_structure.csv', int(_bnum(SC['main']['n_binaries'])),
          int(_bnum(SC['steady']['n_binaries'])),
          detail=f"=3T={3 * 24}；y/z/u 的个数一致 => 启停与爬坡没有被动过")
    check('P1.10 两档广义约束数相等（Weymouth 余弦 PWL 段数与写法相同）',
          'V3_BASELINE_structure.csv', int(_bnum(SC['main']['n_gen_constrs'])),
          int(_bnum(SC['steady']['n_gen_constrs'])))
    exp_dc = (int(_bnum(SC['main']['n_node1'])) + int(_bnum(SC['main']['n_node2']))
              + int(_bnum(SC['main']['n_p1cyc'])) + int(_bnum(SC['main']['n_p2cyc']))
              - int(_bnum(SC['steady']['n_steady_node1']))
              - int(_bnum(SC['steady']['n_steady_node2'])))
    act_dc = int(_bnum(SC['main']['n_cons'])) - int(_bnum(SC['steady']['n_cons']))
    check('P1.11 约束总数之差 == 删除的管存/闭合条数 − 新增的逐时平衡条数（表没被手填）',
          'V3_BASELINE_structure.csv', exp_dc, act_dc,
          detail=f'结构推得 {exp_dc}，CSV 的 n_cons 差 {act_dc}')

    # ---- P2 三列口径同源 ----
    check('P2.1 三列留出日数均为 100', 'V3_GC_*_summary.csv', [100, 100, 100],
          [int(_bnum(smain['n_test_days'])), int(_bnum(sstd['n_test_days'])),
           int(_bnum(sb0['n_test_days']))])
    import config_v3 as CG          # 现读 config，不把 0.8922 / 1e-4 抄进本脚本
    ef_ref = CG.get_e_grid('official_om_nw')
    efs = [_bnum(smain['e_grid']), _bnum(sstd['e_grid']), _bnum(sb0['e_grid'])]
    check('P2.2 三列电网排放因子相同且 == config_v3 官方西北 OM（现读 config）',
          'config_v3.py + summaries', True,
          all(abs(e - ef_ref) < 1e-12 for e in efs),
          detail=f'EF={ef_ref}；三列 {efs}')
    check('P2.3 三列 e_grid_mode 标签相同', 'V3_GC_*_summary.csv',
          str(smain['e_grid_mode']), str(sstd['e_grid_mode']))
    days = {}
    for col, cfg, arm in [('main', 'PS70', 'main'), ('steady', 'PS70', 'steady'),
                          ('B0', 'B0', 'main')]:
        o = pd.read_csv(os.path.join(RES, f'V3_GC_{cfg}_{arm}_oos.csv'),
                        encoding='utf-8-sig')
        days[col] = set(o['test_day'].astype(str))
    check('P2.4 三列的 100 个留出日 test_day 集合逐个相同（同一划分，非各切各的）',
          'V3_GC_*_oos.csv', True,
          days['main'] == days['steady'] == days['B0'] and len(days['main']) == 100,
          detail=f'|main|=|steady|=|B0|={len(days["main"])} 天')
    # 冻结常数一律以 **probe** 为准：两档在同一次 prepare()、同一进程里各解一次，
    # 是"其余口径全冻结"这句话唯一能落到实处的取证面（存档的 main summary 早于
    # 这些键的引入，拿它当基准会读到空）。steady 再与主链产物交叉核对一次。
    FZK = ['K_frozen', 'n_pts_frozen', 'comp_ratio_frozen', 'pd_min_frozen', 'ps2']
    fz_m = {k: _bnum(P['main'][k]) for k in FZK}
    fz_s = {k: _bnum(P['steady'][k]) for k in FZK}
    check('P2.5 两档冻结常数逐项相同（Weymouth K / PWL 断点数 / 压缩比 / 压力下界 / 压缩机出口压）',
          'V3_BASELINE_probe.csv', fz_m, fz_s,
          detail=f'现读 probe：{fz_m}（main） vs {fz_s}（steady）；任何一项不同都说明'
                 f'基线顺手改了别的东西')
    check('P2.5b steady 主链产物的冻结常数与 probe 一致（跑出来的那档就是被对照的那档）',
          'V3_GC_PS70_steady_summary.csv vs V3_BASELINE_probe.csv',
          {'K_frozen': fz_s['K_frozen'], 'n_pts_frozen': fz_s['n_pts_frozen'],
           'comp_ratio_frozen': fz_s['comp_ratio_frozen'],
           'A_frozen': _bnum(P['steady']['A1_frozen'])},
          {'K_frozen': _bnum(sstd['K_frozen']), 'n_pts_frozen': _bnum(sstd['n_pts_frozen']),
           'comp_ratio_frozen': _bnum(sstd['comp_ratio_frozen']),
           'A_frozen': _bnum(sstd['A1_frozen_geometry'])})
    check('P2.6 两档唯一的数值差别是有效管存系数 A_eff（main=几何值，steady=0）',
          'V3_BASELINE_probe.csv', True,
          _bnum(P['main']['A1_eff']) == _bnum(P['main']['A1_frozen'])
          and _bnum(P['main']['A2_eff']) == _bnum(P['main']['A1_frozen'])
          and _bnum(P['steady']['A1_eff']) == 0.0
          and _bnum(P['steady']['A2_eff']) == 0.0,
          detail=f"A_eff main={_bnum(P['main']['A1_eff'])} / steady={_bnum(P['steady']['A1_eff'])}，"
                 f"几何常数两档都是 {_bnum(P['main']['A1_frozen'])}")
    check('P2.7 两耦合档门站调压阀都开着（gate_valve 相同，未给基线松绑）',
          'V3_BASELINE_probe.csv', str(P['main']['gate_valve']),
          str(P['steady']['gate_valve']))
    check('P2.7b 两档 RP 场景数与调度时数相同（probe 侧）',
          'V3_BASELINE_probe.csv',
          (_bnum(P['main']['n_scen']), _bnum(P['main']['T'])),
          (_bnum(P['steady']['n_scen']), _bnum(P['steady']['T'])))
    check('P2.8 两耦合档主链产物的 RP 场景数都是 8', 'gas_rp_n_obs', 8.0,
          _bnum(sstd['gas_rp_n_obs']),
          detail=f"main 存档 gas_rp_n_obs={_bnum(smain['gas_rp_n_obs'])}")
    check('P2.9 两耦合档实际 MIPGap 都不劣于 config 声明的 1e-4',
          'config_v3.GRB_MIPGAP + summaries', True,
          _bnum(smain['rp_mip_gap']) <= CG.GRB_MIPGAP + 1e-18
          and _bnum(sstd['rp_mip_gap']) <= CG.GRB_MIPGAP + 1e-18,
          detail=f"main {_bnum(smain['rp_mip_gap']):.3e} / "
                 f"steady {_bnum(sstd['rp_mip_gap']):.3e}，声明 {CG.GRB_MIPGAP:.1e}")
    rel_repro = _bnum(P['main']['probe_vs_archived_rp_cost_reldiff'])
    check('P2.10 probe 同进程重解的 main RP 成本 == 存档 rp_exp_cost（存档未被覆盖/漂移）',
          'V3_BASELINE_probe.csv vs V3_GC_PS70_main_summary.csv', True, rel_repro < 1e-9,
          detail=f'相对差 {rel_repro:.3e}；这条同时证明基线脚本没有改动本文档的结果文件')
    check('P2.11 B0 列确实无气网（gas_coupled False，且约束数少于两耦合档）',
          'V3_GC_B0_main_summary.csv', True,
          str(sb0['gas_coupled']).strip().lower() == 'false'
          and _bnum(sb0['rp_n_cons']) < _bnum(smain['rp_n_cons'])
          and _bnum(sb0['rp_n_cons']) < _bnum(sstd['rp_n_cons']),
          detail=f"B0 {_bnum(sb0['rp_n_cons'])} / main {_bnum(smain['rp_n_cons'])} "
                 f"/ steady {_bnum(sstd['rp_n_cons'])} 条约束")

    # ---- P3 方向性判定（从解里现算，不看标签）----
    pl = {a: g for a, g in pln.groupby('arm')}
    A1m = _bnum(P['main']['A1_frozen'])
    A2m = A1m                      # 两节点几何同系数（K1=K2=0.00383, A1=A2）
    rmax_s = float(pl['steady'][['res1', 'res2']].abs().values.max())
    check('P3.1 steady 的逐时节点不平衡恒等于 0（max|res| < 1e-6）：无管存状态成立',
          'V3_BASELINE_plan.csv', True, rmax_s < 1e-6,
          detail=f'max|res|={rmax_s:.3e} MWh；f1 = f2(1+r)+g1 与 f2 = g2 逐时闭合')
    sh_s = int(cmp3.loc[cmp3['metric'] == 'store_h_total', 'steady'].iloc[0])
    check('P3.2 steady 使用管存的小时数 == 0（2400 场景小时全为 0）',
          'V3_BASELINE_compare3.csv', 0, sh_s)
    check('P3.3 main 使用管存的小时数 > 0（这层物理在解里是活的）',
          'V3_BASELINE_compare3.csv / probe', True,
          int(P['main']['rp_store_h']) > 0,
          detail=f"main RP 有 {int(P['main']['rp_store_h'])} 个场景小时出现非零不平衡")
    # 恒等式：main 档 res1 必须等于 A1·Δp1、res2 等于 A2·Δp2。
    # Δp 取**后向**差且 t=0 回绕到 p_T（p1_0 == p1[T-1] 由闭合条件保证）。写成前向差
    # 会把整条序列错开一小时——本断言第一轮就是这样假红的，留此注记防复发。
    mm = pl['main'].sort_values(['scenario', 'hour'])
    e1 = e2 = 0.0
    for _sid, gg in mm.groupby('scenario'):
        q1 = gg['p1_bar'].to_numpy(float)
        q2 = gg['p2_bar'].to_numpy(float)
        b1 = q1 - np.roll(q1, 1)
        b2 = q2 - np.roll(q2, 1)
        e1 = max(e1, float(np.abs(gg['res1'].to_numpy(float) - A1m * b1).max()))
        e2 = max(e2, float(np.abs(gg['res2'].to_numpy(float) - A2m * b2).max()))
    check('P3.4 main 的逐时不平衡 == A·Δp（后向差分、t=0 回绕；管存动态在解里逐场景逐时成立）',
          'V3_BASELINE_plan.csv', True, e1 < 1e-6 and e2 < 1e-6,
          detail=f'max|res1 − A1·Δp1|={e1:.3e}，max|res2 − A2·Δp2|={e2:.3e} MWh')
    de_m = float(_bnum(P['main']['rp_day_end_imbal_MWh_max_abs']))
    de_bar = de_m / (A1m + A2m)     # 换成 bar 表述，容差与求解器可行性容差同量级
    check('P3.5 main 日末管存残差 == 0（p_T = p_0 被严格满足）',
          'V3_BASELINE_probe.csv', True, de_bar < 1e-4,
          detail=f'max|Σres|={de_m:.3e} MWh = {de_bar:.3e} bar（除以 A1+A2={A1m + A2m}）；'
                 f'阈值 1e-4 bar 与 Gurobi 可行性容差同量级，不是逐位')
    check('P3.6 steady 的"日末压力闭合误差"是结构性不存在（无闭合条件可违反，残差恒 0）',
          'V3_BASELINE_compare3.csv', 'not modelled (no line-pack state)',
          str(cmp3.loc[cmp3['metric'] == 'closure_by_construction', 'steady'].iloc[0]))
    half_band = (float(fz_m['ps2']) - float(fz_m['pd_min_frozen'])) / 2.0
    check('P3.7 防误归因：(p_s − p_min)/2 = %.1f bar 是 E28 静态帽方案的闭合签名，'
          '**不是** main 的闭合误差（main 实测为 0）' % half_band,
          'V3_BASELINE_probe.csv vs D2/D3', True,
          de_bar < 1e-4 and abs(de_bar - half_band) > 1.0,
          detail='正文若把 15/20/25 bar 写成"本文模型的闭合误差"就是把两个口径混了')
    check('P3.8 包含关系（成本）：main RP 期望成本 <= steady RP 期望成本',
          'V3_BASELINE_probe.csv', True,
          float(P['main']['rp_exp_cost']) <= float(P['steady']['rp_exp_cost']) + 1e-6,
          detail=f"main {float(P['main']['rp_exp_cost']):.3f} vs steady "
                 f"{float(P['steady']['rp_exp_cost']):.3f}"
                 f"（steady − main = {float(P['steady']['rp_exp_cost']) - float(P['main']['rp_exp_cost']):+.3f} 元/日）")
    check('P3.9 包含关系（碳地板）：main 最小期望碳 <= steady 最小期望碳',
          'V3_BASELINE_probe.csv', True,
          float(P['main']['carbon_min_exp_rp']) <= float(P['steady']['carbon_min_exp_rp']) + 1e-6,
          detail=f"main {float(P['main']['carbon_min_exp_rp']):.3f} vs steady "
                 f"{float(P['steady']['carbon_min_exp_rp']):.3f} t")
    check('P3.10 包含关系是严格的（管存确实换来东西，否则两档应逐位相同）',
          'V3_BASELINE_probe.csv', True,
          float(P['main']['rp_exp_cost']) < float(P['steady']['rp_exp_cost']) - 1e-6
          or float(P['main']['carbon_min_exp_rp']) < float(P['steady']['carbon_min_exp_rp']) - 1e-6,
          detail='严格性不成立就意味着本算例里管存是冗余的，那要如实写')
    check('P3.11 OOS 成本同向：main 的 100 留出日期望成本 <= steady 的',
          'V3_GC_PS70_{main,steady}_summary.csv', True,
          _bnum(smain['oos_mean_cost_sp']) <= _bnum(sstd['oos_mean_cost_sp']) + 1e-6,
          detail=f"main {_bnum(smain['oos_mean_cost_sp']):.2f} vs steady "
                 f"{_bnum(sstd['oos_mean_cost_sp']):.2f} 元/日")
    vio = {c: _bnum(cmp3.loc[cmp3['metric'] == 'pressure_viol_h', c].iloc[0])
           for c in ('main', 'steady')}
    check('P3.12 两耦合档压力越限小时数都是 0（没有靠制造越限来贬低基线）',
          'V3_BASELINE_compare3.csv', (0, 0), (vio['main'], vio['steady']),
          detail='由逐日 p_min/p_max 与声明边界比对：任一小时越界必使该日极值越界')
    shed = {c: _bnum(cmp3.loc[cmp3['metric'] == 'infeasible_days', c].iloc[0])
            for c in ('B0', 'main', 'steady')}
    check('P3.13 三列的不可行日数都是 0（没有用人為不可行抬高基线成本）',
          'V3_BASELINE_compare3.csv', 0, shed['steady'],
          detail=f"B0 {shed['B0']} / main {shed['main']} / steady {shed['steady']} 天")
    check('P3.13b 三列的切负荷天数都是 0（同上，能量侧也没有人为不可行）',
          'V3_GC_*_summary.csv', 0.0, _bnum(sstd['oos_n_days_shed_sp']),
          detail=f"main {_bnum(smain['oos_n_days_shed_sp'])} / steady "
                 f"{_bnum(sstd['oos_n_days_shed_sp'])} / B0 {_bnum(sb0['oos_n_days_shed_sp'])}")
    check('P3.14 两耦合档 RP 与碳最小 Gurobi 状态都是 OPTIMAL(2)',
          'V3_BASELINE_probe.csv', True,
          all(int(_bnum(P[a][k])) == 2 for a in ('main', 'steady')
              for k in ('rp_status', 'carbon_min_status')))

    # ---- P4 p_s 三点：无管存口径下源压杠杆是否仍在 ----
    for gm in ('main', 'steady'):
        sub = scan_b[(scan_b['gas_model'] == gm) & scan_b['present'].astype(str).isin(['True', 'true'])]
        sub = sub.sort_values('ps')
        ok_present = len(sub) == 3
        check(f'P4[{gm}] p_s=50/60/70 三格齐备', 'V3_BASELINE_ps_scan.csv', True, ok_present,
              detail=f'实到 ps 档 {sub["ps"].tolist()}')
        if not ok_present:
            continue
        cb = sub['carbon_min_exp_rp'].to_numpy(float)
        cc = sub['rp_exp_cost'].to_numpy(float)
        check(f'P4[{gm}] 碳地板随 p_s 严格单调下降（源压是减排杠杆）',
              'V3_BASELINE_ps_scan.csv', True, bool(cb[0] > cb[1] > cb[2]),
              detail=f'{cb[0]:.3f} > {cb[1]:.3f} > {cb[2]:.3f} t')
        check(f'P4[{gm}] RP 期望成本随 p_s 严格单调下降（提高源压同时更便宜）',
              'V3_BASELINE_ps_scan.csv', True, bool(cc[0] > cc[1] > cc[2]),
              detail=f'{cc[0]:.1f} > {cc[1]:.1f} > {cc[2]:.1f} 元')
        check(f'P4[{gm}] 三格碳地板求解状态都是 OPTIMAL(2)', 'V3_BASELINE_ps_scan.csv',
              [2, 2, 2], [int(v) for v in sub['carbon_min_status'].to_numpy()])
    sd = scan_b[scan_b['gas_model'] == 'steady'].sort_values('ps')
    if len(sd) == 3:
        lever_s = float(sd['carbon_min_exp_rp'].iloc[0] - sd['carbon_min_exp_rp'].iloc[-1])
        check('P4[steady] 无管存口径下杠杆幅度 > 0（源压杠杆不靠管存也能存在）',
              'V3_BASELINE_ps_scan.csv', True, lever_s > 1e-6,
              detail=f'steady 50→70 碳地板降 {lever_s:.3f} t；只判方向，不判百分比')
        check('P4[steady] 三格的管存使用小时数全为 0（杠杆的实现与管存无关）',
              'V3_BASELINE_ps_scan.csv', [0, 0, 0],
              [int(v) for v in sd['store_h'].to_numpy()])
    md = scan_b[scan_b['gas_model'] == 'main'].sort_values('ps')
    if len(md) == 3 and len(sd) == 3:
        lever_m = float(md['carbon_min_exp_rp'].iloc[0] - md['carbon_min_exp_rp'].iloc[-1])
        check('P4 两档杠杆同号（都为正 = 源压升高降碳），故"杠杆主要由管存撑起"这一说法不成立',
              'V3_BASELINE_ps_scan.csv', True,
              (lever_m > 0) == (lever_s > 0),
              detail=f'main 降 {lever_m:.3f} t / steady 降 {lever_s:.3f} t；'
                     f'幅度差 {lever_m - lever_s:+.3f} t 只作实测记录，不设判据')

    # ---- P5 不可比指标与禁入正文守卫 ----
    check('P5.1 steady 的管存利用率被显式标为无定义并附原因（不是 0%、不是 inf）',
          'V3_GC_PS70_steady_summary.csv', True,
          str(sstd.get('gas_oos_lp_util_na_reason', '')).startswith('no line-pack state')
          and (pd.isna(_bnum(sstd['gas_oos_lp_util_pct'])) or _bnum(sstd['gas_oos_lp_util_pct']) is None),
          detail=str(sstd.get('gas_oos_lp_util_na_reason', '')))
    check('P5.1b main 的管存利用率有定义且无该原因串',
          'V3_GC_PS70_main_summary.csv', '',
          '' if 'gas_oos_lp_util_na_reason' not in smain.index
          else str(smain['gas_oos_lp_util_na_reason']))
    # steady 档没有管存，压力只是"能不能送下这一小时的气"的容量旋钮：
    # 不等式 f1 <= f1ub(p1) 在 steady 里对 p1 无目标压力，最优基退化解，
    # p1 贴界小时数 / 压力带摆幅在这档里是求解器产物而非物理量。
    degenerate = ['gas_oos_p1_at_min_h', 'gas_oos_p1_at_max_h', 'gas_oos_lp_swing_mean_MWh']
    check('P5.2 steady 的三个压力带聚合确实存在于产物中（供 P5.3 判定其不可比）',
          'V3_GC_PS70_steady_summary.csv', degenerate,
          [k for k in degenerate if k in sstd.index])
    check('P5.3 steady 的压力带/节流聚合未进正文（它们与 main 不同名可比）',
          'ALLTEX', 'none',
          ', '.join(t for t in ['p1_at_max_h', 'lp_util', 'lp_swing_mean'] if t in ALLTEX)
          or 'none',
          detail='steady 的 f1_throttle_h/p1_at_*_h 含义与 main 不同（压力非状态，'
                 'PWL 上界只起容量作用，最优基有退化），并入正文前必须先换成可比口径')
    check('P5.4 内部格名与标签不得进正文',
          'ALLTEX', 'none',
          ', '.join(t for t in ['steady_node1', 'gas_model', 'A1_eff', 'V3_BASELINE']
                    if t in ALLTEX) or 'none',
          detail='正文只写口径与协议，不写实现标识符')
    check('P5.5 基线列名/臂名不得被写成 "proposed" 或 "ours"（避免把自己的模型当基线）',
          'ALLTEX', 'none',
          ', '.join(t for t in ['Kanelakis-style baseline arm', 'steady arm']
                    if t in ALLTEX) or 'none',
          detail='Task 4 正文并入时须用与 II 节表格一致的措辞（steady-state gas transmission）')

# ---------- Q. 基线并入正文后：IV-K 与引言/讨论章实际印出的每个基线数 vs CSV 字段 ----------
# 与 N13 同一纪律：期望值一律由 V3_BASELINE_{compare3,ps_scan,structure,probe}.csv 与
# 两耦合档 summary **现读现格式化**，再与正文串比对；绝不把正文里的常数抄进本脚本。
# 因此它是双向可失败的：正文改了数而 CSV 未重跑 -> 红；CSV 重跑动了数而正文没跟 -> 红；
# 把 IV-K 整节删掉 -> Q0 与下面全部红（不是"少了几条绿"）。
print('=== Q. 基线正文数字锁（Task 4 并入轮：IV-K / sec:baseline）===')
if not all(_have_b.values()):
    check('Q0 基线产物齐备（缺任一件则下面所有正文数字锁失去取证对象）',
          'results/V3_BASELINE_*.csv + V3_GC_*_summary.csv', True, False,
          detail='P0 已逐项报缺；此处再登记一条，防止 if 分支整体跳过造成"静默少断言而 FAIL=0"')
else:
    def _qflat(s):
        """正文归一化：\\% -> %（TeX 里 11.37\\% 否则匹配不到），空白折叠。"""
        return re.sub(r'\s+', ' ', s.replace('\\%', '%'))

    def _latexnum(v, fmt):
        """CSV 现读值 -> 正文该印的排版串。

        分节符按稿件自己的千分位规则插入（`normalize_numbers.py` 声明：整数部分
        4 位不分节、≥5 位用 `{,}`）。这只是排版，数值逐位不变；把它去掉会让
        "CSV 现读 -> 正文串"的锁看不见分节符而假红，所以规则放在这里而不是写死在正文。
        """
        s = format(v, fmt)
        sign = s[0] if s[:1] in '+-' else ''
        ip, dot, fp = s.lstrip('+-').partition('.')
        if len(ip) >= 5:
            groups = []
            while len(ip) > 3:
                groups.insert(0, ip[-3:])
                ip = ip[:-3]
            groups.insert(0, ip)
            ip = '{,}'.join(groups)
        return sign + ip + dot + fp

    _res_raw_q = _tex('sec_v_results.tex')
    _m_ivk = re.search(r'\\subsection\{Method-Versus-Method Baseline', _res_raw_q)
    IVK = _qflat(_res_raw_q[_m_ivk.start():]) if _m_ivk else ''
    INTRO_Q = _qflat(_tex('sec_i_intro.tex'))
    REL_Q = _qflat(_tex('sec_ii_related.tex'))
    DISC_Q = _qflat(_tex('sec_vi_vii_discussion.tex'))
    ALL_Q = _qflat(_tex('manuscript_v2.tex', 'sec_i_intro.tex', 'sec_ii_related.tex',
                        'sec_iii_framework.tex', 'sec_v_results.tex',
                        'sec_vi_vii_discussion.tex'))

    check('Q0a 正文存在 IV-K 基线小节（缺失则下面每条正文锁全部失去对象）',
          'sec_v_results.tex', True, bool(_m_ivk),
          detail='\\subsection{Method-Versus-Method Baseline: Steady-State Gas '
                 'Transmission} + \\label{sec:baseline}')
    check('Q0b IV-K 带 \\label{sec:baseline} 且被引言/相关工作/讨论章前指',
          'sec_v_results.tex / sec_i_intro.tex / sec_ii_related.tex / '
          'sec_vi_vii_discussion.tex', True,
          '\\label{sec:baseline}' in _res_raw_q
          and 'sec:baseline' in INTRO_Q and 'sec:baseline' in REL_Q
          and 'sec:baseline' in DISC_Q,
          detail='基线若只成一节孤立结果就没有回答 "compared to what"')
    check('Q0c 基线小节标题与对照表已就地命名（读者不需要回读编号）',
          'sec_v_results.tex', True,
          'Steady-State Gas Transmission' in IVK and '\\label{tab:baseline}' in _res_raw_q
          and 'Table~\\ref{tab:baseline}' in _res_raw_q,
          detail='表必须被正文引用，否则成品取证的"每张表都被引用"项会红')

    def qnum(label, value, fmt, source, needle=None, where=None, extra=''):
        """断言"正文印出的串 == 把 CSV 字段按 fmt 格式化出来的串"（先红后绿的主体）。
        期望串一律经 `_latexnum`，即含稿件千分位排版；needle 为显式串时原样使用。"""
        s = needle if needle is not None else _latexnum(value, fmt)
        w = IVK if where is None else where
        check(f'Q 正文数字 {label}', source, True, bool(s) and s in w,
              detail=f'CSV 现读 -> "{s}"；正文命中={bool(s) and s in w}'
                     + (f'；{extra}' if extra else ''))

    def m3(metric, col):
        return _bnum(cmp3.loc[cmp3['metric'] == metric, col].iloc[0])

    COLS_Q = ('B0', 'steady', 'main')
    # ---- Q1 三列并排：碳地板 / RP 成本 / OOS 成本（Tab. baseline 的三个 headline 行）----
    KEY = {'carbon_min_exp_rp': ('.3f', '碳最小 RP 期望碳 (tCO$_2$/日)'),
           'rp_exp_cost': ('.2f', 'RP 期望成本 (元/日)'),
           'oos_mean_cost_sp': ('.2f', 'OOS 期望成本 (元/日)')}
    for mk, (fmt, zh) in KEY.items():
        for col in COLS_Q:
            v = float(m3(mk, col))
            qnum(f'{zh} [{col}]', v, fmt, f'V3_BASELINE_compare3.csv:{mk}:{col}')
    # ---- Q2 求解时间与咬合统计（同一表的两行 + 正文那句）----
    for mk, fmt, zh in [('carbon_min_time', '.2f', '碳最小求解时间 (s)'),
                        ('rp_solve_time', '.2f', 'RP 求解时间 (s)')]:
        for col in ('steady', 'main'):
            qnum(f'{zh} [{col}]', float(m3(mk, col)), fmt,
                 f'V3_BASELINE_compare3.csv:{mk}:{col}')
    thr = {c: int(m3('f1_throttle_h', c)) for c in ('steady', 'main')}
    qnum('闸阀节流小时数 [steady]', thr['steady'], '.0f',
         'V3_BASELINE_compare3.csv:f1_throttle_h:steady')
    qnum('闸阀节流小时数 [main]', thr['main'], '.0f',
         'V3_BASELINE_compare3.csv:f1_throttle_h:main')
    HRS_Q = int(_bnum(sstd['gas_oos_hours_total']))
    check('Q2a 节流计数的分母是 2400 = 100 留出日 × 24 h，两耦合档相同',
          'V3_GC_PS70_{steady,main}_summary.csv', (HRS_Q, HRS_Q),
          (HRS_Q, int(_bnum(smain['gas_oos_hours_total']))),
          detail='788 与 1776 若不共享分母就不能并排成"32.8% 对 74%"')
    qnum('steady 节流占比 (%)', 100 * thr['steady'] / HRS_Q, '.1f',
         'V3_BASELINE_compare3.csv + gas_oos_hours_total', needle='32.8%',
         extra=f'现算 {100 * thr["steady"] / HRS_Q:.4f}%')
    qnum('main 节流占比 (%)', 100 * thr['main'] / HRS_Q, '.0f',
         'V3_BASELINE_compare3.csv + gas_oos_hours_total', needle='74%',
         extra=f'现算 {100 * thr["main"] / HRS_Q:.4f}%（正文已发表的 74% 同一口径）')
    sh = {'steady': int(_bnum(P['steady']['rp_store_h'])),
          'main': int(_bnum(P['main']['rp_store_h']))}
    check('Q2b 管存小时数取自同进程同场景的 probe（steady 0 / main 157）',
          'V3_BASELINE_probe.csv:rp_store_h', (0, 157), (sh['steady'], sh['main']),
          detail=f'实测 {sh}')
    qnum('表行"scenario-hours with nonzero line-pack change 0 & 157"', None, None,
         'V3_BASELINE_probe.csv:rp_store_h', needle='0 & 157')
    qnum('B0 无气网 => 节流计数不适用', None, None, 'V3_BASELINE_compare3.csv',
         needle='Hours with throttled gate-station valve (of 2400) & -- & 788 & 1776',
         extra='B0 列印 "--"，不得给一个 0 冒充测量')
    # ---- Q3 派生量：差额、百分比、倍数（必须与 CSV 现算逐位对齐）----
    d_rp = float(m3('rp_exp_cost', 'steady')) - float(m3('rp_exp_cost', 'main'))
    d_oos = float(m3('oos_mean_cost_sp', 'steady')) - float(m3('oos_mean_cost_sp', 'main'))
    d_c = float(m3('carbon_min_exp_rp', 'steady')) - float(m3('carbon_min_exp_rp', 'main'))
    qnum('steady − main 的 RP 成本差 (元/日)', d_rp, '+.1f',
         'V3_BASELINE_compare3.csv:rp_exp_cost 两列之差')
    qnum('steady − main 的 RP 成本差 (%)', 100 * d_rp / float(m3('rp_exp_cost', 'main')),
         '+.2f', '同上（分母 = main）', needle='+1.18%',
         extra=f'现算 {100 * d_rp / float(m3("rp_exp_cost", "main")):.4f}%')
    qnum('steady − main 的 OOS 成本差 (元/日)', d_oos, '+.1f',
         'V3_BASELINE_compare3.csv:oos_mean_cost_sp 两列之差')
    qnum('steady − main 的 OOS 成本差 (%)',
         100 * d_oos / float(m3('oos_mean_cost_sp', 'main')), '+.2f',
         '同上（分母 = main）', needle='+1.68%',
         extra=f'现算 {100 * d_oos / float(m3("oos_mean_cost_sp", "main")):.4f}%')
    qnum('steady − main 的碳地板差 (tCO$_2$/日)', d_c, '+.3f',
         'V3_BASELINE_compare3.csv:carbon_min_exp_rp 两列之差')
    qnum('steady − main 的碳地板差 (%)',
         100 * d_c / float(m3('carbon_min_exp_rp', 'main')), '+.2f', '同上（分母 = main）',
         needle='+0.85%', extra=f'现算 {100 * d_c / float(m3("carbon_min_exp_rp", "main")):.4f}%')
    qnum('碳最小求解加速倍数 (×)',
         float(m3('carbon_min_time', 'main')) / float(m3('carbon_min_time', 'steady')),
         '.1f', 'V3_BASELINE_compare3.csv:carbon_min_time 两列之比',
         needle='$27.9\\times$')
    qnum('RP 求解加速倍数 (×)',
         float(m3('rp_solve_time', 'main')) / float(m3('rp_solve_time', 'steady')),
         '.1f', 'V3_BASELINE_compare3.csv:rp_solve_time 两列之比', needle='$50.4\\times$')
    qnum('删除气网（B0）相对 main 的 OOS 成本变化 (%)，正文以"看似更便宜"表述',
         100 * (float(m3('oos_mean_cost_sp', 'B0')) - float(m3('oos_mean_cost_sp', 'main')))
         / float(m3('oos_mean_cost_sp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv:oos_mean_cost_sp B0/main', needle='0.51%',
         extra='符号为负（B0 更便宜），正文写 "appears to save 0.51%"，不得写成成本更高')
    check('Q3a B0 相对 main 的 OOS 差是**负**的（"更便宜"是被支配方向的假象，正文措辞依赖它）',
          'V3_BASELINE_compare3.csv', True,
          float(m3('oos_mean_cost_sp', 'B0')) < float(m3('oos_mean_cost_sp', 'main')),
          detail=f"B0 {float(m3('oos_mean_cost_sp', 'B0')):.2f} < main "
                 f"{float(m3('oos_mean_cost_sp', 'main')):.2f}")
    check('Q3b 支配方向：steady 在成本与碳上**双双不优于** main（正文"dominated"一句的依据）',
          'V3_BASELINE_compare3.csv', True,
          d_rp > 0 and d_oos > 0 and d_c > 0,
          detail=f'+{d_rp:.1f} / +{d_oos:.1f} / +{d_c:.3f}；任一翻号则正文须改写')
    # ---- Q3' Tab. baseline 的**整行**锁：单个表元被改也必红 ----
    # 逐数锁有一个已知盲区：同一个数在正文与表里各出现一次时，只改表里那一处不会翻红
    # （轮 8 M1 变异实测：33.190->33.191 与 3688->3690 都逃过了逐数锁）。整行锁把
    # "标签 + 三列值"当一个串比对，任何一格单独改动都会红。
    def _row(label, cells):
        return label + ' & ' + ' & '.join(cells)

    NA = '--'
    ROWS_Q = [
        (_row('Daily-closure constraints',
              [NA, format(int(_bnum(SC['steady']['n_p1cyc']))
                          + int(_bnum(SC['steady']['n_p2cyc'])), '.0f'),
               format(int(_bnum(SC['main']['n_p1cyc']))
                      + int(_bnum(SC['main']['n_p2cyc'])), '.0f')]),
         'V3_BASELINE_structure.csv:n_p1cyc+n_p2cyc'),
        (_row('Model constraints',
              [format(int(m3('rp_n_cons', c)), '.0f') for c in COLS_Q]),
         'V3_BASELINE_compare3.csv:rp_n_cons'),
        (_row('Scenario-hours with nonzero line-pack change (of 192)',
              [NA, format(sh['steady'], '.0f'), format(sh['main'], '.0f')]),
         'V3_BASELINE_probe.csv:rp_store_h'),
        (_row('Min.\\ exp.\\ carbon (tCO$_2$/day)',
              [format(float(m3('carbon_min_exp_rp', c)), '.3f') for c in COLS_Q]),
         'V3_BASELINE_compare3.csv:carbon_min_exp_rp'),
        (_row('Risk-neutral exp.\\ cost (CNY/day)',
              [_latexnum(float(m3('rp_exp_cost', c)), '.2f') for c in COLS_Q]),
         'V3_BASELINE_compare3.csv:rp_exp_cost'),
        (_row('Out-of-sample exp.\\ cost (CNY/day)',
              [_latexnum(float(m3('oos_mean_cost_sp', c)), '.2f') for c in COLS_Q]),
         'V3_BASELINE_compare3.csv:oos_mean_cost_sp'),
        (_row('Hours with throttled gate-station valve (of 2400)',
              [NA, format(thr['steady'], '.0f'), format(thr['main'], '.0f')]),
         'V3_BASELINE_compare3.csv:f1_throttle_h'),
        (_row('Carbon-minimum solve time (s)',
              [NA, format(float(m3('carbon_min_time', 'steady')), '.2f'),
               format(float(m3('carbon_min_time', 'main')), '.2f')]),
         'V3_BASELINE_compare3.csv:carbon_min_time'),
        (_row('Risk-neutral solve time (s)',
              [NA, format(float(m3('rp_solve_time', 'steady')), '.2f'),
               format(float(m3('rp_solve_time', 'main')), '.2f')]),
         'V3_BASELINE_compare3.csv:rp_solve_time'),
    ]
    for needle, src in ROWS_Q:
        qnum('表行整行在场 %s' % needle.split(' & ')[0], None, None, src, needle=needle)
    check('Q3c 表行锁未静默缩水（9 行 = 口径 2 + 结构 3 + 结果 4 的登记数）',
          '本脚本 ROWS_Q', 9, len(ROWS_Q),
          detail='少一行就等于把一列基线数从锁集里放出去，必须显式改而不是删')

    # ---- Q4 结构口径（"去掉的是管存与闭合，不是别的"）----
    sc_m, sc_s = SC['main'], SC['steady']
    qnum('基线删除的日循环闭合约束数（main 侧 8+8）', 
         int(_bnum(sc_m['n_p1cyc'])) + int(_bnum(sc_m['n_p2cyc'])), '.0f',
         'V3_BASELINE_structure.csv:n_p1cyc+n_p2cyc', needle='0 rather than 16',
         extra=f'steady 侧实测 {int(_bnum(sc_s["n_p1cyc"])) + int(_bnum(sc_s["n_p2cyc"]))} 条')
    qnum('两耦合档 RP 约束数（3688 对 3704）', None, None,
         'V3_BASELINE_structure.csv:n_cons', needle='3688 constraints against 3704',
         extra=f"structure: main {sc_m['n_cons']} / steady {sc_s['n_cons']}；"
               f"compare3: main {int(m3('rp_n_cons', 'main'))} / "
               f"steady {int(m3('rp_n_cons', 'steady'))}")
    _nc_m3 = (int(m3('rp_n_cons', 'main')), int(m3('rp_n_cons', 'steady')))
    _nc_sm = (int(_bnum(smain['rp_n_cons'])), int(_bnum(sstd['rp_n_cons'])))
    _nc_sc = (int(_bnum(sc_m['n_cons'])), int(_bnum(sc_s['n_cons'])))
    check('Q4a 约束数三处同源：structure.n_cons == compare3.rp_n_cons == summary.rp_n_cons',
          'structure vs compare3 vs summaries', _nc_sc,
          _nc_m3 if _nc_m3 == _nc_sm else ('summary-mismatch', _nc_sm),
          detail=f'structure={_nc_sc} / compare3={_nc_m3} / summary={_nc_sm}；'
                 f'表里印的两个约束数由同一次建模计数产生，不是手填')
    qnum('无气网列的 RP 约束数', int(m3('rp_n_cons', 'B0')), '.0f',
         'V3_BASELINE_compare3.csv:rp_n_cons:B0')
    check('Q4b steady 无初始压力变量、main 有（正文 "no initial-pressure variables"）',
          'V3_BASELINE_structure.csv:has_p0_1/2', (False, False),
          (bool(_bnum(sc_s['has_p0_1'])), bool(_bnum(sc_s['has_p0_2']))))
    check('Q4b2 main 侧同两项为 True（否则"no initial-pressure variables"是删了本文的状态）',
          'V3_BASELINE_structure.csv:has_p0_1/2', (True, True),
          (bool(_bnum(sc_m['has_p0_1'])), bool(_bnum(sc_m['has_p0_2']))))
    qnum('逐时平衡条数（steady_node1+steady_node2）',
         int(_bnum(sc_s['n_steady_node1'])) + int(_bnum(sc_s['n_steady_node2'])), '.0f',
         'V3_BASELINE_structure.csv:n_steady_node1+2', needle='the same 384 hourly nodal')
    qnum('动态节点平衡条数（main 侧 node1+node2）',
         int(_bnum(sc_m['n_node1'])) + int(_bnum(sc_m['n_node2'])), '.0f',
         'V3_BASELINE_structure.csv:n_node1+2', needle='384 dynamic')
    check('Q4c 正文写"384 对 384"确实成立（替换而非增删这一族）',
          'V3_BASELINE_structure.csv', True,
          int(_bnum(sc_s['n_steady_node1'])) + int(_bnum(sc_s['n_steady_node2']))
          == int(_bnum(sc_m['n_node1'])) + int(_bnum(sc_m['n_node2'])) == 384)
    for _k, _lbl in [('n_scen', 'RP 场景数'), ('e_grid', '电网排放因子'),
                     ('n_test_days', '留出日数')]:
        check(f'Q4d 三列口径同值（{_lbl}）', 'V3_BASELINE_compare3.csv:' + _k, True,
              len({str(m3(_k, c)) for c in COLS_Q}) == 1,
              detail={c: str(m3(_k, c)) for c in COLS_Q})
    qnum('正文声明的场景数（8）', int(m3('n_scen', 'main')), '.0f',
         'V3_BASELINE_compare3.csv:n_scen:main', needle='the 8 scenarios')
    qnum('正文声明的排放因子（0.8922）', float(m3('e_grid', 'main')), '.4f',
         'V3_BASELINE_compare3.csv:e_grid:main', needle='0.8922~tCO$_2$/MWh')
    qnum('正文声明的留出日数（100）', int(m3('n_test_days', 'main')), '.0f',
         'V3_BASELINE_compare3.csv:n_test_days:main', needle='the 100 held-out days')

    # ---- Q5 源压杠杆归因（本轮最重要的新事实）----
    sd_q = scan_b[scan_b['gas_model'] == 'steady'].sort_values('ps')
    md_q = scan_b[scan_b['gas_model'] == 'main'].sort_values('ps')
    cb_s = sd_q['carbon_min_exp_rp'].to_numpy(float)
    cb_m = md_q['carbon_min_exp_rp'].to_numpy(float)
    _ps_i = sd_q['ps'].to_numpy(float)
    for i in range(3):
        # steady 三档地板全部新印在 IV-K，逐档锁；main 三档只把 @70 印进 IV-K（@50/@60
        # 已由 IV-B 表与 A2/A3/A4 锁过），这里只锁确实印出的那个，不做"整表都在正文"的假断言。
        qnum(f'steady 碳地板 @{_ps_i[i]:.0f} bar', cb_s[i], '.3f',
             'V3_BASELINE_ps_scan.csv:carbon_min_exp_rp[steady]')
    qnum('正文 "37.448, 34.929 and 33.190" 三值序列整体在场（防"数对但句子被拆"）', None, None,
         'V3_BASELINE_ps_scan.csv:carbon_min_exp_rp[steady] 三档',
         needle='%s, %s and %s' % tuple(format(v, '.3f') for v in cb_s))
    qnum('main 碳地板 @70 bar（IV-K 表右列）', cb_m[2], '.3f',
         'V3_BASELINE_ps_scan.csv:carbon_min_exp_rp[main]')
    check('Q5g main @50/@60 两档地板仍只在 IV-B/IV-J 出现（本轮未把它们搬进 IV-K）',
          'V3_GC_scan_carbon.csv vs V3_BASELINE_ps_scan.csv', True,
          abs(cb_m[0] - float(main.loc['PS50', 'carbon_min_exp_rp'])) < 1e-9
          and abs(cb_m[1] - float(main.loc['PS60', 'carbon_min_exp_rp'])) < 1e-9
          and abs(cb_m[2] - float(main.loc['PS70', 'carbon_min_exp_rp'])) < 1e-9,
          detail='基线扫描的 main 列必须与主链存档逐位一致，否则"同一算例两个口径"这句话不成立')
    lev_s = 100 * (cb_s[0] - cb_s[-1]) / cb_s[0]
    lev_m = 100 * (cb_m[0] - cb_m[-1]) / cb_m[0]
    qnum('steady 的 50→70 杠杆降幅 (%)', lev_s, '.2f',
         'V3_BASELINE_ps_scan.csv[steady] 端点现算', needle='11.37%')
    qnum('main 的 50→70 杠杆降幅 (%)', lev_m, '.2f',
         'V3_BASELINE_ps_scan.csv[main] 端点现算（正文已发表 11.19%）', needle='11.19%')
    qnum('两档杠杆之差的绝对值 (百分点)', abs(lev_s - lev_m), '.2f',
         'V3_BASELINE_ps_scan.csv 两档现算', needle='$0.18$ percentage points',
         extra=f'现算 |{lev_s:.4f} - {lev_m:.4f}| = {abs(lev_s - lev_m):.4f} pp')
    check('Q5a 归因判据：两档杠杆之差 < 1 个百分点（正文"几乎不变"的说法以此为限）',
          'V3_BASELINE_ps_scan.csv', True, abs(lev_s - lev_m) < 1.0,
          detail=f'实测 {abs(lev_s - lev_m):.4f} pp；若日后重跑把差拉开到 >=1pp，'
                 f'"a property of the deliverability boundary" 这句必须改写')
    check('Q5b "both monotone and front-loaded the same way"：两档 50→60 步都大于 60→70 步',
          'V3_BASELINE_ps_scan.csv', True,
          all(cb[0] > cb[1] > cb[2] and (cb[0] - cb[1]) > (cb[1] - cb[2])
              for cb in (cb_s, cb_m)),
          detail=f'steady 步长 {cb_s[0] - cb_s[1]:.3f}/{cb_s[1] - cb_s[2]:.3f}，'
                 f'main {cb_m[0] - cb_m[1]:.3f}/{cb_m[1] - cb_m[2]:.3f}')
    check('Q5c 杠杆只在**碳**侧对照：两档 RP 成本同样单调下降（正文未无限定引用，此处仍锁）',
          'V3_BASELINE_ps_scan.csv', True,
          all(sub['rp_exp_cost'].to_numpy(float)[0] >
              sub['rp_exp_cost'].to_numpy(float)[-1] for sub in (sd_q, md_q)))
    check('Q5d steady 三格的管存使用小时数全为 0（杠杆在"零管存"口径下实现）',
          'V3_BASELINE_ps_scan.csv:store_h', [0, 0, 0],
          [int(v) for v in sd_q['store_h'].to_numpy()])
    check('Q5e 归因句在正文在场：IV-K 与讨论章都把杠杆归到可交付边界、并否定管存来源',
          'sec_v_results.tex + sec_vi_vii_discussion.tex', True,
          'not a by-product of the line-pack dynamics' in IVK
          and 'a property of the \\emph{pressure-dependent deliverability boundary}' in IVK
          and 'not a by-product of the gas held in the pipes' in DISC_Q
          and 'The lever is therefore a property of the pressure-dependent '
              'deliverability boundary' in DISC_Q,
          detail='删掉任一侧的归因限定句都会红：这是"改写既有句子"的可执行形式')
    check('Q5f 讨论章机制段的旧归因未回潮（不得把杠杆说成管存的产物）',
          'sec_vi_vii_discussion.tex', 'none',
          ', '.join(t for t in ['lever because gas is stored', 'lever arises from line pack',
                                'lever is created by line pack', 'lever depends on line-pack']
                    if t in DISC_Q) or 'none')

    # VSS 与 EVPI 之间没有普适序：WS<=RP<=EEV 只给出两条非负性。反例
    # ws,rp,eev = 0,1,101 满足前提却有 VSS=100 > EVPI=1，所以旧句 "and hence
    # 0<=VSS<=EVPI hold" 不成立。这里锁"旧写法缺席 + 限定句在场 + 等价条件在场"，
    # 把普适序写回来会让这条先红。用去空格串比较，免得被 `0 \le` / `0\le` 两种排版绕过。
    _ns_q = re.sub(r'\s', '', ALL_Q)
    check('Q5h VSS<=EVPI 未被写成普适定理（旧 and hence 缺席，限定句与等价条件在场）',
          'ALL_Q(去空格)', True,
          r'andhence$0\le\mathrm{VSS}\le\mathrm{EVPI}$' not in _ns_q
          and r'$0\le\mathrm{VSS}\le\mathrm{EVPI}$hold' not in _ns_q
          and r'\le\mathrm{EVPI}$isguaranteed' not in _ns_q
          and r'\le\mathrm{EVPI}$areguaranteed' not in _ns_q
          and 'nouniversalorderingisclaimed' in _ns_q
          and r'\mathrm{EEV}+\mathrm{WS}\le2\,\mathrm{RP}' in _ns_q,
          detail='反例 (ws,rp,eev)=(0,1,101)：前提真而 VSS<=EVPI 假；'
                 '正文只可主张两条非负性 + 实测满足的序')

    # ---- Q6 引言/相关工作/讨论章印出的基线数 ----
    qnum('引言 C2 的 RP 成本差 (+1.18%)', 100 * d_rp / float(m3('rp_exp_cost', 'main')),
         '.2f', 'V3_BASELINE_compare3.csv', needle='+1.18%', where=INTRO_Q)
    qnum('引言 C2 的 OOS 成本差 (+1.68%)',
         100 * d_oos / float(m3('oos_mean_cost_sp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='+1.68%', where=INTRO_Q)
    qnum('引言 C2 的碳地板差 (+0.85%)',
         100 * d_c / float(m3('carbon_min_exp_rp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='+0.85%', where=INTRO_Q)
    qnum('引言 C2 的加速倍数 (27.9×)',
         float(m3('carbon_min_time', 'main')) / float(m3('carbon_min_time', 'steady')),
         '.1f', 'V3_BASELINE_compare3.csv', needle='$27.9\\times$', where=INTRO_Q)
    qnum('引言 C2 的 steady 杠杆 (11.37%)', lev_s, '.2f',
         'V3_BASELINE_ps_scan.csv[steady]', needle='11.37%', where=INTRO_Q)
    qnum('引言结果预览段的 steady 杠杆 (11.37%)', lev_s, '.2f',
         'V3_BASELINE_ps_scan.csv[steady]', needle='11.37%', where=INTRO_Q)
    qnum('引言 C2 的 main 杠杆锚点 11.19% 未被改写', lev_m, '.2f',
         'V3_BASELINE_ps_scan.csv[main]', needle='11.19%', where=INTRO_Q)
    qnum('讨论章机制段的 steady 杠杆 (11.37%)', lev_s, '.2f',
         'V3_BASELINE_ps_scan.csv[steady]', needle='11.37%', where=DISC_Q)
    qnum('讨论章机制段的 main 杠杆 (11.19%)', lev_m, '.2f',
         'V3_BASELINE_ps_scan.csv[main]', needle='11.19%', where=DISC_Q)
    qnum('讨论章"两条通道"句的 RP 成本差 (+1.18%)',
         100 * d_rp / float(m3('rp_exp_cost', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='risk-neutral cost by $1.18%$', where=DISC_Q)
    qnum('讨论章"两条通道"句的 OOS 成本差 (1.68%)',
         100 * d_oos / float(m3('oos_mean_cost_sp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='out-of-sample cost by $1.68%$', where=DISC_Q)
    qnum('讨论章"两条通道"句的碳地板差 (0.85%)',
         100 * d_c / float(m3('carbon_min_exp_rp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='carbon floor by $0.85%$', where=DISC_Q)
    qnum('讨论章"两条通道"句的 B0 对照 (0.51%)',
         100 * (float(m3('oos_mean_cost_sp', 'B0')) - float(m3('oos_mean_cost_sp', 'main')))
         / float(m3('oos_mean_cost_sp', 'main')), '.2f',
         'V3_BASELINE_compare3.csv', needle='$0.51%$ out of sample', where=DISC_Q)
    # Q6a/Q6b 的期望串在轮 18 被**更正**过：原期望把 Ordoudis/Kanelakis 说成
    # "不带节点压力状态 / Nodal pressure state=No"，而我下载两篇原文核对后发现那是反的
    # （Ordoudis Eq.(2) 即 Weymouth + Eq.(9a)-(9b) 带日际衔接的管存；
    #   Kanelakis Eq.(32) 亦为 Weymouth、有节点压力变量，linepack 全文 0 命中）。
    # 判据的**意图不变**（不得悄悄改写对他人论文的定性），但方向翻过来：
    # 现在同时要求"更正后的表述在场"且"已被否证的旧断言不得回来"，退回即红。
    check('Q6a 相关工作章对 Kanelakis 的定性仍逐字保留，且合评句已按轮 18 原文核对更正',
          'sec_ii_related.tex vs 两篇原文', True,
          'augmented with steady-state gas transmission constraints, and demonstrated it '
          'on the medium-size Greek systems' in REL_Q
          and 'commitment over steady-state transmission with no line-pack term at all' in REL_Q
          and 'Section~\\ref{sec:baseline} implements it on the present case study' in REL_Q
          and 'neither carries line-pack dynamics as a pressure state' not in REL_Q,
          detail='对其模型的定性句必须逐字保留；旧合评句已被原文否证，回来即红')
    check('Q6b Table I 两行定性未回退：Ordoudis/Kanelakis 的 Nodal pressure state 均为 Yes'
          '（轮 18 按 Eq.(2)/Eq.(32) 更正），且 Kanelakis 行 Line-pack=No 未动',
          'sec_ii_related.tex', True,
          'Steady-state gas transmission constraints & Yes (steady-state) & No & '
          'Two-stage stochastic unit commitment & No & System level (Greek system)'
          in REL_Q
          and 'Weymouth flow linearized over fixed pressure points, tractable MILP & '
              'Yes (linearized) & Yes (quasi-dynamic)' in REL_Q
          and 'No (steady-state)' not in REL_Q,
          detail='对照表里对他文的定性只能经原文核对后改动，改动须双向可判')
    check('Q6c 正文未把基线说成"完整复现了该方法"（它复现的是气网口径，不是整篇工作）',
          'ALL_Q', True,
          'implements it on the present case study' in REL_Q
          and 're-implements the steady-state transmission' in DISC_Q
          and 'we do not replicate the published formulation as a whole' not in DISC_Q
          and 'full replication' not in ALL_Q)

    # ---- Q7 反向守卫：内部标识、不可比口径、以及"本文当基线"的措辞 ----
    for _tok in ['store_h_rp', 'rp_store_h', 'oos_mean_cost_sp', 'carbon_min_exp_rp',
                 'n_p1cyc', 'n_steady_node1', 'has_p0_1', 'ps_scan', 'compare3',
                 'gas_oos_hours_total', 'V3_BASELINE']:
        check(f'Q7 内部字段名/文件名不得进正文：{_tok}', 'ALL_Q', 'none',
              _tok if _tok in ALL_Q else 'none',
              detail='正文只写口径与协议；字段名留给脚本与 notes')
    for _tok in ['Kanelakis-style baseline arm', 'steady arm', 'baseline arm',
                 'proposed baseline', 'our baseline arm']:
        check(f'Q7b 基线措辞须与 II 节表格一致，不得出现：{_tok}', 'ALL_Q', 'none',
              _tok if _tok in ALL_Q else 'none',
              detail='统一说 steady-state gas transmission，不把本文的臂标签当方法名')
    check('Q7c 不可比聚合仍不得进正文（steady 的压力带贴界/管存利用率/摆幅是退化解产物）',
          'V3_GC_PS70_steady_summary.csv', 'none',
          ', '.join(t for t in ['p1_at_max_h', 'p1_at_min_h', 'lp_util', 'lp_swing_mean']
                    if t in ALL_Q) or 'none',
          detail='P5.3 同源；基线并入后正文引用的是节流小时数与成本/碳，不是压力带计数')
    check('Q7d 正文没有把 788 与 1776 说成同一件事的两次测量（口径差异必须就地承认）',
          'sec_v_results.tex', True,
          'the weaker of the two diagnostics' in IVK
          and 'in the baseline the pressure is not a state' in IVK,
          detail='压力非状态时 PWL 上界只起容量作用，节流计数在其中一列更弱；'
                 '不写这句就是拿不可比数并列')
    check('Q7e 11.37% 与 11.19% 不得被写成"基线的杠杆更强/更弱"的排名式断言',
          'ALL_Q', 'none',
          ', '.join(t for t in ['stronger lever', 'weaker lever', 'larger lever',
                                'the baseline lever wins', 'lever is greater']
                    if t in ALL_Q) or 'none',
          detail='两者之差 0.18pp 只支持"几乎不变"，不支持排序；排序性措辞会超出证据')
    check('Q7f 基线小节未声称本文方法在求解时间上占优（倍数是基线一侧的优势）',
          'sec_v_results.tex', True,
          'What it does buy is speed' in IVK and 'faster on those two runs' in IVK
          and 'slower than the baseline' not in IVK)

# ---------- R. 口径带（IV-L / sec:band）正文数字锁 ----------
print('=== R. 稳健性口径带（IV-L sec:band）正文引用的每个带数 vs V3_BAND_*.csv 现读现算 ===')
# 轮 9 并入稳健性带。R 节把正文**实际印出**的每个带数绑到 V3_BAND_{scan,summary}.csv
# 的字段上：期望串一律由 CSV 现读现格式化，绝不把正文里的常数抄进脚本。因此它双向可
# 失败：正文改了数而 CSV 未重跑 -> 红；CSV 重跑动了数而正文没跟 -> 红。
# 另加**退化格守卫**：正文任何区间端点都不得是 0.000%（恒等格混入区间的签名），且
# 界导出段（网状那格）不得与点值段合成一个区间。
_BAND_SCAN_F = os.path.join(RES, 'V3_BAND_scan.csv')
_BAND_SUM_F = os.path.join(RES, 'V3_BAND_summary.csv')
_HAVE_BAND = os.path.exists(_BAND_SCAN_F) and os.path.exists(_BAND_SUM_F)
check('R0 口径带存档在位（缺档则 R 节失去对象，不得静默通过）',
      'V3_BAND_scan.csv + V3_BAND_summary.csv', True, _HAVE_BAND,
      detail='band_scan_v3.py 的两个产物')
_BAND_WORDS = {0: 'no', 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five',
               6: 'six', 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten',
               11: 'eleven', 12: 'twelve'}
_IVL_RE = re.compile(r'\\subsection\{Certified Caliber Band')
_m_ivl = _IVL_RE.search(RESULTS_TEX_RAW)
IVL = _flat(RESULTS_TEX_RAW[_m_ivl.start():]) if _m_ivl else ''
check('R0b 正文存在 IV-L 口径带小节（标题 + \\label{sec:band}）',
      'sec_v_results.tex', True,
      bool(_m_ivl) and '\\label{sec:band}' in RESULTS_TEX_RAW,
      detail='\\subsection{Certified Caliber Band ...} + \\label{sec:band}')
check('R0c IV-L 排在 IV-K（sec:baseline）之后，且被引言/讨论章前指',
      'sec_v_results.tex / sec_i_intro.tex / sec_vi_vii_discussion.tex', True,
      bool(_m_ivl) and RESULTS_TEX_RAW.find('sec:baseline') < RESULTS_TEX_RAW.find(
          '\\label{sec:band}')
      and 'sec:band' in _flat(_tex('sec_i_intro.tex'))
      and 'sec:band' in _flat(_tex('sec_vi_vii_discussion.tex')),
      detail='并入的目的正是让 headline 句前指本节，而不是加一节孤立结果')
if not _HAVE_BAND:
    check('R1--R20 全部跳过：口径带存档缺失', 'V3_BAND_*.csv', True, False,
          detail='先跑 band_scan_v3.py 生成存档')
else:
    # dtype=str：True/False 列必须按字符串比，否则 pandas 会把它们解析成 numpy bool，
    # `== 'True'` 恒假，检查就成了"永远红"的假守卫。
    bsc = pd.read_csv(_BAND_SCAN_F, encoding='utf-8-sig', dtype=str)
    bsu = pd.read_csv(_BAND_SUM_F, encoding='utf-8-sig', dtype=str).set_index('metric')

    def _band_val(cell, metric):
        r = bsc[(bsc['cell_id'] == cell) & (bsc['metric'] == metric)]
        return None if r.empty else r.iloc[0]

    def rnum(label, cell, metric, fmt, extra=''):
        """断言"正文 IV-L 印出的串 == CSV 该格该指标按 fmt 格式化出来的串"。"""
        r = _band_val(cell, metric)
        if r is None or r['value_pct'] == 'NOT_RUN':
            return check(f'R 正文数字 {label}', 'V3_BAND_scan.csv', True, False,
                         detail=f'{cell}/{metric} 在存档里没有可用取值')
        s = format(float(r['value_pct']), fmt)
        return check(f'R 正文数字 {label}', 'V3_BAND_scan.csv', True, s in IVL,
                     detail=f'CSV 现读 -> "{s}"（{fmt}，basis={r["basis"]}，'
                            f'certified={r["certified"]}）；正文命中={s in IVL}'
                            + (f'；{extra}' if extra else ''))

    # ---- R1--R8：四个认证点值格 × 两个头条指标，逐格锁 ----
    _PT_CELLS = ['A_declared', 'B_ef055', 'C_heatreal', 'D_steady']
    for _c in _PT_CELLS:
        rnum(f'{_c} lever', _c, 'lever_50_70', '.4f')
        rnum(f'{_c} uplift@70', _c, 'uplift_ps70', '.4f')
    # ---- R9--R10：网状那格的两个界导出读数 ----
    rnum('E_mesh lever（界导出，非界）', 'E_mesh', 'lever_50_70', '.4f',
         'basis=bound_lower，正文须标 not a bound')
    rnum('E_mesh uplift@70（严格下界）', 'E_mesh', 'uplift_ps70', '.4f',
         'basis=bound_lower，正文须写 >=')
    _me = _band_val('E_mesh', 'lever_50_70')
    check('R10b 网状两格在存档里确为 bound_lower / certified=False',
          'V3_BAND_scan.csv', True,
          all(_band_val('E_mesh', m)['basis'] == 'bound_lower'
              and _band_val('E_mesh', m)['certified'] == 'False'
              for m in ('lever_50_70', 'uplift_ps70')),
          detail=f'存档 basis={_me["basis"]}')
    # ---- R11：恒等格原始值仍在表里（排除 != 删除），但不得充当区间端点 ----
    _dn = _band_val('D_nogas', 'uplift_ps70')
    check('R11 恒等格 0.0000 仍印在带表里（行未被静默删除）',
          'V3_BAND_scan.csv', True,
          _dn is not None and format(float(_dn['value_pct']), '.4f') in IVL,
          detail=f'存档 value={_dn["value_pct"]} degenerate={_dn["degenerate"]}')
    check('R11b 恒等格在存档里被显式标记为退化且被排除出区间派生',
          'V3_BAND_scan.csv', True,
          _dn['degenerate'] == 'True' and _dn['excluded_from_range'] == 'True'
          and _dn['in_range_pool'] == 'True',
          detail='degenerate/excluded_from_range=True，in_range_pool 仍为 True')
    _ends = [(float(a), float(b)) for a, b in re.findall(
        r'(\d+\.\d+)--(\d+\.\d+)', IVL)]
    check('R12 退化格守卫：正文任何区间端点都不是 0.00（防恒等格再混入）',
          'sec_v_results.tex IV-L', True,
          bool(_ends) and all(a > 1e-9 and b > 1e-9 for a, b in _ends),
          detail=f'正文区间端点对={_ends}；只要有一个 0.00 就红')
    check('R12b 存档侧同一守卫：summary 四个区间端点全部 > 0',
          'V3_BAND_summary.csv', True,
          all(abs(float(bsu.loc[m, c])) > 1e-12
              for m in bsu.index for c in ('point_value_range_low',
                                           'point_value_range_high',
                                           'bound_informed_range_low',
                                           'bound_informed_range_high')),
          detail='point/bound-informed 的 low/high 共 12 个端点')
    # ---- R13--R14：两个头条区间本身由 summary 现读，正文必须逐字一致 ----
    for _m, _tag in (('lever_50_70', 'R13'), ('uplift_ps70', 'R14')):
        _lo = format(float(bsu.loc[_m, 'point_value_range_low']), '.2f')
        _hi = format(float(bsu.loc[_m, 'point_value_range_high']), '.2f')
        check(f'{_tag} 正文认证点值区间 {_lo}--{_hi} == summary 现读',
              'V3_BAND_summary.csv', True, f'{_lo}--{_hi}' in IVL,
              detail=f'summary: {bsu.loc[_m, "point_value_range_low"]} .. '
                     f'{bsu.loc[_m, "point_value_range_high"]} '
                     f'（{int(bsu.loc[_m, "n_point_cells"])} 格）')
        check(f'{_tag}b 该指标进入区间的格数与正文"certified"列一致',
              'V3_BAND_summary.csv', True,
              int(bsu.loc[_m, 'n_point_cells']) == len(_PT_CELLS)
              and IVL.count('point & yes') == len(_PT_CELLS),
              detail=f'n_point_cells={bsu.loc[_m, "n_point_cells"]}；正文 '
                     f'"point & yes" 出现 {IVL.count("point & yes")} 次')
    check('R15 排除明细在档：被排除的格与原因写进了 summary',
          'V3_BAND_summary.csv', True,
          int(bsu.loc['uplift_ps70', 'n_degenerate_excluded']) >= 1
          and 'D_nogas' in str(bsu.loc['uplift_ps70', 'degenerate_excluded_cells'])
          and 'identity' in str(bsu.loc['uplift_ps70', 'degenerate_excluded_why']),
          detail=f"excluded={bsu.loc['uplift_ps70', 'degenerate_excluded_cells']}"
                 f" / why={str(bsu.loc['uplift_ps70', 'degenerate_excluded_why'])[:70]}...")
    # ---- R16：NOT_RUN 计数由 CSV 现读，正文用同一数量 ----
    _n_nr = int(bsu.loc['uplift_ps70', 'n_not_run_cells'])
    _n_nr_lever = int(bsu.loc['lever_50_70', 'n_not_run_cells'])
    check('R16 未跑交叉格数：正文写出的英文数词 == summary 现读',
          'V3_BAND_summary.csv', True,
          f'{_BAND_WORDS.get(_n_nr, "?")} two-axis cross cells' in IVL.lower()
          and 'NOT\\_RUN' in IVL,
          detail=f'uplift 侧 {_n_nr} 格、lever 侧 {_n_nr_lever} 格（含无气网那格的'
                 f'无定义杠杆）；正文须写 "{_BAND_WORDS.get(_n_nr, "?")} two-axis '
                 f'cross cells" 并印 NOT\\_RUN')
    check('R16b 正文那六个交叉格在存档里确为 basis=not_run / value=NOT_RUN',
          'V3_BAND_scan.csv', True,
          len(bsc[(bsc['metric'] == 'uplift_ps70') & (bsc['value_pct'] == 'NOT_RUN')
                  & (bsc['in_range_pool'] == 'True')]) == _n_nr
          and set(bsc[(bsc['cell_id'].str.startswith('X'))]['basis']) == {'not_run'},
          detail=f'存档 NOT_RUN 行 {int((bsc["value_pct"] == "NOT_RUN").sum())} 条')
    # ---- R17--R20：措辞守卫（禁把点值段与界导出段合并、禁把界当置信区间） ----
    _merged = [p for p in ('4.65--11.62', '6.77--21.94', '0.00--21.30',
                           '4.65\\%$--$11.62', '6.77\\%$--$21.94',
                           '0.00\\%$--$21.30', '0.00--', '--0.00', '0.000--',
                           '--0.000')
               if p in ALLTEX]
    check('R17 正文未把点值段与界导出段合成一个区间，也没有 0.00 型端点',
          'ALL tex', 'none', ', '.join(_merged) or 'none',
          detail='合并写法（如 4.65--11.62）或以恒等格 0.00 充当端点一旦出现即红；'
                 '正文允许在否定句里提到 0.000%（那正是在解释为什么排除）')
    _bad_ge = [s for s in re.findall(r'.{0,16}21\.94', ALLTEX) if '\\ge' not in s]
    check('R18 21.94% 每次出现都带 >=（只能说"至少"，不得写成"网状抬升就是它"）',
          'ALL tex', [], _bad_ge,
          detail=f'无 >= 前缀的出现 {len(_bad_ge)} 处')
    check('R18b 网状 11.62% 在正文被明说不是界',
          'sec_v_results.tex IV-L', True,
          'not a bound in either direction' in IVL
          and 'ratio of two lower bounds' in IVL,
          detail='两个下界之比不构成任何方向的界')
    check('R19 正文未把带说成置信区间/统计显著性',
          'sec_v_results.tex IV-L', True,
          'read as a confidence interval' in IVL
          and 'modeling calibers, not sampling error' in IVL,
          detail='带是口径跨度，不是抽样区间')
    check('R19b 正文未声称"各口径均已认证/数字稳定"',
          'ALL tex', 'none',
          ', '.join(p for p in ('all calibers are certified', 'every caliber is '
                               'certified', 'numbers are stable across calibers')
                    if p in ALLTEX) or 'none',
          detail='拓扑维度只有界、六个交叉格未跑，这类措辞会超出证据')
    check('R20 网状 incumbent（58.3076）未被引用为地板值或区间端点',
          'ALL tex + V3_BAND_scan.csv', True,
          '58.3076' not in ALLTEX and '58.3076' not in IVL,
          detail='三格并列在同一零流浅层点，按 mesh_notes 规定不得当地板值引用')
    # ---- R21--R23：gap 与图的落盘状态 ----
    check('R21 链上碳地板 gap 未落盘这件事如实写出（状态 OPTIMAL + MIPGap 参数 1e-4）',
          'sec_v_results.tex IV-L + V3_BAND_scan.csv', True,
          'MIPGap setting of' in IVL and '$10^{-4}$' in IVL
          and 'no ``gap below' in IVL
          and str(bsc['floor_ps70_gap_pct'].iloc[0]) == 'NOT_RECORDED',
          detail=f'存档 gap 列 = {bsc["floor_ps70_gap_pct"].iloc[0]}，'
                 f'authority 列写明 MIPGap 参数')
    _figf = os.path.join(SUB_V2, 'figures', 'fig_band_scan.png')
    check('R22 图 fig_band_scan.png 在位且被 IV-L 以 \\includegraphics 引用',
          'figures/fig_band_scan.png + sec_v_results.tex', True,
          os.path.exists(_figf) and 'figures/fig_band_scan.png' in IVL
          and '\\label{fig:band}' in IVL,
          detail=f'{_figf} 存在={os.path.exists(_figf)}')
    check('R23 图注写明了点值段与界导出段的视觉区别（实心圆/斜纹+空心方框/空心菱形）',
          'sec_v_results.tex IV-L figure caption', True,
          'filled circles' in IVL and 'open squares' in IVL
          and 'open diamond' in IVL and 'never merged into a certified span' in IVL,
          detail='实心圆=认证点值、斜纹+空心方框=界导出、空心菱形=恒等格，且明写不合并')
    check('R23b caption 的分母定义与存档 denominator_definition 同口径',
          'V3_BAND_scan.csv', True,
          "cell's own 50" in IVL and 'uncoupled floor of the same heat' in IVL,
          detail=str(bsu.loc['lever_50_70', 'denominator_definition'])[:80] + '...')


# ---------- S. 轮 19 两张新图的图注数字锁（期望值一律由存档 CSV 现读派生） ----------
# 图件本身由 make_v2_figures_extra.py 从 CSV 生成，风险在**图注文字**：人在图注里重打一
# 遍数字，就可能与图/存档不一致。故这里每个数都从 CSV 现算再与 tex 图注比对，
# 并同时反向锁住"图注不得声称图里没画的东西"。
_FW_S = _flat(_tex('sec_iii_framework.tex'))
_RS_S = _flat(_tex('sec_v_results.tex'))


def _kv_s(fname, kcol, vcol='value'):
    _d = pd.read_csv(os.path.join(RES, fname))
    out = {}
    for _, _r in _d.iterrows():
        try:
            out[str(_r[kcol])] = float(_r[vcol])
        except (TypeError, ValueError):
            continue
    return out


_pairS = _kv_s('wind_pv_pairing_metrics.csv', 'metric')
_shapeS = _kv_s('load_shape_compare_metrics.csv', 'metric')
_heatS = _kv_s('heat_real_vs_syn.csv', 'item')
_meshS = pd.read_csv(os.path.join(RES, 'V3_MESH_cells.csv'))
_topoS = {str(r['item']): str(r['value'])
          for _, r in pd.read_csv(os.path.join(RES, 'V3_MESH_topology.csv')).iterrows()}

_S_CAPS = [
    ('S1 图注的风光相关系数与存档同值',
     '%.3f' % abs(_pairS['corr_wind_gansu_vs_pv_gansu']),
     'Pearson correlation $-%.3f$' % abs(_pairS['corr_wind_gansu_vs_pv_gansu'])),
    ('S2 图注的甘肃典型日相关与存档同值',
     '%.3f' % _shapeS['corr_typicalday_gansu_vs_syn'],
     'at $%.3f$' % _shapeS['corr_typicalday_gansu_vs_syn']),
    ('S3 图注的江苏典型日相关与存档同值',
     '%.3f' % _shapeS['corr_typicalday_jiangsu_vs_syn'],
     'and $%.3f$' % _shapeS['corr_typicalday_jiangsu_vs_syn']),
    ('S4 图注的实测热形状相关与存档同值',
     '%.3f' % _heatS['corr(measured_mean_day, synthetic)'],
     'shape correlation $%.3f$' % _heatS['corr(measured_mean_day, synthetic)']),
    ('S5 图注的 1 月/7 月比与存档同值',
     '%.2f' % _heatS['jan_over_jul_ratio'],
     'ratio $%.2f$' % _heatS['jan_over_jul_ratio']),
    ('S6 图注的实测日能量与存档同值（一位小数）',
     '%.1f' % _heatS['measured_daily_energy_MWh_at_4MWpeak'],
     '$%.1f$~MWh$_{\\mathrm{th}}$ measured' % _heatS['measured_daily_energy_MWh_at_4MWpeak']),
    ('S7 图注的合成日能量与存档同值（一位小数）',
     '%.1f' % _heatS['synthetic_daily_energy_MWh_at_4MWpeak'],
     '$%.1f$~MWh$_{\\mathrm{th}}$ synthetic' % _heatS['synthetic_daily_energy_MWh_at_4MWpeak']),
    ('S8 图注的合成模板小时均值 = 存档日能量/24',
     '%.2f' % (_heatS['synthetic_daily_energy_MWh_at_4MWpeak'] / 24.0),
     'dashed line at $%.2f$~MW' % (_heatS['synthetic_daily_energy_MWh_at_4MWpeak'] / 24.0)),
]
for _cl, _val, _needle in _S_CAPS:
    check(_cl, 'code_v3/results vs 图注', True, _needle in _FW_S,
          detail=f'存档值 {_val}，图注须逐字含 {_needle!r}')

check('S9 图注的天数与逐时档案的实际天数同值',
      'gansu_wind_2019_hourly.csv', True,
      ('%d days of 2019' % pd.read_csv(
          os.path.join(RES, 'gansu_wind_2019_hourly.csv'))['ts'].astype(str)
       .str[:10].nunique()) in _FW_S,
      detail='天数从档案现读，不写 365 字面量')
check('S10 图注称合成负荷"零变异系数"，存档 cv_daily_peak_synthetic 必须确为 0',
      'load_shape_compare_metrics.csv', 0.0, _shapeS['cv_daily_peak_synthetic'], tol=0.0)

# 网状图：可交付量三元组与拓扑计数
_dl = ['%.3f' % v for v in _meshS.loc[_meshS['cell'] != 'M_B0',
                                      'gate_deliverability_MWh_h'].sort_values()]
check('S11 网状图注的可交付量三元组与存档逐格同值',
      'V3_MESH_cells.csv', _dl,
      ['%s' % d for d in _dl if d in _RS_S],
      detail=f'存档 {tuple(_dl)}，图注命中 {tuple(d for d in _dl if d in _RS_S)}')
check('S11b 三个值必须**全部**出现在图注里（缺一即红，防只写端点）',
      'V3_MESH_cells.csv', 3, sum(1 for d in _dl if d in _RS_S))
check('S12 图注的拓扑计数与 .net 解析结果同值',
      'V3_MESH_topology.csv', True,
      all(s in _RS_S for s in [
          '%s nodes' % _topoS['n_nodes_raw'],
          '%s pipelines' % _topoS['n_pipes_raw'],
          '%s control valve' % _topoS['n_valves_raw'],
          '%s compressor stations' % _topoS['n_compressors_raw']]),
      detail=str({k: _topoS[k] for k in ('n_nodes_raw', 'n_pipes_raw',
                                         'n_valves_raw', 'n_compressors_raw')}))
check('S13 图注不得把全图说成求解用的核（必须明写是缩核前的实例）',
      'sec_v_results.tex 图注', True,
      'not this full graph' in _RS_S
      and 'reduced 6-element' in _RS_S)
check('S13b 反向：图注不得声称网状三格已认证到最优',
      'sec_v_results.tex 图注', 0, _RS_S.count('certified to optimality'))

# 两张图都必须被引用、图件必须真的存在（防止"tex 引用了不存在的图"或图成了孤儿）
for _lab, _texfile in [('fig:data', 'sec_iii_framework.tex'),
                       ('fig:mesh', 'sec_v_results.tex')]:
    _allt = _flat(_tex('manuscript_v2.tex', 'sec_i_intro.tex', 'sec_ii_related.tex',
                       'sec_iii_framework.tex', 'sec_v_results.tex',
                       'sec_vi_vii_discussion.tex'))
    check(f'S14 {_lab} 有 label 且至少被 \\ref 一次（不做孤儿浮动体）',
          _texfile, True,
          (f'\\label{{{_lab}}}' in _allt) and (f'{{{_lab}}}' in _allt))
for _png in ('fig_data_layer.png', 'fig_mesh_replication.png'):
    check(f'S15 图件 {_png} 在盘上且非空', _png, True,
          os.path.isfile(os.path.join(HERE, '..', 'submission', '论文源_v2',
                                      'figures', _png))
          and os.path.getsize(os.path.join(HERE, '..', 'submission', '论文源_v2',
                                           'figures', _png)) > 20000)


# ---------- T. 轮 20 全文审查整改锁（新数字一律由 V3_AXIS5_scan.csv 现读派生） ----------
# 轮 20 补算了三条从没算过碳下限的口径（静态线 cap、K/A/p_min、数据溯源两臂），并把
# 20.3% 的归因从"线性气容"改回"去掉气网"。这里每条判据都从存档重算再与 tex 比对，
# 并且都配一个反向着陆点：删掉数字、改回旧说法、或把基准算错，都会红。
import math as _math

_AXIS5P = os.path.join(RES, 'V3_AXIS5_scan.csv')
check('T0 轴补算存档 V3_AXIS5_scan.csv 在位且非空',
      'code_v3/results/V3_AXIS5_scan.csv', True,
      os.path.exists(_AXIS5P) and os.path.getsize(_AXIS5P) > 1500,
      detail='轮 20 新数字的唯一来源')
_ax = pd.read_csv(_AXIS5P).set_index('cell_id')
_scanC = pd.read_csv(os.path.join(RES, 'V3_GC_scan_carbon.csv'))


def _gc(arm, cfg):
    _m = _scanC[(_scanC['arm'] == arm) & (_scanC['cfg'] == cfg)]
    return float(_m['carbon_min_exp_rp'].iloc[0])


def _axf(cell, col):
    return float(_ax.loc[cell, col])


_b0m = _gc('main', 'B0')
_cpl = dict((p, _gc('main', 'PS%d' % p)) for p in (50, 60, 70))
_T_MS = _flat(_tex('manuscript_v2.tex'))
_T_FW = _flat(_tex('sec_iii_framework.tex'))
_T_RS = _flat(_tex('sec_v_results.tex'))
_T_RL = _flat(_tex('sec_ii_related.tex'))
_T_DI = _flat(_tex('sec_vi_vii_discussion.tex'))
_T_IN = _flat(_tex('sec_i_intro.tex'))
_T_ALL = ' '.join([_T_MS, _T_FW, _T_RS, _T_RL, _T_DI, _T_IN])

# --- T1/T2/T3：静态线 cap 自己的碳下限（B1 的正面回答） ---
for _p in (50, 60, 70):
    _v = _axf('GASCAP_PS%d' % _p, 'floor_tCO2_per_day')
    check('T1_%d 线 cap 的碳下限 %.3f 由存档派生且已在正文逐字印出' % (_p, _v),
          'V3_AXIS5_scan.csv', round(_v, 3),
          round(_v, 3) if ('%.3f' % _v) in _T_RS else None, tol=0.0005)
    _dv = 100.0 * (_v - _cpl[_p]) / _cpl[_p]
    check('T2_%d 线 cap 相对同压耦合的碳偏差算得 +%.2f%%，正文须含同值' % (_p, _dv),
          'V3_AXIS5_scan.csv + V3_GC_scan_carbon.csv', round(_dv, 2),
          round(_dv, 2) if ('%.2f' % _dv) in _T_RS else None, tol=0.005)
check('T3 线 cap 三格全部 OPTIMAL（表题声称十格全 OPTIMAL，先锁这三格）',
      'V3_AXIS5_scan.csv', 3,
      int(((_ax['status_name'] == 'OPTIMAL')
           & (_ax.index.to_series().str.startswith('GASCAP'))).sum()))
check('T3b 线 cap 碳下限必须**高于**同压耦合下限（cap 更保守，方向不得反）',
      'V3_AXIS5_scan.csv', [True] * 3,
      [_axf('GASCAP_PS%d' % p, 'floor_tCO2_per_day') > _cpl[p] for p in (50, 60, 70)])

# --- T4/T5：气网常数轴，单调性与印出的值 ---
_up = dict((c, _axf(c, 'uplift_pct_vs_uncoupled')) for c in _ax.index)
_up['BASE70'] = 100.0 * (_cpl[70] - _b0m) / _b0m
_up['BASE50'] = 100.0 * (_cpl[50] - _b0m) / _b0m
check('T4 70 bar 上浮对 K 单调递减，且 K 基准格与主链存档逐位同源',
      'V3_AXIS5_scan.csv', True,
      _up['K_x0.5_PS70'] > _up['BASE70'] > _up['K_x2.0_PS70'])
for _c, _n in [('K_x0.5_PS70', '32.78'), ('K_x2.0_PS70', '7.13'),
               ('A_x0.5_PS70', '20.81'), ('A_x2.0_PS70', '18.98'),
               ('pmin15bar_PS70', '19.41'), ('pmin25bar_PS70', '21.35')]:
    check('T5 %s 的上浮 %.2f%% 已在正文以 %s 印出' % (_c, _up[_c], _n),
          'V3_AXIS5_scan.csv', round(_up[_c], 2),
          round(_up[_c], 2) if _n in _T_RS else None, tol=0.005)
_APM = [_up['A_x0.5_PS70'], _up['A_x2.0_PS70'], _up['pmin15bar_PS70'], _up['pmin25bar_PS70']]
check('T5b A 轴与 p_min 轴的总变幅必须小于 K 轴（正文"almost flat"才成立）',
      'V3_AXIS5_scan.csv', True,
      (max(_APM) - min(_APM)) < (_up['K_x0.5_PS70'] - _up['K_x2.0_PS70']))

# --- T6：数据溯源两臂与带宽披露 ---
_pair_up = 100.0 * (_gc('paironly', 'PS70') - _gc('paironly', 'B0')) / _gc('paironly', 'B0')
_shape_up = 100.0 * (_gc('shapeonly', 'PS70') - _gc('shapeonly', 'B0')) / _gc('shapeonly', 'B0')
check('T6 paironly 上浮算得 %.2f%%，低于四口径下限 6.77%%，正文必须同时印出两者' % _pair_up,
      'V3_GC_scan_carbon.csv', round(_pair_up, 2),
      6.25 if ('6.25' in _T_RS and '6.77' in _T_RS) else None, tol=0.005)
check('T6b shapeonly 上浮 %.2f%% 同批披露' % _shape_up,
      'V3_GC_scan_carbon.csv', round(_shape_up, 2),
      9.79 if '9.79' in _T_RS else None, tol=0.005)
check('T6c 正文必须给出合并后实测最宽区间 6.25–32.78，并声明四口径段是刻意选的',
      'sec_v_results.tex', True,
      '6.25\\%$--$32.78\\%'.replace('\\', '') in _T_RS.replace('\\', '')
      and 'deliberately the four-caliber ones' in _T_RS)
check('T6d 新轴两压都跑过：正文必须承认 lever 段也被加宽到 12.46，并交代 K×0.5@50 无解',
      'V3_AXIS5_scan.csv + sec_v_results.tex', True,
      _axf('pmin25bar_PS50', 'lever_pct_50to70') > 11.371445
      and '4.65\\%$--$12.46\\%'.replace('\\', '') in _T_RS.replace('\\', '')
      and 'no' in _T_RS and 'infeasible' in _T_RS
      and str(_ax.loc['K_x0.5_PS50', 'floor_kind']) == 'infeasible')
check('T6e K×0.5 在 70 bar 有界、在 50 bar 无解：正文的表位必须留空而非补 0',
      'V3_AXIS5_scan.csv', ['infeasible', 'point'],
      [str(_ax.loc['K_x0.5_PS50', 'floor_kind']), str(_ax.loc['K_x0.5_PS70', 'floor_kind'])])

# --- T7：百分比基准 ---
_under = 100.0 * (_cpl[70] - _b0m) / _cpl[70]
check('T7 "低估 %.1f%%" 由存档派生（(耦合−无网)/耦合），摘要与正文都要在场' % _under,
      'V3_GC_scan_carbon.csv', round(_under, 1),
      round(_under, 1) if ('16.9' in _T_RS and '16.9' in _T_MS) else None, tol=0.05)
check('T7b 摘要与正文都不得再用"understates the reachable carbon floor by 20.3"这一错基准句',
      'manuscript_v2.tex + sec_v_results.tex', 0,
      sum('understates the reachable carbon floor by 20' in t for t in (_T_MS, _T_RS)))
check('T7c 正文必须点明这些百分比是 uplift on the network-free base',
      'sec_v_results.tex', True, 'uplift on the network-free base' in _T_RS)
check('T7d 引言的三数对照必须含 33.185 与 0.8\\% 的 cap 结论',
      'sec_i_intro.tex', True, '33.185' in _T_IN and '$0.8\\%$' in _T_IN)

# --- T8：标题与归因 ---
check('T8 标题不再把失真记给线性气容，改记给"去掉气网"',
      'manuscript_v2.tex', [True, 0],
      ['What Omitting the Network Distorts' in _T_MS,
       _T_MS.count('Linear Gas Cap Distorts')])
check('T8b 引言不得再把 27.361 说成"换成固定小时燃料上限"的结果',
      'sec_i_intro.tex + sec_vi_vii_discussion.tex', 0,
      sum('replaced by a fixed hourly fuel cap' in t for t in (_T_IN, _T_DI)))
check('T8c 结论必须把 cap 与"不设网"分开：前者 +0.8--1.0\\%，后者才 hides 20--35\\%',
      'sec_vi_vii_discussion.tex', True,
      '$0.8$--$1.0\\%$ \\emph{above}' in _T_DI
      and 'Pricing gas and imposing no network' in _T_DI)

# --- T9–T13：符号、单位与术语 ---
check('T9 结果节不再使用未定义符号 p_min（全部改用 III 定义的 \\underline p）',
      'sec_v_results.tex + sec_vi_vii_discussion.tex', 0,
      _T_RS.count('p_\\mathrm{min}') + _T_DI.count('p_\\mathrm{min}'))
check('T9b \\underline p 的定义句与参数小结都还在 III（不得只在结果节改名）',
      'sec_iii_framework.tex', True,
      'pressure floor $\\underline p = 20$~bar' in _T_FW
      and '$\\underline p = 20$~bar;' in _T_FW)
check('T10 摘要与结果节不再出现裸 gate valve（一律 gate-station valve）',
      'manuscript_v2.tex + sec_v_results.tex', 0,
      sum(t.replace('gate-station valve', '').count('gate valve')
          for t in (_T_MS, _T_RS)))
check('T10b gate-station valve 写法仍在使用（改错方向会先掉到 0）',
      'manuscript_v2.tex + sec_v_results.tex', True,
      sum(t.count('gate-station valve') for t in (_T_MS, _T_RS)) >= 4)
check('T11 风险系数一律 $\\lambda_r$，裸 $\\lambda=0.8$ 残留 0 处',
      'sec_v_results.tex', [0, True],
      [_T_RS.count('$\\lambda=0.8$'), '\\lambda_r=0.8' in _T_RS])
_ctl = pd.read_csv(os.path.join(RES, 'EPS_controls.csv'), encoding='utf-8-sig')
_ctlv = float(_ctl[_ctl['tag'] == 'ctrl_carbon_shed']['exp_cost'].iloc[0])
check('T12  shedding 对照的成本 731,677.1 CNY/day 与存档同值，且全文不再出现 kCNY',
      'EPS_controls.csv', round(_ctlv, 1),
      round(_ctlv, 1) if ('731{,}677.1' in _T_RS and 'kCNY' not in _T_ALL) else None,
      tol=0.05)
check('T13 间隙的绝对陈述已缩到碳下限那批运行，"anywhere in this paper"残留 0 处',
      'sec_v_results.tex', [0, 1],
      [_T_RS.count('claim is made anywhere in this paper'),
       _T_RS.count('claim is made for those carbon-floor runs')])

# --- T14–T17：图注、表 I 与 NOT_RUN 计数 ---
check('T14 数据层图注不再称 capacity factor，改称"除以当年最大小时出力"',
      'sec_iii_framework.tex', [0, True],
      [_T_FW.count('capacity factors'),
       "divided by that site's largest hourly" in _T_FW])
_pk = _kv_s('load_shape_compare_metrics.csv', 'metric')
check('T15 峰时错配（模板比 Gansu 晚 1 小时、比 Jiangsu 晚 5 小时）与存档同值且已印出',
      'load_shape_compare_metrics.csv', [1.0, 5.0],
      [_pk['peak_hour_syn'] - _pk['peak_hour_gansu_typical'],
       _pk['peak_hour_syn'] - _pk['peak_hour_jiangsu_typical']])
check('T15b 图注用文字写死了这两个小时差（只改 CSV 不改图注会红）',
      'sec_iii_framework.tex', True,
      'one hour after the Gansu' in _T_FW and 'five hours after the Jiangsu' in _T_FW)
check('T16 表 I 的"本研究"行不再自称 System-level，改为园区尺度并注明两节点气网',
      'sec_ii_related.tex', [0, True],
      [_T_RL.count('System-level unit commitment'),
       'Park scale (5~MW electric peak), two-node gas network' in _T_RL])
_bs = pd.read_csv(os.path.join(RES, 'V3_BAND_scan.csv'), encoding='utf-8-sig')
_nr = _bs[_bs['basis'] == 'not_run']
_n_x = int((_nr['cell_id'].astype(str).str.startswith('X')).sum()) // 3
_n_lv = int((_nr['metric'] == 'lever_50_70').sum())
check('T17 交叉格 %d 个、lever 行 NOT_RUN %d 格：正文须写 six 并解释第七格' % (_n_x, _n_lv),
      'V3_BAND_scan.csv', [6, 7], [_n_x, _n_lv])
check('T17b 第七格的说法与存档 missing_reason 同源（不得自创解释）',
      'V3_BAND_scan.csv', True,
      'D\\_nogas' in _T_RS
      and 'uplift is identically' in ' '.join(
          _nr[_nr['cell_id'].astype(str).str.startswith('D_')]['missing_reason']
          .astype(str).tolist()))

# --- T18：两个新浮动体 ---
check('T18 IV-I 对照表在位并被引用，六个耦合下限与存档逐格同值',
      'V3_GC_scan_carbon.csv', True,
      '\\label{tab:heatreal}' in _T_RS and 'Table~\\ref{tab:heatreal}' in _T_RS
      and all(('%.3f' % _gc(a, c)) in _T_RS
              for a, c in [('main', 'PS50'), ('main', 'PS60'), ('main', 'PS70'),
                           ('heatreal', 'PS50'), ('heatreal', 'PS60'),
                           ('heatreal', 'PS70')]))
check('T18b IV-I 表的无网两格与杠杆/上浮三对值同样来自存档',
      'V3_GC_scan_carbon.csv', True,
      ('%.3f' % _b0m) in _T_RS and ('%.3f' % _gc('heatreal', 'B0')) in _T_RS
      and '6.63' in _T_RS and '14.4' in _T_RS)
_T18_CELLS = ['K_x0.5_PS70', 'K_x2.0_PS70', 'A_x0.5_PS70', 'A_x2.0_PS70',
              'pmin15bar_PS70', 'pmin25bar_PS70', 'GASCAP_PS70',
              'paironly_PS70', 'shapeonly_PS70']
_T18_LABELED = ('\\label{tab:axis5}' in _T_RS
                and 'Table~\\ref{tab:axis5}' in _T_RS)
check('T18c 扩展表在位、被引用，九格的 70 bar 上浮与 lever 全部与存档同值',
      'V3_AXIS5_scan.csv', [True] * 9,
      ([(_T18_LABELED
         and ('%.2f' % _axf(c, 'uplift_pct_vs_uncoupled')) in _T_RS
         and (('%.2f' % _axf(c, 'lever_pct_50to70')).rstrip('0').rstrip('.') in _T_RS
              or c == 'K_x0.5_PS70')) for c in _T18_CELLS]
       if _T18_LABELED else [False] * 9))
check('T18d 50 bar 一侧的上浮同样逐格与存档同值（表里第二列不是手抄）',
      'V3_AXIS5_scan.csv', [True] * 8,
      [('%.2f' % _axf(c, 'uplift_pct_vs_uncoupled')) in _T_RS
       for c in ['K_x2.0_PS50', 'A_x0.5_PS50', 'A_x2.0_PS50', 'pmin15bar_PS50',
                 'pmin25bar_PS50', 'GASCAP_PS50', 'paironly_PS50', 'shapeonly_PS50']])
_up50b = 100.0 * (_cpl[50] - _b0m) / _b0m
_levb = 100.0 * (_cpl[50] - _cpl[70]) / _cpl[50]
check('T18e 表里"K as calibrated"一整行都由主链存档现算：%.2f / %.2f / %.2f'
      % (_up50b, 100.0 * (_cpl[70] - _b0m) / _b0m, _levb),
      'V3_GC_scan_carbon.csv', ['35.43', '20.28', '11.19'],
      [('%.2f' % _up50b), ('%.2f' % (100.0 * (_cpl[70] - _b0m) / _b0m)),
       ('%.2f' % _levb)] if ('%.2f' % _up50b) in _T_RS else ['', '', ''])

# --- T19：III-D 新增的设计选择披露 ---
_K_T, _PD_T = 0.00383, 20.0
_re_cfg = re.search(r"pmax=([\d.]+),\s*eta_e=([\d.]+)", cfg_src)
_pmax_t = float(_re_cfg.group(1)) / float(_re_cfg.group(2))
_re_gb = re.search(r"GB = dict\(hmax=([\d.]+),\s*eta=([\d.]+)", cfg_src)
_gb_t = float(_re_gb.group(1)) / float(_re_gb.group(2))
check('T19 III-D 上限句的日量 68.1/84.0/99.6 MWh 全部由 K、p_min 与 24 h 现算',
      'config_v3 + 供路公式', True,
      all(('%.1f' % (_math.sqrt(_K_T * (p * p - _PD_T ** 2)) * 24.0)) in _T_FW
          for p in (50, 60, 70)))
check('T19b 额定时燃料 8.571（CHP）与 3.333（GB）由 config 现算并印出',
      'config_v3.py', [round(_pmax_t, 3), round(_gb_t, 3)],
      [round(_pmax_t, 3), round(_gb_t, 3)]
      if ('%.3f' % _pmax_t in _T_FW and '%.3f' % _gb_t in _T_FW) else [0, 0])
check('T19c "under half the CHP nameplate" 与现算比值一致（4.152/8.571 < 0.5）',
      'config_v3.py', True,
      _math.sqrt(_K_T * (70.0 ** 2 - _PD_T ** 2)) / _pmax_t < 0.5
      and 'under half the CHP' in _T_FW)

# --- T20–T21：此前只存档、未写入的两组结果 ---
_capT = pd.read_csv(os.path.join(RES, 'V3_all_cap_summary_table.csv'), encoding='utf-8-sig')


def _num_eq(s, v):
    try:
        return abs(float(str(s).strip()) - v) < 1e-9
    except (TypeError, ValueError):
        return False


def _eens(capval):
    """按 tag 列匹配档位：存档里 inf 档的 cap 列是 NaN，档位记在 tag 上。"""
    _s = str(capval).strip().lower()
    if _s in ('inf', 'none', 'unbounded'):
        _m = _capT[(_capT['tag'].astype(str).str.strip().str.lower() == 'inf')
                   & (_capT['arm'].astype(str) == 'main')]
    else:
        _m = _capT[(_capT['arm'].astype(str) == 'main')
                   & _capT['tag'].apply(lambda s: _num_eq(s, float(_s)))]
    return float(_m['eens_e'].iloc[0]) if len(_m) else None


check('T20 进口容量 5.0 MW 与不设限两档的 EENS 均为 0，且正文写出了这两档',
      'V3_all_cap_summary_table.csv', [0.0, 0.0],
      [_eens('5.0'), _eens('inf')]
      if 'at 5.0~MW, exactly the peak load' in _T_RS else [None, None])
_oosf = pd.read_csv(os.path.join(RES, 'EPS_oossum_end_carbon.csv'), encoding='utf-8-sig')
check('T21 前沿 OOS 碳非单调（端点 %.2f 高于两个 refine 档）已由正文明说'
      % float(_oosf['oos_mean_carbon'].iloc[0]),
      'EPS_oossum_end_carbon.csv', True,
      abs(float(_oosf['oos_mean_carbon'].iloc[0]) - 38.02) < 0.01
      and 'not monotone in it' in _T_RS and '37.78 and 37.73' in _T_RS)

# --- T22–T27：缩写、限定语、命名与结构 ---
check('T22 MINLP / coefficient of performance / column-and-constraint 均在首现处展开',
      'sec_ii_related.tex + sec_iii_framework.tex', [True, True, True],
      ['mixed-integer nonlinear program (MINLP)' in _T_RL,
       'coefficient of performance' in _T_FW,
       'column-and-constraint generation' in _T_RL])
check('T22b 对邻居的绝对否定已加限定，旧的无限定否定句残留 0',
      'sec_ii_related.tex', [0, True],
      [_T_RL.count('and neither treats gas-side pressure'),
       'neither, on the published descriptions, treats gas-side pressure' in _T_RL])
check('T22c 引言/相关工作不再把"两篇都没做"写成无条件断言（正向限定句在场）',
      'sec_ii_related.tex', True,
      'on the published descriptions' in _T_RL)
check('T23 单例上的"两条学科观点可推广"已改为"两种记录习惯"，旧句残留 0',
      'sec_vi_vii_discussion.tex', [0, True],
      [_T_DI.count('Two disciplinary points generalize'),
       'Two reporting habits are worth separating' in _T_DI])
check('T24 网状核命名收敛：定义句在场，park-facing / 7-edge core 残留 0',
      'sec_v_results.tex', [0, 0, True],
      [_T_RS.count('park-facing'), _T_RS.count('7-edge core'),
       '\\emph{the meshed core}' in _T_RS])
check('T24b 网状核的单向元件改称固定方向管，旧的"gate valve and the compressor"残留 0',
      'sec_v_results.tex', [0, True],
      [_T_RS.count('the gate valve and the compressor'),
       'modeled as a fixed-direction' in _T_RS])
check('T25 IV-J 相邻两说已按"同图内 vs 跨图"调和，且引用值与存档同值',
      'sec_v_results.tex + V3_MESH_cells.csv', True,
      'of that graph' in _T_RS and 'Across graphs the' in _T_RS
      and abs(float(_meshS.loc[_meshS['cell'] == 'M_PS50',
                                     'carbon_min_obj_bound'].iloc[0])
              - 37.7518) < 1e-3 and '37.752' in _T_RS)
check('T26 §IV 路线图点名了 IV-L（此前只到 IV-K）',
      'sec_v_results.tex', True,
      'Section~IV-L collects the certified caliber band' in _T_RS)
check('T27 供路功率单位统一为 MW，MW_th per hour 与 (MW$_\\mathrm{th}$/h) 残留 0',
      'sec_v_results.tex', [0, 0, True],
      [_T_RS.count('~MW$_\\mathrm{th}$ per hour'), _T_RS.count('(MW$_\\mathrm{th}$/h)'),
       'MW of fuel per hour' in _T_RS])
check('T28 图 3(b) 已换成四档气侧表示阶梯，其两个中间值与存档同值',
      'V3_AXIS5_scan.csv + V3_GC_scan_carbon.csv', True,
      ('%.3f' % _axf('GASCAP_PS70', 'floor_tCO2_per_day')) in _T_RS
      and ('%.3f' % _gc('steady', 'PS70')) in _T_RS
      and 'ladder of gas-side representations' in _T_RS)
# review-template.sty 里另有一份写死的 PDF /Title（轮 20 改标题时它没跟着改，
# 成品验收 §17 才发现）。两份字面量必须逐字绑在一起，否则元数据与印刷体分家。
_sty = _tex('review-template.sty')
_m_tt = re.search(r'\\title\{(.*?)\}\s*\\author', _T_MS, re.S)
_m_pt = re.search(r'/Title \((.*?)\)\s*%', _sty, re.S)


def _norm_title(s):
    return re.sub(r'\s+', ' ', s.replace('---', '-').replace('--', '-')).strip()


check('T29 sty 里写死的 /Title 与 manuscript 的 \\title 归一化后逐字相等',
      'manuscript_v2.tex + review-template.sty',
      _norm_title(_m_tt.group(1)) if _m_tt else None,
      _norm_title(_m_pt.group(1)) if (_m_tt and _m_pt
                                      and _norm_title(_m_tt.group(1))
                                      == _norm_title(_m_pt.group(1))) else None,
      detail='两份字面量任一处单独改动都会在这里红')
check('T29b /Title 里不得残留旧标题片段',
      'review-template.sty', 0, _sty.count('Linear Gas Cap Distorts'))


# ---------- T30–T37：轮 20 变异证据暴露的"只要正文别处还有这个数就放行"松动，逐条收紧 ----------
# 第一轮 55 支单点变异里有 10 支一锁都没杀死：判据只查"值在全文某处出现"，删掉整张表的
# 行也不会红。下面按浮动体分块，把值绑到它必须出现的那张表里。
_RS_RAW = _tex('sec_v_results.tex')
_MS_RAW = _tex('sec_iii_framework.tex')


def _block(raw, label, span=1700, back=0):
    """浮动体分块：\\label 排在 \\caption 之后，所以图要往前取才含得到表题。"""
    i = raw.find('\\label{%s}' % label)
    return raw[max(0, i - back):i + span] if i >= 0 else ''


_B_LIN = _flat(_block(_RS_RAW, 'tab:linwey'))
_B_AX5 = _flat(_block(_RS_RAW, 'tab:axis5'))
_B_HR = _flat(_block(_RS_RAW, 'tab:heatreal'))
_B_PS = _flat(_block(_RS_RAW, 'fig:pslever', 400, back=1200))
check('T30 表 V 内必须自带线 cap 三条碳行（正文别处出现不算）',
      'V3_AXIS5_scan.csv', [True] * 3,
      [('%.3f' % _axf('GASCAP_PS%d' % p, 'floor_tCO2_per_day')) in _B_LIN
       for p in (50, 60, 70)] if _B_LIN else [False] * 3)
check('T30b 表 V 的 cap−耦合差值行按行绑定，且三值与存档同值',
      'V3_AXIS5_scan.csv', [True] * 3,
      [('%.2f' % (100.0 * (_axf('GASCAP_PS%d' % p, 'floor_tCO2_per_day')
                      - _cpl[p]) / _cpl[p])) in _B_LIN for p in (50, 60, 70)])
check('T31 扩展表表体必须逐行含九格的 50/70 bar 上浮与 lever（行内绑定，不是全文扫）',
      'V3_AXIS5_scan.csv', [True] * 9,
      [(('%.2f' % _axf(c, 'uplift_pct_vs_uncoupled')) in _B_AX5
        and (not np.isfinite(_axf(c.replace('_PS70', '_PS50'),
                                   'uplift_pct_vs_uncoupled'))
             or ('%.2f' % _axf(c.replace('_PS70', '_PS50'),
                               'uplift_pct_vs_uncoupled')) in _B_AX5))
       for c in _T18_CELLS] if _B_AX5 else [False] * 9)
check('T31b 扩展表里 K×0.5 的 50 bar 位必须是 infeasible，不得用 0 或界值顶替',
      'V3_AXIS5_scan.csv', True,
      'infeasible' in _B_AX5
      and str(_ax.loc['K_x0.5_PS50', 'floor_kind']) == 'infeasible')
check('T32 IV-I 对照表表体必须含两列三档耦合下限 + 两个无网下限',
      'V3_GC_scan_carbon.csv', [True] * 5,
      [(('%.3f' % _gc('main', 'PS%d' % p)) in _B_HR
        and ('%.3f' % _gc('heatreal', 'PS%d' % p)) in _B_HR) for p in (50, 60, 70)]
      + [(_s in _B_HR) for _s in ('%.3f' % _b0m, '%.3f' % _gc('heatreal', 'B0'))]
      if _B_HR else [False] * 5)
check('T32b IV-I 表的 lever/上浮两行也按行绑定（删行必须红）',
      'sec_v_results.tex', True,
      'Lever, 50$\\to$70~bar (\\%) & 11.19 & 6.63' in _RS_RAW
      and 'Coupling uplift at 70~bar (\\%) & 20.3 & 6.8' in _RS_RAW)
check('T33 阶梯句必须是"对 K 强单调"，改成"不规则"要红（措辞与数据同向）',
      'sec_v_results.tex', True,
      'strongly monotone in $K$' in _T_RS
      and _up['K_x0.5_PS70'] > _up['BASE70'] > _up['K_x2.0_PS70'])
check('T33b 无解格必须被写成"没有可行调度"，不得静默消失',
      'sec_v_results.tex', True,
      'feasible dispatch with load shedding disabled' in _T_RS
      and '\\emph{no}' in _RS_RAW and 'heat balance requires' in _T_RS)
check('T34 摘要区不得再出现旧的 4.7%，且 4.65% 必须在摘要区内',
      'manuscript_v2.tex', [0, 1],
      [_T_MS.count('4.7\\%'), _T_MS.count('4.65\\%')])
check('T35 复现包措辞不得声称脚本"随投稿附上"（正文只允许 in the replication package）',
      'sec_v_results.tex', 0, _RS_RAW.count('shipped with the'))
check('T36 图 3 表题内必须自带两个中间保真度值（挪到正文别处不算）',
      'V3_GC_scan_carbon.csv', True,
      ('%.3f' % _axf('GASCAP_PS70', 'floor_tCO2_per_day')) in _B_PS
      and ('%.3f' % _gc('steady', 'PS70')) in _B_PS)
check('T37 相关工作的邻居限定句必须留在源里（撤掉限定即红）',
      'sec_ii_related.tex', [0, 1],
      [_T_RL.count('and neither treats gas-side pressure'),
       _T_RL.count('on the published descriptions')])
check('T37b 讨论章"两种记录习惯"改写必须在场，旧写法 0 处',
      'sec_vi_vii_discussion.tex', [0, 1],
      [_T_DI.count('Two disciplinary points generalize'),
       _T_DI.count('Two reporting habits are worth separating')])
check('T37c 表 I 的园区尺度行标签必须留在表体内（改回 System-level 即红）',
      'sec_ii_related.tex', True,
      'Park scale (5~MW electric peak), two-node gas network'
      in _flat(_block(_tex('sec_ii_related.tex'), 'tab:related', 6000)))


# ---------- Z. 稿件自描述锁（必须在所有断言登记完之后核对）----------
# IV-H 印了"多少条断言、其中几条未判定"，这两个数是本脚本自己的输出，故用不动点写法：
# 正文声明的总数 == 已登记条数 + 本条自身（CSV 最终行数即该总数）。SKIPPED 不受本条影响。
_comp = _flat(_tex('sec_v_results.tex'))
_m_tot = re.search(r'number printed here---(\d+) assertions', _comp)
_m_skip = re.search(r'(\d+) of them recorded as not determined', _comp)
_claim_tot = int(_m_tot.group(1)) if _m_tot else -1
_claim_skip = int(_m_skip.group(1)) if _m_skip else -1
_n_skip_now = sum(1 for r in results if r['status'] == SKIPPED)
# 自描述恒等式的常数项：Z1 与 Z1b 这两行本身也进 CSV，所以"落盘行数"等于
# 本条求值时的 len(results) + 2。轮 7 时只有一条 Z 行，常数写的是 +1；Task 4 加了
# Z1b 之后没同步这个常数，于是正文并入完成、数字却永久差 1（实测 433 而判据要 432）。
# 这里改成从"Z 行清单"推导，而不是再写一个字面量，避免下一轮又差一行。
_Z_CLAIMS = ('Z1 IV-H', 'Z1b ')
_n_z_after = sum(1 for _c in _Z_CLAIMS if True)      # = 2，显式列出便于下一轮增删
assert _n_z_after == len(_Z_CLAIMS) == 2, 'Z 节行数变了，上面的常数推导必须一起改'
# 并入轮之间允许一种**可判定、已排期**的漂移：正文计数 == 未含 P/Q 节的旧总数。
# 只放开这一种情形，且放开时记 SKIPPED（可见、计数、附原因），绝不静默 PASS；
# 其余任何不一致（例如有人改了 N 节计数、或 P/Q 之外多了断言）仍判 FAIL。
_n_pq = sum(1 for r in results if re.match(r'[PQ]\d', str(r['claim'])))
_n_pq_skip = sum(1 for r in results
                 if re.match(r'[PQ]\d', str(r['claim'])) and r['status'] == SKIPPED)
_FINAL = len(results) + _n_z_after
_in_sync = (_claim_tot == _FINAL and _claim_skip == _n_skip_now)
_p_gap_only = (_n_pq > 0 and _claim_tot == _FINAL - _n_pq
               and _claim_skip == _n_skip_now - _n_pq_skip)
check('Z1 IV-H 印的断言总数与"未判定"条数 == 本次运行的实测值（含 Z 节自身）',
      'sec_v_results.tex',
      True, _in_sync,
      skip=(None if (_in_sync or not _p_gap_only) else
            f'P/Q 节新增 {_n_pq} 条断言已进审计、尚未并入 IV-H 的计数（正文并入为'
            f'下一步，本轮不改 tex）。并入后本条自动回到 PASS 判定。'
            f'目标值：total={_FINAL} / skipped={_n_skip_now}'),
      detail=f'正文声明 total={_claim_tot} / skipped={_claim_skip}；实测（含 Z1/Z1b）'
             f'total={_FINAL} / skipped={_n_skip_now}。改断言数必须同批改正文')
check('Z1b 若 P/Q 节尚未并入正文，缺口必须**恰好**等于 P/Q 节条数（多一条少一条都红）',
      'sec_v_results.tex vs 本脚本',
      True, _in_sync or _p_gap_only,
      detail=f'P/Q 节 {_n_pq} 条；正文 {int(_claim_tot)} vs 实测 {_FINAL}；'
             f'缺口 {_FINAL - int(_claim_tot)} 条必须全来自 P/Q 节，'
             f'否则就是别的节的计数漂了')

# ---------- 汇总 ----------
df = pd.DataFrame(results)
df.to_csv(os.path.join(RES, 'audit_v3_check.csv'), index=False, encoding='utf-8-sig')
n_total = len(df)
n_pass = int((df['status'] == PASS).sum())
n_fail = int((df['status'] == FAIL).sum())
n_skip = int((df['status'] == SKIPPED).sum())
# Z2：落盘后的复读核对。正文印的总数最终必须等于 audit_v3_check.csv 的行数；
# 这条不进 CSV（CSV 已写完），但会改退出码，所以"Z 节自己多了一行把常数带偏"这类
# 事故只能被它抓到——Z1 的 +2 是推导的，Z2 是对着产物验的。
try:
    _n_csv_rows = sum(1 for _ in open(os.path.join(RES, 'audit_v3_check.csv'),
                                      encoding='utf-8-sig')) - 1
except OSError:
    _n_csv_rows = -1
if _claim_tot == n_total == _n_csv_rows:
    print(f'\n  [PASS] Z2 落盘复读：IV-H 印的 total={_claim_tot} == CSV 行数 {n_total}'
          f'（表头除外）== 现读 {_n_csv_rows}')
else:
    n_fail += 1
    print(f'\n  [**FAIL**] Z2 落盘复读：IV-H 印 total={_claim_tot}，DataFrame {n_total} 行，'
          f'CSV 现读 {_n_csv_rows} 行 —— 三者必须相同；不同则说明 Z 节的常数推导又漂了')
if n_skip != _claim_skip:
    n_fail += 1
    print(f'\n  [**FAIL**] Z2b 落盘复读：正文印 skipped={_claim_skip}，CSV 实测 {n_skip}')
else:
    print(f'  [PASS] Z2b 落盘复读：正文印的"未判定"条数 {_claim_skip} == CSV 实测 {n_skip}')
print(f'\n=== v3 审计完成: 总 {n_total} 项 | PASS {n_pass} | FAIL {n_fail} | '
      f'SKIPPED {n_skip} ===')
if n_skip:
    print('---- SKIPPED 明细（未判定，附原因，不计入 PASS/FAIL）----')
    for _, r in df[df['status'] == SKIPPED].iterrows():
        print(f'  [SKIPPED] {r["claim"]} :: {r["detail"]}')
if n_fail:
    print('---- FAIL 明细 ----')
    print(df[df['status'] == FAIL].to_string(index=False))
sys.exit(0 if n_fail == 0 else 1)
