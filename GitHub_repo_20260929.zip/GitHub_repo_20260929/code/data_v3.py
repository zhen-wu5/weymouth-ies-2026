# -*- coding: utf-8 -*-
"""code_v3 数据准备：新数据层（重建负荷形状 + 甘肃风/甘肃光同省配对）场景库生成。

协议与 code_v2/data_probe.py（E13 口径）完全一致，仅替换数据源，划分/削减/定标算法不变：
  - 逐日 24h 曲线，70% 渗透率定标（风:光 = 3:4）
  - 训练/测试划分：seed=42，265/100
  - k-means 削减 8 场景（seed=0，n_init=10）
  - 电/热负荷峰值 5.0 / 4.0 MW（口径不变，形状可切换）

数据臂（V3_ARM 环境变量，用于因素分离；默认 'main'）：
  old       : 合成电负荷 + 连云港风/甘肃光 + EF 旧值（= 旧数据层，仅作移植校验）
  shapeonly : 甘肃重建负荷形状 + 连云港风/甘肃光（旧配对）+ EF 旧值
  paironly  : 合成电负荷 + 甘肃风/甘肃光（同省配对）+ EF 旧值
  efold     : 甘肃重建负荷形状 + 甘肃风/甘肃光 + EF 旧值 0.55（分离排放因子影响）
  main      : 甘肃重建负荷形状 + 甘肃风/甘肃光 + EF 官方 0.8922（v3 主口径，默认）
  heatreal  : 同 main，但**热负荷换成实测**逐时区域供热计量（丹麦 Brønderslev，
              4910 块热量表，CC BY 4.0，见 data_heat_real.py）。热侧形状与逐日
              变化都来自实测，其余（电负荷形状、风光配对、EF）一律不动，
              因此这是对"热负荷为合成"这一声明局限的单因素检验。
  steady    : **Task 4 方法对方法基线臂**。数据层与 main 逐字节相同（同 load /
              同 pairing / 同合成热形状 / 同 EF），唯一区别是 gas_model='steady'：
              气网按 Kanelakis 式稳态输送建模（保留节点压力与 Weymouth 关系，
              抽掉管存状态与日循环闭合）。数据层本身不读 gas_model，
              由 gc_run_v3 取出后透传给 model_gc_v3。

负荷归一化口径（一次定死，见 data_manifest.md §1）：典型日 = 全年日历平均日
（每小时对 365 天取平均）的 24h 曲线，除以该曲线最大值（峰值归一），再乘 5.0 MW。
热负荷维持合成曲线（data_manifest.md §6），价格维持原口径。
"""
import os
import numpy as np
import pandas as pd

import config_v3 as C

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

PEN = 0.7
K = 8

ARM = os.environ.get('V3_ARM', 'main')
ARMS = {
    'old':       dict(load='syn',      pairing='ly_gs'),
    'shapeonly': dict(load='real',     pairing='ly_gs'),
    'paironly':  dict(load='syn',      pairing='gs_gs'),
    'efold':     dict(load='real',     pairing='gs_gs'),
    'main':      dict(load='real',     pairing='gs_gs'),
    # heat='real' 是唯一差别；未写 heat 的臂一律用合成曲线
    'heatreal':  dict(load='real',     pairing='gs_gs', heat='real'),
    # --- Task 4 方法对方法基线臂 -------------------------------------------
    # 'steady' 是**数据层与 main 逐字节相同**的一个臂：load/pairing/heat 全部照抄
    # main，唯一区别是下面这个 gas_model 标签（数据层本身不读它，由 gc_run_v3 取出
    # 后透传给 model_gc_v3）。这样"基线 vs 本文"的差异被**锁死在气网物理那一层**，
    # 场景集 / 种子 / 划分 / 削减 / 定标全部由同一段 prepare() 生成，不存在第二条
    # 数据链，也不可能出现"基线偷偷换了负荷形状或换了场景数"这类口径漂移。
    #   gas_model='dynamic'（默认，未写即此）: 本文口径，管存状态 + 日循环闭合
    #   gas_model='steady'                  : Kanelakis 式稳态输送——保留节点压力与
    #       Weymouth 输送关系，抽掉管存状态与日循环闭合，逐时独立平衡
    'steady':    dict(load='real',     pairing='gs_gs', gas_model='steady'),
}

# 未写 gas_model 的臂一律走本文的动态管存口径（保持既有所有臂的行为逐字不变）。
GAS_MODEL_DEFAULT = 'dynamic'


def gas_model(arm=None):
    """该数据臂对应的气网物理口径：'dynamic'（本文）| 'steady'（基线）。"""
    return ARMS[arm or ARM].get('gas_model', GAS_MODEL_DEFAULT)



# ---------------- 合成形状（与 code/data.py 逐字一致，不 import code 包） ----------------
def _norm(x):
    x = np.asarray(x, dtype=float)
    return x / x.max()


def heat_load_profile():
    """热负荷标幺曲线（冬季型，早晚供热高峰、午后低谷）——v3 维持合成（manifest §6）"""
    t = np.arange(24)
    temp = 2.0 + 7.0 * np.sin((t - 9) / 24 * 2 * np.pi)
    hdd = np.clip(12.0 - temp, 0, None)
    occ = 1.0 + 0.25 * ((t >= 6) & (t <= 9)) + 0.35 * ((t >= 18) & (t <= 22))
    return _norm(hdd * occ)


def synthetic_elec_profile():
    """合成电负荷标幺曲线（早晚双峰）——旧口径对照用"""
    t = np.arange(24)
    x = (0.55 + 0.30 * np.exp(-((t - 11) / 2.8) ** 2)
         + 0.42 * np.exp(-((t - 19) / 2.6) ** 2)
         + 0.12 * np.exp(-((t - 3) / 2.0) ** 2))
    return _norm(x)


def _kmeans(X, k, seed=0, n_init=10, iters=100):
    """与 code_v2/data_probe._kmeans 逐字一致"""
    rng = np.random.default_rng(seed)
    best = (np.inf, None, None)
    for _ in range(n_init):
        centers = [X[rng.integers(len(X))]]
        for _ in range(k - 1):
            d2 = np.min(((X[:, None, :] - np.array(centers)[None]) ** 2).sum(-1), axis=1)
            centers.append(X[rng.choice(len(X), p=d2 / d2.sum())])
        centers = np.array(centers, dtype=float)
        labels = np.zeros(len(X), dtype=int)
        for _ in range(iters):
            d2 = ((X[:, None, :] - centers[None]) ** 2).sum(-1)
            nl = d2.argmin(1)
            if np.all(nl == labels):
                break
            labels = nl
            for c in range(k):
                if np.any(labels == c):
                    centers[c] = X[labels == c].mean(0)
                else:
                    centers[c] = X[np.argmax(d2.min(1))]
        inertia = ((X - centers[labels]) ** 2).sum()
        if inertia < best[0]:
            best = (inertia, labels, centers.copy())
    return best[1], best[2]


# ---------------- 数据源加载 ----------------
def _real_elec_typical_day():
    """甘肃 2019 重建负荷：日历平均日 24h 曲线，峰值归一（manifest §1 口径）"""
    df = pd.read_csv(os.path.join(RES, 'load_gansu_2019_hourly.csv'),
                     parse_dates=['ts']).set_index('ts')
    assert len(df) == 8760 and not df['load_gwh'].isna().any()
    s = df['load_gwh'].astype(float)
    md = s.groupby(s.index.hour).mean()          # 日历平均日（GWh/h）
    shape = (md / md.max()).to_numpy()           # 峰值归一 24h
    return shape


def _syn_elec_typical_day():
    return synthetic_elec_profile()


def _wind_pv_curves(pairing):
    """返回 (wind_pu, pv_pu) 各 8760 小时标幺曲线（按全年观测最大出力归一）"""
    idx = pd.date_range('2019-01-01 00:00', '2019-12-31 23:00', freq='h')
    if pairing == 'gs_gs':
        w = pd.read_csv(os.path.join(RES, 'gansu_wind_2019_hourly.csv'),
                        parse_dates=['ts']).set_index('ts')['wind_pu']
        pv = pd.read_csv(os.path.join(RES, 'gansu_pv_2019_mw.csv'), parse_dates=['ts']).set_index('ts')['pv_mw']
        pv = pv / pv.max()                       # 按观测最大出力标幺（与旧口径一致）
    elif pairing == 'ly_gs':
        # 旧组合：连云港风 + 甘肃光（v2 缓存只读，列 wind_pu/pv_pu 已标幺）
        df = pd.read_csv(os.path.normpath(os.path.join(HERE, '..', 'code_v2', 'results',
                                                       'real_hourly_2019.csv')),
                         index_col=0, parse_dates=True)
        w, pv = df['wind_pu'], df['pv_pu']
    else:
        raise ValueError(pairing)
    w = w[~w.index.duplicated()].reindex(idx)
    pv = pv[~pv.index.duplicated()].reindex(idx)
    # 光伏源文件时间轴为 2018-12-31 23:00 -> 2019-12-31 22:00，与全年日历对齐后
    # 仅 2019-12-31 23:00 一个边界缺测小时；按 data_manifest.md §3 声明的口径
    # 以线性插值填补（该小时为深夜，物理值为 0 附近）。
    if pv.isna().any():
        n_nan = int(pv.isna().sum())
        pv = pv.interpolate(method='linear', limit_direction='both')
        print(f'[data_v3] 光伏边界缺测 {n_nan} h 已线性插值填补（manifest §3 声明口径）')
    assert len(w) == 8760 and not w.isna().any(), '风电曲线对齐失败'
    assert len(pv) == 8760 and not pv.isna().any(), '光伏曲线对齐失败'
    return w.to_numpy(float), pv.to_numpy(float)


def build_profiles(pen=PEN, p_load_peak=5.0, h_load_peak=4.0):
    """给定渗透率下的源荷数据（load / heat 形状按 ARM 切换；定标算法与 code/data.py 一致）"""
    load_kind = ARMS[ARM]['load']
    heat_kind = ARMS[ARM].get('heat', 'syn')
    pl_shape = _real_elec_typical_day() if load_kind == 'real' else _syn_elec_typical_day()
    pl = pl_shape * p_load_peak

    if heat_kind == 'real':
        import data_heat_real as DH
        # 先按该年逐时最大值归一，再乘 h_load_peak：热峰仍是 4.0 MW_th（论文的
        # 电侧备用覆盖假设据此成立），换掉的只是小时形状与逐日幅度。
        heat_d = DH.heat_daily() * h_load_peak
        hl = heat_d.mean(axis=0)
        print('[data_v3] 热负荷=实测 %s 2019 逐时区域供热计量；热峰 %.3f MW_th, '
              '日均热量 %.3f MWh_th（合成口径 %.3f）'
              % (DH.RECORD, heat_d.max(), heat_d.sum(axis=1).mean(),
                 heat_load_profile().sum() * h_load_peak))
    else:
        hl = heat_load_profile() * h_load_peak
        heat_d = np.tile(hl, (365, 1))

    w, s = _wind_pv_curves(ARMS[ARM]['pairing'])
    e_load = pl.sum()
    # 与 data_probe 口径一致：unit = 逐日潜在电量 (3·wind + 4·pv) 的 365 天均值
    unit = (w * C.RATIO_WIND + s * C.RATIO_PV).reshape(-1, 24).sum(axis=1).mean()
    k = pen * e_load / unit
    cw, cs = k * C.RATIO_WIND, k * C.RATIO_PV
    # 逐日 24h 曲线 × 装机
    w_d = w.reshape(-1, 24) * cw
    s_d = s.reshape(-1, 24) * cs

    return dict(
        wind=w_d[0] if False else w * cw,      # 兼容字段（不使用逐日视图时）
        wind_d=w_d, pv_d=s_d, heat_d=heat_d,
        pv=s * cs, p_load=pl, h_load=hl,
        price=np.array(C.price_profile()),
        cap_wind=cw, cap_pv=cs, penetration=pen,
        heat_kind=heat_kind,
    )


def prepare(verify=False):
    """返回 dict(base, wind_d, pv_d, heat_d, dates, tr, te, reduced, cap_w, cap_pv)"""
    base = build_profiles(PEN)
    wind_d, pv_d, heat_d = base['wind_d'], base['pv_d'], base['heat_d']
    heat_real = base.get('heat_kind') == 'real'
    n_days = len(wind_d)
    assert n_days == 365, n_days
    dates = pd.date_range('2019-01-01', periods=n_days, freq='D').strftime('%Y-%m-%d')

    rng = np.random.default_rng(42)
    perm = rng.permutation(n_days)
    tr, te = perm[:265], perm[265:]

    def _sig(i):
        v = [wind_d[i] / max(wind_d[i].max(), 1e-9),
             pv_d[i] / max(pv_d[i].max(), 1e-9)]
        if heat_real:      # 代表日须同时代表它实际携带的热形状，故并入签名
            v.append(heat_d[i] / max(heat_d[i].max(), 1e-9))
        return np.concatenate(v)

    X = np.array([_sig(i) for i in tr])
    labels, _ = _kmeans(X, K, seed=0)
    reduced = []
    for c in range(K):
        idx = tr[labels == c]
        d2 = np.linalg.norm(X[labels == c] - X[labels == c].mean(0), axis=1)
        rep = idx[np.argmin(d2)]
        sc = dict(wind=wind_d[rep], pv=pv_d[rep],
                  prob=len(idx) / len(tr), rep_day=dates[rep])
        if heat_real:
            sc['h_load'] = heat_d[rep]
        reduced.append(sc)

    return dict(base=base, wind_d=wind_d, pv_d=pv_d, heat_d=heat_d, dates=dates,
                tr=tr, te=te, reduced=reduced,
                cap_w=base['cap_wind'], cap_pv=base['cap_pv'])


def expected_scenario(dat):
    """确定性期望日（训练日均值曲线，与 data_probe 口径一致）"""
    base = dat['base']
    return dict(wind=(dat['wind_d'][dat['tr']].mean(0)),
                pv=(dat['pv_d'][dat['tr']].mean(0)),
                p_load=base['p_load'], h_load=base['h_load'],
                price=base['price'], penetration=PEN)


def test_scenario(dat, i):
    base = dat['base']
    h_load = dat['heat_d'][i] if base.get('heat_kind') == 'real' else base['h_load']
    return dict(wind=dat['wind_d'][i], pv=dat['pv_d'][i],
                p_load=base['p_load'], h_load=h_load,
                price=base['price'], penetration=PEN)


if __name__ == '__main__':
    d = prepare()
    b = d['base']
    print(f'ARM={ARM}  场景库 {len(d["dates"])} 天, 训练 {len(d["tr"])}, 测试 {len(d["te"])}')
    print(f'风电装机 {d["cap_w"]:.3f} MW, 光伏装机 {d["cap_pv"]:.3f} MW')
    print(f'日电负荷 {b["p_load"].sum():.3f} MWh, 日热负荷 {b["h_load"].sum():.3f} MWh_th')
    print('电负荷 24h:', np.round(b['p_load'], 3).tolist())
    reps = [(sc['rep_day'], round(sc['prob'], 4)) for sc in d['reduced']]
    print('8 场景代表日/概率:', reps)
