# -*- coding: utf-8 -*-
"""code_v3 电网受入容量运行器：一次跑一个 (cap, mode)，独立进程。

协议与 code_v2/probe_gridcap_run.py（E13/E32/CAL 口径）完全一致：
  - 265 训练 / 100 测试，seed=42；k=8 场景削减，seed=0（数据层按 V3_ARM 切换）
  - HEP：8 场景两阶段 SP 求解 -> 承诺 u_fix
  - EEV：训练期期望场景确定性求解 -> 承诺 u_eev
  - 样本外：承诺固定，逐测试日（当日全信息）再调度；VSS = EEV_oos - HEP_oos
  - grid_cap 同时施加于 HEP、EEV、样本外再调度三处（E32 同步施加原则）
  - heat_shed=True（EENS_h 由显式热切负荷变量度量，VOLL=5000 元/MWh）
  - mode sp = 纯两阶段 SP（默认主口径，不开备用耦合）
  - mode c  = SP + 备用耦合（c_res=0）对照档
  - Gurobi 13.0.3，MIPGap 1e-4，TimeLimit 600s（不改动）

用法：
  V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe cap_run_v3.py inf sp
  ... tag ∈ {inf, 6.25, 5.0, 3.5, 3.0, 2.5}
输出：code_v3/results/V3_CAP_<tag>_<mode>[_<arm>]_{oos,scen,summary}.csv
arm=old + tag=inf + mode=sp 内置锚点断言（移植校验）。
"""
import os
import sys
import numpy as np
import pandas as pd

import config_v3 as C
import model_cap_v3 as MC
import data_v3 as DP

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

ANCHOR_EEV = 33941.95756022965
ANCHOR_HEP = 33425.63695664427

PEN = 0.7
ARM = DP.ARM


def run(tag, mode='sp'):
    gc = None if tag == 'inf' else float(tag)
    ftag = f'{tag}_{mode}_{ARM}'

    dat = DP.prepare()
    te, dates = dat['te'], dat['dates']
    base, reduced = dat['base'], dat['reduced']

    use_reserve = (mode == 'c')
    kw = dict(use_reserve=use_reserve, c_res=0.0, heat_shed=True, grid_cap=gc)
    if use_reserve:
        kw['risk_lambda'] = 0.0

    # ---------- HEP：两阶段 SP ----------
    hep = MC.solve_rc_cap(base, scenarios=reduced, **kw)
    if hep is None:
        pd.DataFrame([dict(tag=tag, mode=mode, arm=ARM, feasible=False)]).to_csv(
            os.path.join(RES, f'V3_CAP_{ftag}_summary.csv'), index=False,
            encoding='utf-8-sig')
        print(f'[V3 gridcap {tag} {mode} {ARM}] RP 不可行')
        return
    u_fix = hep['u'].astype(float)
    pbar_fix = hep['pbar'] if use_reserve else None
    rplus_fix = hep['rplus'] if use_reserve else None
    rminus_fix = hep['rminus'] if use_reserve else None

    # ---------- EEV ----------
    exp_sc = DP.expected_scenario(dat)
    eev = MC.solve_rc_cap(exp_sc, None, **kw)
    assert eev is not None, 'EEV 确定性问题不可行'
    u_eev = eev['u'].astype(float)
    pbar_eev = eev['pbar'] if use_reserve else None
    rplus_eev = eev['rplus'] if use_reserve else None
    rminus_eev = eev['rminus'] if use_reserve else None

    # ---------- 样本外评价 ----------
    rows = []
    for j, i in enumerate(te):
        sc = DP.test_scenario(dat, i)
        re_avail = float((sc['wind'] + sc['pv']).sum())
        r = MC.solve_rc_cap(sc, None, u_fix=u_fix, pbar_fix=pbar_fix,
                            rplus_fix=rplus_fix, rminus_fix=rminus_fix, **kw)
        e = MC.solve_rc_cap(sc, None, u_fix=u_eev, pbar_fix=pbar_eev,
                            rplus_fix=rplus_eev, rminus_fix=rminus_eev, **kw)
        assert r is not None and e is not None, f'测试日 {dates[i]} 不可行'
        rows.append(dict(
            test_day=dates[i],
            cost_hep=float(r['exp_cost']), cost_eev=float(e['exp_cost']),
            shed_e_hep=float(r['scen_rows'][0]['shed_e_MWh']),
            shed_h_hep=float(r['scen_rows'][0]['shed_h_MWh']),
            shed_e_eev=float(e['scen_rows'][0]['shed_e_MWh']),
            shed_h_eev=float(e['scen_rows'][0]['shed_h_MWh']),
            carbon_hep=float(r['scen_rows'][0]['carbon']),
            re_avail_MWh=re_avail,
        ))
        if (j + 1) % 20 == 0:
            print(f'  OOS {j + 1}/100')
    df = pd.DataFrame(rows)

    costs = df['cost_hep'].to_numpy()
    costs_eev = df['cost_eev'].to_numpy()
    n = len(costs)
    vss = float(costs_eev.mean() - costs.mean())
    eens_e = float(df['shed_e_hep'].mean())
    eens_h = float(df['shed_h_hep'].mean())

    scen_rows = []
    for r in hep['scen_rows']:
        s = r['scenario']
        scen_rows.append(dict(
            scenario=s, prob=r['prob'], rep_day=reduced[s]['rep_day'],
            re_avail_MWh=r['re_avail_MWh'],
            shed_e_MWh=r['shed_e_MWh'], shed_h_MWh=r['shed_h_MWh'],
            shed_hours=int(sum(1 for v in r['shed_e_hours'] if v > 1e-9)
                           + sum(1 for v in r['shed_h_hours'] if v > 1e-9)),
            op_cost=r['op_cost'],
        ))
    pd.DataFrame(scen_rows).to_csv(
        os.path.join(RES, f'V3_CAP_{ftag}_scen.csv'), index=False, encoding='utf-8-sig')

    n_changes = int((np.diff(hep['u']) != 0).sum())
    summary = [
        dict(metric='tag', value=tag, unit=''),
        dict(metric='mode', value=mode, unit=''),
        dict(metric='arm', value=ARM, unit=''),
        dict(metric='e_grid_mode', value=C.E_GRID_MODE, unit=''),
        dict(metric='grid_cap_MW', value=('' if gc is None else gc), unit=''),
        dict(metric='feasible', value=True, unit=''),
        dict(metric='hep_oos_mean', value=float(costs.mean()), unit='元'),
        dict(metric='eev_oos_mean', value=float(costs_eev.mean()), unit='元'),
        dict(metric='vss', value=vss, unit='元'),
        dict(metric='vss_pct', value=float(100 * vss / costs_eev.mean()), unit='%'),
        dict(metric='eens_e_MWh_per_day', value=eens_e, unit='MWh/日'),
        dict(metric='eens_h_MWh_per_day', value=eens_h, unit='MWh/日'),
        dict(metric='n_days_shed_e_hep', value=int((df['shed_e_hep'] > 1e-9).sum()), unit='天'),
        dict(metric='n_days_shed_h_hep', value=int((df['shed_h_hep'] > 1e-9).sum()), unit='天'),
        dict(metric='n_days_shed_e_eev', value=int((df['shed_e_eev'] > 1e-9).sum()), unit='天'),
        dict(metric='n_days_shed_h_eev', value=int((df['shed_h_eev'] > 1e-9).sum()), unit='天'),
        dict(metric='oos_max_shed_e_MWh', value=float(df['shed_e_hep'].max()), unit='MWh'),
        dict(metric='oos_max_shed_h_MWh', value=float(df['shed_h_hep'].max()), unit='MWh'),
        dict(metric='oos_mean_carbon_hep', value=float(df['carbon_hep'].mean()), unit='tCO2/日'),
        dict(metric='n_commit_changes', value=n_changes, unit=''),
        dict(metric='rp_exp_cost', value=hep['exp_cost'], unit='元'),
        dict(metric='rp_solve_time', value=hep['solve_time'], unit='s'),
        dict(metric='rp_mip_gap', value=hep['mip_gap'], unit=''),
        dict(metric='rp_status', value=hep['status'], unit=''),
        dict(metric='n_vars', value=hep['n_vars'], unit=''),
        dict(metric='n_cons', value=hep['n_cons'], unit=''),
    ]

    # 移植校验门槛：arm=old + inf + sp 必须逐位复现旧层锚点
    if ARM == 'old' and tag == 'inf' and mode == 'sp':
        rel_h = abs(costs.mean() - ANCHOR_HEP) / ANCHOR_HEP
        rel_e = abs(costs_eev.mean() - ANCHOR_EEV) / ANCHOR_EEV
        summary.append(dict(metric='anchor_HEP_diff_rel', value=rel_h, unit=''))
        summary.append(dict(metric='anchor_EEV_diff_rel', value=rel_e, unit=''))
        print(f'[anchor old/inf/sp] HEP rel {rel_h:.2e} | EEV rel {rel_e:.2e}')
        if rel_h >= 1e-9 or rel_e >= 1e-9:
            pd.DataFrame(summary).to_csv(
                os.path.join(RES, f'V3_CAP_{ftag}_summary.csv'), index=False,
                encoding='utf-8-sig')
            print('STOP: cap 模型移植未逐位复现旧层锚点')
            sys.exit(2)

    df.to_csv(os.path.join(RES, f'V3_CAP_{ftag}_oos.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(summary).to_csv(os.path.join(RES, f'V3_CAP_{ftag}_summary.csv'),
                                 index=False, encoding='utf-8-sig')

    sh = [(r['scenario'], round(r['shed_e_MWh'], 4), round(r['shed_h_MWh'], 4))
          for r in scen_rows if r['shed_e_MWh'] > 1e-9 or r['shed_h_MWh'] > 1e-9]
    print(f'[V3 gridcap {tag} {mode} {ARM}] OOS均值 {costs.mean():.1f} | EEV {costs_eev.mean():.1f} '
          f'| VSS {vss:.1f} ({100 * vss / costs_eev.mean():.2f}%) '
          f'| EENS_e {eens_e:.4f} EENS_h {eens_h:.4f} MWh/日 '
          f'| 切负荷天数 e={int((df["shed_e_hep"] > 1e-9).sum())} '
          f'h={int((df["shed_h_hep"] > 1e-9).sum())} | 承诺切换 {n_changes}')
    print(f'  训练场景切负荷: {sh if sh else "无（8 场景全部 EENS=0）"}')
    print(f'  -> V3_CAP_{ftag}_{{oos,scen,summary}}.csv')


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 'sp')
    print('done')
