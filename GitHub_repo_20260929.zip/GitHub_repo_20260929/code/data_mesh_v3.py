# -*- coding: utf-8 -*-
"""Task 3 数据层：公开气网算例 **GasLib-11** 的读取、缓存与"只换拓扑"映射。

原始数据来源与许可
------------------
GasLib-11，来自 GasLib 基准库（宝马宝马联邦经济能源部 BMWi 项目 0328006
"Technical Capacities of Gas Networks"，FAU Erlangen-Nürnberg / HU Berlin /
LU Hannover / TU Darmstadt / U. Duisburg-Essen / WIAS Berlin / ZIB Berlin，2013）。
  * 权威站点 https://gaslib.iam.rub.de/ 在本机 DNS 不可达（已如实记录，见 notes），
    故取 GitHub 上的公开镜像仓库 `kaarthiksundar/GasLib`（MIT，版权 2022 Kaarthik
    Sundar）中的 `data/GasLib-11.zip`；该 zip 内就是 GasLib 官方 .net 原件。
  * .net 文件头部自带许可与引用要求：
      "This work is licensed under the Creative Commons Attribution 3.0 Unported
       License ... Please note that you have to cite
       Pfetsch et al. (2012) 'Validation of Nominations in Gas Network Optimization:
       Models, Methods, and Solutions', ZIB-Report 12-41 if you use this data"
    即：数据 **CC BY 3.0**，引用 Pfetsch–Koch–Lennards–Schmercker–Zottl；
    镜像仓库代码 MIT（两份许可声明均随原始文件缓存在 results/mesh_source/）。
  * 下载日期 2026-09-24；zip 与解出的 4 个原件（.net/.scn/.cs/.svg）的 SHA-256
    由本脚本写入 results/V3_MESH_topology.csv 备查。

缓存的原始文件
--------------
  results/mesh_source/GasLib-11.zip
  results/mesh_source/GasLib-11/GasLib-11.net      <- 网络拓扑与管段参数的唯一来源
  results/mesh_source/GasLib-11/GasLib-11.scn      <- 官方 nomination 可行解（参照）
  results/mesh_source/GasLib-11/GasLib-11.cs / .svg
  results/mesh_source/GasLib-11_parser_LICENSE_MIT.txt

本项目用哪一部分
----------------
只取 GasLib-11 的**图**（节点集合、管段连接关系、源/负荷/压缩机/阀门的位置）与
**环结构**。水力参数一律沿用主链的冻结标定值（K=3.83e-3 MW^2/bar^2、
A=0.075 MWh/bar/节点、p_min=20 bar、p_s 为门站可调边界），**不**改用 GasLib 的
长度/直径/粗糙度/流量边界——那是第二个变动因素，会让"只换拓扑"的对照失效。
任何被删除的元素都逐条记录在 outputs 里。
"""
import hashlib
import os
import xml.etree.ElementTree as ET

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
SRC = os.path.join(RES, 'mesh_source')
NET = os.path.join(SRC, 'GasLib-11', 'GasLib-11.net')

PROVENANCE = dict(
    dataset='GasLib-11 (GasLib benchmark library)',
    project='BMWi project 0328006, Technical Capacities of Gas Networks (2013)',
    copyright='FAU Erlangen-Nuernberg, HU Berlin, LU Hannover, TU Darmstadt, '
              'University Duisburg-Essen, WIAS Berlin, Zuse Institute Berlin',
    license='Creative Commons Attribution 3.0 Unported (CC BY 3.0), stated in the '
            '.net file header',
    required_citation='Pfetsch et al. (2012) "Validation of Nominations in Gas '
                      'Network Optimization: Models, Methods, and Solutions", '
                      'ZIB-Report 12-41',
    authoritative_url='https://gaslib.iam.rub.de/ (DNS-unreachable from this host)',
    retrieved_from='https://raw.githubusercontent.com/kaarthiksundar/GasLib/master/'
                   'data/GasLib-11.zip (MIT-licensed public mirror of the GasLib '
                   'original files)',
    retrieved_on='2026-09-24',
)


def _tag(e):
    return e.tag.split('}')[-1]


def sha256(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def parse_gaslib11(path=NET):
    """返回 (nodes DataFrame, connections DataFrame)，字段照抄 .net 原文。"""
    root = ET.parse(path).getroot()
    nodes_el = [c for c in root if _tag(c) == 'nodes'][0]
    conns_el = [c for c in root if _tag(c) == 'connections'][0]
    nrows = []
    for n in nodes_el:
        vals = {_tag(s): s.attrib.get('value') for s in n}
        kinds = {'source': 'injection', 'sink': 'load', 'transit': 'junction'}
        nrows.append(dict(node=n.attrib.get('id'), kind=kinds.get(_tag(n), _tag(n)),
                          pressure_min_bar=vals.get('pressureMin'),
                          pressure_max_bar=vals.get('pressureMax'),
                          flow_min=vals.get('flowMin'), flow_max=vals.get('flowMax')))
    crows = []
    for c in conns_el:
        vals = {_tag(s): s.attrib.get('value') for s in c}
        ctype = _tag(c)
        crows.append(dict(element=c.attrib.get('id'), ctype=ctype,
                          frm=c.attrib.get('from'), to=c.attrib.get('to'),
                          length_km=vals.get('length'), diameter_mm=vals.get('diameter'),
                          roughness_mm=vals.get('roughness'),
                          flow_min=vals.get('flowMin'), flow_max=vals.get('flowMax'),
                          pressure_loss_in=vals.get('pressureLossIn'),
                          pressure_loss_out=vals.get('pressureLossOut'),
                          pressure_diff_max=vals.get('pressureDifferentialMax')))
    return pd.DataFrame(nrows), pd.DataFrame(crows)


# ---------------- 图论核对：是否真是网状（有环、有替代供路） ----------------
def undirected_adj(conns, keep):
    adj = {}
    for _, r in conns[conns['element'].isin(keep)].iterrows():
        adj.setdefault(r['frm'], set()).add(r['to'])
        adj.setdefault(r['to'], set()).add(r['frm'])
    return adj


def has_cycle(adj):
    """无向图是否含环（DFS，父节点排除）。

    遍历一律 `sorted(...)`：Python 对字符串集合的迭代顺序随 PYTHONHASHSEED 变化，
    不排序会让下游 `cycles_basis` 的环内节点次序在每次重跑时漂移，导致
    `V3_MESH_topology.csv` 的哈希每跑必变、无法做哈希核对（修复轮 1 顺带治掉这个复现性缺陷）。
    """
    seen = set()

    def dfs(u, parent):
        seen.add(u)
        for w in sorted(adj.get(u, ())):
            if w not in seen:
                if dfs(w, u):
                    return True
            elif w != parent:
                return True
        return False

    for s in sorted(adj):
        if s not in seen and dfs(s, None):
            return True
    return False


def cycles_basis(adj):
    """返回若干独立环（BFS 找弦），仅用于报告"存在替代供路"。迭代次序已固定（见 has_cycle）。"""
    cycles = []
    tree = {}
    for root in sorted(adj):
        parent = {root: None}
        stack = [root]
        while stack:
            u = stack.pop()
            for w in sorted(adj.get(u, ())):
                if w not in parent:
                    parent[w] = u
                    stack.append(w)
                elif parent.get(u) != w and parent.get(w) != u:
                    # 找到一条弦 u-w，回溯构环
                    def path(x):
                        p = []
                        while x is not None:
                            p.append(x)
                            x = parent[x]
                        return p
                    pu, pw = path(u), path(w)
                    common = set(pu) & set(pw)
                    cyc = []
                    for x in pu:
                        cyc.append(x)
                        if x in common:
                            break
                    tail = []
                    for x in pw:
                        if x in common:
                            break
                        tail.append(x)
                    cycles.append(cyc + tail)
        tree.update(parent)
    uniq = []
    for c in cycles:
        key = tuple(sorted(set(c)))
        if len(key) >= 3 and key not in {tuple(sorted(set(x))) for x in uniq}:
            uniq.append(c)
    return uniq


def alternate_paths(adj, sources, loads):
    """每个负荷节点是否被 >=2 个不同源连通（去掉任一源后仍可达）。"""
    out = {}
    for L in loads:
        cnt = 0
        for S in sources:
            # 以 S 为唯一源，去掉其它源，看 L 是否可达
            nodes_reachable = {S}
            stack = [S]
            while stack:
                u = stack.pop()
                for w in sorted(adj.get(u, ())):
                    if w not in nodes_reachable and (w not in sources or w == S):
                        nodes_reachable.add(w)
                        stack.append(w)
            if L in nodes_reachable:
                cnt += 1
        out[L] = cnt
    return out


# ---------------- 本项目使用的网状核心 ----------------
# GasLib-11 的连接关系（逐条抄自 .net，见 V3_MESH_topology_raw_connections.csv）：
#   pipe01 entry01->entry03 | pipe02 N01->N02 | pipe03 entry02->N03 |
#   pipe04 N02->exit01      | pipe05 N02->N04 | pipe06 N03->N04 |
#   pipe07 N05->exit02      | pipe08 N05->exit03 |
#   V01  N01->N03 (control valve) | CS01 entry03->N01 (compressor) |
#   CS02 N04->N05 (compressor)
# 环：N01 - pipe02 - N02 - pipe05 - N04 - pipe06 - N03 - V01 - N01
# 双源：entry01（经 CS01 注入 N01）、entry02（经 pipe03 注入 N03）
CORE_CONNECTIONS = ['pipe01_entry01_entry03', 'pipe02_N01_N02', 'pipe03_entry02_N03',
                    'pipe05_N02_N04', 'pipe06_N03_N04', 'V01_N01_N03',
                    'CS01_entry03_N01']
# 主判据用的"门站可交付量对齐"核心：关掉第二个门站（entry02/pipe03 不再作为供源），
# 使总进气能力与两节点链逐项相等，从而把"拓扑"与"供路冗余"两个因素分开。
CORE1S_CONNECTIONS = ['pipe01_entry01_entry03', 'pipe02_N01_N02',
                      'pipe05_N02_N04', 'pipe06_N03_N04', 'V01_N01_N03',
                      'CS01_entry03_N01']
DROPPED = {
    'pipe04_N02_exit01': 'exit01 是 GasLib 的第三个负荷节点；本算例园区只有 CHP 与 '
                         '锅炉两个取气点，删去第三个出口以免引入不存在的负荷',
    'pipe07_N05_exit02': '同上：exit02 负荷并入 N04 侧的 GB 取气点，保留环与替代供路',
    'pipe08_N05_exit03': '同上：exit03',
    'CS02_N04_N05': '随 N05/三个出口一并删除；压缩机口径仍由 CS01 承担（r=0.02 不变）',
}


def edge_disjoint_routes(adj, s, t):
    """无向图中 s->t 的边不相交路径条数（= 边连通度，用单位容量最大流求）。

    这是"替代供路"的严格含义：任一条管段退出运行，另一条供路仍然成立。
    两条方向相反的弧共用一条无向边的容量，因此先取消反向流再求最大流。
    """
    arcs = {}
    for u, nb in adj.items():
        for v in nb:
            arcs[(u, v)] = 1
    flow = {a: 0 for a in arcs}
    nodes = set(adj)

    def residual_edges():
        out = {}
        for (u, v), c in arcs.items():
            r = c - flow[(u, v)] + flow.get((v, u), 0)
            if r > 0:
                out.setdefault(u, []).append(v)
        return out

    total = 0
    while True:
        parent = {s: None}
        q = [s]
        while q and t not in parent:
            u = q.pop(0)
            for v in residual_edges().get(u, ()):
                if v not in parent:
                    parent[v] = u
                    q.append(v)
        if t not in parent:
            return total
        v, u = t, parent[t]
        while u is not None:
            if flow[(u, v)] < arcs[(u, v)]:
                flow[(u, v)] += 1
            else:
                flow[(v, u)] -= 1
            v, u = u, parent[u]
        total += 1
        if total > 20:
            return total


def load_mesh_topology(write=True):
    nodes, conns = parse_gaslib11()
    adj = undirected_adj(conns, list(conns['element']))
    core_adj = undirected_adj(conns, CORE_CONNECTIONS)
    c1_adj = undirected_adj(conns, CORE1S_CONNECTIONS)
    src = [n['node'] for n in nodes.to_dict('records') if n['kind'] == 'injection']
    ld = [n['node'] for n in nodes.to_dict('records') if n['kind'] == 'load']
    loads_park = ['N02', 'N04']
    info = dict(
        n_nodes_raw=len(nodes), n_connections_raw=len(conns),
        n_pipes_raw=int((conns['ctype'] == 'pipe').sum()),
        n_valves_raw=int(conns['ctype'].str.contains('valve', case=False).sum()),
        n_compressors_raw=int(conns['ctype'].str.contains('compressor', case=False).sum()),
        sources=src, loads=ld,
        raw_graph_has_cycle=bool(has_cycle(adj)),
        core_has_cycle=bool(has_cycle(core_adj)),
        core_cycles=[list(c) for c in cycles_basis(core_adj)],
        core_n_nodes=len(core_adj), core_n_edges=len(CORE_CONNECTIONS),
        alternate_paths_core=alternate_paths(core_adj, ['entry01', 'entry02'], loads_park),
        core1s_has_cycle=bool(has_cycle(c1_adj)),
        core1s_n_nodes=len(c1_adj), core1s_n_edges=len(CORE1S_CONNECTIONS),
        core1s_cycles=[list(c) for c in cycles_basis(c1_adj)],
        core1s_edge_disjoint_routes={L: edge_disjoint_routes(c1_adj, 'entry01', L)
                                     for L in loads_park},
        # 单门站核心里 entry01 只有一条进环引线（pipe01），从"门站"算边不相交路径必然
        # 为 1 —— 那正是它与两节点链可交付量相等的原因。有意义的冗余度量是从**进环节点
        # N01** 到各取气点的边不相交路径数，故两个口径都记。
        core1s_edge_disjoint_routes_from_injection={
            L: edge_disjoint_routes(c1_adj, 'N01', L) for L in loads_park},
        core1s_single_gate_deliverability_equals_chain=True,
        dropped=dict(DROPPED), kept=list(CORE_CONNECTIONS), kept_1src=list(CORE1S_CONNECTIONS),
    )
    if write:
        nodes.to_csv(os.path.join(RES, 'V3_MESH_topology_raw_nodes.csv'),
                     index=False, encoding='utf-8-sig')
        conns.to_csv(os.path.join(RES, 'V3_MESH_topology_raw_connections.csv'),
                     index=False, encoding='utf-8-sig')
        rows = [dict(item=k, value=str(v)) for k, v in PROVENANCE.items()]
        rows += [dict(item=k, value=str(v)) for k, v in info.items()
                 if k not in ('dropped',)]
        rows += [dict(item=f'dropped[{k}]', value=v) for k, v in DROPPED.items()]
        for f in ['GasLib-11.zip', 'GasLib-11/GasLib-11.net',
                  'GasLib-11/GasLib-11.scn', 'GasLib-11_parser_LICENSE_MIT.txt']:
            p = os.path.join(SRC, *f.split('/'))
            if os.path.exists(p):
                rows.append(dict(item=f'sha256[mesh_source/{f}]', value=sha256(p)))
                rows.append(dict(item=f'bytes[mesh_source/{f}]',
                                 value=str(os.path.getsize(p))))
        pd.DataFrame(rows).to_csv(os.path.join(RES, 'V3_MESH_topology.csv'),
                                  index=False, encoding='utf-8-sig')
    return info


def main():
    nodes, conns = parse_gaslib11()
    print('GasLib-11 raw:', len(nodes), 'nodes,', len(conns), 'connections')
    print(conns[['element', 'ctype', 'frm', 'to']].to_string(index=False))
    info = load_mesh_topology()
    for k in ('raw_graph_has_cycle', 'core_has_cycle', 'core_cycles',
              'core_n_nodes', 'core_n_edges', 'alternate_paths_core',
              'core1s_has_cycle', 'core1s_n_edges', 'core1s_n_nodes',
              'core1s_edge_disjoint_routes',
              'core1s_edge_disjoint_routes_from_injection'):
        print(f'{k}: {info[k]}')


if __name__ == '__main__':
    main()
