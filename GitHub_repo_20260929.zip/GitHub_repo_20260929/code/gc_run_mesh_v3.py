# -*- coding: utf-8 -*-
"""code_v3 MESH 运行器：Task 3 —— 在非链式（网状 / 有替代供路）气网上复现两条结构性结论。

口径与 gc_run_v3.py 同源，**只换拓扑**：
  同一 data_v3 场景层与随机种子（V3_ARM 默认 main）、同一排放因子 0.8922（config_v3
  官方西北 OM）、同一 Weymouth 标定值 K=3.83e-3 MW^2/bar^2、同一管存常数
  0.075 MWh/bar 与压力下限 20 bar、同一 60 余弦 PWL 断点、同一日循环
  p0_mode='periodic'、同一 MIPGap 1e-4 / 600 s、同一电热侧设备与负荷。

三个动作：
  --regress   回归自检（必须先过）：通用模型退化回两节点链，须复现
              results/V3_GC_scan_carbon.csv 的 arm=main 四条可达碳地板、
              rp_exp_carbon，以及 results/V3_GC_<cfg>_main_summary.csv 的 rp_exp_cost。
              复现不了就退出码 2，不进入网状实验。
  --cells     三格：M_B0（mesh + 无气网约束，线性气帽口径）/ M_PS50 / M_PS70
              环境变量 V3_MESH_CELL 选格，V3_MESH_DIR 选方向线性化（binary|pwl_asym）。
              每格记录期望成本、期望碳、可达碳地板、闸阀节流小时数、节点压力贴界小时数、
              管存利用率、可逆管段反向流小时数、求解时间、Gurobi 状态码。
  --topology  GasLib-11 原始数据 -> 本项目网状核心的完整性核对。

用法（每格独立进程，与 gc_run_v3 的"禁止同进程连跑"纪律一致）：
  Y:/cuda/python.exe -B gc_run_mesh_v3.py --regress
  V3_MESH_CELL=M_PS70 Y:/cuda/python.exe -B gc_run_mesh_v3.py --cells

输出（results/）：V3_MESH_regression.csv、V3_MESH_cells.csv、
  V3_MESH_<cell>_gasmetrics.csv、V3_MESH_<cell>_directions.csv、V3_MESH_topology.csv
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

import config_v3 as C
import data_v3 as DP
import model_mesh_v3 as MM

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

ARM = DP.ARM
K_W = 0.00383          # model_gc_v3 / 论文冻结标定值
A_NODE = 0.075         # MWh/bar 每节点
PD_MIN = 20.0          # bar
COMP_R = 0.02          # 压缩机燃料率
N_PTS = 60             # 余弦 PWL 断点
# 回归闸门容差：唯一出处是 config_v3.MESH_REG_TOL，audit_v3.py 的 N3/N3b 引用同一常量
# （历史上两处各写一份、审计那份松 10 倍，见修复轮 1 / I5）。
TOL_H = C.MESH_REG_TOL

CELLS = {
    # 主判据：GasLib-11 网状核心，**关掉第二个门站**，使门站总可交付量与两节点链相等，
    # 于是"两节点 vs 网状"的差别只剩拓扑本身（环 + 流向不定），不混入供路冗余。
    'M_B0':   dict(coupled=False, ps=None, single=True),
    'M_PS50': dict(coupled=True, ps=50.0, single=True),
    'M_PS60': dict(coupled=True, ps=60.0, single=True),
    'M_PS70': dict(coupled=True, ps=70.0, single=True),
    # 稳健性：公开算例原样的双门站网状（供路冗余 + 环），只跑 70 bar
    'M2S_PS70': dict(coupled=True, ps=70.0, single=False),
}
REG_CELLS = {'B0': None, 'PS50': 50.0, 'PS60': 60.0, 'PS70': 70.0}


# ---------------------------------------------------------------- 通用工具
def _val(r, key):
    if r is None or key not in r or r[key] is None:
        return np.nan
    return float(r[key])


def _status(r):
    return -1 if r is None else int(r['status'])


def _name(r):
    if r is None:
        return 'None'
    return str(r.get('status_name') or MM.status_name(r['status']))


def archive_reference():
    """主链存档：V3_GC_scan_carbon.csv（arm=ARM）+ V3_GC_<cfg>_<arm>_summary.csv。"""
    scan = pd.read_csv(os.path.join(RES, 'V3_GC_scan_carbon.csv'),
                       encoding='utf-8-sig')
    ref = scan[scan['arm'] == ARM].set_index('cfg')
    out = {}
    for cfg in REG_CELLS:
        s = pd.read_csv(os.path.join(RES, f'V3_GC_{cfg}_{ARM}_summary.csv'),
                        encoding='utf-8-sig')
        ser = s.set_index(s.columns[0])[s.columns[1]]
        out[cfg] = dict(carbon_min=float(ref.loc[cfg, 'carbon_min_exp_rp']),
                        rp_carbon=float(ref.loc[cfg, 'rp_exp_carbon']),
                        rp_cost=float(ser['rp_exp_cost']),
                        rp_status=int(float(ref.loc[cfg, 'carbon_min_rp_status'])))
    return out


def net_metrics(rows, met, net):
    """逐场景行 -> 气网诊断指标（命名口径对齐 gc_run_v3.rp_gas_metrics）。"""
    n = len(rows)
    out = dict(n_obs=n, hours_total=int(n * met['T']))
    for nd in net['nodes']:
        nid = nd['id']
        out[f'{nid}_at_min_h'] = int(sum(r[f'{nid}_at_min_h'] for r in rows))
        out[f'{nid}_at_max_h'] = int(sum(r[f'{nid}_at_max_h'] for r in rows))
        out[f'{nid}_min_obs'] = float(min(r[f'{nid}_min'] for r in rows))
        out[f'{nid}_max_obs'] = float(max(r[f'{nid}_max'] for r in rows))
    for e in net['elements']:
        eid = e['id']
        out[f'{eid}_throttle_h'] = int(sum(r.get(f'{eid}_throttle_h', 0) for r in rows))
        out[f'{eid}_peak_MWh_h'] = float(max(r[f'{eid}_peak_abs'] for r in rows))
        out[f'{eid}_fmax_MWh_h'] = float(e['fmax'])
        out[f'{eid}_util_pct'] = 100.0 * out[f'{eid}_peak_MWh_h'] / max(e['fmax'], 1e-12)
        if e['kind'] == 'link':
            out[f'{eid}_rev_h'] = int(sum(r[f'{eid}_rev_h'] for r in rows))
            out[f'{eid}_fwd_h'] = int(sum(r[f'{eid}_fwd_h'] for r in rows))
            out[f'{eid}_zero_h'] = int(sum(r[f'{eid}_zero_h'] for r in rows))
    out['throttle_h_total'] = int(sum(out[f"{e['id']}_throttle_h"] for e in net['elements']))
    out['valve_h_denom'] = int(sum(n * met['T'] for e in net['elements']
                                   if e['kind'] == 'const' and not e['equality']))
    out['at_min_h_total'] = int(sum(out[f"{nd['id']}_at_min_h"] for nd in net['nodes']))
    out['at_max_h_total'] = int(sum(out[f"{nd['id']}_at_max_h"] for nd in net['nodes']))
    out['node_h_denom'] = int(n * met['T'] * len(net['nodes']))
    out['lp_swing_mean_MWh'] = float(np.mean([r['lp_swing'] for r in rows]))
    out['lp_util_pct'] = 100.0 * out['lp_swing_mean_MWh'] / max(met['lp_cap'], 1e-12)
    out['purchase_MWh_day'] = float(np.mean([r['purchase_MWh'] for r in rows]))
    out['comp_fuel_MWh_day'] = float(np.mean([r['comp_fuel_MWh'] for r in rows]))
    out['shed_MWh_day'] = float(np.mean([r['shed_MWh'] for r in rows]))
    out['n_scen_shed'] = int(sum(1 for r in rows if r['shed_MWh'] > 1e-6))
    links = [e for e in net['elements'] if e['kind'] == 'link']
    out['links_rev_h_total'] = int(sum(out[f"{e['id']}_rev_h"] for e in links))
    out['links_fwd_h_total'] = int(sum(out[f"{e['id']}_fwd_h"] for e in links))
    out['links_zero_h_total'] = int(sum(out[f"{e['id']}_zero_h"] for e in links))
    out['links_h_denom'] = int(len(links) * n * met['T'])
    out['links_ever_rev'] = int(sum(1 for e in links if out[f"{e['id']}_rev_h"] > 0))
    out['links_n'] = len(links)
    return out


def append_row(path, row, keycol, keyval):
    new = pd.DataFrame([row])
    if os.path.exists(path):
        old = pd.read_csv(path, encoding='utf-8-sig')
        old = old[old[keycol] != keyval]
        new = pd.concat([old, new], ignore_index=True)
    new.to_csv(path, index=False, encoding='utf-8-sig')


# ---------------------------------------------------------------- 回归自检
def regress(legacy_control=False, verbose=False, tol=None):
    """通用模型退化回两节点链 vs 主链存档；可选再做一次 model_gc_v3 现场对照。

    tol 缺省取 config_v3.MESH_REG_TOL（与 audit_v3 N3/N3b 同源，不再各写一份）。
    """
    tol = TOL_H if tol is None else float(tol)
    import model_gc_v3 as MG
    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']
    ref = archive_reference()
    rows = []
    for cfg, ps in REG_CELLS.items():
        coupled = cfg != 'B0'
        net = MM.build_chain(ps=ps if coupled else 50.0, ps2=ps if coupled else 50.0,
                             pd_min=PD_MIN, K=K_W, A=A_NODE, comp_ratio=COMP_R)
        kw = dict(gas_coupled=coupled)
        if coupled:
            kw.update(ps=ps, ps2=ps)
        t0 = 0.0
        carb = MM.solve_mesh(base, net, scenarios=reduced, mode='carbon',
                             allow_shed=False, n_pts=N_PTS, gas_coupled=coupled,
                             verbose=verbose)
        cost = MM.solve_mesh(base, net, scenarios=reduced, mode='cost',
                             n_pts=N_PTS, gas_coupled=coupled, verbose=verbose)
        r = dict(cfg=cfg, arm=ARM, coupled=coupled, ps=ps if coupled else np.nan,
                 carbon_generic=_val(carb, 'exp_carbon'),
                 carbon_archived=ref[cfg]['carbon_min'],
                 cost_generic=_val(cost, 'exp_cost'),
                 cost_archived=ref[cfg]['rp_cost'],
                 rp_carbon_generic=_val(cost, 'exp_carbon'),
                 rp_carbon_archived=ref[cfg]['rp_carbon'],
                 carbon_status=_status(carb), carbon_status_name=_name(carb),
                 cost_status=_status(cost), cost_status_name=_name(cost),
                 carbon_generic_time=_val(carb, 'solve_time'),
                 cost_generic_time=_val(cost, 'solve_time'),
                 carbon_generic_gap=_val(carb, 'mip_gap'),
                 cost_generic_gap=_val(cost, 'mip_gap'),
                 n_vars_generic=_val(cost, 'n_vars'), n_bin_generic=_val(cost, 'n_bin'))
        r['absdiff_carbon'] = abs(r['carbon_generic'] - r['carbon_archived'])
        r['reldiff_carbon'] = r['absdiff_carbon'] / abs(r['carbon_archived'])
        r['absdiff_cost'] = abs(r['cost_generic'] - r['cost_archived'])
        r['reldiff_cost'] = r['absdiff_cost'] / abs(r['cost_archived'])
        r['absdiff_rp_carbon'] = abs(r['rp_carbon_generic'] - r['rp_carbon_archived'])
        r['reldiff_rp_carbon'] = r['absdiff_rp_carbon'] / abs(r['rp_carbon_archived'])
        if legacy_control:
            lc = MG.solve_gc(base, scenarios=reduced, mode='carbon',
                             allow_shed=False, **kw)
            lk = MG.solve_gc(base, scenarios=reduced, mode='cost', **kw)
            r['carbon_legacy'] = _val(lc, 'exp_carbon')
            r['cost_legacy'] = _val(lk, 'exp_cost')
            r['absdiff_carbon_generic_vs_legacy'] = abs(r['carbon_generic'] - r['carbon_legacy'])
            r['absdiff_cost_generic_vs_legacy'] = abs(r['cost_generic'] - r['cost_legacy'])
        rows.append(r)
        print(f'[regress {cfg}] carbon floor: generic {r["carbon_generic"]:.9f} | '
              f'archived {r["carbon_archived"]:.9f} | '
              f'legacy {r.get("carbon_legacy", float("nan")):.9f} | '
              f'|d| = {r["absdiff_carbon"]:.3e} (rel {r["reldiff_carbon"]:.2e})')
        print(f'[regress {cfg}] RP cost   : generic {r["cost_generic"]:.6f} | '
              f'archived {r["cost_archived"]:.6f} | rel {r["reldiff_cost"]:.2e} | '
              f'RP carbon rel {r["reldiff_rp_carbon"]:.2e} | '
              f'status {r["carbon_status_name"]}/{r["cost_status_name"]} | '
              f't {r["carbon_generic_time"]:.1f}s/{r["cost_generic_time"]:.1f}s')
        sys.stdout.flush()
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, 'V3_MESH_regression.csv'), index=False, encoding='utf-8-sig')
    bad = df[(~df['carbon_generic'].isna())]
    w_carb = float(bad['reldiff_carbon'].max())
    w_cost = float(bad['reldiff_cost'].max())
    w_rpc = float(bad['reldiff_rp_carbon'].max())
    ok = bool((df['carbon_status'] >= 0).all() and w_carb < tol and w_cost < tol
              and w_rpc < tol)
    print(f'[regress] 最大相对偏差：碳地板 {w_carb:.3e} | RP 成本 {w_cost:.3e} | '
          f'RP 碳 {w_rpc:.3e}（阈值 {tol:.0e}）')
    print(f'[regress] 判定：{"PASS" if ok else "FAIL —— 新模型有问题，停止网状实验并报告"}')
    return 0 if ok else 2


# ---------------------------------------------------------------- 三格
def run_cell(cell, dir_mode='soc', verbose=False):
    if cell not in CELLS:
        raise ValueError(cell)
    ckw = CELLS[cell]
    coupled, ps = ckw['coupled'], ckw['ps']
    single = ckw.get('single', True)
    dat = DP.prepare()
    base, reduced = dat['base'], dat['reduced']
    # M_B0 走 gas_coupled=False（线性气帽），net 只作元数据记录
    net = MM.build_mesh(ps=ps if coupled else 50.0, ps2=ps if coupled else 50.0,
                        pd_min=PD_MIN, K=K_W, A=A_NODE, comp_ratio=COMP_R,
                        single_source=single)
    print(f'[{cell}] arm={ARM} E_grid={C.E_GRID} coupled={coupled} ps={ps} '
          f'nodes={len(net["nodes"])} elements={len(net["elements"])} '
          f'single_source={single} dir_mode={dir_mode}  ({net["name"]})')
    sys.stdout.flush()

    # 只影响搜索、不改模型语义/冻结的 MIPGap 与 TimeLimit（见 model_mesh.solve_mesh）。
    # 网状 SOC(MIQCP) 在 8 场景下首个可行解不易找到。统一声明口径见 V3_MESH_PROTOCOL：
    #   mipstart（默认，主判据）：给每条臂注入解析零流可行点作 MIP Start，只加起点、
    #     不加约束、不改目标——保证 50/60/70 三格同口径且都能进分支定界（给出上界
    #     incumbent + 下界 bound）。heur：仅存档启发式（NoRel150+Heur0.5），
    #     对 p_s=70 冻结 600s 内进不了分支定界，故不作统一主口径。
    # 状态/gap/bound 一律如实记录，不粉饰、不为凑结论改口径。
    protocol = os.environ.get('V3_MESH_PROTOCOL', 'mipstart')
    heur = dict(NoRelHeurTime=150.0, MIPFocus=1, Heuristics=0.5) \
        if os.environ.get('V3_MESH_HEUR') == '1' else None
    mip_start = 'zero_flow' if protocol == 'mipstart' else None

    sp = MM.solve_mesh(base, net, scenarios=reduced, mode='cost', n_pts=N_PTS,
                       gas_coupled=coupled, dir_mode=dir_mode, params=heur,
                       mip_start=mip_start, verbose=verbose)
    carb = MM.solve_mesh(base, net, scenarios=reduced, mode='carbon', allow_shed=False,
                         n_pts=N_PTS, gas_coupled=coupled, dir_mode=dir_mode,
                         params=heur, mip_start=mip_start, verbose=verbose)
    exp_sc = DP.expected_scenario(dat)
    eev = None if os.environ.get('V3_MESH_SKIP_EEV') == '1' else MM.solve_mesh(
        exp_sc, net, mode='cost', n_pts=N_PTS, gas_coupled=coupled,
        dir_mode=dir_mode, params=heur, mip_start=mip_start, verbose=verbose)
    sp_ok = sp is not None
    if sp is None:
        append_row(os.path.join(RES, 'V3_MESH_cells_failed.csv'),
                   dict(cell=cell, arm=ARM, net=net['name'], coupled=coupled, ps=ps,
                        sp_status=-1, carb_status=_status(carb),
                        eev_status=_status(eev)), 'cell', cell)
        print(f'[{cell}] RP(cost) 在冻结 600s 内未找到可行整数解（status=TIME_LIMIT/'
              f'SolCount=0，不代表模型不可行）—— 如实记录，不改口径凑成功；carbon 侧 '
              f'status={_status(carb)}({_name(carb)})，**继续记录已求得的碳地板/bound，'
              f'不丢弃真数据**')

    gm = net_metrics(sp['scen_rows'], sp, net) if (coupled and sp_ok) else {}
    row = dict(
        cell=cell, arm=ARM, net=net['name'], e_grid=C.E_GRID, e_grid_mode=C.E_GRID_MODE,
        coupled=coupled, ps=ps if coupled else np.nan,
        protocol=protocol, mip_start=mip_start, dir_mode=dir_mode, n_pts=N_PTS,
        pd_min=PD_MIN, A_node=A_NODE, K_pipe=K_W,
        comp_ratio=COMP_R if coupled else np.nan,
        n_gas_nodes=len(net['nodes']), n_elements=len(net['elements']),
        n_links=sum(1 for e in net['elements'] if e['kind'] == 'link'),
        n_const=sum(1 for e in net['elements'] if e['kind'] == 'const'),
        lp_cap_MWh=_val(sp, 'lp_cap'),
        gate_deliverability_MWh_h=float(sum(e['fmax'] for e in net['elements']
                                            if e['kind'] == 'const'
                                            and e['id'] in net['purchases']
                                            and 'fmax' in e)),
        rp_exp_cost=_val(sp, 'exp_cost'), rp_exp_carbon=_val(sp, 'exp_carbon'),
        rp_solve_time=_val(sp, 'solve_time'), rp_mip_gap=_val(sp, 'mip_gap'),
        rp_status=_status(sp), rp_status_name=_name(sp),
        rp_obj_bound=_val(sp, 'obj_bound'), rp_n_vars=_val(sp, 'n_vars'),
        rp_n_cons=_val(sp, 'n_cons'), rp_n_bin=_val(sp, 'n_bin'),
        carbon_min_exp_rp=_val(carb, 'exp_carbon'),
        carbon_min_solve_time=_val(carb, 'solve_time'),
        carbon_min_mip_gap=_val(carb, 'mip_gap'),
        carbon_min_status=_status(carb), carbon_min_status_name=_name(carb),
        carbon_min_obj_bound=_val(carb, 'obj_bound'),
        single_source=single, gate_purchases=len(net['purchases']),
        eev_exp_cost=_val(eev, 'exp_cost'), eev_status=_status(eev),
        eev_solve_time=_val(eev, 'solve_time'),
    )
    if not coupled:
        row.update({k: np.nan for k in
                    ['n_gas_nodes', 'n_elements', 'n_links', 'n_const', 'lp_cap_MWh']})
    row.update({'gas_' + k: v for k, v in gm.items()})
    print(f'[{cell}] RP cost {row["rp_exp_cost"]:.4f} ({row["rp_status_name"]} '
          f'{row["rp_solve_time"]:.0f}s gap {row["rp_mip_gap"]:.1e}) | '
          f'RP carbon {row["rp_exp_carbon"]:.4f} | carbon floor '
          f'{row["carbon_min_exp_rp"]:.6f} ({row["carbon_min_status_name"]} '
          f'{row["carbon_min_solve_time"]:.0f}s gap {row["carbon_min_mip_gap"]:.1e})')
    if coupled and sp_ok:
        print(f'[{cell}]   throttle {row["gas_throttle_h_total"]}/'
              f'{row["gas_valve_h_denom"]} h | p@min {row["gas_at_min_h_total"]} '
              f'p@max {row["gas_at_max_h_total"]} / {row["gas_node_h_denom"]} h | '
              f'lp_util {row["gas_lp_util_pct"]:.2f}% | purchase '
              f'{row["gas_purchase_MWh_day"]:.3f} MWh/d | shed {row["gas_shed_MWh_day"]:.3f}')
        print(f'[{cell}]   reverse-flow pipe-hours {row["gas_links_rev_h_total"]}/'
              f'{row["gas_links_h_denom"]} | pipes that ever run backwards '
              f'{row["gas_links_ever_rev"]}/{row["gas_links_n"]}')
    sys.stdout.flush()

    append_row(os.path.join(RES, 'V3_MESH_cells.csv'), row, 'cell', cell)
    pd.DataFrame([gm]).to_csv(os.path.join(RES, f'V3_MESH_{cell}_gasmetrics.csv'),
                              index=False, encoding='utf-8-sig')
    if coupled and sp_ok and row['n_links']:
        drows = []
        for r in sp['scen_rows']:
            for e in net['elements']:
                if e['kind'] != 'link':
                    continue
                col = r['sched'][f"f_{e['id']}"].to_numpy(float)
                drows.append(dict(scenario=r['scenario'], hours=1.0, element=e['id'],
                                  fwd_h=int((col > 1e-6).sum()),
                                  rev_h=int((col < -1e-6).sum()),
                                  zero_h=int((np.abs(col) <= 1e-6).sum()),
                                  peak_fwd=float(col.max()),
                                  peak_rev=float(-col.min()),
                                  fmax_MWh_h=float(e['fmax'])))
        pd.DataFrame(drows).to_csv(os.path.join(RES, f'V3_MESH_{cell}_directions.csv'),
                                   index=False, encoding='utf-8-sig')
    return row


# ---------------------------------------------------------------- 判定两条结构性结论
def verdict():
    """两条结构性结论的判定表。**只判方向与次序，且碳侧一律以 bound（下界）为基。**

    口径纪律（修复轮 1 · Critical C1）：
      * 网状三格的 incumbent（58.3076）被统一声明口径的**零流 MIP-start 锚点**钳制，是
        未收敛的**上界**，不是"可达碳地板值"（mesh_notes §7′、§8）。
      * 本函数**曾经**用 incumbent 基算 `c1_carbon_distort_pct_*` / `c1_ratio_*`，落盘出
        113.101% / 16.095×，还写了 `c2_monotone_decline=True`——与 mesh_notes 的诚实结论
        （保守比 ≈5.4×、结论二"方向一致但未认证"）直接矛盾，并违反"任何网状 incumbent
        吨数/百分比不得进正文"。故：
        - 碳侧失真一律取 **bound（下界 L）** = 低估失真（保守）；
        - 成本侧失真取 **incumbent（上界 U）** = 高估失真（偏乐观）；
        两侧都朝"不让结论显得更强"的方向取值 ⇒ 得到的比值是**真实比值的下界**。
      * incumbent 吨数只作留痕列 `incumbent_<cell>`，并配三个标志列
        （`incumbent_is_upper_bound_not_floor` / `incumbent_usable_for_c2_ranking` /
        `c1_basis_is_bound`）；`floor_*` 列名不再用于 incumbent，也不再有
        `c2_monotone_decline` 这类 incumbent 基的"单调下降"断言。
      * `audit_v3.py` N12a–N12e 把上述口径写成断言锁死：改回 incumbent 基即翻红。
    """
    cells = pd.read_csv(os.path.join(RES, 'V3_MESH_cells.csv'), encoding='utf-8-sig')
    ref = archive_reference()
    scan = pd.read_csv(os.path.join(RES, 'V3_GC_scan_carbon.csv'), encoding='utf-8-sig')
    m2 = scan[scan['arm'] == ARM].set_index('cfg')
    cx = cells.set_index('cell')

    def g(cell, col):
        return float(cx.loc[cell, col]) if (cell in cx.index and col in cx.columns
                                            and pd.notna(cx.loc[cell, col])) else np.nan

    b0 = ref['B0']['carbon_min']            # 线性气帽碳地板（拓扑无关；链臂 OPTIMAL，是真值）
    cb0 = ref['B0']['rp_cost']
    out = dict(floor_linecap=b0, linecap_rp_cost=cb0)
    for tag in ('M_PS50', 'M_PS60', 'M_PS70', 'M2S_PS70'):
        out[f'incumbent_{tag}'] = g(tag, 'carbon_min_exp_rp')      # 上界 U：未收敛，非碳地板值
        out[f'bound_{tag}'] = g(tag, 'carbon_min_obj_bound')       # 下界 L：判据一律用它
        out[f'cost_{tag}'] = g(tag, 'rp_exp_cost')                 # 成本 incumbent（=上界）
        out[f'status_{tag}'] = g(tag, 'carbon_min_status')
    u50, u60, u70, u2 = (out['incumbent_M_PS50'], out['incumbent_M_PS60'],
                         out['incumbent_M_PS70'], out['incumbent_M2S_PS70'])
    b50, b60, b70, b2 = (out['bound_M_PS50'], out['bound_M_PS60'],
                         out['bound_M_PS70'], out['bound_M2S_PS70'])
    c50, c70 = out['cost_M_PS50'], out['cost_M_PS70']
    # 链臂（两节点，600 s 内全 OPTIMAL）：真值可直接引用
    ch50 = float(m2.loc['PS50', 'carbon_min_exp_rp'])
    ch60 = float(m2.loc['PS60', 'carbon_min_exp_rp'])
    ch70 = float(m2.loc['PS70', 'carbon_min_exp_rp'])
    ch50_cost, ch60_cost, ch70_cost = (ref['PS50']['rp_cost'], ref['PS60']['rp_cost'],
                                       ref['PS70']['rp_cost'])

    # 统一声明口径核对（三格是否同协议、同方向线性化）+ 界认证式结论二判定
    coupled_present = [c for c in ('M_PS50', 'M_PS60', 'M_PS70') if c in cx.index]
    protos = sorted({str(cx.loc[c, 'protocol']) for c in coupled_present}
                    ) if 'protocol' in cx.columns else []
    dirs = sorted({str(cx.loc[c, 'dir_mode']) for c in coupled_present})
    same_protocol = (protos == ['mipstart'] and dirs == ['soc'])
    all_finite = all(np.isfinite(v) for v in (u50, u60, u70, b50, b60, b70))
    bound_monotone = bool(all_finite and b50 >= b60 >= b70)
    # 允许的最强表述：L(50) > U(70) ⟹ floor(50) > floor(70)（界认证，混合口径但合法）
    c2_certified_by_bound = bool(all_finite and b50 > u70)
    # 界层面的方向一致性：只看**下界**是否严格随 p_s 下降（这是"方向一致"的全部内容）
    c2_direction_consistent_by_bound = bool(all_finite and b50 > b60 > b70)
    # 三格 incumbent 被同一零流锚点钉住（相对差 <1e-6 即求解噪声）⇒ 不得据其判序
    c2_incumbent_tied_at_anchor = bool(np.isfinite(u50) and np.isfinite(u70)
                                       and abs(u50 - u70) <= 1e-6 * abs(u50))
    c2_verdict = ('成立(界认证)' if c2_certified_by_bound
                  else ('方向一致但未认证'
                        if (same_protocol and all_finite and bound_monotone) else '不可判定'))
    out.update(
        c2_protocol_uniform=bool(same_protocol),
        c2_bound_monotone=bound_monotone,
        c2_certified_by_bound=c2_certified_by_bound,
        c2_direction_consistent_by_bound=c2_direction_consistent_by_bound,
        c2_incumbent_tied_at_anchor=c2_incumbent_tied_at_anchor,
        # incumbent 一律显式标注"上界、非碳地板真值、不可判序"（C1 锁死项）
        incumbent_is_upper_bound_not_floor=True,
        incumbent_usable_for_c2_ranking=False,
        c2_verdict=c2_verdict,
    )
    # ---- 结论一：去气网物理低估可达碳地板；碳侧失真 vs 成本侧失真（**碳侧 bound 基**）----
    cd50 = 100 * (b50 - b0) / b0 if np.isfinite(b50) else np.nan     # 碳：取下界 → 保守
    cd70 = 100 * (b70 - b0) / b0 if np.isfinite(b70) else np.nan
    cc50 = 100 * (c50 - cb0) / cb0 if np.isfinite(c50) else np.nan   # 成本：取上界 → 偏乐观
    cc70 = 100 * (c70 - cb0) / cb0 if np.isfinite(c70) else np.nan
    r50 = cd50 / abs(cc50) if (np.isfinite(cd50) and np.isfinite(cc50)) else np.nan
    r70 = cd70 / abs(cc70) if (np.isfinite(cd70) and np.isfinite(cc70)) else np.nan
    out.update(
        c1_basis_is_bound=True,
        c1_carbon_distort_basis='bound(下界 L)：低估碳侧失真 ⇒ 保守',
        c1_cost_distort_basis='incumbent(上界 U)：高估成本侧失真 ⇒ 保守；故 c1_ratio 是真比值的下界',
        c1_floor_above_linecap_PS50=bool(np.isfinite(b50) and b50 > b0),
        c1_floor_above_linecap_PS70=bool(np.isfinite(b70) and b70 > b0),
        c1_carbon_distort_pct_PS50=cd50, c1_carbon_distort_pct_PS70=cd70,
        c1_cost_distort_pct_PS50=cc50, c1_cost_distort_pct_PS70=cc70,
        c1_ratio_PS50=r50, c1_ratio_PS70=r70,
        c1_ratio_is_lower_bound=True,
        # "大一个数量级（≥10×）"只有下界，未被认证；若将来真收敛到 ≥10×，N12b 会翻红提示复核
        c1_ge10x_certified_PS50=bool(np.isfinite(r50) and r50 >= 10),
        c1_ge10x_certified_PS70=bool(np.isfinite(r70) and r70 >= 10),
        # 两节点链臂（OPTIMAL 真值，可进正文）：碳/成本失真与比值——数量级说法只在这里成立
        c1_2node_carbon_distort_pct_PS50=100 * (ch50 - b0) / b0,
        c1_2node_carbon_distort_pct_PS70=100 * (ch70 - b0) / b0,
        c1_2node_cost_distort_pct_PS50=100 * (ch50_cost - cb0) / cb0,
        c1_2node_cost_distort_pct_PS70=100 * (ch70_cost - cb0) / cb0,
        c1_2node_ratio_PS50=(100 * (ch50 - b0) / b0) / abs(100 * (ch50_cost - cb0) / cb0),
        c1_2node_ratio_PS60=(100 * (ch60 - b0) / b0) / abs(100 * (ch60_cost - cb0) / cb0),
        c1_2node_ratio_PS70=(100 * (ch70 - b0) / b0) / abs(100 * (ch70_cost - cb0) / cb0),
    )
    # ---- 结论二：源压杠杆（全部 bound 基；不再产出 incumbent 基的"单调/递减"字段）----
    s5060 = b50 - b60 if (np.isfinite(b50) and np.isfinite(b60)) else np.nan
    s6070 = b60 - b70 if (np.isfinite(b60) and np.isfinite(b70)) else np.nan
    out.update(
        c2_bound_step_50_to_60=s5060,
        c2_bound_step_60_to_70=s6070,
        # 下界步长在收缩，这只是**下界**的性质，不构成"边际递减"的认证（认证需 c2_certified）
        c2_bound_step_shrinks=bool(np.isfinite(s5060) and np.isfinite(s6070) and s6070 < s5060),
        c2_direction_matches_2node=bool((ch50 > ch70) == (np.isfinite(b50) and np.isfinite(b70)
                                                          and b50 > b70)),
        # 双门站冗余稳健性格：该格本轮未跑 -> 记 NaN（不是"判为不成立"）
        redundancy_cell_available=bool(np.isfinite(b2)),
        redundancy_floors_same_direction=(bool(b2 > b0) if np.isfinite(b2) else np.nan),
        ref_2node_floor_B0=b0, ref_2node_floor_PS50=ch50,
        ref_2node_floor_PS60=ch60, ref_2node_floor_PS70=ch70,
    )
    df = pd.DataFrame([out])
    # 自检：写盘前再核一次"碳侧百分比确实由 bound 派生"，防止今后有人把基改回 incumbent
    _exp = 100 * (b50 - b0) / b0
    if np.isfinite(_exp) and abs(float(df['c1_carbon_distort_pct_PS50'].iloc[0]) - _exp) > 1e-9:
        raise AssertionError('c1_carbon_distort_pct_PS50 不是 bound 基 —— C1 回归，拒绝落盘')
    df.to_csv(os.path.join(RES, 'V3_MESH_verdict.csv'), index=False, encoding='utf-8-sig')
    for k, v in out.items():
        print(f'  {k}: {v}')
    return df


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--regress', action='store_true')
    ap.add_argument('--cells', action='store_true')
    ap.add_argument('--verdict', action='store_true')
    ap.add_argument('--topology', action='store_true')
    ap.add_argument('--dir-mode', default=os.environ.get('V3_MESH_DIR', 'soc'))
    ap.add_argument('--legacy', action='store_true',
                    help='额外现场重跑 model_gc_v3 做同进程对照（慢，默认关）')
    ap.add_argument('--verbose', action='store_true')
    a = ap.parse_args()
    rc = 0
    if a.topology:
        import data_mesh_v3 as DMT
        DMT.main()
    if a.regress:
        rc = max(rc, regress(legacy_control=a.legacy, verbose=a.verbose))
    if a.cells:
        run_cell(os.environ.get('V3_MESH_CELL', 'M_PS70'),
                 dir_mode=a.dir_mode, verbose=a.verbose)
    if a.verdict:
        verdict()
    if not (a.regress or a.cells or a.verdict or a.topology):
        ap.print_help()
    sys.exit(rc)
