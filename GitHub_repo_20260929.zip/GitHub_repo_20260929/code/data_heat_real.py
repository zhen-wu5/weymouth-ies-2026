# -*- coding: utf-8 -*-
"""实测热负荷数据层：丹麦 Brønderslev 区域供热逐时计量数据（公开、CC BY 4.0）

用途：替换 v3 主口径里**合成**的冬季热负荷典型日（data_v3.heat_load_profile，
manifest §6 自己声明为 synthetic），给热侧提供真实的小时形状与逐日变化。

数据源（可复现下载，无需登录）：
  Zenodo record 17398331, "A Real World Multi Year Hourly District Heating
  Demand Data for Denmark", 发布 2025-10-20, 许可 CC BY 4.0
  论文 DOI: 10.1016/j.egyai.2026.100704
  内容：丹麦 Brønderslev 某供热公司 4,910 块热量表的累计读数，经一阶差分
  化为逐时 kWh，并按三个分区（DMA A/B/C）聚合。
  时间轴 2016-01-01 00:00 至 2019-12-31 23:00，逐时，官方声明无缺测。
  直链：https://zenodo.org/api/records/17398331/files/<key>/content

口径（一次定死）：
  - 取 **2019 年**（与现有甘肃风/甘肃光同年，8760 h 对齐），三个 DMA 全取；
  - 主序列用 DMA B（年供热最大、表计最多，噪声最小）；A/C 留作分区敏感性；
  - 峰值归一：h_pu = cons / max(cons)，再乘论文热负荷峰值 4.0 MW_th，
    使"热峰 = 4.0 MW_th"这一既有假设保持不变，只把**形状**换成实测；
  - 逐日 24h 曲线 heat_d 形状 [365, 24]，供场景库使用（热侧由此获得逐日变化）。

输出（code_v3/results/）：
  heat_dma_2019_hourly.csv    2019 逐时三 DMA 热负荷（kWh）
  heat_real_vs_syn.csv        实测典型日 vs 合成曲线的形状差异指标
"""
import os
import urllib.request

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')
os.makedirs(RES, exist_ok=True)

RECORD = '17398331'
DOI = '10.1016/j.egyai.2026.100704'
LICENSE = 'CC BY 4.0'
YEAR = 2019
DMA_MAIN = 'dma_b'
FILES = {'dma_a': 'dma_a_aggregated.csv',
         'dma_b': 'dma_b_aggregated.csv',
         'dma_c': 'dma_c_aggregated.csv'}
CACHE = os.path.join(RES, 'heat_dma_2019_hourly.csv')


def _download(key):
    url = 'https://zenodo.org/api/records/%s/files/%s/content' % (RECORD, key)
    req = urllib.request.Request(url, headers={'User-Agent': 'data-heat-real/1.0'})
    with urllib.request.urlopen(req, timeout=180) as fh:
        raw = fh.read()
    import io
    return pd.read_csv(io.BytesIO(raw))


def load_heat_year(refresh=False):
    """返回 2019 逐时 DataFrame（index=ts，列=dma_a/dma_b/dma_c，单位 kWh）。"""
    if os.path.exists(CACHE) and not refresh:
        df = pd.read_csv(CACHE, parse_dates=['ts']).set_index('ts')
    else:
        parts = {}
        for name, key in FILES.items():
            d = _download(key)
            s = pd.Series(d.iloc[:, 1].astype(float).to_numpy(),
                          index=pd.DatetimeIndex(
                              pd.to_datetime(d.iloc[:, 0]).dt.tz_localize(None)))
            parts[name] = s
        df = pd.DataFrame(parts)
        df.index.name = 'ts'
        df = df.loc[df.index.year == YEAR]      # 缓存只存文件名所示的那一年
        df.to_csv(CACHE)
    # 完整性断言：这正是敢用它替换合成曲线的依据，缺一项就不该继续往下跑
    yr = df.loc[df.index.year == YEAR]
    assert len(yr) == 8760, 'expected 8760 hourly rows for %d, got %d' % (YEAR, len(yr))
    assert not yr.isna().any().any(), 'NaN in measured heat'
    assert (yr >= 0).all().all(), 'negative heat consumption'
    steps = pd.Series(yr.index).diff().dropna()
    assert int((steps != pd.Timedelta('1h')).sum()) == 0, 'non-hourly gap in timeline'
    return yr


def heat_pu(dma=DMA_MAIN):
    """峰值归一的 8760 维标幺热负荷（1.0 = 该年最高逐时热负荷）。"""
    yr = load_heat_year()
    s = yr[dma].to_numpy(float)
    return s / s.max()


def heat_daily(dma=DMA_MAIN):
    """[365, 24] 逐日热负荷标幺曲线。"""
    return heat_pu(dma).reshape(-1, 24)


def compare_with_synthetic():
    """实测典型日 vs 现用合成曲线的形状差异，写 heat_real_vs_syn.csv。"""
    import data_v3 as DV
    yr = load_heat_year()
    s = pd.Series(yr[DMA_MAIN].to_numpy(float), index=yr.index)
    md = s.groupby(s.index.hour).mean()
    meas_mean = (md / md.max()).to_numpy()          # 与电负荷同口径：日历平均日峰值归一
    meas_peaknorm = heat_pu() / heat_pu().max()     # 全年逐时峰值归一
    syn = DV.heat_load_profile()

    def corr(a, b):
        return float(np.corrcoef(a, b)[0, 1])
    days = s.to_numpy().reshape(-1, 24)
    dn = days / days.max(axis=1, keepdims=True)
    rows = [
        dict(item='corr(measured_mean_day, synthetic)', value=corr(meas_mean, syn)),
        dict(item='corr(measured_hourly_pu, synthetic_tiled)',
             value=corr(meas_peaknorm, np.tile(syn, 365))),
        dict(item='daily_shape_std_across_hours', value=float(dn.std(axis=0).mean())),
        dict(item='jan_over_jul_ratio',
             value=float(days[0:31].sum() / days[181:212].sum())),
        dict(item='synthetic_daily_energy_MWh_at_4MWpeak', value=float(syn.sum() * 4.0)),
        dict(item='measured_daily_energy_MWh_at_4MWpeak',
             value=float((heat_pu().mean()) * 24 * 4.0)),
    ]
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(RES, 'heat_real_vs_syn.csv'), index=False)
    return out


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(errors='replace')
    yr = load_heat_year()
    print('cached %s: %d rows, %s .. %s' % (os.path.basename(CACHE), len(yr),
                                            yr.index[0], yr.index[-1]))
    for c in yr.columns:
        print('  %s: annual %.1f GWh, hourly max %.0f kWh' % (c, yr[c].sum() / 1e6,
                                                              yr[c].max()))
    hd = heat_daily()
    print('heat_daily shape', hd.shape, ' peak-normalised max %.3f' % hd.max())
    print('\n=== measured vs current synthetic heat shape ===')
    print(compare_with_synthetic().to_string(index=False))
