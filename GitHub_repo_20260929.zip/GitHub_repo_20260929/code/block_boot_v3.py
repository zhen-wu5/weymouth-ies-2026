# -*- coding: utf-8 -*-
"""BLOCK BOOT：逐日配对差的移动块 bootstrap 稳健性复核。

动机（论文 sec_v_results.tex 的 OOS 价值段）：配对 bootstrap 与 Wilcoxon
符号秩检验都把 100 个逐日差当作独立样本，但测试日并非彼此远离——相邻日历
日成对出现，逐日差存在正的 lag-1 自相关，故报告出的 p 值偏乐观。本脚本在
**不改动任何既有归档产物**的前提下（BOOT_*_v3.csv 由 boot_v3.py 独占），
用移动块 bootstrap 重算区间，量化这一依赖带来的影响。

方法
  - 逐日差 d_i = cost_eev_i - cost_sp_i，按 test_day 升序排列（保留日历次序，
    这是块 bootstrap 成立的前提）。
  - iid 对照臂：有放回重抽 n=100 个索引，与 boot_v3.py 同约定。
  - 移动块臂：块长 L，每轮取 ceil(n/L) 个随机起点，拼接后截断到 n，
    块内日历相邻性因此被保留。
  - 区间取 bootstrap 分布的 2.5%/97.5% 百分位。
  - 诊断量：lag-1 自相关、相邻日历日对数（gap==1）。

输出 results/BOOT_block_v3.csv（cfg × 方法的长表），供 audit_v3.py 校验。
不依赖 Gurobi，只读 V3_GC_<cfg>_main_oos.csv。
"""
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

SEED = 20260922
NB = 20000
BLOCKS = (3, 5, 7)
CFGS = ('B0', 'PS70')


def _draw(d, n, rng, L=None):
    """L=None -> iid；否则移动块（块内保序，拼接后截断到 n）。"""
    if L is None:
        idx = rng.integers(0, n, n)
    else:
        nb = int(np.ceil(n / L))
        starts = rng.integers(0, n - L + 1, nb)
        idx = np.concatenate([np.arange(s, s + L) for s in starts])[:n]
    return d[idx].mean()


def run_cfg(cfg):
    oos = pd.read_csv(os.path.join(RES, f'V3_GC_{cfg}_main_oos.csv'))
    ok = oos.dropna(subset=['cost_eev', 'cost_sp']).copy()
    assert len(ok) == 100, f'{cfg}: 测试日数 {len(ok)} != 100'
    ok = ok.sort_values('test_day')
    d = (ok['cost_eev'] - ok['cost_sp']).to_numpy(float)
    n = len(d)

    days = pd.to_datetime(ok['test_day']).dt.normalize().to_numpy()
    gaps = np.diff(days).astype('timedelta64[D]').astype(int)
    adj = int((gaps == 1).sum())
    ac1 = float(np.corrcoef(d[:-1], d[1:])[0, 1])

    rows = [dict(cfg=cfg, method='diagnostic', L=0, n_days=n,
                 point=d.mean(), ci_lo=np.nan, ci_hi=np.nan, width=np.nan,
                 boot_sd=np.nan, adjacent_day_pairs=adj,
                 lag1_autocorr=ac1, n_boot=0)]

    rng = np.random.default_rng(SEED)
    arms = [('iid', None)] + [(f'block', L) for L in BLOCKS]
    for name, L in arms:
        means = np.array([_draw(d, n, rng, L) for _ in range(NB)])
        lo, hi = np.percentile(means, [2.5, 97.5])
        rows.append(dict(cfg=cfg, method=name, L=(0 if L is None else L),
                         n_days=n, point=float(means.mean()),
                         ci_lo=float(lo), ci_hi=float(hi),
                         width=float(hi - lo),
                         boot_sd=float(means.std(ddof=1)),
                         adjacent_day_pairs=adj, lag1_autocorr=ac1,
                         n_boot=NB))
    return rows


def main():
    rows = []
    for cfg in CFGS:
        rows.extend(run_cfg(cfg))
    df = pd.DataFrame(rows)
    out = os.path.join(RES, 'BOOT_block_v3.csv')
    df.to_csv(out, index=False, encoding='utf-8-sig')

    base = {}
    for _, r in df.iterrows():
        if r['method'] == 'diagnostic':
            print(f"[{r['cfg']}] point={r['point']:.2f} CNY/d  "
                  f"相邻日历日对={int(r['adjacent_day_pairs'])}/99  "
                  f"lag-1 自相关={r['lag1_autocorr']:+.3f}")
        elif r['method'] == 'iid':
            base[r['cfg']] = r['width']
            print(f"    iid     95%CI [{r['ci_lo']:7.1f}, {r['ci_hi']:7.1f}]  "
                  f"width {r['width']:6.1f}  sd {r['boot_sd']:5.1f}")
        else:
            w = r['width'] / base[r['cfg']] - 1.0
            print(f"    L={int(r['L']):<5d} 95%CI [{r['ci_lo']:7.1f}, {r['ci_hi']:7.1f}]  "
                  f"width {r['width']:6.1f}  (较 iid {w:+.1%})")
    print(f'\n-> {out}')


if __name__ == '__main__':
    main()
