# Input data - what is here, and what you must obtain yourself

This folder holds the input data that may be redistributed publicly. Four series are **not** here because
their terms do not permit redistribution; they are listed in `INPUT_DATA_REQUIRED.csv` with the exact
filenames the code expects, and are described below with their provenance.

---

## Included

| File | Content | Licence |
|---|---|---|
| `heat_dma_2019_hourly.csv` | hourly district-heating consumption for calendar year 2019 over three district-metered areas (`dma_a`, `dma_b`, `dma_c`), 4,910 meters, gap-free, 8,760 rows | **CC BY 4.0** - Zenodo record 17398331 (Ramachandran, Bayer, Maier, Chatterjee). Attribution required. |
| `mesh_source/` | the GasLib-11 network instance (`.net`, `.scn`, `.cs`, `.svg`), the distribution archive and the MIT licence text of the parser mirror | instance **CC BY 3.0**; parser **MIT**. Only the graph structure is used. |
| `mee_2019_grid_baseline_ef.pdf` | official grid baseline emission factor (MEE 2019) | public official document |
| `data_manifest.md` | the data ledger: provenance, aggregation and normalisation of every input series, plus completeness checks | documentation |
| `load_completeness_diag.csv`, `load_typical_day_compare.csv`, `load_shape_compare_metrics.csv` | completeness and shape diagnostics of the load reconstruction | derived |
| `wind_pv_pairing_metrics.csv` | wind-PV pairing metrics behind the scenario calibration | derived |
| `power_coefficients_heating.csv`, `power_coefficients_cooling.csv`, `power_coeff_heating_gansu_jiangsu_2019.csv` | temperature-to-heat power coefficients | derived |
| `heat_real_vs_syn.csv` | synthetic versus measured heat load (the comparison reported in the manuscript) | derived |
| `PWL_E28_anchor_check.csv` | anchor check for the piecewise-linear interpolation | derived |
| `quanzhou_temp_2016_2018_hourly.csv`, `quanzhou_temp_diag.csv` | third-party temperature/load series used only for a sensitivity check; not part of any headline result | third-party |
| `turkey_loader_check.csv` | loader self-check artifact | derived |

## Not included - place these under `results/` to reproduce the full pipeline

`INPUT_DATA_REQUIRED.csv` is the machine-readable version of this list.

### 1. Measured wind and photovoltaic records

- `results/gansu_wind_2019_hourly.csv` - measured wind power, Gansu, 2019, hourly means aggregated from
  5-minute power. Site 94.43 E, 40.88 N.
- `results/gansu_pv_2019_mw.csv` - measured photovoltaic power, a Gansu plant, 2019, hourly means
  aggregated from 15-minute power.

These are third-party compilations, not ours. **The manuscript states that these records are not
redistributed and are available from the corresponding author**, and this repository follows that
statement. Request them from the corresponding author at the address given in the manuscript.

### 2. Reconstructed provincial load curves

- `results/load_gansu_2019_hourly.csv` - Gansu, main column
- `results/load_jiangsu_2019_hourly.csv` - Jiangsu, reserve column

Source: Yi, B., Luo, Q., Zhang, S., Ji, Y., Yu, S., & Fan, Y. *Hourly electricity load curve dataset for
Chinese provinces derived from meteorological variables*, **Scientific Data** 13:978, 2026,
doi:10.1038/s41597-026-07327-8. The published dataset is licensed **CC BY-NC-ND 4.0**; our hourly
extraction is a derived series and therefore cannot be redistributed. Obtain the source dataset from the
publisher and extract the `Gansu` and `Jiangsu` columns for 2019.

Note on what this series is: the source is a *reconstruction* that combines limited official load
statistics with hourly meteorological observations. The manuscript describes it as a "published load
reconstruction", never as metered utility telemetry.

---

## Before running the code

Place each required file at the path given in `INPUT_DATA_REQUIRED.csv` (all under `results/`). A run whose
inputs are incomplete will fail its loader rather than substitute synthetic data silently. To confirm that
the files you have are the ones that produced the reported results, compare them against
`../MANIFEST_sha256.csv`.
