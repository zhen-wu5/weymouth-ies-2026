# Replication package — Weymouth-coupled stochastic dispatch for an electricity–heat–gas park

Code, archived results and input data for the manuscript:

> **A Scenario-Calibrated, Weymouth-Coupled Stochastic Dispatch Framework for Electricity–Heat–Gas
> Integrated Energy Systems: Gas-Network Physics, the Reachable Carbon Set, and What Omitting the
> Network Distorts** — Guozhen Wu, East China Jiaotong University

Every number in the manuscript is read from a file in `results/`. Products of earlier iterations of the
study were removed, so everything here is a **final** artifact.

```
code/        model, run and analysis scripts
results/     archived result files (final only)
datasets/    input data actually used, plus the data-provenance ledger
MANIFEST_sha256.csv   path, byte size and SHA-256 of every file here
```

---

## code/ — what each script is for

| File | Purpose |
|---|---|
| `config_v3.py` | single source of truth for model constants, tariffs, solver tolerances and random seeds |
| `data_v3.py` | assembles the hourly input series and the calibration scenario set |
| `data_wind_gansu.py` | reads and aggregates the measured Gansu wind and PV records to hourly means |
| `data_load_real.py` | reads the provincial load reconstruction and builds the peak-normalised load shape |
| `data_heat_real.py` | reads the Danish district-heating series and normalises it to the park heat peak |
| `data_temp_quanzhou.py` | reads the third-party temperature series used only for a sensitivity check |
| `data_mesh_v3.py` | reads the GasLib-11 instance and aligns its gate station with the two-node chain |
| `model_stoch_v3.py` | two-stage stochastic unit commitment, uncoupled arm (RP, EEV, WS, VSS, EVPI) |
| `model_gc_v3.py` | gas-coupled model: Weymouth PWL, line pack, gate-station valve, compressor fuel |
| `model_cap_v3.py` | static linear capacity-cap baseline (the simplification being audited) |
| `model_mesh_v3.py` | meshed-core variant of the coupled model |
| `gc_run_v3.py` | run driver for the gas-coupled arms; writes the `V3_GC_*` result files |
| `gc_run_baseline_v3.py` | run driver for the static-cap and steady-state baseline arms; writes `V3_BASELINE_*` |
| `gc_run_mesh_v3.py` | run driver for the meshed GasLib-11 arm; writes `V3_MESH_*` |
| `cap_run_v3.py` | sweeps the import-capacity settings; writes `V3_CAP_*` |
| `eps_driver.py` | ε-constraint frontier: chooses constraint levels and drives the sweep |
| `eps_run_level.py` | solves one frontier level and writes its in-sample row |
| `eps_oos_level.py` | out-of-sample re-dispatch of one frontier level |
| `in_sample_value_v3.py` | in-sample VSS/EVPI diagnostics on the training measure; writes `IN_*` |
| `boot_v3.py` | paired bootstrap of the out-of-sample policy difference; writes `BOOT_*` |
| `block_boot_v3.py` | moving-block bootstrap that preserves day-to-day adjacency |
| `axis_scan_v3.py` | sweeps one caliber axis at a time; writes `V3_AXIS5_scan.csv` |
| `band_scan_v3.py` | builds the certified caliber band over the axes; writes `V3_BAND_*` |
| `pwl_recheck.py` | piecewise-linear Weymouth accuracy study (cosine vs uniform breakpoints); writes `PWL_*` |
| `mesh_arm_diag.py` | diagnostics on the meshed arm |
| `mesh_feas_probe.py` | feasibility probes on the meshed arm |
| `mesh_ps_entry_map.py` | maps the source-pressure entry range on the meshed core |
| `compare_heatreal.py` | synthetic-versus-measured heat comparison; writes `heat_real_vs_syn.csv` |
| `diagnose_heatreal_infeasible.py` | diagnoses the infeasible days under measured heat |
| `audit_v3.py` | internal consistency audit over the archived result files |
| `band_notes.md` | working notes behind the certified band |
| `mesh_notes.md` | working notes behind the meshed replication |
| `mesh_ps70_diagnosis.md` | diagnosis of the meshed core at 70 bar |
| `EPS_phaseAB.log`, `EPS_phaseCD.log` | captured solver logs from the frontier phases |

## results/ — what each file family contains

| Prefix / file | Contents |
|---|---|
| `V3_GC_scan_carbon.csv` | headline source-pressure scan: minimum expected carbon per configuration |
| `V3_GC_<cfg>_<arm>_summary.csv` | one coupled run: cost, carbon, binding counts, solve statistics |
| `V3_GC_<cfg>_<arm>_oos.csv` | day-by-day out-of-sample re-dispatch records behind those summaries |
| `V3_GC_<cfg>_<arm>_gas.csv` | gas-side state records (pressures, flows, line pack) for that run |
| `V3_GC_u_compare_*.csv` | first-stage commitment comparison between arms |
| `cfg` codes | `B0` uncoupled; `PS50/PS60/PS70` coupled at 50/60/70 bar; `CVAR` risk-averse probe |
| `arm` codes | `main` declared caliber; `efold` emission-factor contrast (0.55); `heatreal` measured heat; `paironly`/`shapeonly` data-provenance arms; `steady` steady-state transmission |
| `V3_all_gc_summary_table.csv` | one row per coupled configuration: VSS, EVPI, CVaR, EENS, carbon, solve stats |
| `V3_all_cap_summary_table.csv` | the same for the import-capacity sweep |
| `V3_BASELINE_compare3.csv`, `_plan`, `_probe`, `_ps_scan`, `_structure.csv` | static-cap and steady-state baselines: cost/carbon, replay plan, feasibility probes, structure |
| `V3_CAP_<cap>_<mode>_*` | import-capacity cases (`2.5`–`6.25`, `inf`) with their scenario and summary rows |
| `EPS_frontier.csv` | the ε-constraint frontier: cap, cost and marginal abatement cost per level |
| `EPS_controls.csv`, `EPS_adaptive_log.csv`, `EPS_rp_probe_low.csv` | frontier controls, level-selection log, lower feasibility probe |
| `EPS_oos_<level>.csv`, `EPS_rp_<level>.csv`, `EPS_u_<level>.npy` | out-of-sample re-dispatch, in-sample rows and arrays per level |
| `EPS_rp_ctrl_*shed*.csv`, `EPS_u_ctrl_*shed*.npy` | the load-shedding control that makes the frontier meaningful |
| `EPS_notes.md` | notes on how the frontier levels were placed |
| `IN_B0_*.csv`, `IN_PS70_*.csv` | in-sample VSS/EVPI diagnostics, training costs, commitments, feasibility |
| `IN_notes.md` | notes on the in-sample value computation |
| `BOOT_B0_v3.csv`, `BOOT_PS70_v3.csv` | paired bootstrap of the out-of-sample saving per configuration |
| `BOOT_block_v3.csv` | moving-block bootstrap (block length 7 days) |
| `BOOT_significance_v3.csv` | point estimates, intervals, Wilcoxon p-values, positive-day counts |
| `V3_BAND_summary.csv`, `V3_BAND_scan.csv` | certified caliber band: per-axis cells and the full scan |
| `V3_AXIS5_scan.csv` | the two extra axes (K/A/p̲ sweep and data-provenance arms) |
| `PWL_E28_ps50/60/70.csv`, `_scen.csv` | piecewise-linear Weymouth maximum/mean flow error per pressure |
| `PWL_E28_summary.csv`, `PWL_E29_accuracy.csv`, `PWL_E28_anchor_check.csv`, `PWL_BOOT_notes.md` | accuracy summary, spacing comparison, anchor check, notes |
| `V3_MESH_topology*.csv`, `V3_MESH_M_PS*.csv`, `V3_MESH_cells*.csv`, `V3_MESH_verdict.csv` | meshed core: topology, per-pressure directions and gas metrics, cells, verdict |
| `V3_MESH_PROBE_*.csv`, `V3_MESH_PROBE_*.log` | meshed feasibility probes, pressure-entry maps, solver logs |
| `V3_MESH_regression*.csv`, `V3_MESH_*.log` | mesh regression gate and captured logs |
| `V3_MESH_PS70_floorretry.log` | retry log for the meshed carbon floor at 70 bar |
| `heat_real_vs_syn.csv` | synthetic vs measured heat series |
| `audit_v3_check.csv` | output of `audit_v3.py` on the final state |

## datasets/ — input data used, with provenance

`data_manifest.md` is the ledger: where every input series came from, how it was aggregated and
normalised, and what the completeness checks found.

| File | Purpose | Licence |
|---|---|---|
| `heat_dma_2019_hourly.csv` | measured district-heating series for the heat-load sensitivity | Zenodo 17398331, **CC BY 4.0** (attribution required) |
| `mesh_source/GasLib-11/**`, `GasLib-11.zip`, `GasLib-11_parser_LICENSE_MIT.txt` | the meshed benchmark instance and its parser licence | instance **CC BY 3.0**, parser **MIT**; only the graph is used |
| `mee_2019_grid_baseline_ef.pdf` | official grid baseline emission factor (MEE 2019) | public official document |
| `data_manifest.md` | the data ledger: provenance, aggregation and normalisation of every input series | documentation |
| `load_completeness_diag.csv`, `load_typical_day_compare.csv`, `load_shape_compare_metrics.csv` | completeness and shape diagnostics of the load reconstruction | derived |
| `wind_pv_pairing_metrics.csv` | wind-PV pairing metrics behind the scenario calibration | derived |
| `power_coefficients_heating.csv`, `power_coefficients_cooling.csv`, `power_coeff_heating_gansu_jiangsu_2019.csv` | temperature-to-heat power coefficients | derived |
| `heat_real_vs_syn.csv` | synthetic vs measured heat load (the table reported in the manuscript) | derived |
| `PWL_E28_anchor_check.csv` | anchor check for the piecewise-linear interpolation | derived |
| `quanzhou_temp_2016_2018_hourly.csv`, `quanzhou_temp_diag.csv` | third-party temperature/load series, sensitivity check only | third-party |
| `turkey_loader_check.csv` | loader self-check artifact | derived |

### Not redistributed - obtain these to run the full pipeline

Four input series are **not** in this repository because their terms do not permit redistribution. They
are listed with the exact expected filenames in `datasets/INPUT_DATA_REQUIRED.csv`:

| Required file (place under `results/`) | What it is | Why it is not here |
|---|---|---|
| `gansu_wind_2019_hourly.csv` | measured wind power, Gansu 2019, hourly | third-party compilation; the manuscript states it is **available from the corresponding author**, not redistributed |
| `gansu_pv_2019_mw.csv` | measured PV power, Gansu 2019, hourly | as above |
| `load_gansu_2019_hourly.csv` | reconstructed hourly load, Gansu 2019 | *Scientific Data* doi:10.1038/s41597-026-07327-8, **CC BY-NC-ND 4.0** (derived series) |
| `load_jiangsu_2019_hourly.csv` | reconstructed hourly load, Jiangsu 2019 | as above |

`datasets/README.md` gives the provenance of each series and how to obtain it. A run whose inputs are
incomplete fails its loader rather than substituting synthetic data.


## Verification

`MANIFEST_sha256.csv` lists every file with its size and SHA-256:

```bash
python - <<'PY'
import csv, hashlib, os
bad = 0
for row in csv.DictReader(open('MANIFEST_sha256.csv')):
    p = row['path']
    if not os.path.exists(p):
        print('missing', p); bad += 1; continue
    if hashlib.sha256(open(p, 'rb').read()).hexdigest() != row['sha256']:
        print('checksum mismatch', p); bad += 1
print('problems:', bad)
PY
```

## Running the code

Requires Python 3 with `numpy`, `pandas` and the Gurobi Python interface (the reported solves use
Gurobi; the mixed-integer programs are built directly rather than through a modelling layer). Seeds are
in `code/config_v3.py`; every archived file records solver status, MIP gap and runtime so a re-run can
be compared field by field. Example drivers: `gc_run_v3.py` (source-pressure scan), `eps_driver.py`
(frontier), `in_sample_value_v3.py`, `boot_v3.py`, `band_scan_v3.py`.

## Licence

Code and archived results: see `LICENSE` (MIT). Redistributed data keep their own licences, restated
above and in `datasets/data_manifest.md`.
