# IN_*：样本内价值度量（VSS/EVPI 不等式验证）+ 训练场景成本矩阵 + 共同可行集验证

日期：2026-09-22。脚本：`code_v3/in_sample_value_v3.py`（只新增，未改任何既有模型/运行器文件）。
目的：论文要报 VSS，而理论不等式 `0 ≤ VSS ≤ EVPI` 只在**样本内**（优化集 = 评估集）成立；
样本外（100 测试日）不保证成立（v2 臂 VSS=516.32 > EVPI=435.36 即源于此）。
本实验在 **8 个 k-means 训练场景**（优化所用的同一场景集）上补齐样本内验证。

## 1. 协议与参数（与 gc_run_v3.py / 既有 OOS 协议逐项一致）

- 数据臂：`V3_ARM=main`（甘肃风 + 甘肃光同省配对 + 甘肃重建负荷形状）；
  `E_GRID_MODE=official_om_nw`（E_GRID = 0.8922 tCO2/MWh）。
- 场景库：`data_v3.prepare()`，seed=42 做 265/100 训练/测试划分，k-means k=8（seed=0, n_init=10）。
  8 训练场景概率 = 簇内训练日占比：
  π = [0.132075, 0.158491, 0.120755, 0.052830, 0.116981, 0.158491, 0.147170, 0.113208]（Σ=1，非均匀）。
  代表日（s=0..7）：2019-02-20 / 10-30 / 08-28 / 11-23 / 01-26 / 04-06 / 09-16 / 10-26。
- EEV 模型场景：`DP.expected_scenario()`（265 训练日均值曲线，既有口径，未改）。
- c_s(u) 的评估协议：把承诺 u 以 `u_fix` 固定（**只固定 u**，y 与第二阶段变量对场景 s 重新
  优化），单场景求 `mode='cost'`，c_s = op_cost + startup。与 gc_run_v3 的 OOS 逐日评估口径
  完全一致。
- 期望的主口径 = 按 8 场景概率 π 加权（与 RP 的目标测度同一概率空间）；另报 1/8 等权版作对照。
- Gurobi 13.0.3，MIPGap=1e-4、TimeLimit=600s（config_v3 默认，**未调任何求解参数**）。
- 每档独立进程：`b0`（gas_coupled=False）与 `ps70`（gas_coupled=True, ps=ps2=70）分两次调用。

## 2. 三个量的定义（样本内）

- **RP_train** = u_hep（两阶段随机最优解）的 c_s(u) 按概率加权的期望。
  交叉校验：与 RP 模型目标值 `rp_exp_cost` 的相对差 = 2.1e-16（B0）/ 2.0e-9（PS70），
  即 u_fix 评估协议与 RP 优化完全对称（启动成本口径一致）。
- **EEV_train** = u_eev（确定性期望值模型解）的 c_s(u) 按概率加权的期望。
- **WS_train** = Σ_s π_s · c*_s，c*_s = 场景 s 单独优化（完美信息）的最优成本。
  **是概率加权期望，不是 max**（初版脚本汇总时字段错位曾把"最坏场景成本"写进 ws_train_prob，
  已修正；逐场景求解本身从来都是对的，见 train_costs 文件）。
- VSS_train = EEV_train − RP_train；EVPI_train = RP_train − WS_train。
- 判据：`VSS_train ≥ 0`、`EVPI_train ≥ 0`、`VSS_train ≤ EVPI_train`。
  理论保证：RP 是该概率测度下最优策略的期望成本，任何其他承诺（含 u_eev）评估值 ≥ RP_train；
  WS 逐场景下界。两侧测度一致（同一 π、同一 u_fix 评估协议、同一场景集）。

## 3. 结果

### 3.1 B0 臂（无气网耦合，与论文 VSS 主口径同臂）— `IN_B0_in_sample_summary.csv`

| 量 | 概率加权（主口径） | 1/8 等权（对照） |
|---|---|---|
| RP_train | 33933.33 元 | 33203.41 元 |
| EEV_train | 34058.32 元 | 33348.07 元 |
| WS_train | 33431.21 元 | 32616.44 元 |
| **VSS_train** | **124.99 元** | 144.66 元 |
| **EVPI_train** | **502.12 元** | 586.97 元 |

**判据：0 ≤ 124.99 ≤ 502.12，成立**（等权对照口径同样成立）。
锚点：RP 目标值逐位复现 `V3_GC_B0_main_summary.csv` 的 rp_exp_cost=33933.32765119941（rel 0）。

### 3.2 PS70 臂（Weymouth 气网耦合，ps=ps2=70 bar）— `IN_PS70_in_sample_summary.csv`

| 量 | 概率加权（主口径） | 1/8 等权（对照） |
|---|---|---|
| RP_train | 34122.46 元 | 33385.71 元 |
| EEV_train | 34210.95 元 | 33489.04 元 |
| WS_train | 33526.21 元 | 32707.70 元 |
| **VSS_train** | **88.49 元** | 103.33 元 |
| **EVPI_train** | **596.25 元** | 678.01 元 |

**判据：0 ≤ 88.49 ≤ 596.25，成立**。锚点：rp_exp_cost=34122.45845808811、
CVaR 臂期望成本 34251.02415374644 均逐位复现（rel 0）。RP MIPGap=2.0e-7，CVaR MIPGap=0。

### 3.3 训练场景成本矩阵 c_s(u)（PS70，元）— `IN_PS70_cost_matrix_wide.csv` / `IN_PS70_cost_matrix.csv`

| 承诺 \ s | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| u_hep | 15529.16 | 42027.96 | 44019.99 | 25779.34 | 31520.98 | 26509.09 | 46966.50 | 34732.70 |
| u_eev | 16570.94 | 42023.32 | 43821.19 | 26003.46 | 31827.74 | 26411.64 | 46782.56 | 34471.47 |
| u_cvar | 17356.93 | 41573.74 | 43844.25 | 26611.68 | 31409.65 | 26770.61 | 46534.91 | 34480.87 |

μ/ρ 汇总（μ=概率加权均值；ρ=最坏场景成本与 std。注：8 场景下经验 CVaR95/CVaR90 的
top-k 截断 k=1，均退化为最坏场景成本，故此处 ρ 以 worst_s 为准）：

| 承诺 | μ（概率加权） | μ（等权） | std | worst_s |
|---|---|---|---|---|
| u_hep | 34122.46 | 33385.71 | 10009.41 | 46966.50 |
| u_eev | 34210.95 | 33489.04 | 9697.78 | 46782.56 |
| u_cvar | 34251.02 | 33572.83 | 9358.95 | 46534.91 |

两两差值（`IN_PS70_cost_deltas.csv`）：
- Δμ(u_cvar−u_hep) = **+128.57** 元，Δρ(u_cvar−u_hep) = **−431.58** 元（worst_s）；
- Δμ(u_eev−u_hep) = +88.49 元，Δρ = −183.94 元；
- Δμ(u_cvar−u_eev) = +40.07 元，Δρ = −247.64 元。

**判读**：v3 臂下风险厌恶（λ=0.8, β=0.95）的行为是"用期望换尾部"——μ 升 128.57 元/日
（+0.38%），最坏场景成本降 431.58 元/日，std 降 650 元。风险厌恶确有区别于风险中性与 EEV
的独立行为，且方向符合 CVaR 语义。

### 3.4 共同可行集验证 — `IN_PS70_feasibility.csv`

三个承诺 u_hep / u_eev / u_cvar 逐一代入 **同一** ps=ps2=70 bar 的 Weymouth 耦合模型二阶段
问题，在 8 训练场景逐一 u_fix 求解：**24/24 全部可行**（status=2 OPTIMAL，无失负荷
shed=0）。同一场景定义（`data_v3.prepare` 的 8 代表日 + 共享 p_load/h_load/price）、同一
ps/ps2、同一 u_fix 协议，故三承诺落在**同一可行集**内。气网侧证据：p1∈[20, 70] bar、
p2∈[69.5, 70] bar、f1 ≤ 4.1515 MW 上界（部分小时触顶），与 `V3_GC_PS70_main_gas.csv`
的 OOS 观测一致。

## 4. 样本内 vs 样本外对照（为何不同）

| 量 | 样本内（8 训练场景, B0） | 样本外（100 测试日, B0, V3_GC_B0_main_summary.csv） |
|---|---|---|
| SP/RP | 33933.33 | 33417.34 |
| EEV | 34058.32 | 33800.75 |
| WS | 33431.21 | 32571.03 |
| VSS | **124.99** | 383.41 |
| EVPI | **502.12** | 1229.72 |

样本内不等式成立（124.99 ≤ 502.12），样本外 VSS(383.41) < EVPI(1229.72) 也成立，但样本外
不保证成立（v2 臂曾出现 VSS > EVPI）。两者数值不同的原因：训练 8 场景（k-means 代表日 +
簇概率）与 100 测试日是**不同的分布实现**——RP/EEV 在 8 场景上优化，其"训练分布"比测试年
的 100 天更平滑（代表日聚类抹掉了尾部天气日），故样本外三个量整体更低（测试日成本更低）
而 VSS/EVPI 更大；样本外 EEV 相对 SP 的劣势被训练分布未覆盖的天气实现放大。**结论：VSS
的理论不等式只能在样本内验证，样本外只能报"带区间的成本差"（点估计 + 不确定区间），不能
声称满足 0 ≤ VSS ≤ EVPI。**

## 5. 复现途径

```
cd code_v3
V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe in_sample_value_v3.py b0    # 进程 1
V3_ARM=main E_GRID_MODE=official_om_nw Y:/cuda/python.exe in_sample_value_v3.py ps70  # 进程 2
```

输出文件（均在 `code_v3/results/`）：
- `IN_B0_in_sample_summary.csv`：B0 样本内三量 + VSS/EVPI + 判据（每个 metric 附 desc 列，
  写明"哪个承诺、哪个权重、哪个场景集"）。
- `IN_B0_train_costs.csv`：B0 逐场景 c_s（u_hep/u_eev/ws_perfect × 8 场景，含可行性、
  MIPGap、启动次数）。
- `IN_B0_u_commitments.csv`：B0 的 u_hep/u_eev（24h，二者在 h8/h17 不同）。
- `IN_PS70_in_sample_summary.csv` / `IN_PS70_train_costs.csv` / `IN_PS70_u_commitments.csv`：同上，PS70 版。
- `IN_PS70_cost_matrix_wide.csv`：3×8 成本矩阵；`IN_PS70_cost_matrix.csv`：μ/ρ 汇总；
  `IN_PS70_cost_deltas.csv`：两两 Δμ/Δρ。
- `IN_PS70_feasibility.csv`：共同可行集验证逐条记录（24 行，全 feasible）。

注：本目录初版汇总表曾有字段错位（eev_train/ws_train_prob 取错行，导致不等式误判为不成立）
与差值列标量广播两处 bug，均已修正并全量重跑；最终数字以本 notes 与当前 CSV 为准。
